"""Advisory correlation: what published guidance would look at first.

A posture read produces facts - this header is absent, that value is weak, the
certificate expires in nine days. On its own each fact is a sentence in a table.
What a reader wants next is *why that matters*, and that is public, dated,
citable knowledge: the header recommendations, the TLS guidance, the release
notes of the software the service names.

This module holds that knowledge as **data** (``config/advisories.yaml``) and
correlates it against the signals a run already recorded. Three rules keep it
honest:

* **A match is a lead, never a finding.** ``Lead`` is a different type from a
  confirmed claim on purpose. The product's rule is that a finding needs a
  completed observation behind it; "a missing HSTS header correlates with this
  advisory" is a prompt for a human to look, and is labelled as one everywhere
  it is printed.
* **Matching is on structured signals only.** No advisory is matched against a
  sentence the model wrote, and none is matched against raw tool output: the
  keys are the facts ``agent/mission_state._signals`` extracted, and an unknown
  key is a refusal at load time rather than a silent non-match.
* **The catalogue is dated and fails closed.** Every entry states when it was
  reviewed and what it is based on. A malformed entry - an unknown severity, a
  match key nobody implements, a regex that does not compile, a duplicate id -
  stops the load with a sentence naming the entry, so a typo cannot quietly
  remove advice from a report.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

import yaml

from config.settings import CONFIG_DIR
from tools.parsers import SEVERITIES

__all__ = [
    "CATALOGUE_PATH",
    "MATCH_KEYS",
    "AdvisoriesError",
    "Advisory",
    "Lead",
    "leads_for",
    "load_advisories",
]

#: Where the shipped catalogue lives. An install copies it with the rest of
#: ``config/``; a missing file is reported, never guessed around.
CATALOGUE_PATH: Path = CONFIG_DIR / "advisories.yaml"

#: The only keys a ``match:`` block may use. Each one is a fact some adapter
#: actually records, so a key here is a promise that a signal exists for it.
MATCH_KEYS: frozenset[str] = frozenset(
    {
        "capability",
        "missing_header",
        "weak_header",
        "tls_version",
        "tls_verified",
        "tls_days_left_max",
        "tls_expired",
        "server_pattern",
    }
)

#: Ascending index, as ``SEVERITIES`` orders them: info first, critical last.
_SEVERITY_RANK: dict[str, int] = {
    severity: index for index, severity in enumerate(SEVERITIES)
}


class AdvisoriesError(ValueError):
    """The catalogue cannot be used as written. Never silently tolerated."""


@dataclass(frozen=True)
class Lead:
    """A fact that correlates with published guidance. Not a finding.

    Args:
        advisory_id: the catalogue entry's id.
        title: what the guidance is about, in one line.
        severity: the advisory's own severity, not a score of this target.
        why: why this target's facts pulled the advisory in.
        capability: the run whose signals matched.
        target: the target that run addressed.
        evidence_seq: the audit entry that carries the observation.
        reviewed: the date the catalogue entry was last checked.
        source: where the guidance comes from, for a reader to check.
    """

    advisory_id: str
    title: str
    why: str
    severity: str = "info"
    capability: str = ""
    target: str = ""
    evidence_seq: int = 0
    reviewed: str = ""
    source: str = ""

    @property
    def rank(self) -> int:
        return _SEVERITY_RANK.get(self.severity, len(_SEVERITY_RANK))

    def line(self) -> str:
        where = f" on {self.target}" if self.target else ""
        return (
            f"lead     [{self.severity}] {self.title}{where} - {self.why} "
            f"(advisory {self.advisory_id}, reviewed {self.reviewed}; "
            f"evidence {self.evidence_seq})"
        )

    def describe(self) -> dict[str, Any]:
        return {
            "advisory_id": self.advisory_id,
            "title": self.title,
            "why": self.why,
            "severity": self.severity,
            "capability": self.capability,
            "target": self.target,
            "evidence_seq": self.evidence_seq,
            "reviewed": self.reviewed,
            "source": self.source,
            # Stated in the data, so no reader of the JSON can promote it.
            "is_finding": False,
        }


@dataclass(frozen=True)
class Advisory:
    """One dated entry: what it says, and which facts pull it in."""

    id: str
    title: str
    severity: str
    reviewed: str
    source: str = ""
    rationale: str = ""
    match: Mapping[str, Any] = field(default_factory=dict)

    # ------------------------------------------------------------- matching
    def matches(self, signals: Mapping[str, Any]) -> tuple[str, ...]:
        """The reasons this advisory applies, or an empty tuple.

        Every clause must hold: a ``match`` block is a conjunction, so an entry
        that names a header *and* a TLS condition only fires when both were
        observed. The reasons are returned rather than a boolean because the
        report has to say *why* the reader is being sent to the advisory.
        """
        reasons: list[str] = []
        for key, expected in self.match.items():
            if key == "server_pattern":
                server = str(signals.get("server") or "")
                if not server or not re.search(str(expected), server, re.IGNORECASE):
                    return ()
                reasons.append(f"the server banner reads {server!r}")
                continue
            if key in {"missing_header", "weak_header"}:
                bucket = (
                    "missing_headers" if key == "missing_header" else "weak_headers"
                )
                if str(expected) not in tuple(signals.get(bucket) or ()):
                    return ()
                reasons.append(f"{expected}: {_reason(key, expected)}")
                continue
            actual = signals.get(key)
            if key == "tls_days_left_max":
                if actual is None or int(actual) > int(expected):
                    return ()
                reasons.append(f"{int(actual)} day(s) remain on the certificate")
                continue
            if isinstance(expected, (list, tuple)):
                if actual not in tuple(expected):
                    return ()
            elif actual != expected:
                return ()
            reasons.append(_reason(key, actual))
        return tuple(reasons)

    def lead(self, reasons: Sequence[str], evidence: Any) -> Lead:
        return Lead(
            advisory_id=self.id,
            title=self.title,
            why="; ".join(reasons) or self.title,
            severity=self.severity,
            capability=str(getattr(evidence, "capability", "")),
            target=str(getattr(evidence, "target", "")),
            evidence_seq=int(getattr(evidence, "seq", 0) or 0),
            reviewed=self.reviewed,
            source=self.source,
        )


def _actual(key: str, signals: Mapping[str, Any]) -> Any:
    """One signal, normalised so a header name and a version compare by value."""
    if key in {"missing_header", "weak_header"}:
        bucket = "missing_headers" if key == "missing_header" else "weak_headers"
        wanted = signals.get(bucket) or ()
        return wanted
    return signals.get(key)


def _reason(key: str, actual: Any) -> str:
    if key == "missing_header":
        return "the recommended header is absent"
    if key == "weak_header":
        return "the header is present but weaker than its recommendation"
    if key == "tls_version":
        return f"the handshake negotiated {actual}"
    if key == "tls_verified":
        return "the certificate verified" if actual else "the certificate did not verify"
    if key == "tls_expired":
        return "the certificate has expired" if actual else "the certificate is in date"
    if key == "capability":
        return f"observed by {actual}"
    return f"{key}: {actual}"


# --------------------------------------------------------------------- loading
_DATE = re.compile(r"^\d{4}-\d{2}-\d{2}$")


def _entry(raw: Any, where: str) -> Advisory:
    """One catalogue entry, validated. Every failure names the entry."""
    if not isinstance(raw, Mapping):
        raise AdvisoriesError(f"{where} is not a mapping")
    identifier = str(raw.get("id") or "").strip()
    if not identifier:
        raise AdvisoriesError(f"{where} has no id")
    where = f"advisory {identifier!r}"
    for required in ("title", "severity", "reviewed"):
        if not str(raw.get(required) or "").strip():
            raise AdvisoriesError(f"{where} has no {required}")
    severity = str(raw["severity"]).strip().lower()
    if severity not in SEVERITIES or severity == "unknown":
        raise AdvisoriesError(
            f"{where} has severity {raw['severity']!r}; use one of "
            f"{', '.join(item for item in SEVERITIES if item != 'unknown')}"
        )
    reviewed = str(raw["reviewed"]).strip()
    if not _DATE.match(reviewed):
        raise AdvisoriesError(
            f"{where} is dated {reviewed!r}; a review date is YYYY-MM-DD, "
            "because a reader has to be able to judge how old the advice is"
        )
    match = raw.get("match")
    if not isinstance(match, Mapping) or not match:
        raise AdvisoriesError(f"{where} has no match block")
    unknown = sorted(str(key) for key in match if str(key) not in MATCH_KEYS)
    if unknown:
        raise AdvisoriesError(
            f"{where} matches on {unknown}, which no adapter records. The "
            f"catalogue may use: {', '.join(sorted(MATCH_KEYS))}"
        )
    if "server_pattern" in match:
        try:
            re.compile(str(match["server_pattern"]))
        except re.error as trouble:
            raise AdvisoriesError(
                f"{where} has a server_pattern that does not compile: {trouble}"
            ) from None
    return Advisory(
        id=identifier,
        title=str(raw["title"]).strip(),
        severity=severity,
        reviewed=reviewed,
        source=str(raw.get("source") or "").strip(),
        rationale=" ".join(str(raw.get("why") or "").split()),
        match={str(key): value for key, value in match.items()},
    )


def load_advisories(path: str | Path | None = None) -> tuple[Advisory, ...]:
    """Read the catalogue. A malformed entry is an error, never a dropped row."""
    source_path = Path(path) if path is not None else CATALOGUE_PATH
    if not source_path.is_file():
        raise AdvisoriesError(
            f"the advisory catalogue is missing: {source_path}. Without it the "
            "report cannot say which guidance a fact relates to, and it must "
            "not invent one."
        )
    try:
        payload = yaml.safe_load(source_path.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError as trouble:
        raise AdvisoriesError(
            f"{source_path.name} is not valid YAML: {trouble}"
        ) from None
    if not isinstance(payload, Mapping):
        raise AdvisoriesError(f"{source_path.name} must contain a mapping")
    entries = payload.get("advisories")
    if not isinstance(entries, list) or not entries:
        raise AdvisoriesError(f"{source_path.name} lists no advisories")

    catalogue: list[Advisory] = []
    seen: set[str] = set()
    for index, raw in enumerate(entries, start=1):
        entry = _entry(raw, f"{source_path.name} entry {index}")
        if entry.id in seen:
            raise AdvisoriesError(
                f"{source_path.name} lists advisory {entry.id!r} twice; one id "
                "must mean one piece of advice"
            )
        seen.add(entry.id)
        catalogue.append(entry)
    return tuple(catalogue)


# ------------------------------------------------------------------ correlation
def leads_for(
    evidence: Iterable[Any],
    catalogue: Sequence[Advisory] | None = None,
) -> tuple[Lead, ...]:
    """Correlate recorded evidence with the catalogue. Leads, most severe first.

    An evidence row with no signals (a skipped run, an unparsable answer) is
    skipped: correlation needs facts, and inventing an empty fact set would
    make every "Header absent" entry fire on every failed run.
    """
    advisories = tuple(catalogue) if catalogue is not None else load_advisories()
    found: list[Lead] = []
    seen: set[tuple[str, str, int]] = set()
    for row in evidence:
        signals = getattr(row, "signals", None) or {}
        if not signals:
            continue
        capability = str(getattr(row, "capability", "") or "")
        # The capability is a fact about the run, not about the target, so it is
        # folded in here rather than trusted to be inside the signal map.
        facts = dict(signals)
        facts.setdefault("capability", capability)
        for advisory in advisories:
            expected = advisory.match.get("capability")
            if expected is not None and expected != capability:
                continue
            reasons = advisory.matches(facts)
            if not reasons:
                continue
            lead = advisory.lead(reasons, row)
            key = (lead.advisory_id, lead.target, lead.evidence_seq)
            if key in seen:
                continue
            seen.add(key)
            found.append(lead)
    # ``rank`` ascends with severity (info = 0), so the negation puts the most
    # severe first; the id and the sequence make the order stable between runs.
    found.sort(key=lambda lead: (-lead.rank, lead.advisory_id, lead.evidence_seq))
    return tuple(found)


