"""The lab's own write-ups, as a small versioned corpus of evidence cases.

The planner is told to separate what a tool showed from what the model
concluded. A prompt cannot demonstrate that, and three cases are far too few to
train on. So they are used for the two things they can carry:

* **retrieval** - :func:`relevant_to` hands back the one or two cases that bear
  on an objective, as bounded text, instead of a permanent block in the system
  prompt that every scan pays for;
* **evaluation** - :mod:`agent.research_eval` scores an answer against the same
  fields, and each case below is a fixture with a known right answer.

What this module deliberately is not:

* **A vulnerability taxonomy.** Three defects in three libraries say nothing
  about what any target is likely to contain, and nothing here builds a
  checklist from them. The planner still chooses from capability metadata and
  observed evidence.
* **A training set.** Three cases cannot fine-tune a model, and the licensing,
  privacy, representativeness and train/eval-leakage questions a training corpus
  raises are not answered by a file of case studies. ``provenance`` records what
  each claim rests on instead, and every case is first-party work.
* **A claim about a new target.** A case here is about the package it names, at
  the version it names, and its ``limitations`` say what the reproduction did
  not cover.

The facts are the ones the write-ups publish. The compatibility case is
classified as compatibility and availability, not as a security vulnerability:
the fit aborts, no model with less noise is returned, and the write-up says so.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

__all__ = [
    "CASES",
    "COMPATIBILITY",
    "CORPUS_VERSION",
    "LOCAL",
    "PRIVACY_GUARANTEE",
    "ROBUSTNESS",
    "SECURITY_IMPACTS",
    "SUITE_REPORTED",
    "ResearchCase",
    "brief",
    "by_slug",
    "relevant_to",
    "render",
    "validate",
]

#: Bumped when a case's facts, classification or provenance change. A prompt or
#: an evaluation run that quotes a version is reproducible against this number.
CORPUS_VERSION = 1

#: Impact classes. The first two are guarantees a library makes to its callers;
#: the third is a dependency boundary that breaks a workflow without weakening
#: anything, and it is kept separate on purpose.
PRIVACY_GUARANTEE = "weakened privacy guarantee"
ROBUSTNESS = "robustness on untrusted input"
COMPATIBILITY = "dependency compatibility and availability"

#: The classes that would be a security vulnerability if claimed. A compatibility
#: finding promoted into this set is the overclaim the write-up rules out, so the
#: guard reads from here rather than restating the list.
SECURITY_IMPACTS = (PRIVACY_GUARANTEE, ROBUSTNESS)

#: Provenance, in the terms a report has to be able to print.
LOCAL = "reproduced locally"
SUITE_REPORTED = "test-suite result reported by the upstream contributor"


@dataclass(frozen=True)
class ResearchCase:
    """One published case, in the fields a report is required to fill.

    ``claim`` is the single sentence the case supports. It is admissible at
    ``status`` only: ``confirmed`` where the reproduction is local, and
    ``unverified`` where the only evidence is a result the contributor reported
    and this lab did not rerun.
    """

    slug: str
    title: str
    claim: str
    component: str
    version: str
    symptom: str
    reproduction: str
    root_cause: str
    fix: str
    #: The token a minimal remediation names, and the evaluation checks for.
    fix_anchor: str
    regression_test: str
    impact_class: str
    provenance: str
    status: str
    #: Where the case can be read: the write-up folder and the upstream thread.
    source: str
    references: tuple[str, ...]
    limitations: str

    @property
    def locally_reproduced(self) -> bool:
        return self.provenance == LOCAL


CASES: tuple[ResearchCase, ...] = (
    ResearchCase(
        slug="diffprivlib-linear-regression-sensitivity",
        title="diffprivlib silently drops the noise for a diagonal coefficient",
        claim=(
            "LinearRegression calibrated the diagonal sensitivity from the lower "
            "bound twice, so with a lower bound of zero the sensitivity was 0.0 "
            "and the privacy noise for that coefficient was effectively absent."
        ),
        component="diffprivlib (IBM differential-privacy-library), LinearRegression",
        version="0.6.6 - the version named in the upstream issue",
        symptom=(
            "No visible failure: the model trained and its output looked "
            "plausible. The only observable was the sensitivity handed to "
            "LaplaceFolded, which came back as 0.0 for bounds of 0 to 100."
        ),
        reproduction=(
            "Installed the released 0.6.6 and called _construct_regression_obj "
            "directly with bounds_X=(0, 100); the diagonal sensitivity was 0.0 "
            "where 10000.0 is correct."
        ),
        root_cause=(
            "The diagonal term read np.abs([bounds_X[0][i], bounds_X[0][i]]) and "
            "so paired the lower bound with itself, never using bounds_X[1]. The "
            "off-diagonal case and the bounds_y term beside it already paired "
            "lower with upper, which is what marked this as a copy error."
        ),
        fix="Pair the lower and upper bound: bounds_X[0][i] becomes bounds_X[1][i].",
        fix_anchor="bounds_X[1][i]",
        regression_test=(
            "test_diagonal_sensitivity_uses_both_bounds records the sensitivity "
            "passed to LaplaceFolded; it fails on the old code and passes on the "
            "fix, and the 13 existing LinearRegression tests still pass."
        ),
        impact_class=PRIVACY_GUARANTEE,
        provenance=LOCAL,
        status="confirmed",
        source="writeups/2026-10-upstream-contributions/README.md, case 1",
        references=("#105", "#110"),
        limitations=(
            "One coefficient's calibration path in one released version. It does "
            "not establish how often other calibrations mispair bounds, and it "
            "says nothing about a model that has not been trained with it."
        ),
    ),
    ResearchCase(
        slug="cpython-tarfile-codec-exceptions",
        title="tarfile lets raw codec exceptions escape its documented error type",
        claim=(
            "Corrupted compressed members in seekable mode surfaced as zlib.error, "
            "OSError and lzma.LZMAError instead of tarfile.ReadError, so a caller "
            "catching the documented exception missed them."
        ),
        component="CPython standard library, tarfile (_FileInFile.read)",
        version="CPython main at the time of the report (gh-156057)",
        symptom=(
            "Opening a corrupt archive succeeded; the damage appeared only during "
            "extractfile(), as a codec-specific exception."
        ),
        reproduction=(
            "Built archives corrupted after the header and read them back on "
            "current main: gzip, bzip2 and xz each leaked their own exception. "
            "zstd could not be tested because the build lacked compression.zstd."
        ),
        root_cause=(
            "The seekable path called the underlying file object with no exception "
            "handling, while the streaming path already wrapped codec errors via a "
            "per-codec exception attribute on _Stream. The same failure was "
            "handled two different ways."
        ),
        fix=(
            "Give TarFile and _FileInFile the same per-codec exception attribute "
            "and re-raise as tarfile.ReadError in _FileInFile.read()."
        ),
        fix_anchor="ReadError",
        regression_test=(
            "Unit tests on _FileInFile.read(), including one that an unconfigured "
            "exception type still propagates, plus an integration test through "
            "gzopen(); all fail before the fix and pass after."
        ),
        impact_class=ROBUSTNESS,
        provenance=LOCAL,
        status="confirmed",
        source="writeups/2026-10-upstream-contributions/README.md, case 2",
        references=("gh-156057", "gh-156143"),
        limitations=(
            "Robustness only: the write-up does not claim memory corruption or "
            "code execution and neither does this case. zstd was not exercised."
        ),
    ),
    ResearchCase(
        slug="diffprivlib-scipy-iprint-compatibility",
        title="diffprivlib logistic regression passes a keyword SciPy removed",
        claim=(
            "Logistic regression raised TypeError on SciPy 1.18.1 because it still "
            "passed iprint to scipy.optimize.fmin_l_bfgs_b, which no longer accepts "
            "it; the fit aborts rather than returning a weaker model."
        ),
        component="diffprivlib, LogisticRegression on scipy.optimize.fmin_l_bfgs_b",
        version="SciPy 1.18.1, reproduced against the merged fix (PR #113)",
        symptom=(
            "TypeError: fmin_l_bfgs_b() got an unexpected keyword argument "
            "'iprint', raised at the optimizer call when fitting."
        ),
        reproduction=(
            "The included script calls the optimizer both ways on SciPy 1.18.1: it "
            "raises with iprint and converges without it (x=[0.0], value 0.0, "
            "warnflag 0)."
        ),
        root_cause=(
            "The module mapped verbose to iprint and passed it after SciPy had "
            "documented iprint as deprecated and nonfunctional and scheduled its "
            "removal for 1.18."
        ),
        fix=(
            "Remove the verbose-to-iprint mapping and drop the keyword; the noisy "
            "objective, its arguments, regularization and convergence settings are "
            "unchanged."
        ),
        fix_anchor="iprint",
        regression_test=(
            "The PR reports that tests/models/test_LogisticRegression.py passed all "
            "17 tests; that is a test-suite result reported by the upstream "
            "contributor and was not independently rerun here."
        ),
        impact_class=COMPATIBILITY,
        provenance=LOCAL,
        status="confirmed",
        source="writeups/2026-11-scipy-optimizer-compatibility/README.md",
        references=("#113",),
        limitations=(
            "The local reproduction is the dependency-boundary failure and a "
            "minimal optimizer call, not an end-to-end rerun of diffprivlib's "
            "suite. It is a compatibility and availability issue, not an identified "
            "security vulnerability: epsilon, sensitivity, privacy accounting and "
            "the noise mechanism are untouched, and no data was exposed."
        ),
    ),
)
def by_slug(slug: str) -> ResearchCase:
    """The case with this slug, or ``KeyError`` naming the ones that exist."""
    for case in CASES:
        if case.slug == slug:
            return case
    raise KeyError(f"no research case {slug!r}; known: {', '.join(c.slug for c in CASES)}")


def validate() -> None:
    """Check the corpus' invariants. Raises ``ValueError`` rather than returning.

    These are the properties code downstream relies on, so a violated one is a
    broken build, not a warning: unique slugs, a non-empty claim and limitation,
    a remediation anchor, and - the one worth a test of its own - a compatibility
    case that is not filed as a security impact.
    """
    slugs = [case.slug for case in CASES]
    if len(set(slugs)) != len(slugs):
        raise ValueError("two research cases share a slug")
    for case in CASES:
        for field in ("claim", "symptom", "root_cause", "fix", "limitations", "fix_anchor"):
            if not getattr(case, field).strip():
                raise ValueError(f"{case.slug} has an empty {field}")
        if case.status not in ("confirmed", "unverified", "inconclusive"):
            raise ValueError(f"{case.slug} has the status {case.status!r}")
        if case.status == "confirmed" and not case.locally_reproduced:
            raise ValueError(f"{case.slug} is confirmed without a local reproduction")
        if case.impact_class not in SECURITY_IMPACTS + (COMPATIBILITY,):
            raise ValueError(f"{case.slug} uses the unknown impact {case.impact_class!r}")
        if case.slug == "diffprivlib-scipy-iprint-compatibility" and (
            case.impact_class != COMPATIBILITY
        ):
            raise ValueError("the compatibility case must not be filed as a security impact")


#: Words that make an objective look related to a case. Deliberately narrow: a
#: retrieval that matches everything is a permanent prompt block with extra
#: steps, which is the thing this module exists to avoid.
_TERMS: dict[str, tuple[str, ...]] = {
    "diffprivlib-linear-regression-sensitivity": (
        "differential privacy", "diffprivlib", "epsilon", "noise", "privacy budget",
    ),
    "cpython-tarfile-codec-exceptions": (
        "tarfile", "tar archive", "archive", "codec", "extract", "python standard library",
    ),
    "diffprivlib-scipy-iprint-compatibility": (
        "scipy", "dependency", "compatibility", "optimizer",
        "upgrade", "logistic regression",
    ),
}


def relevant_to(objective: str, *, limit: int = 2) -> tuple[ResearchCase, ...]:
    """Cases whose subject appears in the objective, strongest match first.

    A plain term match over the objective text, ordered by how many terms hit and
    capped: the planner gets a hint, not a lecture, and an objective that matches
    nothing gets nothing rather than the whole corpus.
    """
    text = (objective or "").lower()
    scored: list[tuple[int, int, ResearchCase]] = []
    for order, case in enumerate(CASES):
        hits = sum(1 for term in _TERMS.get(case.slug, ()) if term in text)
        if hits:
            scored.append((-hits, order, case))
    scored.sort()
    return tuple(case for _hits, _order, case in scored[: max(1, int(limit))])


def render(case: ResearchCase) -> str:
    """The bounded text the planner is shown for one case.

    Facts only, and the limitation is not optional: a case presented without it
    reads as broader than it is, which is the habit this corpus exists to break.
    """
    return (
        f"- {case.title} [{case.impact_class}; {case.status}; {case.provenance}]\n"
        f"  - claim: {case.claim}\n"
        f"  - fix: {case.fix}\n"
        f"  - limitation: {case.limitations}"
    )


def brief(objective: str) -> str:
    """The retrieval block for a system prompt, or ``""`` when nothing matches."""
    rendered = [render(case) for case in relevant_to(objective)]
    if not rendered:
        return ""
    return (
        "## First-party research that bears on this objective\n\n"
        "Prior work by this lab, retrieved because the objective names the "
        "subject. It is evidence about the named package and version, not a "
        "finding about this target, and not a checklist: use it to judge what a "
        "similar symptom would mean, and cite it only as prior work.\n\n"
        + "\n".join(rendered)
    )



