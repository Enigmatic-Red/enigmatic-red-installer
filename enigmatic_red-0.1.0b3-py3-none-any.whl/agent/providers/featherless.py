"""Featherless AI provider.

Featherless serves open-weight models through an OpenAI-compatible API:
``POST {base_url}/chat/completions`` with ``Authorization: Bearer <key>``,
``tools`` for native function calling, and an SSE stream when ``stream`` is
true. That compatibility is what keeps this file small — it only has to add
retries, model-role resolution and token accounting.

Two roles, two models:

* ``fast``   — triage, tool-argument extraction, summarisation. Many calls,
  low stakes, so bias cheap.
* ``reason`` — exploit planning and verification design. Few calls, high
  stakes, so bias capable.

Model ids are resolved in this order: an explicit override, the environment
(``FEATHERLESS_MODEL_FAST`` / ``FEATHERLESS_MODEL_REASON``), then the
candidate list in ``config/models.yaml``. The candidates in that file are
*unverified*; confirm them with ``python -m agent.providers.featherless
--list-models`` before the first real scan.
"""

from __future__ import annotations

import asyncio
import json
import logging
import random
import time
from collections.abc import AsyncIterator, Iterable, Sequence
from pathlib import Path
from typing import Any

import httpx
import yaml

from agent.providers.base import (
    ChatMessage,
    ChatResult,
    ChatStreamChunk,
    LLMProvider,
    ModelSpec,
    TokenLedger,
    ToolCall,
    ToolSpec,
    Usage,
    host_is_local,
)
from config.settings import Settings, get_settings
from enigmatic_red.llm_router import DEFAULT_MODEL, LLMRouter, route_from_settings
from safety.errors import ProviderError

logger = logging.getLogger(__name__)

__all__ = [
    "RETRYABLE_STATUS",
    "FeatherlessProvider",
    "load_models_config",
    "provider_from_settings",
    "resolve_model_spec",
]

#: Statuses worth another attempt: rate limits and transient server problems.
RETRYABLE_STATUS = frozenset({408, 409, 425, 429, 500, 502, 503, 504})


def load_models_config(path: str | Path | None = None) -> dict[str, Any]:
    """Load ``config/models.yaml``; a missing file is not fatal."""
    target = Path(path) if path else get_settings().models_file
    if not target.exists():
        logger.warning("models config %s not found; relying on env overrides", target)
        return {}
    return yaml.safe_load(target.read_text(encoding="utf-8")) or {}


def resolve_model_spec(
    role: str,
    settings: Settings,
    models_config: dict[str, Any] | None = None,
    *,
    override: str | None = None,
) -> ModelSpec:
    """Pick the model id and generation defaults for ``role``."""
    config = models_config or {}
    roles = config.get("roles") or {}
    role_key = role if role in roles else "fast"
    role_cfg = roles.get(role_key) or {}
    candidates = list(role_cfg.get("candidates") or [])

    if override:
        model_id = override
    elif role == "fast" and settings.featherless_model_fast:
        model_id = settings.featherless_model_fast
    elif role == "reason" and settings.featherless_model_reason:
        model_id = settings.featherless_model_reason
    elif candidates:
        model_id = candidates[0]
    else:
        # No candidate and no pin is not an error any more: BYOK is the
        # default path, so it resolves to the router's default model rather
        # than refusing to start a self-hosted install with no models.yaml.
        model_id = DEFAULT_MODEL

    return ModelSpec(
        id=model_id,
        role=role_key,
        max_tokens=int(role_cfg.get("max_tokens", settings.llm_max_tokens)),
        temperature=float(role_cfg.get("temperature", settings.llm_temperature)),
    )


class FeatherlessProvider(LLMProvider):
    """Async client for the Featherless chat-completions endpoint.

    Args:
        api_key: overrides ``FEATHERLESS_API_KEY``.
        base_url: overrides ``FEATHERLESS_BASE_URL`` (no trailing slash).
        client: inject an :class:`httpx.AsyncClient`. Tests pass one built on
            ``httpx.MockTransport`` so the suite stays offline.
        ledger: shared :class:`TokenLedger`, so several agent calls can be
            metered against one scan budget.
        model_fast / model_reason: pin model ids, bypassing config lookup.
    """

    name = "featherless"

    def __init__(
        self,
        *,
        api_key: str | None = None,
        base_url: str | None = None,
        settings: Settings | None = None,
        models_config: dict[str, Any] | None = None,
        client: httpx.AsyncClient | None = None,
        timeout: float | None = None,
        max_retries: int | None = None,
        ledger: TokenLedger | None = None,
        model_fast: str | None = None,
        model_reason: str | None = None,
        router: LLMRouter | None = None,
        reasoning_effort: str | None = None,
    ) -> None:
        self._settings = settings or get_settings()
        # BYOK-first: a router, when given, is the authority on endpoint, key
        # and default model. Everything explicit still wins, so an operator can
        # override one field without rebuilding the route.
        self._route = router.route() if router is not None else None
        self._api_key = (
            api_key
            if api_key is not None
            else (
                (self._route.api_key if self._route else "")
                or self._settings.featherless_api_key
            )
        ) or ""
        self._base_url = (
            base_url
            or (self._route.base_url if self._route else "")
            or self._settings.featherless_base_url
        ).rstrip("/")
        self._reasoning_effort = (
            reasoning_effort
            if reasoning_effort is not None
            else (
                (self._route.reasoning_effort if self._route else None)
                or (self._settings.llm_reasoning_effort or None)
            )
        )
        self._timeout = (
            timeout if timeout is not None else self._settings.llm_timeout_s
        )
        self._max_retries = (
            max_retries if max_retries is not None else self._settings.llm_max_retries
        )
        self._models = (
            models_config if models_config is not None else load_models_config()
        )
        self._ledger = ledger or TokenLedger(
            budget=self._settings.llm_scan_token_budget
        )
        route_model = self._route.model if self._route else None
        self._specs: dict[str, ModelSpec] = {
            "fast": resolve_model_spec(
                "fast", self._settings, self._models, override=model_fast or route_model
            ),
            "reason": resolve_model_spec(
                "reason",
                self._settings,
                self._models,
                override=model_reason or route_model,
            ),
        }
        self._owns_client = client is None
        self._client = client or httpx.AsyncClient(
            timeout=self._timeout, headers=self._headers()
        )

    @classmethod
    def from_byok(cls, settings: Settings | None = None, **overrides: Any) -> FeatherlessProvider:
        """Build the provider from the BYOK-first route ``settings`` describes.

        The key comes from the operator (keyring or a private ``.env``), the
        endpoint from ``FEATHERLESS_BASE_URL``, and the model from the pin or
        the router's default. A local Ollama endpoint stays supported: it is
        just one route among three rather than a requirement.
        """
        resolved = settings or get_settings()
        route = route_from_settings(resolved)
        router = overrides.pop("router", None) or LLMRouter(
            provider=route.provider,
            base_url=route.base_url,
            model=route.model,
            api_key=route.api_key,
            reasoning_effort=route.reasoning_effort,
            max_tokens=route.max_tokens,
            temperature=route.temperature,
        )
        return cls(settings=resolved, router=router, **overrides)

    # ----------------------------------------------------------------- setup
    def _headers(self) -> dict[str, str]:
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": "enigmaticred/0.1",
        }
        if self._api_key:
            headers["Authorization"] = f"Bearer {self._api_key}"
        return headers

    def require_key(self) -> str:
        """Refuse to call a *hosted* API without a key, with an actionable message.

        A model on this machine - or on this network - authenticates nobody, and
        the setup scripts point the provider at one, so refusing a keyless call
        there would break the self-hosted build while protecting nothing. The
        key is required exactly where a stranger is on the other end: a public
        endpoint.
        """
        if not self._api_key:
            if host_is_local(self._base_url):
                return ""  # a local model needs no credential
            raise ProviderError(
                "FEATHERLESS_API_KEY is not set, and "
                f"{self._base_url} is remote. Put the key in .env (never in code, "
                "never in git) and restart the process, or point "
                "FEATHERLESS_BASE_URL at a model on this machine, which needs "
                "none."
            )
        return self._api_key

    def spec_for(self, role: str) -> ModelSpec:
        return self._specs.get(role, self._specs["fast"])

    @staticmethod
    def _build_payload(
        messages: Sequence[ChatMessage],
        spec: ModelSpec,
        *,
        tools: Iterable[ToolSpec] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        json_mode: bool = False,
        stream: bool = False,
        reasoning_effort: str | None = None,
    ) -> dict[str, Any]:
        """Assemble the request body. Pure, so tests can assert on it."""
        payload: dict[str, Any] = {
            "model": spec.id,
            "messages": [message.to_openai() for message in messages],
            "temperature": spec.temperature if temperature is None else temperature,
            "max_tokens": spec.max_tokens if max_tokens is None else max_tokens,
        }
        if reasoning_effort:
            # An OpenAI-compatible reasoning model accepts this; a non-reasoning
            # endpoint ignores it, which is why it is only sent when set.
            payload["reasoning_effort"] = reasoning_effort
        tool_list = list(tools or ())
        if tool_list:
            payload["tools"] = [tool.to_openai() for tool in tool_list]
            payload["tool_choice"] = "auto"
        if json_mode:
            payload["response_format"] = {"type": "json_object"}
        if stream:
            payload["stream"] = True
        return payload

    # ------------------------------------------------------------- transport
    async def _post(self, payload: dict[str, Any]) -> dict[str, Any]:
        """POST to /chat/completions with backoff on transient failures."""
        self.require_key()
        url = f"{self._base_url}/chat/completions"
        attempt = 0
        last_error = "no attempt made"

        while True:
            response: httpx.Response | None = None
            try:
                response = await self._client.post(url, json=payload)
            except httpx.HTTPError as exc:
                last_error = f"transport error: {exc.__class__.__name__}: {exc}"
                delay = min(30.0, 2.0**attempt)
            else:
                if response.status_code < 300:
                    try:
                        return response.json()
                    except ValueError as exc:
                        raise ProviderError(
                            f"featherless returned non-JSON body: {exc}"
                        ) from exc

                body = response.text[:600]
                last_error = f"HTTP {response.status_code}: {body}"

                # Some hosted models reject response_format. Degrade once
                # rather than failing the scan: JSON is then parsed from text.
                if (
                    response.status_code == 400
                    and "response_format" in payload
                    and "response_format" in body.lower()
                ):
                    logger.warning(
                        "provider rejected response_format; retrying in text mode"
                    )
                    payload = {
                        key: value
                        for key, value in payload.items()
                        if key != "response_format"
                    }
                    continue

                if response.status_code not in RETRYABLE_STATUS:
                    raise ProviderError(f"featherless request failed: {last_error}")

                retry_after = (response.headers.get("retry-after") or "").strip()
                delay = (
                    float(retry_after)
                    if retry_after.replace(".", "", 1).isdigit()
                    else min(30.0, 2.0**attempt)
                )

            if attempt >= self._max_retries:
                raise ProviderError(
                    f"featherless request failed after {attempt + 1} attempt(s): "
                    f"{last_error}"
                )
            delay = min(30.0, delay) + random.uniform(0.0, 0.3 * max(0.1, delay))
            logger.warning(
                "retrying featherless request in %.1fs (attempt %d): %s",
                delay,
                attempt + 1,
                last_error,
            )
            await asyncio.sleep(delay)
            attempt += 1

    # ------------------------------------------------------------------- chat
    async def chat(
        self,
        messages: Sequence[ChatMessage],
        *,
        tools: Iterable[ToolSpec] | None = None,
        role: str = "fast",
        temperature: float | None = None,
        max_tokens: int | None = None,
        json_mode: bool = False,
    ) -> ChatResult:
        """One completion. Raises :class:`ProviderError` on failure."""
        if self._ledger.exhausted:
            raise ProviderError(
                f"scan token budget exhausted ({self._ledger.used.total_tokens} "
                f"of {self._ledger.budget} tokens); refusing further model calls"
            )
        spec = self.spec_for(role)
        payload = self._build_payload(
            messages,
            spec,
            tools=tools,
            temperature=temperature,
            max_tokens=max_tokens,
            json_mode=json_mode,
            reasoning_effort=self._reasoning_effort,
        )
        started = time.perf_counter()
        body = await self._post(payload)
        latency_ms = (time.perf_counter() - started) * 1000.0

        choices = body.get("choices") or []
        if not choices:
            raise ProviderError(f"featherless returned no choices: {str(body)[:300]}")
        choice = choices[0] or {}
        raw_message = choice.get("message") or {}
        calls = tuple(
            ToolCall.from_openai(entry)
            for entry in (raw_message.get("tool_calls") or [])
        )
        content = raw_message.get("content") or ""
        message = ChatMessage.assistant(content, calls)

        usage = Usage.from_openai(body.get("usage"))
        self._ledger.add(usage)
        return ChatResult(
            message=message,
            model=str(body.get("model") or spec.id),
            usage=usage,
            finish_reason=choice.get("finish_reason"),
            latency_ms=latency_ms,
            raw=body,
            role_used=spec.role,
        )

    # ----------------------------------------------------------------- stream
    async def stream(
        self,
        messages: Sequence[ChatMessage],
        *,
        tools: Iterable[ToolSpec] | None = None,
        role: str = "fast",
        temperature: float | None = None,
        max_tokens: int | None = None,
    ) -> AsyncIterator[ChatStreamChunk]:
        """Server-sent-events stream, as the chat UI consumes it."""
        self.require_key()
        spec = self.spec_for(role)
        payload = self._build_payload(
            messages,
            spec,
            tools=tools,
            temperature=temperature,
            max_tokens=max_tokens,
            stream=True,
            reasoning_effort=self._reasoning_effort,
        )
        url = f"{self._base_url}/chat/completions"
        async with self._client.stream("POST", url, json=payload) as response:
            if response.status_code >= 300:
                body = (await response.aread()).decode("utf-8", "replace")[:400]
                raise ProviderError(
                    f"featherless stream failed: HTTP {response.status_code}: {body}"
                )
            async for raw_line in response.aiter_lines():
                line = raw_line.strip()
                if not line or line.startswith(":") or not line.startswith("data:"):
                    continue
                data = line[len("data:") :].strip()
                if data == "[DONE]":
                    break
                try:
                    event = json.loads(data)
                except json.JSONDecodeError:
                    logger.debug("skipping unparseable SSE frame: %r", data[:120])
                    continue
                if event.get("usage"):
                    self._ledger.add(Usage.from_openai(event.get("usage")))
                for choice in event.get("choices") or []:
                    delta = choice.get("delta") or {}
                    yield ChatStreamChunk(
                        text=delta.get("content") or "",
                        tool_call_deltas=tuple(delta.get("tool_calls") or ()),
                        finish_reason=choice.get("finish_reason"),
                    )

    # ------------------------------------------------------------ diagnostics
    async def list_models(self) -> list[str]:
        """Model ids the account can reach (``GET /models``)."""
        self.require_key()
        response = await self._client.get(f"{self._base_url}/models")
        if response.status_code >= 300:
            raise ProviderError(
                f"featherless model list failed: HTTP {response.status_code}: "
                f"{response.text[:300]}"
            )
        body = response.json()
        entries = body.get("data") if isinstance(body, dict) else body
        ids: list[str] = []
        for entry in entries or []:
            if isinstance(entry, dict):
                ids.append(str(entry.get("id") or entry.get("name") or ""))
            elif isinstance(entry, str):
                ids.append(entry)
        return sorted(item for item in ids if item)

    async def aclose(self) -> None:
        if self._owns_client:
            await self._client.aclose()

    @property
    def ledger(self) -> TokenLedger:
        return self._ledger

    def describe(self) -> dict[str, Any]:
        """Safe-to-log summary; the API key itself never appears."""
        return {
            "provider": self.name,
            "base_url": self._base_url,
            "api_key_set": bool(self._api_key),
            "models": {
                role: {"id": spec.id, "max_tokens": spec.max_tokens}
                for role, spec in self._specs.items()
            },
            "ledger": self._ledger.describe(),
        }


def provider_from_settings(
    settings: Settings | None = None, **overrides: Any
) -> FeatherlessProvider:
    """Build the configured provider. The single entry point for production."""
    resolved = settings or get_settings()
    resolved.require_secrets()
    return FeatherlessProvider(settings=resolved, **overrides)


def _main(argv: Sequence[str] | None = None) -> int:
    """Small operator CLI: confirm model ids before the first scan."""
    import argparse

    parser = argparse.ArgumentParser(
        prog="python -m agent.providers.featherless",
        description="Featherless provider diagnostics (needs FEATHERLESS_API_KEY).",
    )
    parser.add_argument(
        "--list-models", action="store_true", help="print model ids the key can reach"
    )
    parser.add_argument(
        "--roles", action="store_true", help="print the resolved fast/reason models"
    )
    args = parser.parse_args(argv)

    provider = FeatherlessProvider()

    async def _finish() -> list[str] | None:
        """List the models and close the client in ONE event loop.

        Calling ``asyncio.run`` a second time closes a *fresh* loop, but the
        client's connections belong to the first one, so the close raises
        ``RuntimeError: Event loop is closed`` on Windows and the command
        exits 1 even though it succeeded.
        """
        try:
            if args.list_models:
                return await provider.list_models()
            return None
        finally:
            await provider.aclose()

    try:
        if args.roles or not args.list_models:
            print(json.dumps(provider.describe(), indent=2))
        ids = asyncio.run(_finish())
        if ids is not None:
            print(f"{len(ids)} model(s) available:")
            for model_id in ids:
                print(f"  {model_id}")
    except ProviderError as exc:
        print(f"error: {exc}")
        return 1
    return 0


if __name__ == "__main__":  # pragma: no cover - operator entry point
    raise SystemExit(_main())
