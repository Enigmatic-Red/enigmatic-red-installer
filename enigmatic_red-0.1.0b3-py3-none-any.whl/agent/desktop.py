"""Launch the Windows desktop workspace over the local, audited agent server."""

from __future__ import annotations

import argparse
import ctypes
import json
import os
import socket
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any

from agent.setup import RELAUNCH_EXIT


def _show_error(message: str) -> None:
    if sys.platform == "win32":
        ctypes.windll.user32.MessageBoxW(None, message, _TITLE, 0x10)
    else:
        print(message, file=sys.stderr)


def _port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as listener:
        listener.bind(("127.0.0.1", 0))
        return int(listener.getsockname()[1])


def _server_ready(
    address: str,
    process: subprocess.Popen[Any],
    deadline: float,
    *,
    expect: str,
) -> dict[str, Any]:
    """Wait for the shape this launch asked for, and return its own report.

    Two shapes are legitimate and each is one the server itself states:
    ``run`` (``red serve --hands``: plan, runs, audited and a tool list) and
    ``setup`` (``red serve --restart-on-setup``: a page whose form writes the
    attestation ``--hands`` needs). Anything else is not "not yet" - it is a
    server that answered a question it should not have answered differently -
    so it raises rather than looping.
    """
    while time.monotonic() < deadline:
        if process.poll() is not None:
            raise RuntimeError(
                "The local agent stopped before it became ready. On a fresh install "
                "run `red init` for this home first; the reason it exited is in "
                "the agent-ui.log file."
            )
        try:
            with urllib.request.urlopen(address + "/api/capabilities", timeout=1) as response:
                status = json.load(response)
        except (urllib.error.URLError, OSError):
            time.sleep(0.25)
            continue

        found = _surface(status)
        if found == expect:
            return status
        if found is not None:
            raise RuntimeError(
                f"The local server started as {found!r} where this launch asked "
                f"for {expect!r}."
            )
    raise RuntimeError("The local agent did not become ready within two minutes.")


def _surface(status: Any) -> str | None:
    """The shape a capabilities answer describes: ``run``, ``setup`` or nothing.

    Pure, so the two shapes are one testable decision rather than two branches
    inside a polling loop. A run surface is the stricter claim and is checked
    first: `runs: true` with no tools is not a run surface at all.
    """
    if not isinstance(status, dict):
        return None
    if (
        status.get("plan") is True
        and status.get("runs") is True
        and status.get("audited") is True
        and isinstance(status.get("tools"), list)
        and status["tools"]
    ):
        return "run"
    if status.get("setup") is True:
        return "setup"
    return None


def _authorized(home: Path) -> bool:
    """Whether ``--hands`` can start here, asked of the gate rather than the file.

    The desktop used to find this out by starting the server and watching it
    die. The same question is answerable first: a seeded scope plus an
    attestation the gate accepts for the target it names. A file that is
    expired, stale or signed against another scope answers ``False`` for the
    same reason the run would be refused, and the window opens on setup.
    """
    scope_file = home / "config" / "scope.yaml"
    authorization_file = home / "config" / "authorization.json"
    if not scope_file.is_file() or not authorization_file.is_file():
        return False
    try:
        from cli.home import attestation_from_dict
        from safety.authz import AuthorizationGate
        from safety.scope import Scope

        scope = Scope.from_yaml(scope_file)
        attestation = attestation_from_dict(
            json.loads(authorization_file.read_text(encoding="utf-8"))
        )
        ok, _reason = AuthorizationGate().check(
            attestation, attestation.target, scope
        )
    except Exception:  # noqa: BLE001 - an unreadable home means "not yet"
        return False
    return ok


def _stop(process: subprocess.Popen[Any]) -> None:
    if process.poll() is not None:
        return
    process.terminate()
    try:
        process.wait(timeout=10)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait()


def _server_command(
    red: Path,
    home: Path,
    port: int,
    interface: Path,
    *,
    hands: bool,
) -> list[str]:
    """The one command this window runs, in the shape the home is in.

    ``--hands`` is the run surface; without it the same page is the setup form,
    which exists because ``--hands`` on an un-attested home dies before the
    window has anything to show. The last flag is what lets the setup form hand
    back: the server exits with :data:`agent.setup.RELAUNCH_EXIT` once the
    attestation is written, and this process restarts it with ``--hands``.
    """
    command = [
        str(red),
        "--home",
        str(home),
        "serve",
        "--host",
        "127.0.0.1",
        "--port",
        str(port),
        "--interface",
        str(interface),
    ]
    command.append("--hands" if hands else "--restart-on-setup")
    return command


def _relaunch_command() -> list[str]:
    """This launcher again, for the restart after setup writes the attestation.

    pywebview allows one ``start()`` per process, so coming back from setup
    means a new process. A frozen build re-runs the exe; a source run re-runs
    the module, because ``sys.argv[0]`` alone would start the script without
    ``-m`` and lose the package context.
    """
    if getattr(sys, "frozen", False):
        return [sys.executable, *sys.argv[1:]]
    return [sys.executable, "-m", "agent.desktop", *sys.argv[1:]]


_TITLE = "Enigmatic Red Agent"
_SW_RESTORE = 9
_HWND_TOPMOST = -1
_HWND_NOTOPMOST = -2
_SWP_NOMOVE = 0x0002
_SWP_NOSIZE = 0x0001
_SWP_SHOWWINDOW = 0x0040
# Per-session, so two users signed in at once each get their own agent, and one
# window, because a second launch must raise the first rather than open beside it.
_INSTANCE_NAME = "Local\\EnigmaticRedAgent"
_ERROR_ALREADY_EXISTS = 183

_libraries: tuple[Any, Any] | None = None
_instance: Any = None


def _last_error() -> int:
    """The Win32 error of the call just made, kept in one place for the tests."""
    return ctypes.get_last_error()


def _win32() -> tuple[Any, Any]:
    """``user32`` and ``kernel32`` with their handle arguments declared.

    Declared, not assumed: an undeclared ``HWND`` parameter is marshalled as a C
    ``int``, which truncates a 64-bit handle and calls into nothing.
    """
    global _libraries
    if _libraries is None:
        from ctypes import wintypes

        user32 = ctypes.WinDLL("user32", use_last_error=True)
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        user32.SetWindowPos.argtypes = [
            wintypes.HWND,
            wintypes.HWND,
            ctypes.c_int,
            ctypes.c_int,
            ctypes.c_int,
            ctypes.c_int,
            ctypes.c_uint,
        ]
        user32.SetWindowPos.restype = wintypes.BOOL
        user32.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
        user32.ShowWindow.restype = wintypes.BOOL
        user32.BringWindowToTop.argtypes = [wintypes.HWND]
        user32.BringWindowToTop.restype = wintypes.BOOL
        user32.SetForegroundWindow.argtypes = [wintypes.HWND]
        user32.SetForegroundWindow.restype = wintypes.BOOL
        user32.SetFocus.argtypes = [wintypes.HWND]
        user32.SetFocus.restype = wintypes.HWND
        user32.GetForegroundWindow.restype = wintypes.HWND
        user32.IsWindowVisible.argtypes = [wintypes.HWND]
        user32.IsWindowVisible.restype = wintypes.BOOL
        user32.GetWindowTextLengthW.argtypes = [wintypes.HWND]
        user32.GetWindowTextLengthW.restype = ctypes.c_int
        user32.GetWindowTextW.argtypes = [
            wintypes.HWND,
            wintypes.LPWSTR,
            ctypes.c_int,
        ]
        user32.GetWindowTextW.restype = ctypes.c_int
        user32.GetWindowThreadProcessId.argtypes = [
            wintypes.HWND,
            ctypes.POINTER(wintypes.DWORD),
        ]
        user32.GetWindowThreadProcessId.restype = wintypes.DWORD
        user32.AttachThreadInput.argtypes = [
            wintypes.DWORD,
            wintypes.DWORD,
            wintypes.BOOL,
        ]
        user32.AttachThreadInput.restype = wintypes.BOOL
        kernel32.GetCurrentThreadId.restype = wintypes.DWORD
        kernel32.CreateMutexW.argtypes = [
            ctypes.c_void_p,
            wintypes.BOOL,
            wintypes.LPCWSTR,
        ]
        kernel32.CreateMutexW.restype = wintypes.HANDLE
        kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
        kernel32.CloseHandle.restype = wintypes.BOOL
        _libraries = (user32, kernel32)
    return _libraries


#: The prototype ``EnumWindows`` takes. ``WINFUNCTYPE`` exists only on Windows,
#: and it used to be spelled out at the decorator below, inside the function -
#: so the module imported everywhere and then raised ``AttributeError`` the
#: moment a test drove `_find_window` against a fake ``user32``. The fallback is
#: the same ABI and is only ever reached where there is no real ``user32`` to
#: call; on Windows this is ``WINFUNCTYPE``, unchanged.
_WINDOW_CALLBACK = getattr(ctypes, "WINFUNCTYPE", ctypes.CFUNCTYPE)


def _find_window(title: str, mine: bool = True) -> int | None:
    """The visible top-level window called ``title`` that this process owns.

    Owned, not merely named: launching the shortcut twice puts two windows with
    the same name on the desktop, and the second launch must raise its own, not
    the one that is already in front. ``mine=False`` asks the opposite question -
    is there already a window from an *earlier* launch - which is how a rejected
    second launch knows what to raise.
    """
    user32, _ = _win32()
    found: list[int] = []

    @_WINDOW_CALLBACK(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)
    def visit(hwnd: int, _extra: int) -> bool:
        length = user32.GetWindowTextLengthW(hwnd)
        if length <= 0 or not user32.IsWindowVisible(hwnd):
            return True
        text = ctypes.create_unicode_buffer(length + 1)
        user32.GetWindowTextW(hwnd, text, length + 1)
        if text.value != title:
            return True
        owner = ctypes.c_ulong(0)
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(owner))
        if (owner.value == os.getpid()) != mine:
            return True
        found.append(int(hwnd or 0))
        return False

    user32.EnumWindows(visit, None)
    return found[0] if found else None


def _front(hwnd: int) -> bool:
    """Bring ``hwnd`` in front of every other window, and say whether it landed.

    ``SetForegroundWindow`` alone is refused whenever this process is not already
    the foreground one - which is exactly the case here, since the user launched
    the shortcut from Explorer and was still looking at it. The rest of the
    sequence is the ways around that refusal: restore, a topmost round trip to
    jump the z-order, ``BringWindowToTop``, and finally attaching this thread's
    input queue to the foreground window's so Windows treats the call as coming
    from the app the user is in.
    """
    user32, kernel32 = _win32()
    flags = _SWP_NOMOVE | _SWP_NOSIZE | _SWP_SHOWWINDOW
    user32.ShowWindow(hwnd, _SW_RESTORE)
    user32.SetWindowPos(hwnd, _HWND_TOPMOST, 0, 0, 0, 0, flags)
    user32.SetWindowPos(hwnd, _HWND_NOTOPMOST, 0, 0, 0, 0, flags)
    user32.BringWindowToTop(hwnd)
    if user32.SetForegroundWindow(hwnd):
        return True

    current = kernel32.GetCurrentThreadId()
    foreground = user32.GetForegroundWindow() or 0
    threads = [current]
    for window in (hwnd, foreground):
        if not window:
            continue
        owner = ctypes.c_ulong(0)
        thread = user32.GetWindowThreadProcessId(window, ctypes.byref(owner))
        if thread and thread != current:
            threads.append(thread)
    attached: list[int] = []
    for thread in threads[1:]:
        if user32.AttachThreadInput(current, thread, True):
            attached.append(thread)
    try:
        user32.SetForegroundWindow(hwnd)
        user32.SetFocus(hwnd)
    finally:
        for thread in attached:
            user32.AttachThreadInput(current, thread, False)
    return bool(user32.GetForegroundWindow() == hwnd)


def _raise_window(title: str, timeout: float = 60.0) -> bool:
    """Wait for this launch's window, raise it once, and stop.

    On a thread because ``webview.start`` owns the main one, and only once the
    window has finished opening: the handle exists a moment after ``start`` and
    not before, so the wait is the point. It stops as soon as the window is in
    front - a window that kept taking the foreground would pull it back from
    whatever the user opened next, which is worse than opening behind them.
    """
    deadline = time.monotonic() + timeout
    attempts = 0
    while time.monotonic() < deadline:
        hwnd = _find_window(title)
        if hwnd is not None:
            attempts += 1
            if _front(hwnd):
                return True
        # Slow down after a refusal: the topmost round trip is visible, and
        # repeating it ten times a second for a minute would flicker.
        time.sleep(min(0.25 * attempts, 2.0) if attempts else 0.25)
    return False


def _claim_instance() -> bool:
    """True when this launch should open the window, False when one is open.

    A named mutex rather than a lock file or a scan for other processes: the
    handle is closed by the kernel however this process ends, so a crash cannot
    leave behind a claim that refuses every launch after it. The name is per
    session, so two signed-in users each keep their own agent.
    """
    global _instance
    if _instance is not None:
        return True
    _, kernel32 = _win32()
    handle = kernel32.CreateMutexW(None, False, _INSTANCE_NAME)
    error = _last_error()
    if not handle:
        raise OSError(f"could not claim the agent window: error {error}")
    # Already existing is not a failure - it means another launch holds it, and
    # this handle is a leftover that must be dropped before it keeps the name
    # alive past this process.
    if error == _ERROR_ALREADY_EXISTS:
        kernel32.CloseHandle(handle)
        return False
    _instance = handle
    return True


def _release_instance() -> None:
    """Give up the name, so a replacement process can take it.

    Only for the relaunch: ``os.execv`` starts a different process, and if this
    one still held the name the replacement would decide that it was a second
    launch and exit without a window.
    """
    global _instance
    if _instance is None:
        return
    _, kernel32 = _win32()
    kernel32.CloseHandle(_instance)
    _instance = None


def _summon_running(title: str, timeout: float = 10.0) -> bool:
    """Raise the window of the launch that is already open.

    Waiting rather than looking once, because the window a second press is
    asking for may still be opening. Only the other process's window will do:
    this launch has none of its own.
    """
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        hwnd = _find_window(title, mine=False)
        if hwnd is not None and _front(hwnd):
            return True
        time.sleep(0.25)
    return False


def _watch(
    process: subprocess.Popen[Any], window: Any, ended: list[int | None]
) -> None:
    """Close the window when the server behind it has gone.

    A window kept open over a dead backend is the failure this change is
    about: a page that cannot answer and does not say so. Called on a thread
    because ``webview.start`` owns the main one.
    """
    process.wait()
    ended.append(process.returncode)
    try:
        window.destroy()
    except Exception:  # noqa: BLE001 - a window already gone is fine
        pass


def run(home: Path) -> None:
    if sys.platform == "win32" and not _claim_instance():
        # The shortcut was pressed while an agent window is already open. That
        # first launch owns the window and the server behind it, so this one
        # raises it instead of opening a rival window over the top - which is
        # also why it exits afterwards: two windows mean two servers, two
        # ports, and two answers to the same question.
        _summon_running(_TITLE)
        return
    try:
        import webview
    except ImportError as exc:
        raise RuntimeError(
            "The desktop window package is missing. Run EnigmaticRed-Setup.exe "
            "again to repair this install."
        ) from exc

    package_root = Path(__file__).resolve().parent.parent
    interface = package_root / "web" / "agent" / "index.html"
    red = Path(sys.executable).with_name("red.exe" if os.name == "nt" else "red")
    if not red.is_file():
        raise RuntimeError(f"The installed agent command is missing: {red}")
    if not interface.is_file():
        raise RuntimeError(f"The desktop interface is missing: {interface}")

    port = _port()
    address = f"http://127.0.0.1:{port}"
    log_path = home / "logs" / "agent-ui.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)
    # The same question the server would die on, asked before it is started, so
    # a fresh install opens on the setup form instead of a MessageBox.
    hands = _authorized(home)
    command = _server_command(red, home, port, interface, hands=hands)
    ended: list[int | None] = []

    with log_path.open("a", encoding="utf-8") as log:
        process = subprocess.Popen(
            command,
            stdin=subprocess.DEVNULL,
            stdout=log,
            stderr=subprocess.STDOUT,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        try:
            _server_ready(
                address,
                process,
                time.monotonic() + 120,
                expect="run" if hands else "setup",
            )
            window = webview.create_window(
                _TITLE,
                address,
                width=1280,
                height=820,
                min_size=(760, 560),
                background_color="#0c0d0f",
            )
            threading.Thread(
                target=_watch, args=(process, window, ended), daemon=True
            ).start()
            if sys.platform == "win32":
                # A window that opens behind the browser the user was in is a
                # window they will not find, and this one holds the whole
                # install. It has to be raised after ``start`` has created it,
                # which is why the thread waits rather than raising here.
                threading.Thread(
                    target=_raise_window, args=(_TITLE,), daemon=True
                ).start()
            webview.start(gui="edgechromium")
        finally:
            _stop(process)

    if ended and ended[0] == RELAUNCH_EXIT:
        # The setup form said the attestation is written and the gate accepts
        # it. Come back as the run surface; the window that comes back is this
        # process's replacement, not a second one.
        restart = _relaunch_command()
        # Hand the instance name over first: the replacement would otherwise
        # see a name still held by a process that is about to vanish, and exit
        # as a second launch with nothing raised.
        _release_instance()
        os.execv(restart[0], restart)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="Enigmatic Red Agent")
    parser.add_argument("--home", required=True, type=Path)
    args = parser.parse_args(argv)
    try:
        run(args.home.expanduser())
    except Exception as exc:
        _show_error(
            f"{exc}\n\nIf the error mentions WebView2, install the Microsoft "
            "Edge WebView2 Runtime. Agent startup details are in "
            f"{args.home.expanduser() / 'logs' / 'agent-ui.log'}."
        )
        return 1
    return 0


if __name__ == "__main__":  # pragma: no cover - launched by the Start Menu shortcut
    raise SystemExit(main())
