"""BYOK secret redaction and respectful target circuit breaking."""

from __future__ import annotations

import re
import threading
import time
from email.utils import parsedate_to_datetime
from datetime import datetime, timezone
from typing import Iterable


class PromptRedactor:
    """Replace secrets with deterministic placeholders that can be restored locally."""

    _patterns = (
        re.compile(r"(?im)\b(Authorization)\s*:\s*[^\r\n]+"),
        re.compile(r"(?i)\bBearer\s+[A-Za-z0-9._~+/=-]+"),
        re.compile(r"(?im)\b(Set-Cookie|Cookie)\s*:\s*[^\r\n]+"),
        re.compile(r"(?i)\b(?:api[_-]?key|apikey|token|secret)\s*[=:]\s*[^\s,;]+"),
        re.compile(r"\bsk-[A-Za-z0-9_-]{8,}\b"),
        re.compile(r"\b(?:AKIA|ASIA)[A-Z0-9]{16}\b"),
        re.compile(r"-----BEGIN (?:[A-Z ]+ )?PRIVATE KEY-----.*?-----END (?:[A-Z ]+ )?PRIVATE KEY-----", re.DOTALL),
    )

    def redact(self, text: str, extra_secrets: list[str] | None = None) -> tuple[str, dict[str, str]]:
        mapping: dict[str, str] = {}
        counter = 1
        sanitized = text

        for secret in sorted((value for value in extra_secrets or [] if value), key=len, reverse=True):
            if secret not in sanitized:
                continue
            placeholder = f"[REDACTED_SECRET_{counter}]"
            counter += 1
            mapping[placeholder] = secret
            sanitized = sanitized.replace(secret, placeholder)

        for pattern in self._patterns:
            while True:
                match = pattern.search(sanitized)
                if not match:
                    break
                placeholder = f"[REDACTED_SECRET_{counter}]"
                counter += 1
                original = match.group(0)
                mapping[placeholder] = original
                sanitized = sanitized[:match.start()] + placeholder + sanitized[match.end():]
        return sanitized, mapping

    def restore(self, text: str, mapping: dict[str, str]) -> str:
        restored = text
        for placeholder, original in mapping.items():
            restored = restored.replace(placeholder, original)
        return restored


class TargetCircuitBreaker:
    """Track overload responses and pause workers for a target host."""

    OPEN = "OPEN"
    CLOSED = "CLOSED"
    HALF_OPEN = "HALF_OPEN"

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._consecutive: dict[str, int] = {}
        self._state: dict[str, str] = {}
        self._backoff: dict[str, float] = {}
        self._open_until: dict[str, float] = {}

    def inject_headers(self, headers: dict[str, str] | None = None) -> dict[str, str]:
        injected = dict(headers or {})
        injected["X-Scanner"] = "Enigmatic-Red-Authorized"
        return injected

    def record_response(
        self,
        host: str,
        status_code: int,
        headers: dict[str, str] | None = None,
        retry_after: str | None = None,
    ) -> float:
        host = host.lower().rstrip(".")
        with self._lock:
            if status_code in (429, 503):
                consecutive = self._consecutive.get(host, 0) + 1
                self._consecutive[host] = consecutive
                if consecutive >= 5:
                    self._state[host] = self.OPEN
                    delay = self._parse_retry_after(headers or {}, retry_after)
                    if delay is None:
                        delay = min(60.0, 5.0 * (2 ** min(consecutive - 1, 4)))
                    self._backoff[host] = delay
                    self._open_until[host] = time.monotonic() + delay
                    return delay
                prior = self._backoff.get(host)
                delay = prior * 2 if prior is not None else 5.0
                delay = min(60.0, delay)
                explicit = self._parse_retry_after(headers or {}, retry_after)
                delay = explicit if explicit is not None else delay
                self._backoff[host] = delay
                self._open_until[host] = time.monotonic() + delay
                self._state[host] = self.HALF_OPEN if consecutive >= 3 else self.CLOSED
                return delay

            self._consecutive[host] = 0
            self._backoff.pop(host, None)
            self._open_until.pop(host, None)
            self._state[host] = self.CLOSED
            return 0.0

    on_response = record_response
    record_status = record_response

    def record_http_response(self, host: str, status_code: int, headers: dict[str, str] | None = None) -> float:
        return self.record_response(host, status_code, headers)

    def record_429(self, host: str, headers: dict[str, str] | None = None) -> float:
        return self.record_response(host, 429, headers)

    def record_503(self, host: str, headers: dict[str, str] | None = None) -> float:
        return self.record_response(host, 503, headers)

    def get_backoff(self, host: str) -> float:
        host = host.lower().rstrip(".")
        with self._lock:
            if not self.can_scan(host):
                return max(0.0, self._open_until.get(host, 0.0) - time.monotonic())
            return self._backoff.get(host, 0.0)

    def should_pause(self, host: str) -> bool:
        return not self.can_scan(host)

    def reset(self, host: str) -> None:
        host = host.lower().rstrip(".")
        with self._lock:
            self._consecutive.pop(host, None)
            self._state.pop(host, None)
            self._backoff.pop(host, None)
            self._open_until.pop(host, None)

    def can_scan(self, host: str) -> bool:
        host = host.lower().rstrip(".")
        with self._lock:
            state = self._state.get(host, self.CLOSED)
            if state != self.OPEN:
                return True
            if time.monotonic() >= self._open_until.get(host, 0.0):
                self._state[host] = self.HALF_OPEN
                return True
            return False

    def get_state(self, host: str) -> str:
        host = host.lower().rstrip(".")
        with self._lock:
            state = self._state.get(host, self.CLOSED)
            if state == self.OPEN and time.monotonic() >= self._open_until.get(host, 0.0):
                self._state[host] = self.HALF_OPEN
                return self.HALF_OPEN
            return state

    state = get_state

    @staticmethod
    def _parse_retry_after(headers: dict[str, str], retry_after: str | None) -> float | None:
        value = retry_after
        if value is None:
            for key, candidate in headers.items():
                if key.lower() == "retry-after":
                    value = candidate
                    break
        if not value:
            return None
        try:
            seconds = float(str(value).strip())
            return max(0.0, seconds)
        except ValueError:
            try:
                retry_at = parsedate_to_datetime(str(value).strip())
                if retry_at.tzinfo is None:
                    retry_at = retry_at.replace(tzinfo=timezone.utc)
                return max(0.0, (retry_at - datetime.now(timezone.utc)).total_seconds())
            except (TypeError, ValueError, OverflowError):
                return None
