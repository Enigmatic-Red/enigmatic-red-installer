"""Tamper-evident findings storage and report exports."""

from __future__ import annotations

import json
import sqlite3
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable


class EvidenceStore:
    """SQLite findings store with an append-only JSONL mirror."""

    _columns = (
        "finding_id", "scan_id", "status", "title", "severity", "cvss4_vector",
        "cvss4_score", "target", "endpoint", "audit_entry_hash", "reproduction_steps",
        "request_artifact", "response_artifact", "remediation", "created_at",
    )

    def __init__(self, db_path: str | Path, jsonl_path: str | Path | None = None) -> None:
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.jsonl_path = Path(jsonl_path) if jsonl_path is not None else self.db_path.with_suffix(".jsonl")
        self.jsonl_path.parent.mkdir(parents=True, exist_ok=True)
        self._initialize()

    def _initialize(self) -> None:
        with sqlite3.connect(self.db_path) as connection:
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS findings (
                    finding_id TEXT PRIMARY KEY,
                    scan_id TEXT NOT NULL,
                    status TEXT NOT NULL,
                    title TEXT NOT NULL,
                    severity TEXT NOT NULL,
                    cvss4_vector TEXT,
                    cvss4_score REAL,
                    target TEXT,
                    endpoint TEXT,
                    audit_entry_hash TEXT,
                    reproduction_steps TEXT,
                    request_artifact TEXT,
                    response_artifact TEXT,
                    remediation TEXT,
                    created_at TEXT NOT NULL
                )
                """
            )
            connection.execute("CREATE INDEX IF NOT EXISTS idx_findings_scan_id ON findings(scan_id)")

    def save_finding(self, finding: dict[str, Any]) -> str:
        status = finding.get("status")
        if status not in {"CONFIRMED", "UNCONFIRMED_LEAD"}:
            raise ValueError("status must be CONFIRMED or UNCONFIRMED_LEAD")
        if status == "CONFIRMED" and (
            not finding.get("audit_entry_hash") or not finding.get("response_artifact")
        ):
            raise ValueError("CONFIRMED findings require audit_entry_hash and response_artifact")

        finding_id = str(finding.get("finding_id") or uuid.uuid4())
        created_at = str(finding.get("created_at") or datetime.now(timezone.utc).isoformat())
        row = {
            "finding_id": finding_id,
            "scan_id": str(finding.get("scan_id", "")),
            "status": status,
            "title": str(finding.get("title", "")),
            "severity": str(finding.get("severity", "UNKNOWN")),
            "cvss4_vector": finding.get("cvss4_vector"),
            "cvss4_score": finding.get("cvss4_score"),
            "target": finding.get("target"),
            "endpoint": finding.get("endpoint"),
            "audit_entry_hash": finding.get("audit_entry_hash"),
            "reproduction_steps": finding.get("reproduction_steps"),
            "request_artifact": finding.get("request_artifact"),
            "response_artifact": finding.get("response_artifact"),
            "remediation": finding.get("remediation"),
            "created_at": created_at,
        }
        with sqlite3.connect(self.db_path) as connection:
            placeholders = ", ".join("?" for _ in self._columns)
            connection.execute(
                f"INSERT OR REPLACE INTO findings ({', '.join(self._columns)}) VALUES ({placeholders})",
                tuple(row[column] for column in self._columns),
            )

        with self.jsonl_path.open("a", encoding="utf-8") as mirror:
            mirror.write(json.dumps(row, sort_keys=True, separators=(",", ":")) + "\n")
        return finding_id

    def get_findings(self, scan_id: str) -> list[dict[str, Any]]:
        with sqlite3.connect(self.db_path) as connection:
            connection.row_factory = sqlite3.Row
            rows = connection.execute(
                "SELECT * FROM findings WHERE scan_id = ? ORDER BY created_at, finding_id",
                (scan_id,),
            ).fetchall()
            return [dict(row) for row in rows]

    def export_json(self, scan_id: str, out_path: str | Path) -> str:
        findings = self.get_findings(scan_id)
        path = Path(out_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(findings, indent=2, sort_keys=True), encoding="utf-8")
        return str(path)

    def export_markdown(self, scan_id: str, out_path: str | Path) -> str:
        findings = self.get_findings(scan_id)
        confirmed = [item for item in findings if item["status"] == "CONFIRMED"]
        leads = [item for item in findings if item["status"] == "UNCONFIRMED_LEAD"]
        lines = [
            f"# Enigmatic Red Assessment Report",
            "",
            f"**Scan:** `{scan_id}`",
            "",
            "## Executive Summary",
            "",
            f"- Confirmed findings: {len(confirmed)}",
            f"- Unconfirmed leads: {len(leads)}",
            "",
            "## Confirmed Findings",
            "",
        ]
        for item in confirmed:
            lines.extend(self._markdown_finding(item))
        lines.extend(["## Unconfirmed Leads", ""])
        for item in leads:
            lines.extend(self._markdown_finding(item))
        if not leads:
            lines.append("_No unconfirmed leads._")

        path = Path(out_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("\n".join(lines).rstrip() + "\n", encoding="utf-8")
        return str(path)

    @staticmethod
    def _markdown_finding(item: dict[str, Any]) -> list[str]:
        vector = item.get("cvss4_vector") or "N/A"
        score = item.get("cvss4_score")
        score_text = str(score) if score is not None else "N/A"
        return [
            f"### {item['title']}",
            "",
            f"- Severity: {item['severity']}",
            f"- CVSS 4.0: {score_text} (`{vector}`)",
            f"- Target: {item.get('target') or 'N/A'}",
            f"- Endpoint: {item.get('endpoint') or 'N/A'}",
            f"- Evidence: `{item.get('audit_entry_hash') or 'N/A'}`",
            "",
            "#### Reproduction",
            "",
            str(item.get("reproduction_steps") or "_Not provided._"),
            "",
            "#### Remediation",
            "",
            str(item.get("remediation") or "_Not provided._"),
            "",
        ]

    def export_sarif(self, scan_id: str, out_path: str | Path) -> str:
        findings = self.get_findings(scan_id)
        rules: list[dict[str, Any]] = []
        results: list[dict[str, Any]] = []
        for item in findings:
            rule_id = str(item["finding_id"])
            rule = {
                "id": rule_id,
                "name": item["title"][:100].replace(" ", "_"),
                "shortDescription": {"text": item["title"]},
                "fullDescription": {"text": item["title"]},
                "properties": {
                    "security-severity": str(item["cvss4_score"]) if item["cvss4_score"] is not None else "0.0",
                    "status": item["status"],
                },
            }
            rules.append(rule)
            level = "warning" if item["status"] == "UNCONFIRMED_LEAD" else "error"
            result = {
                "ruleId": rule_id,
                "ruleIndex": len(rules) - 1,
                "level": level,
                "message": {"text": item["title"]},
                "properties": {
                    "status": item["status"],
                    "cvss4_vector": item.get("cvss4_vector"),
                    "cvss4_score": item.get("cvss4_score"),
                    "target": item.get("target"),
                    "endpoint": item.get("endpoint"),
                },
            }
            if item.get("endpoint"):
                result["locations"] = [{
                    "physicalLocation": {
                        "artifactLocation": {"uri": item["endpoint"]},
                    }
                }]
            results.append(result)

        sarif = {
            "$schema": "https://json.schemastore.org/sarif-2.1.0.json",
            "version": "2.1.0",
            "runs": [{
                "tool": {
                    "driver": {
                        "name": "Enigmatic Red",
                        "informationUri": "https://github.com/EnigmaticRed/EnigmaticRed",
                        "rules": rules,
                    }
                },
                "results": results,
            }],
        }
        path = Path(out_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(sarif, indent=2, sort_keys=True), encoding="utf-8")
        return str(path)
