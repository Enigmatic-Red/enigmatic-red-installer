"""Standalone security utilities for Enigmatic Red."""
