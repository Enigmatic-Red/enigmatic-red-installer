"""Ownership verification and pre-flight health checks."""

from __future__ import annotations

import ipaddress
import json
import shutil
import socket
import subprocess
import urllib.parse
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any


class OwnershipVerifier:
    """Verify that a target is owned or is an explicitly attested lab target."""

    def verify(self, target: str, scope_hash: str, self_attested_lab: bool = False) -> dict[str, Any]:
        parsed = urllib.parse.urlparse(target if "://" in target else f"//{target}")
        host = parsed.hostname or parsed.path.split("/")[0].split(":")[0]
        host = host.strip().strip("[]").rstrip(".")
        if not host:
            return {"verified": False, "method": "none", "reason": "Target host could not be parsed"}

        try:
            address = ipaddress.ip_address(host)
            addresses = [address]
        except ValueError:
            try:
                addresses = [ipaddress.ip_address(item[4][0]) for item in socket.getaddrinfo(host, None)]
            except (socket.gaierror, OSError):
                try:
                    addresses = [ipaddress.ip_address(socket.gethostbyname(host))]
                except (socket.gaierror, OSError):
                    addresses = []

        private = any(
            item.is_loopback
            or item in ipaddress.ip_network("10.0.0.0/8")
            or item in ipaddress.ip_network("172.16.0.0/12")
            or item in ipaddress.ip_network("192.168.0.0/16")
            for item in addresses
        )
        if private:
            if self_attested_lab:
                return {
                    "verified": True,
                    "method": "self_attested_lab",
                    "reason": "Private/loopback lab target self-attested",
                }
            return {
                "verified": False,
                "method": "none",
                "reason": "Private/loopback target requires self_attested_lab=True",
            }

        dns_result = self._verify_dns(host, scope_hash)
        if dns_result:
            return {
                "verified": True,
                "method": "dns_txt",
                "reason": f"DNS TXT record matched scope hash {scope_hash}",
            }

        http_result = self._verify_http(host, target, scope_hash)
        if http_result:
            return {
                "verified": True,
                "method": "http_well_known",
                "reason": "HTTP well-known file matched the scope hash",
            }

        return {
            "verified": False,
            "method": "none",
            "reason": "No matching DNS TXT or HTTP well-known ownership proof",
        }

    @staticmethod
    def _verify_dns(domain: str, scope_hash: str) -> bool:
        expected = f"enigmatic-red-verify={scope_hash}"
        names = [f"_enigmatic-red.{domain}", domain]
        try:
            import dns.resolver

            for name in names:
                try:
                    answers = dns.resolver.resolve(name, "TXT")
                except Exception:
                    continue
                for answer in answers:
                    value = "".join(part.decode("utf-8", "replace") if isinstance(part, bytes) else str(part)
                                    for part in getattr(answer, "strings", []))
                    if not value:
                        value = str(answer).strip('"')
                    if value.strip() == expected:
                        return True
        except ImportError:
            pass

        for tool in ("nslookup", "dig"):
            executable = shutil.which(tool)
            if not executable:
                continue
            for name in names:
                command = [executable, "-type=TXT", name] if tool == "nslookup" else [executable, "+short", "TXT", name]
                try:
                    result = subprocess.run(command, capture_output=True, text=True, timeout=5, check=False)
                    if expected in result.stdout:
                        return True
                except (OSError, subprocess.SubprocessError):
                    continue
        return False

    @staticmethod
    def _verify_http(host: str, original_target: str, scope_hash: str) -> bool:
        ip_host = host
        try:
            if ipaddress.ip_address(host).version == 6:
                ip_host = f"[{host}]"
        except ValueError:
            pass
        if "://" in original_target:
            parsed = urllib.parse.urlparse(original_target)
            port = f":{parsed.port}" if parsed.port else ""
            authority_host = ip_host
            if parsed.hostname:
                try:
                    authority_host = f"[{parsed.hostname}]" if ipaddress.ip_address(parsed.hostname).version == 6 else parsed.hostname
                except ValueError:
                    authority_host = parsed.hostname
            schemes_hosts = [(parsed.scheme, f"{authority_host}{port}")]
            if parsed.scheme.lower() == "https":
                schemes_hosts.append(("http", f"{authority_host}{port}"))
        else:
            schemes_hosts = [("https", ip_host), ("http", ip_host)]

        for scheme, authority in schemes_hosts:
            url = f"{scheme}://{authority}/.well-known/enigmatic-red.txt"
            request = urllib.request.Request(url, headers={"User-Agent": "Enigmatic-Red/OwnershipVerifier"})
            try:
                with urllib.request.urlopen(request, timeout=5) as response:
                    body = response.read().decode("utf-8", "replace").strip()
                    if body == scope_hash:
                        return True
            except (OSError, urllib.error.URLError, urllib.error.HTTPError, TimeoutError):
                continue
        return False


class PreFlightChecker:
    """Run lightweight, local-only pre-flight checks."""

    def run_checks(self, config: dict[str, Any]) -> dict[str, Any]:
        checks: list[dict[str, Any]] = []
        failures: list[dict[str, Any]] = []

        for name in ("nmap", "nuclei", "playwright"):
            configured = config.get("tools", {}).get(name)
            if configured is None:
                configured = config.get(name)
            value = configured if isinstance(configured, str) and configured else name
            found = shutil.which(value)
            check = {"name": f"{name}_binary", "ok": bool(found), "path": found}
            if found:
                check["message"] = f"{name} binary found"
            else:
                check["message"] = f"{name} binary was not found on PATH"
                failures.append({
                    "check": check["name"],
                    "reason": check["message"],
                    "remediation": f"Install {name} and ensure it is available on PATH.",
                })
            checks.append(check)

        template_dir = config.get("nuclei_templates_dir") or config.get("nuclei", {}).get("templates_dir")
        if template_dir:
            templates = Path(str(template_dir))
            try:
                count = sum(1 for item in templates.rglob("*") if item.is_file() and item.suffix.lower() in {".yaml", ".yml"})
                ok = templates.is_dir() and count > 0
            except OSError:
                ok = False
                count = 0
            check = {"name": "nuclei_templates", "ok": ok, "path": str(template_dir), "count": count}
            if ok:
                check["message"] = f"Found {count} nuclei YAML templates"
            else:
                check["message"] = "Nuclei templates directory is missing or contains no YAML templates"
                failures.append({
                    "check": "nuclei_templates",
                    "reason": check["message"],
                    "remediation": "Set nuclei_templates_dir to a directory containing .yaml templates.",
                })
            checks.append(check)

        llm = config.get("llm", config)
        provider = str(llm.get("provider", llm.get("mode", ""))).lower()
        if provider in {"local", "ollama", "local_host"} or "localhost" in str(llm.get("base_url", "")):
            self._check_local_llm(llm, checks, failures)
        elif provider or llm.get("api_key") or llm.get("base_url"):
            self._check_byok_llm(llm, checks, failures)

        return {"ok": not failures, "checks": checks, "failures": failures}

    @staticmethod
    def _check_byok_llm(llm: dict[str, Any], checks: list[dict], failures: list[dict]) -> None:
        base_url = str(llm.get("base_url") or llm.get("endpoint") or "").rstrip("/")
        if not base_url:
            check = {"name": "llm_provider", "ok": False, "message": "BYOK provider endpoint is not configured"}
            failures.append({"check": "llm_provider", "reason": check["message"], "remediation": "Configure base_url or endpoint."})
            checks.append(check)
            return
        api_key = llm.get("api_key") or llm.get("apiKey")
        auth = llm.get("auth_header") or ("Bearer " + str(api_key) if api_key else "")
        provider = str(llm.get("provider", "")).lower()
        if base_url.endswith("/models"):
            url = base_url
        elif provider == "anthropic":
            url = base_url + "/v1/models"
        else:
            url = base_url + "/models"
        headers = {"User-Agent": "Enigmatic-Red/PreFlight"}
        if auth:
            headers["Authorization"] = auth
        if provider == "anthropic" and api_key:
            headers["x-api-key"] = str(api_key)
        request = urllib.request.Request(url, headers=headers, method="GET")
        try:
            with urllib.request.urlopen(request, timeout=5) as response:
                ok = 200 <= response.status < 400
        except (OSError, TimeoutError, urllib.error.URLError, urllib.error.HTTPError) as exc:
            ok = False
            reason = f"LLM provider connectivity failed: {exc}"
        else:
            reason = "LLM provider models endpoint is reachable"
        check = {"name": "llm_provider", "ok": ok, "message": reason}
        checks.append(check)
        if not ok:
            failures.append({"check": "llm_provider", "reason": reason, "remediation": "Check the endpoint URL, API key, network access, and provider status."})

    @staticmethod
    def _check_local_llm(llm: dict[str, Any], checks: list[dict], failures: list[dict]) -> None:
        base_url = str(llm.get("base_url") or llm.get("endpoint") or "http://127.0.0.1:11434").rstrip("/")
        model = llm.get("model") or llm.get("model_tag")
        ok = False
        reason = ""
        for path in ("/api/tags", "/v1/models"):
            url = base_url + path
            try:
                with urllib.request.urlopen(url, timeout=5) as response:
                    payload = json.loads(response.read().decode("utf-8", "replace"))
                names: list[str] = []
                for item in payload.get("models", []) if isinstance(payload, dict) else []:
                    if isinstance(item, dict):
                        names.append(str(item.get("name") or item.get("model") or item.get("id") or ""))
                if "data" in payload and isinstance(payload["data"], list):
                    names.extend(str(item.get("id", "")) for item in payload["data"] if isinstance(item, dict))
                ok = not model or str(model) in names
                reason = "Local model tag is present" if ok else f"Configured local model '{model}' was not found"
                break
            except (OSError, TimeoutError, urllib.error.URLError, urllib.error.HTTPError, json.JSONDecodeError) as exc:
                reason = f"Local LLM endpoint is unreachable: {exc}"
        check = {"name": "local_llm", "ok": ok, "message": reason}
        checks.append(check)
        if not ok:
            failures.append({"check": "local_llm", "reason": reason, "remediation": "Start the local model server and pull/configure the requested model tag."})
