"""BYOK-first routing for the model call.

One module decides *where* a completion goes, so no caller has to know which
vendor is behind it:

* ``openai`` - any OpenAI-compatible ``/chat/completions`` endpoint, which is
  the default. The default model is ``deepseek-ai/DeepSeek-V4.1-Flash-1017``
  and ``reasoning_effort`` is carried through when the caller sets it, because
  a reasoning model that is not told how hard to think spends the operator's
  tokens at its own default.
* ``anthropic`` - the Messages API (``/v1/messages``, ``x-api-key``).
* ``ollama`` - the model on this machine (``http://127.0.0.1:11434/v1``),
  which authenticates nobody and is therefore always keyless.

"BYOK" is literal here: the key is the operator's own, against the operator's
own endpoint. Nothing is issued by this project and nothing is proxied. The key
lives in the OS keyring when one is available, and in ``.env`` written with
``0600`` permissions when it is not - the fallback exists because the Windows
installer cannot assume a keyring backend is present, not because a plain file
is as good.

Prompts leaving this machine are piped through
:class:`enigmatic_red.egress_guard.PromptRedactor` before they are serialised,
so a credential that a target returned in a response body is not forwarded to a
third party. A loopback endpoint is skipped: nothing leaves the machine, and
redacting there would only corrupt the operator's own context.
"""

from __future__ import annotations

import ipaddress
import os
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

from enigmatic_red.egress_guard import PromptRedactor

__all__ = [
    "ANTHROPIC_DEFAULT_BASE_URL",
    "ANTHROPIC_DEFAULT_MODEL",
    "ANTHROPIC_VERSION",
    "DEFAULT_BASE_URL",
    "DEFAULT_MODEL",
    "OLLAMA_DEFAULT_BASE_URL",
    "OLLAMA_DEFAULT_MODEL",
    "PROVIDERS",
    "BYOKStore",
    "LLMRouter",
    "Route",
    "default_env_path",
    "is_loopback",
    "route_from_settings",
]

#: The BYOK default: an open-weight reasoning model served over an
#: OpenAI-compatible API. A caller that names nothing gets this.
DEFAULT_MODEL = "deepseek-ai/DeepSeek-V4.1-Flash-1017"

#: The OpenAI-compatible host this build documents. Any compatible host works;
#: the model id above is the one the default is resolved against.
DEFAULT_BASE_URL = "https://api.featherless.ai/v1"

ANTHROPIC_DEFAULT_BASE_URL = "https://api.anthropic.com"
ANTHROPIC_DEFAULT_MODEL = "claude-sonnet-4-5"
#: Anthropic versions the Messages API by header, not by URL.
ANTHROPIC_VERSION = "2023-06-01"

OLLAMA_DEFAULT_BASE_URL = "http://127.0.0.1:11434/v1"
OLLAMA_DEFAULT_MODEL = "llama3.2:3b"

PROVIDERS = ("openai", "anthropic", "ollama")

#: Environment names that hold the operator's key, in priority order. The
#: generic ones come first so one key can serve whichever endpoint is set.
_GENERIC_ENV = ("ENIGMATIC_RED_API_KEY", "LLM_API_KEY")
_PROVIDER_ENV = {
    "openai": ("DEEPSEEK_API_KEY", "OPENAI_API_KEY", "FEATHERLESS_API_KEY"),
    "anthropic": ("ANTHROPIC_API_KEY",),
    "ollama": (),
}
#: The name :meth:`BYOKStore.set` writes when there is no keyring.
_ENV_FILE_NAME = "ENIGMATIC_RED_API_KEY_{provider}"


def default_env_path() -> Path:
    """Where the fallback key file lives.

    Deliberately *not* the checkout's ``.env``: that file is read by
    ``config.settings`` and may be a shared template, while this one holds one
    machine's credential. ``ENIGMATIC_RED_HOME`` is honoured so an install and
    a checkout can point at the same place when they should.
    """
    override = os.environ.get("ENIGMATIC_RED_HOME", "").strip()
    base = Path(override).expanduser() if override else Path.home() / ".enigmatic-red"
    return base / ".env"


def is_loopback(base_url: str) -> bool:
    """True when ``base_url`` names this machine and nothing leaves it.

    Only loopback counts - ``localhost``, ``127.0.0.0/8`` and ``::1``. A LAN
    address is *not* loopback here even though ``host_is_local`` treats it as
    local for the purpose of needing a key: a prompt sent to another box has
    left this machine and still deserves redaction.
    """
    raw = base_url if "//" in base_url else f"//{base_url}"
    host = (urlsplit(raw).hostname or "").lower().strip("[]").rstrip(".")
    if not host:
        return False
    if host == "localhost" or host.endswith(".localhost"):
        return True
    try:
        address = ipaddress.ip_address(host)
    except ValueError:
        return False
    return address.is_loopback


def _check_provider(provider: str) -> str:
    value = (provider or "").strip().lower()
    if value not in PROVIDERS:
        raise ValueError(
            f"unknown provider {provider!r}: expected one of {', '.join(PROVIDERS)}"
        )
    return value


def _infer_provider(provider: str | None, base_url: str | None) -> str:
    """Name the wire format when the caller did not.

    An explicit value always wins. Otherwise a loopback endpoint is Ollama (the
    only thing this build starts locally), a host with ``anthropic`` in it is
    the Messages API, and everything else is OpenAI-compatible - which is what
    "OpenAI-compatible" means: the shape is the default rather than a vendor.
    """
    if provider:
        return _check_provider(provider)
    if base_url and is_loopback(base_url):
        return "ollama"
    host = (urlsplit(base_url or "").hostname or "").lower()
    if "anthropic" in host:
        return "anthropic"
    return "openai"


def _normalise_base_url(base_url: str, provider: str) -> str:
    """Strip trailing slashes, and give a keyless Ollama host its ``/v1``."""
    value = (base_url or "").strip().rstrip("/")
    if not value:
        value = {
            "anthropic": ANTHROPIC_DEFAULT_BASE_URL,
            "ollama": OLLAMA_DEFAULT_BASE_URL,
        }.get(provider, DEFAULT_BASE_URL)
    if provider == "ollama":
        parts = urlsplit(value if "//" in value else f"//{value}")
        if not parts.path.strip("/"):
            value = value + "/v1"
    return value


def _default_model(provider: str) -> str:
    return {
        "anthropic": ANTHROPIC_DEFAULT_MODEL,
        "ollama": OLLAMA_DEFAULT_MODEL,
    }.get(provider, DEFAULT_MODEL)


def _role_of(value: Any) -> str:
    if isinstance(value, Mapping):
        role: Any = value.get("role", "user")
    else:
        role = getattr(value, "role", None)
        role = getattr(role, "value", role)
    return str(role or "user").strip().lower()


def _content_of(value: Any) -> str:
    content = getattr(value, "content", None)
    if content is None and isinstance(value, Mapping):
        content = value.get("content", "")
def _content_of(value: Any) -> str:
    content = getattr(value, "content", None)
    if content is None and isinstance(value, Mapping):
        content = value.get("content", "")
    return "" if content is None else str(content)


class BYOKStore:
    """The operator's key: environment, then keyring, then a private ``.env``.

    Read order is deliberate. An environment variable is the most explicit
    thing an operator can do (and the only one that works in a container), the
    keyring is the least exposed place to keep a key on a desktop, and the file
    is the fallback for a machine with no keyring backend - which is the normal
    case for a fresh Windows install.

    Args:
        env_path: the fallback file. Tests pass a temporary one.
        environ: injected environment mapping; defaults to ``os.environ``.
        keyring_module: injected keyring module, or ``False`` to disable it.
            ``None`` (the default) means "import it on first use".
    """

    service_name = "enigmatic-red"

    def __init__(
        self,
        env_path: str | Path | None = None,
        *,
        environ: Mapping[str, str] | None = None,
        keyring_module: Any = None,
    ) -> None:
        self.env_path = Path(env_path) if env_path else default_env_path()
        self._environ = os.environ if environ is None else environ
        self._injected_keyring = keyring_module
        self._loaded_keyring: Any = None

    # ------------------------------------------------------------------ read
    def get(self, provider: str) -> str:
        """The key for ``provider``, or ``""``. Never raises."""
        name = _check_provider(provider)
        return (
            self._from_environment(name)
            or self._from_keyring(name)
            or self._from_env_file(name)
        )

    def _from_environment(self, provider: str) -> str:
        names = list(_GENERIC_ENV) + list(_PROVIDER_ENV.get(provider, ()))
        for name in names:
            value = (self._environ.get(name) or "").strip()
            if value:
                return value
        return ""

    def _keyring(self) -> Any:
        """The keyring module, or ``None`` when this machine has none."""
        if self._injected_keyring is False:
            return None
        if self._injected_keyring is not None:
            return self._injected_keyring
        if self._loaded_keyring is None:
            try:
                import keyring  # type: ignore[import-not-found]
            except Exception:  # noqa: BLE001 - no backend is a normal install
                self._loaded_keyring = False
            else:
                self._loaded_keyring = keyring
        return None if self._loaded_keyring is False else self._loaded_keyring

    def _from_keyring(self, provider: str) -> str:
        module = self._keyring()
        if module is None:
            return ""
        try:
            return (module.get_password(self.service_name, provider) or "").strip()
        except Exception:  # noqa: BLE001 - a broken backend is not a key
            return ""

    def _from_env_file(self, provider: str) -> str:
        text = self._read_env_file()
        if not text:
            return ""
        wanted = {
            _ENV_FILE_NAME.format(provider=provider).upper(),
            *(name.upper() for name in _PROVIDER_ENV.get(provider, ())),
        }
        for line in text.splitlines():
            stripped = line.strip()
            if not stripped or stripped.startswith("#") or "=" not in stripped:
                continue
            key, value = stripped.split("=", 1)
            if key.strip().upper() in wanted:
                return value.strip().strip("'\"")
        return ""

    def _read_env_file(self) -> str:
        try:
            return self.env_path.read_text(encoding="utf-8")
        except OSError:
            return ""

    # ----------------------------------------------------------------- write
    def set(self, provider: str, key: str) -> str:
        """Store one key. Returns ``"keyring"`` or ``"env"``.

        Raises ``ValueError`` for an empty key rather than storing a blank,
        because a blank entry would *look* configured to every reader.
        """
        name = _check_provider(provider)
        value = (key or "").strip()
        if not value:
            raise ValueError("an empty API key cannot be stored")
        if self._set_keyring(name, value):
            return "keyring"
        self._write_env_file(name, value)
        return "env"

    def _set_keyring(self, provider: str, value: str) -> bool:
        module = self._keyring()
        if module is None:
            return False
        try:
            module.set_password(self.service_name, provider, value)
        except Exception:  # noqa: BLE001 - fall back to the private file
            return False
        return True

    def _write_env_file(self, provider: str, value: str) -> None:
        """Rewrite the fallback file with ``0600`` permissions.

        The file is created with the mode up front (``os.open``) rather than
        written and then chmodded, so there is no window in which the key is
        readable by anyone else on the machine.
        """
        wanted = _ENV_FILE_NAME.format(provider=provider).upper()
        line = f"{wanted}={value}"
        current = self._read_env_file()
        kept = [
            item
            for item in current.splitlines()
            if item.strip() and item.split("=", 1)[0].strip().upper() != wanted
        ]
        body = "\n".join(kept + [line]) + "\n"
        self.env_path.parent.mkdir(parents=True, exist_ok=True)
        descriptor = os.open(
            self.env_path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600
        )
        try:
            os.write(descriptor, body.encode("utf-8"))
        finally:
            os.close(descriptor)
        try:
            os.chmod(self.env_path, 0o600)
        except OSError:  # pragma: no cover - Windows without POSIX modes
            pass


@dataclass(frozen=True)
class Route:
    """A resolved endpoint, model and credential. Immutable by construction."""

    provider: str = "openai"
    base_url: str = DEFAULT_BASE_URL
    model: str = DEFAULT_MODEL
    api_key: str = ""
    reasoning_effort: str | None = None
    max_tokens: int = 4096
    temperature: float = 0.2

    def __post_init__(self) -> None:
        _check_provider(self.provider)
        if not self.base_url:
            raise ValueError("Route requires a base_url")
        if not self.model:
            raise ValueError("Route requires a model id")

    @property
    def local(self) -> bool:
        """Whether this endpoint is on this machine, so nothing egresses."""
        return is_loopback(self.base_url)

    @property
    def chat_url(self) -> str:
        """The absolute URL a completion is POSTed to."""
        base = self.base_url.rstrip("/")
        if self.provider == "anthropic":
            return base + "/messages" if base.endswith("/v1") else base + "/v1/messages"
        return base + "/chat/completions"

    def headers(self) -> dict[str, str]:
        """Auth and content headers for this route. The key is only in memory."""
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": "enigmatic-red/byok-router",
        }
        if self.provider == "anthropic":
            headers["anthropic-version"] = ANTHROPIC_VERSION
            if self.api_key:
                headers["x-api-key"] = self.api_key
        elif self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        return headers

    def describe(self) -> dict[str, Any]:
        """Safe-to-log summary; the key itself never appears."""
        return {
            "provider": self.provider,
            "base_url": self.base_url,
            "model": self.model,
            "reasoning_effort": self.reasoning_effort,
            "local": self.local,
            "api_key_set": bool(self.api_key),
        }


class LLMRouter:
    """Resolve a :class:`Route`, then serialise a request for it.

    Args:
        provider: ``openai``, ``anthropic`` or ``ollama``; inferred from
            ``base_url`` when omitted.
        base_url: the endpoint. Empty means the provider's default.
        model: the model id. Empty means the provider's default, and for the
            OpenAI-compatible default that is :data:`DEFAULT_MODEL`.
        api_key: an explicit key. ``None`` means "ask the store"; ``""`` means
            "this route is keyless on purpose".
        reasoning_effort: passed through to an OpenAI-compatible endpoint.
        store: a :class:`BYOKStore`; tests inject a temporary one.
        redactor: a :class:`PromptRedactor`; injectable for the same reason.
    """

    def __init__(
        self,
        *,
        provider: str | None = None,
        base_url: str | None = None,
        model: str | None = None,
        api_key: str | None = None,
        reasoning_effort: str | None = None,
        max_tokens: int = 4096,
        temperature: float = 0.2,
        timeout_s: float = 120.0,
        store: BYOKStore | None = None,
        redactor: PromptRedactor | None = None,
    ) -> None:
        self._provider = provider
        self._base_url = base_url
        self._model = model
        self._api_key = api_key
        self._reasoning_effort = reasoning_effort
        self._max_tokens = int(max_tokens)
        self._temperature = float(temperature)
        self._timeout_s = float(timeout_s)
        self.store = store or BYOKStore()
        self._redactor = redactor or PromptRedactor()

    # ---------------------------------------------------------------- routing
    def route(
        self,
        *,
        provider: str | None = None,
        base_url: str | None = None,
        model: str | None = None,
        api_key: str | None = None,
        reasoning_effort: str | None = None,
    ) -> Route:
        """Resolve the endpoint, model and credential for one call.

        Per-call arguments win over constructor defaults, which win over the
        provider's own defaults. A remote route with no credential asks
        :attr:`store`; a loopback route never does, because a model on this
        machine authenticates nobody and a key would only be leaked into a
        local log.
        """
        resolved_base = base_url or self._base_url
        resolved_provider = _infer_provider(provider or self._provider, resolved_base)
        resolved_base = _normalise_base_url(resolved_base or "", resolved_provider)
        resolved_model = model or self._model or _default_model(resolved_provider)

        key = api_key if api_key is not None else self._api_key
        if key is None:
            key = "" if is_loopback(resolved_base) else self.store.get(resolved_provider)

        effort = reasoning_effort if reasoning_effort is not None else self._reasoning_effort
        return Route(
            provider=resolved_provider,
            base_url=resolved_base,
            model=resolved_model,
            api_key=key or "",
            reasoning_effort=(effort or None),
            max_tokens=self._max_tokens,
            temperature=self._temperature,
        )

    def redact_prompt(
        self, text: str, *, route: Route | None = None
    ) -> tuple[str, dict[str, str]]:
        """Redact a prompt on its way out, unless the endpoint is loopback."""
        resolved = route or self.route()
        if resolved.local:
            return text, {}
        secrets = [resolved.api_key] if resolved.api_key else None
        return self._redactor.redact(text, extra_secrets=secrets)

    # ------------------------------------------------------------ serialising
    def prepare(
        self,
        messages: Sequence[Any],
        *,
        route: Route | None = None,
        system: str | None = None,
        tools: Sequence[Any] | None = None,
        stream: bool = False,
        max_tokens: int | None = None,
        temperature: float | None = None,
        reasoning_effort: str | None = None,
    ) -> dict[str, Any]:
        """Build the exact HTTP request for ``messages`` on ``route``.

        Pure except for the redaction counter, and offline by construction:
        nothing here opens a socket, so the shape of every provider's request
        can be asserted without a key or a network.
        """
        resolved = route or self.route(reasoning_effort=reasoning_effort)
        redactions: dict[str, str] = {}

        def clean(text: str) -> str:
            sanitized, found = self.redact_prompt(text, route=resolved)
            redactions.update(found)
            return sanitized

        pairs = [(_role_of(message), clean(_content_of(message))) for message in messages]
        system_text = clean(system) if system else None

        limit = int(max_tokens if max_tokens is not None else resolved.max_tokens)
        heat = resolved.temperature if temperature is None else float(temperature)
        effort = resolved.reasoning_effort

        if resolved.provider == "anthropic":
            body: dict[str, Any] = {
                "model": resolved.model,
                "max_tokens": limit,
                "temperature": heat,
                "messages": [
                    {"role": role, "content": content}
                    for role, content in pairs
                    if role != "system"
                ],
            }
            system_parts = [system_text] if system_text else []
            system_parts.extend(content for role, content in pairs if role == "system")
            if system_parts:
                body["system"] = "\n\n".join(part for part in system_parts if part)
            if tools:
                body["tools"] = [_anthropic_tool(tool) for tool in tools]
            if stream:
                body["stream"] = True
        else:
            body = {
                "model": resolved.model,
                "messages": [
                    {"role": role, "content": content} for role, content in pairs
                ],
                "max_tokens": limit,
                "temperature": heat,
            }
            if effort and resolved.provider == "openai":
                body["reasoning_effort"] = effort
            if tools:
                body["tools"] = [_openai_tool(tool) for tool in tools]
                body["tool_choice"] = "auto"
            if stream:
                body["stream"] = True

        return {
            "provider": resolved.provider,
            "method": "POST",
            "url": resolved.chat_url,
            "headers": resolved.headers(),
            "json": body,
            "redactions": redactions,
            "route": resolved.describe(),
        }

    # ---------------------------------------------------------------- egress
    async def complete(self, messages: Sequence[Any], **kwargs: Any) -> dict[str, Any]:
        """Run one completion. Only this method opens a socket."""
        request = self.prepare(messages, **kwargs)
        import httpx

        async with httpx.AsyncClient(timeout=self._timeout_s) as client:
            response = await client.request(
                request["method"],
                request["url"],
                headers=request["headers"],
                json=request["json"],
            )

        if response.status_code >= 400:
            detail = response.text[:300]
            raise RuntimeError(
                f"{request['provider']} completion failed: HTTP "
                f"{response.status_code}: {detail}"
            )
        body = response.json()
        return {
            "text": _response_text(request["provider"], body),
            "raw": body,
            "redactions": request["redactions"],
            "route": request["route"],
        }


def _openai_tool(tool: Any) -> dict[str, Any]:
    """A tool in OpenAI function-calling shape, from either shape we carry."""
    if isinstance(tool, Mapping) and "function" in tool:
        return dict(tool)
    name = getattr(tool, "name", None) or (
        tool.get("name") if isinstance(tool, Mapping) else ""
    )
    description = getattr(tool, "description", None) or (
        tool.get("description", "") if isinstance(tool, Mapping) else ""
    )
    parameters = getattr(tool, "parameters", None) or (
        tool.get("parameters") if isinstance(tool, Mapping) else None
    )
    return {
        "type": "function",
        "function": {
            "name": str(name),
            "description": str(description or ""),
            "parameters": parameters or {"type": "object", "properties": {}},
        },
    }


def _anthropic_tool(tool: Any) -> dict[str, Any]:
    """The same tool in the Messages API's ``input_schema`` shape."""
    payload = _openai_tool(tool)["function"]
    return {
        "name": payload["name"],
        "description": payload["description"],
        "input_schema": payload["parameters"],
    }


def _response_text(provider: str, body: Any) -> str:
    """The assistant's text, from either response shape."""
    if not isinstance(body, Mapping):
        return ""
    if provider == "anthropic":
        blocks = body.get("content") or []
        if isinstance(blocks, list):
            return "".join(
                str(block.get("text", ""))
                for block in blocks
                if isinstance(block, Mapping) and block.get("type", "text") == "text"
            )
        return ""
    choices = body.get("choices") or []
    if choices and isinstance(choices[0], Mapping):
        message = choices[0].get("message") or {}
        if isinstance(message, Mapping):
            return str(message.get("content") or "")
    return ""


def route_from_settings(
    settings: Any,
    *,
    store: BYOKStore | None = None,
    redactor: PromptRedactor | None = None,
) -> Route:
    """The route ``Settings`` already describes, resolved BYOK-first.

    This is the one bridge between configuration and the router: everything
    else takes a :class:`Route` or explicit arguments, so a test never needs a
    ``Settings`` object to exercise serialisation.
    """
    model = getattr(settings, "featherless_model_fast", "") or DEFAULT_MODEL
    return LLMRouter(
        provider="openai",
        base_url=getattr(settings, "featherless_base_url", "") or DEFAULT_BASE_URL,
        model=model,
        api_key=getattr(settings, "featherless_api_key", None) or None,
        reasoning_effort=getattr(settings, "llm_reasoning_effort", "") or None,
        store=store,
        redactor=redactor,
    ).route()
