"""Versioned corpus ingestion, validation and evaluation for the AI domain.

This package is the machinery behind four separations the project makes:

* **raw data vs derived data** - a downloaded corpus is read where the operator
  keeps it and normalised into JSONL outside this repository; nothing
  third-party is bundled with the wheel or the site (:mod:`corpora.ingest`);
* **retrieval knowledge vs evaluation fixtures vs training data** - a source is
  registered with one role and one zone, and a record cannot be in a split its
  zone does not allow (:mod:`corpora.schema`);
* **what is licensed vs what is not** - every source carries a publisher, URL,
  version, retrieval date, licence, checksum and the transformations applied,
  and an unverified or incompatible licence is refused before ingestion
  (:mod:`corpora.manifest`);
* **what a run measured vs what it did not** - the evaluator reports a
  numerator, a denominator and an explicit *not tested* for every metric, so a
  missing result cannot be read as a clean one (:mod:`corpora.evaluate`).

The boundaries the rest of the product holds are unchanged here: no exploitation
workflow, no autonomous action, no real-target material, and no real user data.
A corpus record is *text to measure against*, never a payload to run.
"""

from __future__ import annotations

__all__ = [
    "SCHEMA_VERSION",
    "SchemaError",
    "Record",
    "read_jsonl",
    "validate_record",
]

from corpora.schema import (  # noqa: E402 - re-export deliberately at the end
    SCHEMA_VERSION,
    Record,
    SchemaError,
    read_jsonl,
    validate_record,
)
