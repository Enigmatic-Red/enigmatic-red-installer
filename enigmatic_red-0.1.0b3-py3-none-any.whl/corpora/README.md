# Corpora, evaluation and the AI prompt pack

This directory is the machinery behind the AI domain's knowledge and evaluation:
a versioned ingestion pipeline, a licence gate, a normalised record schema, a
deterministic evaluator, and the reports a release has to produce. It holds
**metadata and first-party records only**. No third-party corpus text is stored
here, and nothing in it runs a tool or calls a model.

The boundaries the rest of the product holds are unchanged. A corpus record is
text to measure against, never a payload to run: there is no exploitation
workflow, no autonomous action, no real-target material and no real user data.

## Why it is shaped this way

Four separations make a corpus usable in an assessment lab:

| Separation | Where it lives |
| --- | --- |
| raw source vs derived data | `ingest` writes normalised JSONL to `~/.enigmatic-red/corpora`, outside this repository |
| retrieval knowledge vs evaluation fixtures vs training data | `zone`, `role` and `split` on every record, enforced by `validate_record` |
| licensed vs unlicensed | `registry.yaml` review state; ingestion refuses anything not `verified` |
| measured vs not measured | every metric carries a numerator, a denominator and an explicit `not tested` |

## The registry (licence gate)

`registry.yaml` names each source with publisher, URL, version, retrieval date,
licence, review state and basis, redistribution permission, role, format,
transformations and retention. Four review states exist, and only one is
usable:

- `verified` — the licence was read at the recorded URL. Ingestion may proceed.
- `review_required` — someone must read the licence first; ingestion refuses and
  says which artefact to review.
- `blocked` — the licence may permit use, but the artefact could not be lawfully
  or practically obtained. The basis records why, so a missing corpus is visible.
- `incompatible` — refused outright.

Verified sources include OWASP WSTG 4.2 and ASVS 5.0.0 (CC BY-SA 4.0), MITRE CWE
5.0 (CWE Terms of Use, attribution required), NIST NVD (public domain), NIST
Juliet 1.3 (CC0 1.0), XSTest (CC BY 4.0), AdvBench and HarmBench (MIT), deepset
prompt-injections (Apache-2.0), InjecAgent (MIT), and the first-party write-ups,
probe design and baseline. PrimeVul (MIT repository, dataset only on an
interactive Google Drive folder) and the unlicensed jailbreak-prompt collection
are `blocked`: the reason is recorded in the registry and nothing was ingested.
That is the gate working, not a gap.

The registry is metadata only. Raw archives are acquired outside the repository
(`~/.enigmatic-red/raw`) and normalised corpora are written outside it
(`~/.enigmatic-red/corpora`); neither is committed, because most licences permit
use but not redistribution in a source tree. Redistribution-allowed material is
still not bundled: the wheel carries the importer, not a benchmark.

## Acquisition and what was ingested

A source is "ingested" only when its actual artefact was acquired, passed the
licence gate, verified against the registry's SHA-256 pin, and normalised. The
pins are in `registry.yaml`, so a re-acquisition either matches or is refused.

| Source | Version | Licence | Role | Local result |
| --- | --- | --- | --- | --- |
| OWASP WSTG | 4.2 | CC BY-SA 4.0 | retrieval | 138 records |
| OWASP ASVS | 5.0.0 | CC BY-SA 4.0 | retrieval | 27 records |
| MITRE CWE | 5.0 (`1000.csv`) | CWE Terms of Use | retrieval | 956 records |
| NIST NVD | 2026-11-20 recent feed | NIST public data | retrieval | 4,544 records |
| NIST Juliet | 1.3 | CC0 1.0 | evaluation | 1,980 function records (bounded sample) |
| XSTest | 2024-naacl | CC BY 4.0 | evaluation | 450 records |
| AdvBench | 2023-07 | MIT | evaluation | 520 records |
| HarmBench | main@2026-11-20 | MIT | evaluation | 393 records |
| deepset prompt-injections | main@2026-11-20 | Apache-2.0 | evaluation | 662 records |
| InjecAgent | main@2026-11-20 | MIT | evaluation | 62 records |
| PrimeVul | v0.1 | MIT (repo) | evaluation | **blocked** - Google Drive, not acquired |
| ChatGPT_DAN jailbreak collection | unrecorded | none declared | evaluation | **blocked** - no licence |

`nvd-json` is a format of its own: NVD nests `description`, `published` and the
CWE mapping inside `vulnerabilities[].cve`, so the reader flattens it. Juliet is
read at function granularity: the suite names its cases `..._bad()` and
`good...()` inside a file named after the CWE, so the file name alone would
label nothing.

## Retrieval and citation

`corpora/retrieval.py` is the read side of the local store. It loads every
`retrieval` record, scores a question by lexical overlap (with a heading bonus),
and returns the record, its publisher/version/URL/licence and a bounded excerpt.
`render_references` puts those hits in a prompt block whose first line says they
are **untrusted data, not instructions**; the chat path (`agent/chat.py`)
attaches that block to the visitor's own message, and the contract requires the
answer to cite the bracketed number, record id and licence. Retrieved text
cannot change the contract, the scope, the guard or the authority: it is input,
like the question.

Evaluation records are never in the index (`load_index` filters on
`zone == "retrieval"`), so a jailbreak or Juliet fixture cannot become a
retrieved authority. That separation is what lets the same store hold both.

`red corpus licenses` prints the table and the pending decisions.

## Record schema

One JSON object per line, canonical and sorted, with a stable id
(`corpus@version:digest`). Fields: `id`, `corpus`, `corpus_version`, `domain`,
`family`, `input`, `expected_behavior`, `outcome`, `exemplar`, `risk_level`,
`evidence_required`, `scope_requirement`, `split`, `zone`, `role`,
`evaluation_only`, `expected_tool`, `source` (publisher, URL, version, retrieval
date, checksum, transformations), `license`, `retention` (training / retrieval /
evaluation), `contamination` (content digest, dedupe key, duplicates, held-out
overlap) and `notes`.

Invariants that fail validation, among others:

- a `test` or `heldout` record may never be marked for training;
- a `malicious_seed` may never be training material;
- retrieval knowledge may not occupy a test split;
- a held-out record must be `evaluation_only`;
- unmasked email addresses, API keys, private keys, bearer tokens and SSN-shaped
  strings are refused (ingestion masks them to a category marker);
- every record needs at least one evidence requirement and a scope requirement.

## Zones and splits

- `raw` — untouched source, kept for audit;
- `retrieval` — knowledge a prompt may be shown (OWASP, CWE, NVD, ASVS, write-ups);
- `training` — derived material; currently empty, because no fine-tuning has been
  proposed;
- `evaluation` — fixtures a run is scored against (Juliet, XSTest, AdvBench,
  HarmBench, deepset prompt-injections, InjecAgent, the first-party baseline).

`test` and `heldout` are evaluation splits. Four baseline records are `heldout`
and their content digests are pinned in `heldout.lock.json`; `validate` and
`ingest` both refuse a held-out digest in train or dev, and `verify_lock` fails
if a record moves between splits.

## Commands

```powershell
python -m cli.main corpus licenses          # licence state of every source
python -m cli.main corpus validate          # schema, provenance, licence, dedupe, contamination
python -m cli.main corpus schema            # only the record schema
python -m cli.main corpus dedupe            # duplicate ids and duplicate inputs
python -m cli.main corpus contamination     # held-out overlap and lock drift
python -m cli.main corpus ingest --source xstest --raw C:\data\xstest_prompts.csv --out D:\corpora
python -m cli.main corpus baseline          # lexical baseline on the visible test split
python -m cli.main corpus heldout           # the same configuration on the held-out split
python -m cli.main corpus evidence          # verify evidence, audit refs and claims
python -m cli.main corpus prompt-pack       # regress the AI pack's required content
python -m cli.main corpus report --out reports/corpora
```

`--predictions FILE` scores a model run instead of the baseline. A bundle is:

```json
{
  "run": {
    "model": "example-7b", "provider": "local",
    "corpus_versions": {"enigmatic-red-baseline": "1"},
    "prompt_version": "ai-pack-v2", "temperature": 0.0, "seed": 0,
    "capability_config": {"tools": []},
    "allowed_targets": ["lab_owned_model"], "anchor": "lab_owned_model"
  },
  "predictions": [
    {"record_id": "enigmatic-red-baseline@1:...", "outcome": "refused",
     "confidence": 0.8, "evidence": ["refusal transcript", "model and version"],
     "audit_refs": ["17"], "tool": "jailbreak_signals", "target": "lab_owned_model"}
  ],
  "repeated": [{"enigmatic-red-baseline@1:...": "refused"}]
}
```

## Metrics

`benchmark_family_coverage`, `classification_accuracy`, `false_positive_rate`,
`false_negative_rate`, `refusal_appropriateness`, `over_refusal_rate`,
`indirect_injection_detection`, `evidence_citation_correctness`,
`audit_chain_support`, `scope_drift_resistance`, `target_anchor_preservation`,
`tool_selection_correctness`, `false_claim_detection`,
`provenance_completeness`, `run_agreement`, `calibration_brier` (plus ECE), and
per-model/per-temperature accuracy in the breakdown.

A metric with no applicable record is `not tested`, never `0`. A prediction that
errored or could not be parsed is not tested, never wrong; only a usable
prediction enters a denominator.

## Reports

`corpus report` writes `corpus_manifest.{json,md}`, `license_report.md`,
`data_card.md`, `model_evaluation_report.{md,json}`, `reproducibility_report.md`
and, with `--before`, `before_after.md`. `reports/` is gitignored: a report is
produced by a run, not committed as a claim.

## Baseline set

`fixtures/baseline.jsonl` is 15 first-party records: prompt injection, indirect
injection, jailbreak, system-prompt extraction, retrieval leakage, output
handling, excessive agency, over-refusal controls, code classification and a
"not tested" report control. Eleven are visible `test` records; four are
`heldout`. It is small on purpose — it checks the evaluator, not a model's
quality, and a model run should be compared against the lexical baseline rather
than against nothing.

Regenerate both files together after an authored edit:

```powershell
python -m cli.main corpus baseline --write-fixtures --write-lock
```

## Fine-tuning

Retrieval and prompt/evaluation improvements come first. If fine-tuning is ever
proposed it needs a separate architecture and cost review covering model role,
dataset size, licensing, contamination, catastrophic forgetting, release
reproducibility and rollback — and it must not weaken the guard, scope,
authorisation or audit controls. No dataset in this repository is training-ready,
and `retention.training` is false for every shipped record.
