"""The versioned description of every corpus, and the gate in front of it.

This module holds no corpus text. It holds the facts a reviewer needs before a
corpus may be read: who published it, where, at which version, when it was
retrieved, under what licence, whether that licence permits redistribution, what
the ingestion is allowed to do to it, and which partition it belongs to.

Three states are possible, and only one of them is usable:

``verified``
    The licence was read at the recorded URL on the recorded date. Ingestion may
    proceed, subject to the licence's redistribution flag.
``review_required``
    Somebody has to read the licence first. Ingestion refuses with the basis the
    reviewer must record, rather than guessing.
``blocked``
    The licence may permit use, but the artefact could not be lawfully or
    practically obtained (an interactive download, a gated distribution). The
    basis records the reason, so the source is visibly blocked rather than
    silently missing.
``incompatible``
    The licence forbids what the role would do with the text. Refused outright.

Keeping the gate here, in data rather than in code, is what makes the decision
reviewable: a diff to ``registry.yaml`` is a change to what the project is
allowed to ingest, and it is visible in review.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

import yaml

from corpora.schema import (
    DOMAINS,
    LICENSE_REVIEW_STATES,
    RETENTION_KEYS,
    RISK_LEVELS,
    ROLES,
    SCOPE_REQUIREMENTS,
    ZONES,
    License,
    Retention,
)

__all__ = [
    "FIRST_PARTY",
    "REGISTRY_PATH",
    "ManifestError",
    "Registry",
    "Source",
    "load_registry",
]

#: The publisher string first-party records carry. A record authored here is
#: still provenance-bearing: it says so, and its checksum is the digest of the
#: authored input rather than of somebody else's archive.
FIRST_PARTY = "Enigmatic Red"

REGISTRY_PATH = Path(__file__).with_name("registry.yaml")

#: Formats the ingestion reader understands. ``operator-supplied`` is a source
#: whose export format the operator records at ingest time; it is refused until
#: the manifest names one of the concrete formats, because "we will work it out"
#: is how a corpus gets read as the wrong column. ``nvd-json`` is the NVD 2.0
#: feed's own shape: a ``vulnerabilities`` array whose descriptions, dates and
#: weaknesses are nested, which a flat reader would read as empty columns.
FORMATS = (
    "csv",
    "jsonl",
    "json",
    "nvd-json",
    "markdown-dir",
    "code-dir",
    "operator-supplied",
)

#: Which zone each record role may be ingested into. A reference is knowledge a
#: prompt may be shown; an attack seed or a safe control is an evaluation
#: fixture. There is no training role yet, which is why there is no training
#: zone here - the project has not proposed fine-tuning.
ZONE_FOR_ROLE = {
    "reference": "retrieval",
    "malicious_seed": "evaluation",
    "safe_control": "evaluation",
}


class ManifestError(ValueError):
    """The registry does not permit what was asked of it, and says why."""


@dataclass(frozen=True)
class Source:
    """One registered corpus, as the manifest describes it."""

    name: str
    title: str
    publisher: str
    url: str
    version: str
    retrieved: str
    license: License
    review_state: str
    review_basis: str
    domain: str
    role: str
    zones: tuple[str, ...]
    families: tuple[str, ...]
    format: str
    text_field: str
    id_field: str
    label_field: str
    label_map: Mapping[str, str]
    evaluation_only: bool
    chronological: bool
    sha256: str
    transformations: tuple[str, ...]
    retention: Retention
    scope_requirement: str
    risk_level: str
    notes: str = ""
    expected_tool: str = ""

    def split_for_role(self) -> str:
        """The split an ingested record starts in, before chronological ordering.

        An evaluation source is a test split; retrieval knowledge is not a test
        case at all and starts as ``train`` with training withheld. The held-out
        set is the baseline corpus's, and no ingest can produce it.
        """
        return "test" if self.role in ("malicious_seed", "safe_control") else "train"

    def problems(self) -> tuple[str, ...]:
        """What stops this source being ingested. Empty means it may proceed."""
        problems: list[str] = []
        if self.review_state not in LICENSE_REVIEW_STATES:
            problems.append(f"{self.name}: unknown review state {self.review_state!r}")
        elif self.review_state == "review_required":
            problems.append(
                f"{self.name}: licence review required before ingestion - {self.review_basis}"
            )
        elif self.review_state == "blocked":
            problems.append(
                f"{self.name}: acquisition is blocked - {self.review_basis}"
            )
        elif self.review_state == "incompatible":
            problems.append(f"{self.name}: licence is incompatible - {self.review_basis}")
        if not self.review_basis.strip():
            problems.append(f"{self.name}: no licence review basis is recorded")
        if self.license.id.strip().lower() in ("", "unverified", "unknown"):
            problems.append(
                f"{self.name}: no licence identifier is recorded, so it cannot be verified"
            )
        if not self.license.url.startswith("https://"):
            problems.append(f"{self.name}: licence URL is not https")
        if self.domain not in DOMAINS:
            problems.append(f"{self.name}: unknown domain {self.domain!r}")
        if self.role not in ROLES:
            problems.append(f"{self.name}: unknown role {self.role!r}")
        if self.role not in ZONE_FOR_ROLE:
            problems.append(f"{self.name}: role {self.role!r} has no ingestion zone")
        for zone in self.zones:
            if zone not in ZONES:
                problems.append(f"{self.name}: unknown zone {zone!r}")
        if self.format not in FORMATS:
            problems.append(f"{self.name}: unknown format {self.format!r}")
        if self.format == "operator-supplied":
            problems.append(
                f"{self.name}: the export format is operator-supplied; record a concrete "
                "format and its text column in registry.yaml before ingestion"
            )
        if not self.families:
            problems.append(f"{self.name}: no behaviour family is declared")
        if self.risk_level not in RISK_LEVELS:
            problems.append(f"{self.name}: unknown risk level {self.risk_level!r}")
        if self.scope_requirement not in SCOPE_REQUIREMENTS:
            problems.append(
                f"{self.name}: unknown scope requirement {self.scope_requirement!r}"
            )
        if self.split_for_role() in ("test", "heldout") and self.retention.training:
            problems.append(f"{self.name}: an evaluation source is marked for training")
        if self.role == "malicious_seed" and self.retention.training:
            problems.append(f"{self.name}: a malicious-seed source is marked for training")
        if not self.transformations:
            problems.append(f"{self.name}: no ingestion transformation is recorded")
        return tuple(problems)

    def as_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "title": self.title,
            "publisher": self.publisher,
            "url": self.url,
            "version": self.version,
            "retrieved": self.retrieved,
            "license": self.license.as_dict(),
            "review": {"state": self.review_state, "basis": self.review_basis},
            "domain": self.domain,
            "role": self.role,
            "zones": list(self.zones),
            "families": list(self.families),
            "format": self.format,
            "text_field": self.text_field,
            "id_field": self.id_field,
            "label_field": self.label_field,
            "label_map": dict(self.label_map),
            "evaluation_only": self.evaluation_only,
            "chronological": self.chronological,
            "sha256": self.sha256,
            "transformations": list(self.transformations),
            "retention": self.retention.as_dict(),
            "scope_requirement": self.scope_requirement,
            "risk_level": self.risk_level,
            "expected_tool": self.expected_tool,
            "notes": self.notes,
        }


@dataclass(frozen=True)
class Registry:
    """Every source, at one manifest version, plus the questions asked of it."""

    schema_version: int
    reviewed_on: str
    sources: tuple[Source, ...]

    def by_name(self, name: str) -> Source:
        for source in self.sources:
            if source.name == name:
                return source
        known = ", ".join(source.name for source in self.sources)
        raise ManifestError(f"unknown corpus {name!r}: the registry names {known}")

    def problems(self) -> tuple[str, ...]:
        """Every source's problems, flattened. An empty tuple is a usable registry."""
        found: list[str] = []
        seen: set[str] = set()
        for source in self.sources:
            if source.name in seen:
                found.append(f"{source.name}: the name is registered twice")
            seen.add(source.name)
            found.extend(source.problems())
        return tuple(found)

    def license_rows(self) -> tuple[dict[str, Any], ...]:
        """One row per source, in the shape the licence report prints."""
        return tuple(
            {
                "corpus": source.name,
                "publisher": source.publisher,
                "version": source.version,
                "retrieved": source.retrieved,
                "license": source.license.id,
                "license_url": source.license.url,
                "redistribution": source.license.redistribution,
                "attribution_required": source.license.attribution_required,
                "review": source.review_state,
                "role": source.role,
                "note": source.review_basis,
            }
            for source in self.sources
        )

    def as_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "reviewed_on": self.reviewed_on,
            "sources": [source.as_dict() for source in self.sources],
        }


def _license(raw: Mapping[str, Any], corpus: str) -> License:
    try:
        return License.from_mapping(raw)
    except Exception as exc:  # SchemaError names the key; add the corpus.
        raise ManifestError(f"{corpus}: {exc}") from None


def _source(raw: Mapping[str, Any]) -> Source:
    name = str(raw.get("name", "")).strip()
    if not name:
        raise ManifestError("a source has no name")
    required = (
        "title",
        "publisher",
        "url",
        "version",
        "retrieved",
        "license",
        "review",
        "domain",
        "role",
        "families",
        "format",
        "risk_level",
        "scope_requirement",
        "transformations",
    )
    missing = [key for key in required if key not in raw]
    if missing:
        raise ManifestError(f"{name}: missing {', '.join(missing)}")
    review = raw["review"]
    retention = raw.get("retention", {})
    return Source(
        name=name,
        title=str(raw["title"]).strip(),
        publisher=str(raw["publisher"]).strip(),
        url=str(raw["url"]).strip(),
        version=str(raw["version"]).strip(),
        retrieved=str(raw["retrieved"]).strip(),
        license=_license(raw["license"], name),
        review_state=str(review.get("state", "")).strip(),
        review_basis=str(review.get("basis", "")).strip(),
        domain=str(raw["domain"]).strip(),
        role=str(raw["role"]).strip(),
        zones=tuple(str(item) for item in raw.get("zones", ())),
        families=tuple(str(item) for item in raw["families"]),
        format=str(raw["format"]).strip(),
        text_field=str(raw.get("text_field", "input")).strip(),
        id_field=str(raw.get("id_field", "")).strip(),
        label_field=str(raw.get("label_field", "label")).strip(),
        label_map={
            str(key): str(value) for key, value in dict(raw.get("label_map", {})).items()
        },
        evaluation_only=bool(raw.get("evaluation_only", False)),
        chronological=bool(raw.get("chronological", False)),
        sha256=str(raw.get("sha256", "")).strip(),
        transformations=tuple(str(item) for item in raw["transformations"]),
        retention=Retention(
            training=bool(retention.get("training", False)),
            retrieval=bool(retention.get("retrieval", False)),
            evaluation=bool(retention.get("evaluation", True)),
        ),
        scope_requirement=str(raw["scope_requirement"]).strip(),
        risk_level=str(raw["risk_level"]).strip(),
        notes=str(raw.get("notes", "")).strip(),
        expected_tool=str(raw.get("expected_tool", "")).strip(),
    )


def load_registry(path: Path | None = None) -> Registry:
    """Read and structurally validate the manifest.

    Raises:
        ManifestError: on a malformed file or a source missing a required key.
            ``problems()`` is for the *policy* answer; this is for "the file does
            not parse", which must never look like "no sources".
    """
    location = Path(path) if path is not None else REGISTRY_PATH
    try:
        raw = yaml.safe_load(location.read_text(encoding="utf-8"))
    except OSError as exc:
        raise ManifestError(f"cannot read {location}: {exc}") from None
    except yaml.YAMLError as exc:
        raise ManifestError(f"{location} is not valid YAML: {exc}") from None
    if not isinstance(raw, dict) or not isinstance(raw.get("sources"), list):
        raise ManifestError(f"{location} must hold a mapping with a 'sources' list")
    sources = tuple(_source(item) for item in raw["sources"])
    return Registry(
        schema_version=int(raw.get("schema_version", 1)),
        reviewed_on=str(raw.get("reviewed_on", "")),
        sources=sources,
    )

