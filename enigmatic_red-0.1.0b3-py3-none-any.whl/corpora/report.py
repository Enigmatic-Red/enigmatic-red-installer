"""The six artefacts a corpus release has to produce.

:func:`corpus_manifest`
    Every source, version, licence, review state, checksum and transformation,
    plus what was actually ingested.
:func:`license_report`
    One row per source: the licence, whether redistribution is permitted, and
    the basis the reviewer recorded. A ``review_required`` row is printed as a
    pending decision, not as a pass.
:func:`data_card`
    What the corpus is for, what it must not be used for, how the partitions
    divide, and what its limits are.
:func:`evaluation_report`
    Every metric with its denominator and status, the run metadata, and the
    records that were not tested.
:func:`reproducibility_report`
    The exact configuration a result was produced under, the corpus versions,
    and whether repeated runs agreed.
:func:`before_after`
    Two reports side by side, per metric, with *not tested* propagated rather
    than shown as zero.

They are Markdown because a report is read, and JSON beside it because a report
is also compared. Nothing here prints corpus text: a record is named by id.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

from corpora.manifest import Registry, load_registry
from corpora.schema import Record

__all__ = [
    "before_after",
    "corpus_manifest",
    "data_card",
    "evaluation_report",
    "license_report",
    "reproducibility_report",
    "write_reports",
]


def _counts(values: Iterable[str]) -> dict[str, int]:
    found: dict[str, int] = {}
    for value in values:
        found[value] = found.get(value, 0) + 1
    return dict(sorted(found.items()))


def corpus_manifest(
    registry: Registry | None = None,
    records: Iterable[Record] = (),
    ingestions: Sequence[Mapping[str, Any]] = (),
) -> dict[str, Any]:
    """The machine-readable manifest: sources first, then what was written."""
    catalogue = registry or load_registry()
    rows = list(records)
    return {
        "schema_version": catalogue.schema_version,
        "registry_reviewed_on": catalogue.reviewed_on,
        "sources": [source.as_dict() for source in catalogue.sources],
        "ingested": list(ingestions),
        "records": {
            "total": len(rows),
            "by_corpus": _counts(record.corpus for record in rows),
            "by_split": _counts(record.split for record in rows),
            "by_role": _counts(record.role for record in rows),
            "by_family": _counts(record.family for record in rows),
        },
    }


def corpus_manifest_markdown(payload: Mapping[str, Any]) -> str:
    lines = [
        "# Corpus manifest",
        "",
        f"- schema version: {payload['schema_version']}",
        f"- registry reviewed: {payload['registry_reviewed_on']}",
        f"- sources registered: {len(payload['sources'])}",
        f"- records ingested: {payload['records']['total']}",
        "",
        "| corpus | version | role | licence | review | redistribution | sha256 |",
        "| --- | --- | --- | --- | --- | --- | --- |",
    ]
    for source in payload["sources"]:
        lines.append(
            "| {name} | {version} | {role} | {license} | {review} | {redistribution} | {sha} |".format(
                name=source["name"],
                version=source["version"],
                role=source["role"],
                license=source["license"]["id"],
                review=source["review"]["state"],
                redistribution="yes" if source["license"]["redistribution"] else "no",
                sha=(source["sha256"][:16] + "...") if source["sha256"] else "unpinned",
            )
        )
    lines.extend(["", "## Records", ""])
    for key in ("by_corpus", "by_split", "by_role", "by_family"):
        values = payload["records"][key]
        lines.append(f"- **{key}**: " + (", ".join(f"{k}={v}" for k, v in values.items()) or "none"))
    return "\n".join(lines) + "\n"



def license_report(registry: Registry | None = None) -> str:
    """One row per source, with the decision and its basis printed plainly."""
    catalogue = registry or load_registry()
    rows = catalogue.license_rows()
    lines = [
        "# Licence report",
        "",
        "A `review_required` row is a decision still to be taken, not a permission. "
        "Ingestion refuses it until a reviewer records the licence and its basis.",
        "",
        "| corpus | publisher | licence | redistribution | review | basis |",
        "| --- | --- | --- | --- | --- | --- |",
    ]
    for row in rows:
        lines.append(
            "| {corpus} | {publisher} | [{license}]({license_url}) | {redistribution} | "
            "{review} | {note} |".format(
                corpus=row["corpus"],
                publisher=row["publisher"].replace("|", "/"),
                license=row["license"],
                license_url=row["license_url"],
                redistribution="permitted" if row["redistribution"] else "not permitted",
                review=row["review"],
                note=str(row["note"]).replace("|", "/"),
            )
        )
    pending = [row["corpus"] for row in rows if row["review"] != "verified"]
    lines.extend(
        [
            "",
            "## Summary",
            "",
            f"- verified: {len(rows) - len(pending)}",
            f"- awaiting review: {len(pending)}" + (f" ({', '.join(pending)})" if pending else ""),
            "- third-party corpus text is written to the operator's data directory, "
            "never into this repository or a release",
        ]
    )
    return "\n".join(lines) + "\n"


def data_card(
    records: Iterable[Record] = (),
    registry: Registry | None = None,
) -> str:
    """The card a reader needs before using the corpus for anything."""
    catalogue = registry or load_registry()
    rows = list(records)
    splits = _counts(record.split for record in rows)
    roles = _counts(record.role for record in rows)
    families = _counts(record.family for record in rows)
    licences = _counts(record.license.id for record in rows)
    pending = [
        source.name for source in catalogue.sources if source.review_state != "verified"
    ]
    contaminated = sum(1 for record in rows if record.contamination.overlaps_heldout)
    trainable = sum(1 for record in rows if record.retention.training)

    lines = [
        "# Data card",
        "",
        "## What this is",
        "",
        "A versioned, normalised corpus set for measuring a defensive AI-security "
        "assistant: prompt injection, indirect injection, jailbreak resistance, "
        "system-prompt extraction, retrieval leakage, insecure output handling and "
        "excessive agency, plus code-vulnerability classification controls.",
        "",
        "## Intended use",
        "",
        "- evaluation and regression testing of refusal, detection and evidence discipline;",
        "- retrieval knowledge for OWASP, CWE, NVD and ASVS material;",
        "- comparison of models and temperatures under the same prompt and corpus versions.",
        "",
        "## Not intended for",
        "",
        "- training or fine-tuning. A ``malicious_seed`` is never training material, and "
        "the held-out split is never a prompt, retrieval block or gradient step;",
        "- producing operational attack instructions. The corpora are measurement "
        "inputs, and a refusal is a valid result;",
        "- any real target. A probe runs only against a model the operator owns or a "
        "target inside a signed scope.",
        "",
        "## Composition",
        "",
        f"- records: {len(rows)}",
        f"- trainable: {trainable} (fine-tuning has not been proposed)",
        f"- held-out overlap: {contaminated}",
        "- splits: " + (", ".join(f"{k}={v}" for k, v in splits.items()) or "none"),
        "- roles: " + (", ".join(f"{k}={v}" for k, v in roles.items()) or "none"),
        "- families: " + (", ".join(f"{k}={v}" for k, v in families.items()) or "none"),
        "- licences: " + (", ".join(f"{k}={v}" for k, v in licences.items()) or "none"),
        "",
        "## Known limits",
        "",
        "- The baseline set is small and first-party. It checks the evaluator; it is "
        "not a leaderboard and cannot support a claim about a model in general.",
        "- A lexical detector has a false-positive rate on ordinary prose that mentions "
        "prompt injection; a rate from this corpus is a screen, not a verdict.",
        "- A refusal is classified by its opening; a compliant answer that opens with a "
        "partial refusal can be miscounted.",
        "- Sources awaiting review are listed in the licence report and are not ingested.",
        "",
        "## Provenance",
        "",
        f"- registry sources: {len(catalogue.sources)}",
        f"- verified: {len(catalogue.sources) - len(pending)}",
        f"- awaiting review: {len(pending)}" + (f" ({', '.join(pending)})" if pending else ""),
        "- every record carries publisher, URL, version, retrieval date, licence, "
        "checksum and the transformations applied",
    ]
    return "\n".join(lines) + "\n"



def evaluation_report(report: Any) -> str:
    """Every metric, with its denominator and status. ``not tested`` is printed."""
    payload = report.as_dict()
    run = payload["run"]
    lines = [
        "# Model evaluation report",
        "",
        "| field | value |",
        "| --- | --- |",
        f"| model | `{run['model']}` |",
        f"| provider | `{run['provider'] or 'unspecified'}` |",
        f"| prompt version | `{run['prompt_version']}` |",
        f"| temperature | {run['temperature']} |",
        f"| seed | {run['seed']} |",
        "| corpus versions | "
        + ", ".join(f"`{k}` {v}" for k, v in sorted(run["corpus_versions"].items()))
        + " |",
        f"| records selected | {payload['records']} |",
        f"| not tested | {payload['not_tested']} |",
        "",
        "| metric | value | numerator | denominator | status | note |",
        "| --- | --- | --- | --- | --- | --- |",
    ]
    for metric in payload["metrics"]:
        value = "not tested" if metric["value"] is None else f"{metric['value']:.3f}"
        lines.append(
            f"| {metric['name']} | {value} | {metric['numerator']} | "
            f"{metric['denominator']} | {metric['status']} | {metric['note']} |"
        )
    gaps = payload["breakdown"].get("coverage_gaps") or []
    untested = payload["breakdown"].get("not_tested_record_ids") or []
    lines.extend(
        [
            "",
            "## What was not measured",
            "",
            "- families with no scored record: " + (", ".join(gaps) if gaps else "none"),
            f"- records not tested: {len(untested)}"
            + (f" ({', '.join(untested)})" if untested else ""),
            "- a metric with denominator 0 is `not tested`, never `0`",
            "",
            "## Calibration",
            "",
            f"- expected calibration error: {payload['breakdown'].get('calibration_ece')}",
            "",
            "## Configuration",
            "",
            "```json",
            json.dumps(run["capability_config"], indent=2, sort_keys=True),
            "```",
        ]
    )
    return "\n".join(lines) + "\n"


def reproducibility_report(report: Any, repeated: int = 0) -> str:
    """What a second run needs in order to be the same run."""
    payload = report.as_dict()
    run = payload["run"]
    agreement = next(
        (metric for metric in payload["metrics"] if metric["name"] == "run_agreement"), None
    )
    lines = [
        "# Reproducibility report",
        "",
        "- This report describes one configuration. A different temperature, seed, "
        "prompt version or corpus version is a different run and must not be compared "
        "as if it were a repeat.",
        "",
        "| field | value |",
        "| --- | --- |",
        f"| model | `{run['model']}` |",
        f"| provider | `{run['provider'] or 'unspecified'}` |",
        f"| prompt version | `{run['prompt_version']}` |",
        f"| temperature | {run['temperature']} |",
        f"| seed | {run['seed']} |",
        f"| capability config | `{json.dumps(run['capability_config'], sort_keys=True)}` |",
        "| corpus versions | "
        + ", ".join(f"`{k}` {v}" for k, v in sorted(run["corpus_versions"].items()))
        + " |",
        "",
        "## Repeat agreement",
        "",
    ]
    if agreement and agreement["status"] == "measured":
        lines.append(
            f"- repeated runs supplied: {repeated}; outcome agreement "
            f"{agreement['numerator']}/{agreement['denominator']} "
            f"({agreement['value']:.3f})"
        )
    else:
        lines.append(
            "- no repeated run was supplied, so agreement is **not tested**. A single "
            "run says nothing about variance."
        )
    lines.extend(
        [
            "",
            "## What makes this repeatable",
            "",
            "- the corpus set digest and every record id are stable and pinned;",
            "- ingestion is deterministic and writes byte-identical JSONL;",
            "- the baseline predictor is lexical and keyless, so its number is a floor;",
            "- a model run reports its model, provider, prompt version, temperature, "
            "seed and capability configuration with every result.",
        ]
    )
    return "\n".join(lines) + "\n"

# __APPEND__


def before_after(
    before: Any, after: Any, *, labels: tuple[str, str] = ("before", "after")
) -> str:
    """Two reports, per metric, with *not tested* propagated rather than zeroed."""
    left, right = before.as_dict(), after.as_dict()
    left_metrics = {metric["name"]: metric for metric in left["metrics"]}
    right_metrics = {metric["name"]: metric for metric in right["metrics"]}
    lines = [
        "# Before / after",
        "",
        f"| metric | {labels[0]} | {labels[1]} | delta |",
        "| --- | --- | --- | --- |",
    ]

    def show(metric: Mapping[str, Any]) -> str:
        if not metric or metric.get("status") != "measured":
            return "not tested"
        return f"{metric['value']:.3f} ({metric['numerator']}/{metric['denominator']})"

    for name in sorted(set(left_metrics) | set(right_metrics)):
        one = left_metrics.get(name, {})
        two = right_metrics.get(name, {})
        if one.get("status") == "measured" and two.get("status") == "measured":
            delta = f"{two['value'] - one['value']:+.3f}"
        else:
            delta = "not comparable"
        lines.append(f"| {name} | {show(one)} | {show(two)} | {delta} |")
    lines.extend(
        [
            "",
            f"- {labels[0]}: `{left['run']['model']}` temperature "
            f"{left['run']['temperature']} seed {left['run']['seed']}",
            f"- {labels[1]}: `{right['run']['model']}` temperature "
            f"{right['run']['temperature']} seed {right['run']['seed']}",
            "- a delta is only meaningful where both runs used the same corpus and "
            "prompt versions",
        ]
    )
    return "\n".join(lines) + "\n"


def write_reports(
    directory: Path,
    *,
    registry: Registry | None = None,
    records: Iterable[Record] = (),
    ingestions: Sequence[Mapping[str, Any]] = (),
    report: Any | None = None,
    before: Any | None = None,
    repeated: int = 0,
) -> tuple[Path, ...]:
    """Write every artefact that applies, and return the paths in order."""
    out = Path(directory)
    out.mkdir(parents=True, exist_ok=True)
    catalogue = registry or load_registry()
    rows = list(records)
    written: list[Path] = []

    manifest = corpus_manifest(catalogue, rows, ingestions)
    (out / "corpus_manifest.json").write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    written.append(out / "corpus_manifest.json")
    (out / "corpus_manifest.md").write_text(
        corpus_manifest_markdown(manifest), encoding="utf-8", newline="\n"
    )
    written.append(out / "corpus_manifest.md")

    for name, body in (
        ("license_report.md", license_report(catalogue)),
        ("data_card.md", data_card(rows, catalogue)),
    ):
        (out / name).write_text(body, encoding="utf-8", newline="\n")
        written.append(out / name)

    if report is not None:
        for name, body in (
            ("model_evaluation_report.md", evaluation_report(report)),
            ("reproducibility_report.md", reproducibility_report(report, repeated)),
        ):
            (out / name).write_text(body, encoding="utf-8", newline="\n")
            written.append(out / name)
        (out / "model_evaluation_report.json").write_text(
            json.dumps(report.as_dict(), indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
            newline="\n",
        )
        written.append(out / "model_evaluation_report.json")

    if before is not None and report is not None:
        (out / "before_after.md").write_text(
            before_after(before, report), encoding="utf-8", newline="\n"
        )
        written.append(out / "before_after.md")

    return tuple(written)

