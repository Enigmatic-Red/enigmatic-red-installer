"""Measure the local ranker against a labelled, synthetic retrieval set.

This is the retrieval half of the offline baseline. It answers one question -
*did the ranker change put a record a reviewer would call relevant in front of
the model?* - and answers it with counts, not adjectives.

The records below are **authored here for this evaluation**. They imitate the
shape of WSTG, ASVS, CWE and NVD records (short guidance, a requirement, a
weakness definition, a long CVE description) without copying any publisher's
text, so the set is licence-free, tiny, and cannot drift with a corpus update.
It is not a model benchmark and it is not a training set: nothing here is
ingested, retrieved at run time, or shipped in a prompt.

Two rankers are measured over the same records:

``baseline``
    the ranker this module was added beside - exact-token overlap, no inverse
    document frequency, no length normalisation, no diversity. Reproduced here
    from twelve lines so the comparison is honest rather than remembered.
``current``
    :func:`corpora.retrieval.search`, which splits compound terms, scores with
    BM25 and prefers a second corpus over a third near-identical record.

The metrics are micro-averaged over the labelled queries: precision@k, recall@k
and hit@k, each with the numerator and denominator it came from. Citation
completeness is a separate check - every hit must carry publisher, version,
URL, record id and licence - because a result a reader cannot check is not a
retrieval result.

    python -m corpora.retrieval_eval
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass
from typing import Callable, Iterable, Mapping, Sequence

from corpora.retrieval import (
    Reference,
    ReferenceIndex,
    _excerpt,
    _tokens,
    search,
)
from corpora.schema import Contamination, License, Record, Retention, SourceRef

__all__ = [
    "CASES",
    "CORPORA",
    "LIMIT",
    "Case",
    "case_index",
    "evaluate",
    "report",
    "run",
]

#: One answer is three records - the same default the chat and planner paths
#: use. A change to that default changes what the evaluation measures.
LIMIT = 3

#: The four corpora the fixture imitates, with the metadata every citation needs.
CORPORA: dict[str, tuple[str, str, str, str]] = {
    "demo-wstg": (
        "Demo Web Security Testing Guide",
        "OWASP Foundation",
        "https://owasp.org/www-project-web-security-testing-guide/",
        "CC-BY-SA-4.0",
    ),
    "demo-asvs": (
        "Demo Application Security Verification Standard",
        "OWASP Foundation",
        "https://github.com/OWASP/ASVS",
        "CC-BY-SA-4.0",
    ),
    "demo-cwe": (
        "Demo Common Weakness Enumeration",
        "The MITRE Corporation",
        "https://cwe.mitre.org/",
        "CC-BY-4.0",
    ),
    "demo-nvd": (
        "Demo National Vulnerability Database",
        "NIST",
        "https://nvd.nist.gov/",
        "CC0-1.0",
    ),
}

#: ``(id, corpus, title/input, excerpt)``. Deliberately terse: enough text to
#: carry a label, not enough to look like a real reference document.
_RECORDS: tuple[tuple[str, str, str, str], ...] = (
    (
        "wstg-sqli",
        "demo-wstg",
        "Testing for SQL Injection",
        "Identify SQL injection points by sending metacharacters and observing how the "
        "application handles them. Test every input that reaches a query, including "
        "hidden fields and cookies. Prefer parameterised queries and least privilege.",
    ),
    (
        "cwe-89",
        "demo-cwe",
        "CWE-89: SQL Injection",
        "The software constructs all or part of an SQL command using externally "
        "influenced input, so the structure of the query can be changed.",
    ),
    (
        "asvs-validation",
        "demo-asvs",
        "V5.3 Input Validation",
        "Verify that input validation is enforced on a trusted service layer and that "
        "queries are parameterised rather than concatenated with input.",
    ),
    (
        "wstg-csrf",
        "demo-wstg",
        "Testing for Cross Site Request Forgery",
        "Check that state-changing requests carry an anti-CSRF token tied to the "
        "session, and that the token is verified before the action is performed.",
    ),
    (
        "cwe-352",
        "demo-cwe",
        "CWE-352: Cross-Site Request Forgery (CSRF)",
        "The web application does not verify that a well-formed request was "
        "intentionally provided by the user who submitted it.",
    ),
    (
        "asvs-csrf",
        "demo-asvs",
        "V3.5 Request Forgery Prevention",
        "Verify that the application checks a per-session token for state-changing "
        "requests, or uses another mechanism that proves user intent.",
    ),
    (
        "nvd-csrf-one",
        "demo-nvd",
        "CVE-2025-1001: CSRF in a web console",
        "A cross-site request forgery issue in the vendor web console allows a remote "
        "attacker to change configuration when an authenticated administrator visits a "
        "crafted page. The vendor states that the product is a server appliance and "
        "that the vulnerability requires user interaction. The issue affects versions "
        "before 4.2.1 and a firmware update is available. The vulnerability has a "
        "network attack vector and low complexity according to the published score. "
        "The product is widely deployed in enterprise networks and the vendor "
        "recommends that administrators review server configuration after upgrading.",
    ),
    (
        "nvd-csrf-two",
        "demo-nvd",
        "CVE-2025-1002: CSRF in a management portal",
        "A cross-site request forgery issue in the management portal allows a remote "
        "attacker to add an administrator account when an authenticated administrator "
        "visits a crafted page. The vendor states that the product is a server "
        "appliance and that the vulnerability requires user interaction. The issue "
        "affects versions before 2.8.0 and a firmware update is available. The "
        "vulnerability has a network attack vector and low complexity according to the "
        "published score. The product is widely deployed in enterprise networks and the "
        "vendor recommends that administrators review server configuration after "
        "upgrading.",
    ),
    (
        "nvd-csrf-three",
        "demo-nvd",
        "CVE-2025-1003: CSRF in a device console",
        "A cross-site request forgery issue in the device console allows a remote "
        "attacker to disable logging when an authenticated administrator visits a "
        "crafted page. The vendor states that the product is a server appliance and "
        "that the vulnerability requires user interaction. The issue affects versions "
        "before 1.9.4 and a firmware update is available. The vulnerability has a "
        "network attack vector and low complexity according to the published score. "
        "The product is widely deployed in enterprise networks and the vendor "
        "recommends that administrators review server configuration after upgrading.",
    ),
    (
        "wstg-traversal",
        "demo-wstg",
        "Testing for Path Traversal",
        "Attempt to read files outside the intended directory using dot-dot-slash "
        "sequences and encoded variants. Confirm that the application resolves the "
        "canonical path before opening a file.",
    ),
    (
        "cwe-22",
        "demo-cwe",
        "CWE-22: Path Traversal",
        "The software uses external input to construct a pathname that should be "
        "within a restricted directory, but it does not neutralise dot-dot-slash "
        "sequences.",
    ),
    (
        "wstg-session",
        "demo-wstg",
        "Testing for Session Fixation",
        "Check whether the session identifier changes after authentication. A session "
        "identifier accepted from the client before login must not survive the login.",
    ),
    (
        "cwe-384",
        "demo-cwe",
        "CWE-384: Session Fixation",
        "Authenticating a user, or otherwise establishing a new user session, without "
        "invalidating an existing session identifier can expose the application to "
        "session fixation.",
    ),
    (
        "asvs-session",
        "demo-asvs",
        "V3.2 Session Binding",
        "Verify that a new session identifier is generated after authentication and "
        "that the previous identifier is invalidated.",
    ),
    (
        "wstg-auth",
        "demo-wstg",
        "Testing for Authentication",
        "Verify that authentication mechanisms cannot be bypassed, that credentials "
        "are never sent over plain HTTP, and that default accounts are removed.",
    ),
    (
        "cwe-287",
        "demo-cwe",
        "CWE-287: Improper Authentication",
        "When an actor claims to have a given identity, the software does not prove or "
        "insufficiently proves that the claim is correct.",
    ),
    (
        "wstg-credentials",
        "demo-wstg",
        "Testing for Hard-coded Credentials",
        "Search the code and configuration for credentials embedded in source, build "
        "artefacts and container images. Prefer a secret store to a literal value.",
    ),
    (
        "cwe-798",
        "demo-cwe",
        "CWE-798: Use of Hard-coded Credentials",
        "The software contains hard-coded credentials, such as a password or "
        "cryptographic key, which it uses for its own inbound authentication or "
        "outbound communication to external components.",
    ),
    (
        "wstg-access",
        "demo-wstg",
        "Testing for Broken Access Control",
        "Verify that every request is authorised against the user's role and the "
        "object being accessed. Try a lower-privileged session against a higher-"
        "privileged endpoint and record the response.",
    ),
    (
        "asvs-access",
        "demo-asvs",
        "V4 Access Control",
        "Verify that access control is enforced on a trusted service layer and that a "
        "user cannot access another user's object by changing an identifier.",
    ),
    (
        "wstg-tls",
        "demo-wstg",
        "Testing for Weak Transport Layer Security",
        "Check the negotiated protocol version and cipher suites, the certificate "
        "chain, and whether the server accepts a downgrade. Prefer TLS 1.3 or TLS 1.2 "
        "with forward secrecy.",
    ),
    (
        "asvs-tls",
        "demo-asvs",
        "V9.1 TLS Configuration",
        "Verify that only strong protocols and cipher suites are enabled and that the "
        "certificate is valid and correctly chained.",
    ),
    (
        "nvd-nginx",
        "demo-nvd",
        "CVE-2025-2001: nginx request smuggling",
        "A request smuggling issue in nginx before 1.27.2 allows an attacker to poison "
        "a shared connection between the proxy and an upstream server. The vendor "
        "states that the vulnerability affects configurations that use the proxy_pass "
        "directive with a specific transfer encoding, and that a configuration change "
        "mitigates the issue. The published score describes a network attack vector "
        "and high complexity. Administrators of the affected server version should "
        "upgrade to 1.27.2.",
    ),
    (
        "nvd-openssl",
        "demo-nvd",
        "CVE-2025-2002: OpenSSL certificate verification",
        "A certificate verification issue in OpenSSL before 3.3.2 allows an attacker "
        "to present a certificate chain that is accepted when it should be rejected. "
        "The vendor states that the vulnerability affects applications that enable a "
        "particular verification flag, and that the default configuration is not "
        "affected. The published score describes a network attack vector and high "
        "complexity. A server that uses the affected library version should upgrade.",
    ),
)


@dataclass(frozen=True)
class Case:
    """One labelled query: what a reviewer would accept in three answers."""

    query: str
    relevant: frozenset[str]
    note: str = ""


#: The labelled set. Generic weakness questions expect guidance and a weakness
#: definition; a product/version question expects the advisory. A recent CVE
#: that merely mentions the weakness is *not* labelled relevant to a generic
#: question, which is exactly the crowding the diversity cap addresses.
CASES: tuple[Case, ...] = (
    Case(
        "SQL injection",
        frozenset({"wstg-sqli", "cwe-89"}),
        "generic weakness: guidance and definition; ASVS V5.3 does not name SQL",
    ),
    Case(
        "cross-site request forgery",
        frozenset({"wstg-csrf", "cwe-352", "asvs-csrf"}),
        "compound term spelled with hyphens",
    ),
    Case(
        "test for csrf",
        frozenset({"wstg-csrf", "cwe-352", "asvs-csrf"}),
        "the acronym a practitioner types",
    ),
    Case(
        "path traversal",
        frozenset({"wstg-traversal", "cwe-22"}),
        "generic weakness with only two labelled records",
    ),
    Case(
        "session fixation",
        frozenset({"wstg-session", "cwe-384", "asvs-session"}),
        "session management",
    ),
    Case(
        "hard-coded credentials",
        frozenset({"wstg-credentials", "cwe-798"}),
        "compound term with a hyphen",
    ),
    Case(
        "authentication bypass",
        frozenset({"wstg-auth", "cwe-287"}),
        "authentication",
    ),
    Case(
        "broken access control",
        frozenset({"wstg-access", "asvs-access"}),
        "authorisation",
    ),
    Case(
        "TLS configuration",
        frozenset({"wstg-tls", "asvs-tls"}),
        "transport security",
    ),
    Case(
        "CVE-2025-2001 nginx",
        frozenset({"nvd-nginx"}),
        "product/version question expects the advisory",
    ),
    Case(
        "OpenSSL certificate verification CVE-2025-2002",
        frozenset({"nvd-openssl"}),
        "product/version question expects the advisory",
    ),
)


def _record(identifier: str, corpus: str, title: str, excerpt: str) -> Record:
    """One in-memory record, with the metadata a citation needs and nothing else."""
    source_title, publisher, url, license_id = CORPORA[corpus]
    return Record(
        id=identifier,
        corpus=corpus,
        corpus_version="1",
        domain="web_app",
        family="input_validation",
        input=title,
        expected_behavior="",
        outcome="",
        exemplar=excerpt,
        risk_level="low",
        evidence_required=(),
        scope_requirement="no_live_target",
        split="test",
        zone="retrieval",
        role="reference",
        evaluation_only=False,
        source=SourceRef(
            publisher=publisher,
            url=f"{url.rstrip('/')}/{identifier}",
            version="1",
            retrieved="2026-11-20",
            checksum="",
        ),
        license=License(
            id=license_id,
            url=url,
            redistribution=True,
            attribution_required=True,
            notice=source_title,
        ),
        retention=Retention(training=False, retrieval=True, evaluation=False),
        contamination=Contamination(input_sha256="", dedupe_key=identifier),
    )


def case_index() -> ReferenceIndex:
    """The fixture as the index shape the ranker reads.

    Built with the same statistics :func:`corpora.retrieval.load_index` keeps,
    so a change to the index cannot leave this evaluation measuring an older
    shape than the store it describes.
    """
    return _index_from(tuple(_record(*row) for row in _RECORDS))


def _index_from(records: Sequence[Record]) -> ReferenceIndex:
    titles = {r.id: CORPORA[r.corpus][0] for r in records}
    publishers = {r.id: CORPORA[r.corpus][1] for r in records}
    licenses = {r.id: CORPORA[r.corpus][3] for r in records}
    tokens = {r.id: tuple(_tokens(f"{r.input} {_excerpt(r)}")) for r in records}
    frequencies: dict[str, int] = {}
    distance = 0
    for row in tokens.values():
        distance += len(row)
        for token in set(row):
            frequencies[token] = frequencies.get(token, 0) + 1
    return ReferenceIndex(
        records=records,
        titles=titles,
        publishers=publishers,
        licenses=licenses,
        document_tokens=tokens,
        frequencies=frequencies,
        average_length=(distance / len(records)) if records else 0.0,
    )



# ---------------------------------------------------------------- the baselines
#: The pre-change tokeniser: a compound term stayed one token, so "cross-site"
#: and "cross site" could never meet.
_LEGACY_WORD = re.compile(r"[a-z0-9][a-z0-9_+-]+")


def _legacy_score(query: Sequence[str], document: Sequence[str], title: str) -> float:
    """The ranker this module was added beside, reproduced for comparison."""
    if not query or not document:
        return 0.0
    wanted = set(query)
    counts: dict[str, int] = {}
    for token in document:
        if token in wanted:
            counts[token] = counts.get(token, 0) + 1
    if not counts:
        return 0.0
    heading = set(_LEGACY_WORD.findall(title.lower()))
    score = 0.0
    for token, count in counts.items():
        score += 1.0 + math.log(count)
        if token in heading:
            score += 2.0
    return score


def _legacy_search(index: ReferenceIndex, query: str, limit: int) -> tuple[str, ...]:
    """Top ``limit`` record ids under the pre-change ranker."""
    wanted = _LEGACY_WORD.findall(query.lower())
    scored: list[tuple[float, str]] = []
    for record in index.records:
        document = _LEGACY_WORD.findall(f"{record.input} {_excerpt(record)}".lower())
        score = _legacy_score(
            wanted, document, f"{record.input} {index.titles[record.id]}"
        )
        if score > 0:
            scored.append((score, record.id))
    scored.sort(key=lambda item: (-item[0], item[1]))
    return tuple(identifier for _score, identifier in scored[:limit])


# ------------------------------------------------------------------- measuring
def _micro(counts: Iterable[tuple[int, int]]) -> dict[str, object]:
    """Sum numerators and denominators; ``None`` when nothing was measured."""
    hits = total = 0
    for numerator, denominator in counts:
        hits += numerator
        total += denominator
    if total == 0:
        return {
            "value": None,
            "numerator": 0,
            "denominator": 0,
            "status": "not_tested",
        }
    return {
        "value": round(hits / total, 4),
        "numerator": hits,
        "denominator": total,
        "status": "measured",
    }


def _cites(hit: Reference) -> bool:
    """Whether a hit carries everything a reader needs to follow it."""
    return bool(
        hit.publisher
        and hit.title
        and hit.record.corpus_version
        and hit.record.id
        and hit.license_id
        and hit.url
    )



def evaluate(
    ranker: Callable[[ReferenceIndex, str, int], Sequence[str]],
    *,
    index: ReferenceIndex | None = None,
    cases: Sequence[Case] = CASES,
    limit: int = LIMIT,
) -> dict[str, object]:
    """Micro-averaged precision, recall and hit rate for one ranker.

    ``ranker`` returns the top record ids it would put in the prompt. The
    citation check needs the richer :class:`corpora.retrieval.Reference`, so it
    is measured on the shipped ranker by :func:`run`.
    """
    resolved = index if index is not None else case_index()
    rows: list[dict[str, object]] = []
    precision: list[tuple[int, int]] = []
    recall: list[tuple[int, int]] = []
    hit: list[tuple[int, int]] = []
    for case in cases:
        chosen = tuple(ranker(resolved, case.query, limit))
        found = [identifier for identifier in chosen if identifier in case.relevant]
        rows.append(
            {
                "query": case.query,
                "relevant": sorted(case.relevant),
                "returned": list(chosen),
                "correct": found,
            }
        )
        precision.append((len(found), len(chosen)))
        recall.append((len(found), len(case.relevant)))
        hit.append((1 if found else 0, 1))
    return {
        "queries": len(cases),
        "limit": limit,
        "precision_at_k": _micro(precision),
        "recall_at_k": _micro(recall),
        "hit_at_k": _micro(hit),
        "per_query": rows,
    }


def run(*, limit: int = LIMIT) -> dict[str, object]:
    """Measure the current ranker and the one it replaced, over the same set."""
    index = case_index()
    baseline = evaluate(
        lambda resolved, query, k: _legacy_search(resolved, query, k),
        index=index,
        limit=limit,
    )
    hits: dict[str, tuple[Reference, ...]] = {
        case.query: search(case.query, index=index, limit=limit) for case in CASES
    }
    current = evaluate(
        lambda resolved, query, k: tuple(hit.record.id for hit in hits[query]),
        index=index,
        limit=limit,
    )
    citations = [
        (1 if all(_cites(hit) for hit in result) else 0, 1)
        for result in hits.values()
        if result
    ]
    return {
        "set": "synthetic first-party retrieval fixture",
        "records": len(index.records),
        "queries": len(CASES),
        "limit": limit,
        "baseline": baseline,
        "current": current,
        "citation_completeness": _micro(citations),
    }




def _line(name: str, value: Mapping[str, object]) -> str:
    rate = value.get("value")
    shown = "not tested" if rate is None else f"{rate:.3f}"
    return (
        f"  {name:<22} {shown:>9}  "
        f"({value.get('numerator')}/{value.get('denominator')})"
    )


def report(result: Mapping[str, object] | None = None) -> str:
    """The evaluation as text: two rankers, three rates, and the denominators."""
    measured = result or run()
    lines = [
        f"retrieval evaluation - {measured['set']}",
        f"  {measured['records']} records, {measured['queries']} labelled queries, "
        f"top {measured['limit']}",
        "",
        "  baseline (exact tokens, no IDF, no diversity)",
    ]
    baseline = measured["baseline"]
    for name in ("precision_at_k", "recall_at_k", "hit_at_k"):
        lines.append(_line(name, baseline[name]))  # type: ignore[index]
    lines += ["", "  current (split compounds, BM25, soft corpus cap)"]
    current = measured["current"]
    for name in ("precision_at_k", "recall_at_k", "hit_at_k"):
        lines.append(_line(name, current[name]))  # type: ignore[index]
    lines += [
        "",
        _line("citation_completeness", measured["citation_completeness"]),  # type: ignore[arg-type]
        "",
        "Per query (current ranker):",
    ]
    for row in current["per_query"]:  # type: ignore[index]
        mark = "ok " if row["correct"] else "MISS"
        lines.append(f"  {mark} {row['query']!r}: {', '.join(row['returned'])}")
    return "\n".join(lines)


def main() -> int:
    print(report())
    return 0


if __name__ == "__main__":  # pragma: no cover - a developer's entry point
    raise SystemExit(main())
