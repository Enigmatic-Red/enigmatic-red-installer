"""The one record shape every corpus is normalised into.

A corpus is useful only if two different sources become the same kind of object,
and if that object carries enough to answer the questions a reviewer asks before
trusting a number: *where did this come from, under what licence, was it trained
on, is it held out, and does it contain anything it must not.*

So the schema is deliberately wider than an input/label pair. The fields map
one-to-one onto the separations this package exists to keep:

``zone`` and ``split``
    Where the record lives (raw / retrieval / training / evaluation) and which
    split it belongs to (train / dev / test / heldout). ``heldout`` is never
    assigned by the ingestion splitter; it is reserved for the baseline set.
``role`` and ``evaluation_only``
    Whether the record is a malicious seed, a safe control or plain reference
    material - and whether it may only ever be evaluated against.
``source``, ``license`` and ``retention``
    Provenance, redistribution permission and what the record may be used for.
``contamination``
    The content digest, the dedupe key, any duplicate it was folded into, and
    whether it overlaps a held-out record.
``evidence_required`` and ``scope_requirement``
    What a model answer has to cite, and what authorisation the probe assumes -
    because a finding without either is the exact overclaim the evaluator
    measures.

The invariants are enforced in :func:`validate_record`, which returns a list of
problems rather than raising: a validator that stops at the first defect hides
the other nine. :func:`read_jsonl` raises, because a corpus that cannot be read
is not a corpus with zero records.
"""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass
from datetime import date
from pathlib import Path
from typing import Any, Iterable, Mapping

__all__ = [
    "CONTAMINATION_KEYS",
    "DOMAINS",
    "FAMILY_CODE_VULNERABILITY",
    "FAMILY_DATA_LEAKAGE",
    "FAMILY_EXCESSIVE_AGENCY",
    "FAMILY_INDIRECT_INJECTION",
    "FAMILY_JAILBREAK",
    "FAMILY_OUTPUT_HANDLING",
    "FAMILY_OVER_REFUSAL",
    "FAMILY_PROMPT_EXTRACTION",
    "FAMILY_PROMPT_INJECTION",
    "LICENSE_REVIEW_STATES",
    "OUTCOMES",
    "RECORD_FIELDS",
    "RETENTION_KEYS",
    "RISK_LEVELS",
    "ROLES",
    "SCHEMA_VERSION",
    "SCOPE_REQUIREMENTS",
    "SPLITS",
    "ZONES",
    "Contamination",
    "IntegrityError",
    "License",
    "Record",
    "Retention",
    "SchemaError",
    "SourceRef",
    "find_sensitive",
    "input_sha256",
    "mask_sensitive",
    "normalise_text",
    "read_jsonl",
    "record_to_mapping",
    "set_digest",
    "stable_id",
    "validate_record",
    "write_jsonl",
]

#: Bumped when a field changes meaning or an invariant tightens. A report that
#: quotes ``SCHEMA_VERSION`` is reproducible against this file.
SCHEMA_VERSION = 1

#: Where a record is allowed to live. ``raw`` is the untouched source text kept
#: for audit; ``retrieval`` is knowledge a prompt may be shown; ``training`` is
#: derived material; ``evaluation`` is fixtures a run is scored against.
ZONES = ("raw", "retrieval", "training", "evaluation")

#: ``heldout`` is the baseline set: never a prompt, retrieval or fine-tuning
#: input. The splitter will not produce it; only the baseline loader may.
SPLITS = ("train", "dev", "test", "heldout")

DOMAINS = ("ai_security", "web_app", "infrastructure", "cloud")

RISK_LEVELS = ("none", "low", "medium", "high", "critical")

#: ``malicious_seed`` is benchmark content that must stay evaluation-only and
#: must never be trained on; ``safe_control`` is the over-refusal material;
#: ``reference`` is retrieval knowledge, not a test case.
ROLES = ("malicious_seed", "safe_control", "reference")

#: The behaviour a record expects, in a machine-readable word as well as the
#: prose in ``expected_behavior``.
OUTCOMES = (
    "should_refuse",
    "should_answer",
    "should_detect",
    "should_report",
    "vulnerable",
    "safe",
)

#: What a probe assumes. ``authorized_scope`` names a target inside a signed
#: scope; ``lab_owned_model`` is a model this lab runs; ``no_live_target`` is
#: code or text, not a system.
SCOPE_REQUIREMENTS = ("authorized_scope", "lab_owned_model", "no_live_target")

#: A licence is either verified, explicitly awaiting review, blocked because the
#: artefact cannot lawfully or practically be obtained, or incompatible. There is
#: no "probably fine": an unverified source cannot be ingested. ``blocked`` is a
#: recorded outcome, not a silent omission - the basis says what stopped it.
LICENSE_REVIEW_STATES = ("verified", "review_required", "blocked", "incompatible")

RETENTION_KEYS = ("training", "retrieval", "evaluation")

CONTAMINATION_KEYS = (
    "input_sha256",
    "dedupe_key",
    "duplicate_of",
    "near_duplicates",
    "overlaps_heldout",
    "note",
)

#: The family names the evaluator groups by. Kept here so a registry entry, a
#: record and a metric cannot spell the same family three ways.
FAMILY_PROMPT_INJECTION = "prompt_injection"
FAMILY_INDIRECT_INJECTION = "indirect_prompt_injection"
FAMILY_JAILBREAK = "jailbreak"
FAMILY_PROMPT_EXTRACTION = "system_prompt_extraction"
FAMILY_DATA_LEAKAGE = "retrieval_data_leakage"
FAMILY_OUTPUT_HANDLING = "insecure_output_handling"
FAMILY_EXCESSIVE_AGENCY = "excessive_agency"
FAMILY_OVER_REFUSAL = "over_refusal"
FAMILY_CODE_VULNERABILITY = "code_vulnerability"

#: Every field a mapping must carry. Listed once so ``from_mapping`` can reject
#: an unknown key instead of silently dropping it.
RECORD_FIELDS = (
    "schema_version",
    "id",
    "corpus",
    "corpus_version",
    "domain",
    "family",
    "input",
    "expected_behavior",
    "outcome",
    "exemplar",
    "risk_level",
    "evidence_required",
    "scope_requirement",
    "split",
    "zone",
    "role",
    "evaluation_only",
    "expected_tool",
    "source",
    "license",
    "retention",
    "contamination",
    "notes",
)


class SchemaError(ValueError):
    """A mapping is not a record, and the sentence says which key and why."""


class IntegrityError(ValueError):
    """A source artefact does not match the digest the manifest pinned."""



# --------------------------------------------------------------------- text
_WHITESPACE = re.compile(r"[ \t\f\v]+")
_BLANK_LINES = re.compile(r"\n{3,}")
_CONTROL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")


def normalise_text(text: str) -> str:
    """Whitespace and control characters only - never the wording.

    A normaliser that rewrote vocabulary would make the corpus a derivative the
    publisher never reviewed. Collapsing runs of spaces and dropping control
    characters is a storage decision, not an edit.
    """
    body = _CONTROL.sub("", str(text or "").replace("\r\n", "\n").replace("\r", "\n"))
    body = _WHITESPACE.sub(" ", body)
    body = re.sub(r"[ \t]+\n", "\n", body)
    body = re.sub(r"\n[ \t]+", "\n", body)
    body = _BLANK_LINES.sub("\n\n", body)
    return body.strip()


def input_sha256(text: str) -> str:
    """The content digest of one normalised input."""
    return hashlib.sha256(normalise_text(text).encode("utf-8")).hexdigest()


def set_digest(digests: Iterable[str]) -> str:
    """A digest over a set of content digests, independent of order.

    Used as the checksum of a first-party corpus: it covers every record's
    input and nothing derived from it, so it can be recomputed without the very
    field it authenticates.
    """
    ordered = "\n".join(sorted(str(digest) for digest in digests))
    return hashlib.sha256(ordered.encode("utf-8")).hexdigest()


def stable_id(corpus: str, corpus_version: str, text: str) -> str:
    """A record identifier that survives re-ingestion of the same source.

    It is the digest of the corpus, its version and the normalised input - not
    a row number, which changes when the publisher adds a row above it, and not
    a random id, which makes two runs of the same ingestion incomparable.
    """
    seed = f"{corpus}\x00{corpus_version}\x00{normalise_text(text)}"
    return f"{corpus}@{corpus_version}:{hashlib.sha256(seed.encode('utf-8')).hexdigest()[:16]}"


# ------------------------------------------------------------ sensitive text
#: Categories a corpus record must not contain unmasked. Deliberately narrow:
#: a false positive here costs a review, a false negative ships somebody's
#: credential or personal data into a fixture file.
_SENSITIVE = (
    ("email_address", re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b")),
    (
        "api_key",
        re.compile(r"\b(?:sk-[A-Za-z0-9_-]{16,}|AKIA[0-9A-Z]{16}|gh[pousr]_[A-Za-z0-9]{20,})\b"),
    ),
    ("private_key", re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----")),
    ("bearer_token", re.compile(r"\bBearer\s+[A-Za-z0-9._~+/-]{20,}=*", re.IGNORECASE)),
    ("us_ssn", re.compile(r"\b\d{3}-\d{2}-\d{4}\b")),
)

#: What a masked span is replaced with. The category is kept, the value is not.
_REDACTION = "[redacted:{kind}]"


def find_sensitive(text: str) -> tuple[str, ...]:
    """Which sensitive-data categories a string carries, in table order."""
    body = str(text or "")
    return tuple(name for name, pattern in _SENSITIVE if pattern.search(body))


def mask_sensitive(text: str) -> tuple[str, tuple[str, ...]]:
    """Replace sensitive spans with a category marker; return what was found.

    The value never reaches a fixture file or a report. The *category* does,
    because "this corpus contained an email address" is the fact a reviewer
    needs, and the address itself is the fact they must not have.
    """
    body = str(text or "")
    found: list[str] = []
    for name, pattern in _SENSITIVE:
        if not pattern.search(body):
            continue
        body = pattern.sub(_REDACTION.format(kind=name), body)
        found.append(name)
    return body, tuple(found)


# ---------------------------------------------------------------- structures
@dataclass(frozen=True)
class License:
    """A licence identifier, where it can be read, and what it permits."""

    id: str
    url: str
    redistribution: bool
    attribution_required: bool = False
    notice: str = ""

    @classmethod
    def from_mapping(cls, raw: Mapping[str, Any]) -> "License":
        missing = [key for key in ("id", "url", "redistribution") if key not in raw]
        if missing:
            raise SchemaError(f"license is missing {', '.join(missing)}")
        return cls(
            id=str(raw["id"]).strip(),
            url=str(raw["url"]).strip(),
            redistribution=bool(raw["redistribution"]),
            attribution_required=bool(raw.get("attribution_required", False)),
            notice=str(raw.get("notice", "")).strip(),
        )

    def as_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "url": self.url,
            "redistribution": self.redistribution,
            "attribution_required": self.attribution_required,
            "notice": self.notice,
        }


@dataclass(frozen=True)
class SourceRef:
    """Where a record came from, at which version, and how it was transformed."""

    publisher: str
    url: str
    version: str
    retrieved: str
    checksum: str
    transformations: tuple[str, ...] = ()

    @classmethod
    def from_mapping(cls, raw: Mapping[str, Any]) -> "SourceRef":
        missing = [
            key
            for key in ("publisher", "url", "version", "retrieved", "checksum")
            if key not in raw
        ]
        if missing:
            raise SchemaError(f"source is missing {', '.join(missing)}")
        return cls(
            publisher=str(raw["publisher"]).strip(),
            url=str(raw["url"]).strip(),
            version=str(raw["version"]).strip(),
            retrieved=str(raw["retrieved"]).strip(),
            checksum=str(raw["checksum"]).strip(),
            transformations=tuple(str(item) for item in raw.get("transformations", ())),
        )

    def as_dict(self) -> dict[str, Any]:
        return {
            "publisher": self.publisher,
            "url": self.url,
            "version": self.version,
            "retrieved": self.retrieved,
            "checksum": self.checksum,
            "transformations": list(self.transformations),
        }


@dataclass(frozen=True)
class Retention:
    """What the record may be used for. ``training`` is the one that matters."""

    training: bool
    retrieval: bool
    evaluation: bool

    @classmethod
    def from_mapping(cls, raw: Mapping[str, Any]) -> "Retention":
        missing = [key for key in RETENTION_KEYS if key not in raw]
        if missing:
            raise SchemaError(f"retention is missing {', '.join(missing)}")
        return cls(
            training=bool(raw["training"]),
            retrieval=bool(raw["retrieval"]),
            evaluation=bool(raw["evaluation"]),
        )

    def as_dict(self) -> dict[str, bool]:
        return {
            "training": self.training,
            "retrieval": self.retrieval,
            "evaluation": self.evaluation,
        }


@dataclass(frozen=True)
class Contamination:
    """Deduplication and held-out-overlap facts about one record."""

    input_sha256: str
    dedupe_key: str
    duplicate_of: str | None = None
    near_duplicates: tuple[str, ...] = ()
    overlaps_heldout: bool = False
    note: str = ""

    @classmethod
    def from_mapping(cls, raw: Mapping[str, Any]) -> "Contamination":
        missing = [key for key in ("input_sha256", "dedupe_key") if key not in raw]
        if missing:
            raise SchemaError(f"contamination is missing {', '.join(missing)}")
        duplicate = raw.get("duplicate_of")
        return cls(
            input_sha256=str(raw["input_sha256"]).strip(),
            dedupe_key=str(raw["dedupe_key"]).strip(),
            duplicate_of=str(duplicate).strip() if duplicate else None,
            near_duplicates=tuple(str(item) for item in raw.get("near_duplicates", ())),
            overlaps_heldout=bool(raw.get("overlaps_heldout", False)),
            note=str(raw.get("note", "")).strip(),
        )

    def as_dict(self) -> dict[str, Any]:
        return {
            "input_sha256": self.input_sha256,
            "dedupe_key": self.dedupe_key,
            "duplicate_of": self.duplicate_of,
            "near_duplicates": list(self.near_duplicates),
            "overlaps_heldout": self.overlaps_heldout,
            "note": self.note,
        }


# -------------------------------------------------------------------- record
@dataclass(frozen=True)
class Record:
    """One normalised corpus record. Every field has a job; none is decorative."""

    id: str
    corpus: str
    corpus_version: str
    domain: str
    family: str
    input: str
    expected_behavior: str
    outcome: str
    exemplar: str
    risk_level: str
    evidence_required: tuple[str, ...]
    scope_requirement: str
    split: str
    zone: str
    role: str
    evaluation_only: bool
    source: SourceRef
    license: License
    retention: Retention
    contamination: Contamination
    expected_tool: str | None = None
    notes: str = ""

    @classmethod
    def from_mapping(cls, raw: Mapping[str, Any]) -> "Record":
        unknown = sorted(set(raw) - set(RECORD_FIELDS))
        if unknown:
            raise SchemaError(f"unknown record field(s): {', '.join(unknown)}")
        missing = [
            key
            for key in RECORD_FIELDS
            if key not in raw and key not in ("expected_tool", "notes")
        ]
        if missing:
            raise SchemaError(f"missing record field(s): {', '.join(missing)}")
        if int(raw["schema_version"]) != SCHEMA_VERSION:
            raise SchemaError(
                f"schema_version {raw['schema_version']!r} is not {SCHEMA_VERSION}"
            )
        tool = raw.get("expected_tool")
        return cls(
            id=str(raw["id"]),
            corpus=str(raw["corpus"]),
            corpus_version=str(raw["corpus_version"]),
            domain=str(raw["domain"]),
            family=str(raw["family"]),
            input=str(raw["input"]),
            expected_behavior=str(raw["expected_behavior"]),
            outcome=str(raw["outcome"]),
            exemplar=str(raw["exemplar"]),
            risk_level=str(raw["risk_level"]),
            evidence_required=tuple(str(item) for item in raw["evidence_required"]),
            scope_requirement=str(raw["scope_requirement"]),
            split=str(raw["split"]),
            zone=str(raw["zone"]),
            role=str(raw["role"]),
            evaluation_only=bool(raw["evaluation_only"]),
            expected_tool=str(tool) if tool else None,
            source=SourceRef.from_mapping(raw["source"]),
            license=License.from_mapping(raw["license"]),
            retention=Retention.from_mapping(raw["retention"]),
            contamination=Contamination.from_mapping(raw["contamination"]),
            notes=str(raw.get("notes", "")),
        )

    @property
    def release_eligible(self) -> bool:
        """Whether this record may be copied into a release at all."""
        return bool(self.license.redistribution)


def record_to_mapping(record: Record) -> dict[str, Any]:
    """The canonical mapping a JSONL line is built from."""
    return {
        "schema_version": SCHEMA_VERSION,
        "id": record.id,
        "corpus": record.corpus,
        "corpus_version": record.corpus_version,
        "domain": record.domain,
        "family": record.family,
        "input": record.input,
        "expected_behavior": record.expected_behavior,
        "outcome": record.outcome,
        "exemplar": record.exemplar,
        "risk_level": record.risk_level,
        "evidence_required": list(record.evidence_required),
        "scope_requirement": record.scope_requirement,
        "split": record.split,
        "zone": record.zone,
        "role": record.role,
        "evaluation_only": record.evaluation_only,
        "expected_tool": record.expected_tool,
        "source": record.source.as_dict(),
        "license": record.license.as_dict(),
        "retention": record.retention.as_dict(),
        "contamination": record.contamination.as_dict(),
        "notes": record.notes,
    }


def validate_record(record: Record) -> tuple[str, ...]:
    """Every invariant a single record can hold, as sentences. Empty is good.

    Corpus-wide rules - checksum agreement, duplicate ids, held-out overlap -
    live in :mod:`corpora.validate`, because they need more than one record.
    """
    problems: list[str] = []

    def require(value: str, name: str) -> None:
        if not str(value or "").strip():
            problems.append(f"{record.id}: {name} is empty")

    for name in (
        "id",
        "corpus",
        "corpus_version",
        "domain",
        "family",
        "input",
        "expected_behavior",
        "outcome",
        "exemplar",
        "risk_level",
        "scope_requirement",
        "split",
        "zone",
        "role",
    ):
        require(getattr(record, name), name)

    if record.domain not in DOMAINS:
        problems.append(f"{record.id}: unknown domain {record.domain!r}")
    if record.risk_level not in RISK_LEVELS:
        problems.append(f"{record.id}: unknown risk level {record.risk_level!r}")
    if record.outcome not in OUTCOMES:
        problems.append(f"{record.id}: unknown outcome {record.outcome!r}")
    if record.split not in SPLITS:
        problems.append(f"{record.id}: unknown split {record.split!r}")
    if record.zone not in ZONES:
        problems.append(f"{record.id}: unknown zone {record.zone!r}")
    if record.role not in ROLES:
        problems.append(f"{record.id}: unknown role {record.role!r}")
    if record.scope_requirement not in SCOPE_REQUIREMENTS:
        problems.append(
            f"{record.id}: unknown scope requirement {record.scope_requirement!r}"
        )

    expected = stable_id(record.corpus, record.corpus_version, record.input)
    if record.id != expected:
        problems.append(
            f"{record.id}: id is not the stable id for this corpus, version and input "
            f"({expected})"
        )

    # Provenance completeness. A checksum of the wrong shape is not a checksum.
    if not re.fullmatch(r"[0-9a-f]{64}", record.source.checksum or ""):
        problems.append(f"{record.id}: source.checksum is not a sha256 digest")
    try:
        date.fromisoformat(record.source.retrieved)
    except ValueError:
        problems.append(
            f"{record.id}: source.retrieved {record.source.retrieved!r} is not a date"
        )
    for name in ("publisher", "url", "version"):
        require(getattr(record.source, name), f"source.{name}")
    if record.source.url and not record.source.url.startswith("https://"):
        problems.append(f"{record.id}: source.url is not https")
    require(record.license.id, "license.id")
    require(record.license.url, "license.url")

    # The containment rules. Each of these is a way a held-out record, or an
    # attack seed, leaks into the material a model is developed on.
    if record.evaluation_only and record.split not in ("test", "heldout"):
        problems.append(
            f"{record.id}: evaluation_only requires split 'test' or 'heldout', "
            f"not {record.split!r}"
        )
    if record.split in ("test", "heldout") and record.retention.training:
        problems.append(f"{record.id}: a {record.split} record is marked for training")
    if record.split == "heldout" and not record.evaluation_only:
        problems.append(f"{record.id}: a heldout record must be evaluation_only")
    if record.role == "malicious_seed" and record.retention.training:
        problems.append(f"{record.id}: a malicious seed is marked for training")
    if record.zone == "training" and record.split not in ("train", "dev"):
        problems.append(
            f"{record.id}: a training-zone record cannot be in split {record.split!r}"
        )
    if record.zone == "training" and record.role == "malicious_seed":
        problems.append(f"{record.id}: a malicious seed cannot live in the training zone")
    if record.zone == "retrieval" and record.split in ("test", "heldout"):
        problems.append(
            f"{record.id}: retrieval knowledge cannot occupy split {record.split!r}"
        )
    if not any(
        (record.retention.training, record.retention.retrieval, record.retention.evaluation)
    ):
        problems.append(f"{record.id}: retention allows no use at all")

    # Evidence and authorisation are requirements, not optional prose.
    if not record.evidence_required:
        problems.append(f"{record.id}: no evidence requirement is stated")
    for item in record.evidence_required:
        if not str(item).strip():
            problems.append(f"{record.id}: an evidence requirement is blank")

    # Never a real person's data, and never a live credential.
    leaked = find_sensitive(" ".join((record.input, record.exemplar, record.notes)))
    if leaked:
        problems.append(
            f"{record.id}: unmasked sensitive data ({', '.join(leaked)}) - "
            "ingestion must mask it before the record is written"
        )

    return tuple(problems)


# ---------------------------------------------------------------------- jsonl
def _line(mapping: Mapping[str, Any]) -> str:
    return json.dumps(mapping, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def write_jsonl(path: Path, records: Iterable[Record]) -> int:
    """Write records in id order, canonically; return how many were written.

    Sorting and a fixed key order make the output byte-identical across runs,
    which is what lets a manifest pin its digest.
    """
    ordered = sorted(records, key=lambda record: record.id)
    body = "".join(_line(record_to_mapping(record)) + "\n" for record in ordered)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(body, encoding="utf-8", newline="\n")
    return len(ordered)


def read_jsonl(path: Path) -> list[Record]:
    """Read and validate a normalised corpus.

    Raises:
        SchemaError: on a line that is not JSON or not a record, naming the line
            number. Skipping it would make a broken corpus look short, which is
            the failure mode this package exists to prevent.
    """
    records: list[Record] = []
    with Path(path).open("r", encoding="utf-8") as handle:
        for number, line in enumerate(handle, start=1):
            if not line.strip():
                continue
            try:
                mapping = json.loads(line)
            except json.JSONDecodeError as exc:
                raise SchemaError(f"{path}:{number}: not JSON ({exc.msg})") from None
            try:
                records.append(Record.from_mapping(mapping))
            except SchemaError as exc:
                raise SchemaError(f"{path}:{number}: {exc}") from None
    return records
