"""Validate a corpus tree: schema, provenance, licence, dedupe, contamination.

Each check answers one of the questions a report has to be able to answer, and
each produces a *finding* rather than an exception: a validator that stops at
the first defect reports one problem and hides the rest.

``schema``
    Every record satisfies :func:`corpora.schema.validate_record`.
``provenance``
    The record names a publisher, URL, version, retrieval date and checksum, and
    the corpus/version it claims is the one the registry names.
``licence``
    The record's licence is the registry's licence for that source, and the
    review state is ``verified``.
``dedupe``
    No two records share an id or a normalised input; a duplicate is reported
    with both subjects so a reviewer can see which one survived.
``contamination``
    No record whose digest appears in the held-out lock sits in train or dev, and
    the lock itself still matches the fixtures.
``bundling``
    Nothing is inside this repository unless its licence permits redistribution.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

from corpora.manifest import ManifestError, Registry, load_registry
from corpora.schema import Record, validate_record

__all__ = [
    "Finding",
    "ValidationReport",
    "validate_records",
    "validate_tree",
]

ERROR = "error"
WARNING = "warning"

#: Where the runtime tree lives. ``data/`` is gitignored, so a normalised corpus
#: is local state, not a source file.
DEFAULT_ROOT = Path("data") / "corpora"


@dataclass(frozen=True)
class Finding:
    """One defect, with the subject a reader can act on."""

    level: str
    code: str
    subject: str
    detail: str

    def sentence(self) -> str:
        return f"{self.level:<7} {self.code:<14} {self.subject}: {self.detail}"

    def as_dict(self) -> dict[str, str]:
        return {
            "level": self.level,
            "code": self.code,
            "subject": self.subject,
            "detail": self.detail,
        }


@dataclass(frozen=True)
class ValidationReport:
    """Every finding from one validation run."""

    findings: tuple[Finding, ...]
    records: int
    corpora: int

    @property
    def errors(self) -> tuple[Finding, ...]:
        return tuple(item for item in self.findings if item.level == ERROR)

    @property
    def warnings(self) -> tuple[Finding, ...]:
        return tuple(item for item in self.findings if item.level == WARNING)

    @property
    def ok(self) -> bool:
        return not self.errors

    def as_dict(self) -> dict[str, Any]:
        return {
            "ok": self.ok,
            "records": self.records,
            "corpora": self.corpora,
            "errors": len(self.errors),
            "warnings": len(self.warnings),
            "findings": [finding.as_dict() for finding in self.findings],
        }

    def describe(self) -> tuple[str, ...]:
        lines = [
            f"corpora   {self.corpora}  records {self.records}  "
            f"errors {len(self.errors)}  warnings {len(self.warnings)}"
        ]
        lines.extend(finding.sentence() for finding in self.findings)
        lines.append("result    " + ("ok" if self.ok else "FAILED"))
        return tuple(lines)


def _group(records: Iterable[Record]) -> dict[tuple[str, str], list[Record]]:
    groups: dict[tuple[str, str], list[Record]] = {}
    for record in records:
        groups.setdefault((record.corpus, record.corpus_version), []).append(record)
    return groups


def validate_records(
    records: Iterable[Record],
    registry: Registry | None = None,
    *,
    bundled_repo_root: Path | None = None,
    heldout: frozenset[str] | None = None,
) -> tuple[Finding, ...]:
    """Every check that needs more than one record, plus the per-record ones."""
    catalogue = registry or load_registry()
    rows = list(records)
    findings: list[Finding] = []
    seen_ids: dict[str, str] = {}
    seen_inputs: dict[str, str] = {}

    for record in rows:
        for problem in validate_record(record):
            findings.append(Finding(ERROR, "schema", record.id, problem))

        source = None
        try:
            source = catalogue.by_name(record.corpus)
        except ManifestError as exc:
            findings.append(Finding(ERROR, "provenance", record.corpus, str(exc)))

        if record.id in seen_ids:
            findings.append(
                Finding(
                    ERROR,
                    "dedupe",
                    record.id,
                    f"id appears twice (first at {seen_ids[record.id]})",
                )
            )
        seen_ids.setdefault(record.id, "this run")

        digest = record.contamination.input_sha256
        if digest in seen_inputs:
            findings.append(
                Finding(
                    WARNING,
                    "duplicate-input",
                    record.id,
                    f"same normalised input as {seen_inputs[digest]}",
                )
            )
        seen_inputs.setdefault(digest, record.id)

        if source is not None:
            if record.corpus_version != source.version:
                findings.append(
                    Finding(
                        ERROR,
                        "provenance",
                        record.id,
                        f"corpus version {record.corpus_version!r} is not the "
                        f"registry's {source.version!r}",
                    )
                )
            if (record.license.id, record.license.url) != (
                source.license.id,
                source.license.url,
            ):
                findings.append(
                    Finding(
                        ERROR,
                        "licence",
                        record.id,
                        "record licence does not match the registry's",
                    )
                )
            if source.review_state != "verified":
                findings.append(
                    Finding(
                        ERROR,
                        "licence",
                        record.corpus,
                        f"source review state is {source.review_state!r}",
                    )
                )
            if record.zone not in source.zones:
                findings.append(
                    Finding(
                        ERROR,
                        "provenance",
                        record.id,
                        f"zone {record.zone!r} is not one the registry declares",
                    )
                )

        if record.contamination.overlaps_heldout and record.split not in ("test", "heldout"):
            findings.append(
                Finding(
                    ERROR,
                    "contamination",
                    record.id,
                    f"overlaps the held-out set but sits in {record.split!r}",
                )
            )
        if heldout and digest in heldout and record.split != "test":
            findings.append(
                Finding(
                    ERROR,
                    "contamination",
                    record.id,
                    f"held-out digest appears in split {record.split!r}",
                )
            )

    for (corpus, version), group in sorted(_group(rows).items()):
        checksums = {record.source.checksum for record in group}
        if len(checksums) > 1:
            findings.append(
                Finding(
                    ERROR,
                    "provenance",
                    f"{corpus}@{version}",
                    f"{len(checksums)} different source checksums in one corpus version",
                )
            )

    if bundled_repo_root is not None:
        unpublishable = [record.id for record in rows if not record.release_eligible]
        if unpublishable:
            findings.append(
                Finding(
                    ERROR,
                    "bundling",
                    f"{len(unpublishable)} record(s)",
                    "a corpus inside this repository carries a licence that does not "
                    "permit redistribution",
                )
            )

    return tuple(findings)


def _file_digest(path: Path) -> str:
    import hashlib

    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def validate_tree(
    root: Path,
    registry: Registry | None = None,
    *,
    repo_root: Path | None = None,
) -> ValidationReport:
    """Validate every ``records.jsonl`` under ``root``, and the manifests beside them."""
    from corpora.baseline import heldout_hashes, verify_lock
    from corpora.schema import read_jsonl

    catalogue = registry or load_registry()
    location = Path(root)
    findings: list[Finding] = []
    records: list[Record] = []
    corpora = 0

    if not location.is_dir():
        findings.append(
            Finding(
                WARNING,
                "no-corpus",
                str(location),
                "no ingested corpus tree; registry and baseline were still checked",
            )
        )
    else:
        for path in sorted(location.rglob("records.jsonl")):
            corpora += 1
            try:
                batch = read_jsonl(path)
            except Exception as exc:
                findings.append(Finding(ERROR, "schema", str(path), str(exc)))
                continue
            records.extend(batch)
            manifest = path.with_name("manifest.json")
            if manifest.is_file():
                try:
                    pinned = json.loads(manifest.read_text(encoding="utf-8"))
                except json.JSONDecodeError as exc:
                    findings.append(Finding(ERROR, "provenance", str(manifest), exc.msg))
                    continue
                if pinned.get("output_sha256") != _file_digest(path):
                    findings.append(
                        Finding(
                            ERROR,
                            "provenance",
                            str(path),
                            "the file digest is not the one its manifest pinned",
                        )
                    )

    inside_repo = False
    if repo_root is not None:
        guard = Path(repo_root).resolve()
        target = location.resolve()
        inside_repo = guard == target or guard in target.parents

    findings.extend(
        validate_records(
            records,
            catalogue,
            bundled_repo_root=Path(repo_root) if inside_repo else None,
            heldout=heldout_hashes(),
        )
    )
    for problem in verify_lock():
        findings.append(Finding(ERROR, "heldout-lock", "baseline", problem))

    return ValidationReport(
        findings=tuple(findings), records=len(records), corpora=corpora
    )



def validate_baseline(registry: Registry | None = None) -> tuple[tuple[Record, ...], tuple[Finding, ...]]:
    """The baseline fixtures and the findings about them.

    This is what CI validates when no operator corpus exists: the set that ships
    with the package is checked for schema, licence, dedupe and the held-out
    lock on every run.
    """
    from corpora.baseline import load_baseline, verify_lock

    records = load_baseline()
    findings = list(validate_records(records, registry))
    findings.extend(
        Finding(ERROR, "heldout-lock", "baseline", problem) for problem in verify_lock()
    )
    return records, tuple(findings)

