"""posture adapter: what an HTTP answer says about its own defences.

``httpx`` answers "what is listening, and what does it call itself". This adapter
answers the next question a reviewer asks without sending a payload: **which of
the headers that limit a browser's trust are present, and what TLS does the
service actually negotiate with us**. It is the honest, low-noise part of an
assessment - the part that can be re-checked next month and compared.

What is fixed here, and why:

* **One request, and the body is never read.** The response is opened with
  ``stream`` and closed without iterating it. A body can be megabytes, can be
  attacker-shaped, and is not what this adapter is about: status, headers and
  the TLS session are. Nothing in the body can become state.
* **Redirects are reported, never followed.** ``follow_redirects=False``, and
  the ``Location`` is recorded with its query and fragment removed - a redirect
  frequently carries a session token, and an adapter that stored it would put a
  credential in the audit log. The reader is told "this answered 301 to X" and
  can point a second call there deliberately, where scope and class are checked
  again.
* **Seven headers, plus ``Server`` and ``Location``, and nothing else.** No
  ``Set-Cookie``, no ``Authorization``, no arbitrary header map: a response is
  not a place this product reads secrets from. Values that are kept are clipped
  and control characters are stripped.
* **TLS is one handshake, and a second only to describe a certificate that
  failed.** A self-signed or expired certificate is a finding, not a blind spot,
  so after a failed verification the adapter makes one *unverified* handshake to
  report the protocol, the cipher and the certificate's dates.
* **A declared fact, not a verdict.** ``missing_headers`` and ``weak_headers``
  are the substance: which recommended header was absent, and which value is
  weaker than the recommendation it implements (HSTS with a short ``max-age``, a
  CSP that allows ``'unsafe-inline'``, ``X-Frame-Options: ALLOW-FROM``). The
  report decides what that means for this customer; the adapter only says it.

The request travels as an argv (``posture GET <url>``), like the hub adapter's
metadata read: the guard classifies *that line*, the audit entry records it, and
the enforcement chain above it - kill switch, authorization, scope, guard, audit,
rate limit - is the base class's, unchanged and not restated.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field, replace
from datetime import UTC, datetime
from typing import Any, Callable, Mapping
from urllib.parse import urlsplit

from safety.errors import ToolExecutionError
from tools.base import ToolAdapter, ToolContext, ToolResult
from tools.runner import CommandResult

__all__ = [
    "BINARY",
    "RECOMMENDED_HEADERS",
    "REQUEST_HEADERS",
    "PostureAdapter",
    "PostureReport",
    "TlsPosture",
    "observe_tls",
    "posture",
]

#: The name the audit line reads as. There is no process behind it; the name is
#: the capability's, and it matches ``domains.yaml`` and the guard table.
BINARY = "posture"

#: What a request may identify itself as. No credentials, ever: this adapter has
#: no notion of a logged-in session, which is what keeps it safe to point at a
#: production login page.
REQUEST_HEADERS: Mapping[str, str] = {
    "User-Agent": "enigmatic-red",
    "Accept": "text/html,application/xhtml+xml;q=0.9,*/*;q=0.5",
}

#: The header allow-list: seven browser-trust headers, and the two names that
#: describe the exchange rather than the page.
RECOMMENDED_HEADERS: tuple[tuple[str, str], ...] = (
    (
        "strict-transport-security",
        "HSTS: tells the browser to refuse plain HTTP for this host",
    ),
    (
        "content-security-policy",
        "CSP: limits which scripts and frames the page may load",
    ),
    (
        "x-content-type-options",
        "nosniff: stops a browser from reinterpreting a declared type",
    ),
    ("x-frame-options", "framing: limits clickjacking via frames"),
    ("referrer-policy", "referrer: limits what a cross-site link learns"),
    ("permissions-policy", "feature policy: narrows powerful browser APIs"),
    (
        "cross-origin-opener-policy",
        "COOP: isolates this document from openers it did not choose",
    ),
)

#: Header names kept beyond the recommendation list. ``server`` is what the
#: service calls itself; ``location`` is a redirect target, recorded without its
#: query so a token cannot be carried into the log.
_KEEP_NAMES: tuple[str, ...] = ("server", "location")

#: HSTS is only HSTS if it covers a meaningful window; below this it is a token
#: gesture. 180 days, the bottom of the range the guidance names.
_HSTS_FLOOR_S = 15_552_000

_MAX_AGE = re.compile(r"max-age\s*=\s*\"?(\d+)\"?", re.IGNORECASE)

#: A header value longer than this is clipped: the first clause is the claim.
VALUE_CEILING = 200

#: ``TlsPosture.verified`` when there was no TLS to verify at all.
_NOT_NEGOTIATED = None


def _text(value: Any, limit: int = VALUE_CEILING) -> str:
    """One line of site-controlled text: no controls, no newlines, bounded."""
    text = " ".join(str(value or "").split())
    return re.sub(r"[\x00-\x1f\x7f]", "", text)[:limit]



@dataclass(frozen=True)
class TlsPosture:
    """The TLS session this adapter negotiated, as facts.

    Args:
        https: whether a TLS handshake was attempted at all.
        protocol: ``TLSv1.3``, ``TLSv1.2``, or empty when the handshake failed.
        cipher: the negotiated cipher suite name.
        subject: the certificate's common name.
        issuer: the issuing organisation, or its common name.
        not_after: the certificate's expiry, as the handshake reported it.
        days_remaining: whole days from now until ``not_after``; negative when
            the certificate has already expired. ``None`` when unreadable.
        verified: ``True`` when the default trust store accepted the chain and
            the name; ``False`` when it did not; ``None`` when no TLS was
            negotiated.
        problem: the verification or connection failure, in one sentence.
    """

    https: bool = False
    protocol: str = ""
    cipher: str = ""
    subject: str = ""
    issuer: str = ""
    not_after: str = ""
    days_remaining: int | None = None
    verified: bool | None = _NOT_NEGOTIATED
    problem: str = ""

    @property
    def expired(self) -> bool:
        return self.days_remaining is not None and self.days_remaining < 0

    def describe(self) -> dict[str, Any]:
        return {
            "https": self.https,
            "protocol": self.protocol,
            "cipher": self.cipher,
            "subject": self.subject,
            "issuer": self.issuer,
            "not_after": self.not_after,
            "days_remaining": self.days_remaining,
            "verified": self.verified,
            "problem": self.problem,
        }


@dataclass(frozen=True)
class PostureReport:
    """One URL's answer, reduced to the facts a reviewer can act on."""

    url: str
    status_code: int
    server: str = ""
    location: str = ""
    headers: Mapping[str, str] = field(default_factory=dict)
    missing_headers: tuple[str, ...] = ()
    weak_headers: tuple[str, ...] = ()
    tls: TlsPosture = field(default_factory=TlsPosture)
    notes: tuple[str, ...] = ()

    @property
    def present_headers(self) -> tuple[str, ...]:
        return tuple(name for name, _ in RECOMMENDED_HEADERS if name in self.headers)

    @property
    def redirect(self) -> bool:
        return bool(self.location) and 300 <= int(self.status_code) < 400

    def describe(self) -> dict[str, Any]:
        return {
            "url": self.url,
            "status_code": self.status_code,
            "server": self.server,
            "location": self.location,
            "headers": {
                name: self.headers[name]
                for name, _ in RECOMMENDED_HEADERS
                if name in self.headers
            },
            "missing_headers": list(self.missing_headers),
            "weak_headers": list(self.weak_headers),
            "tls": self.tls.describe(),
            "notes": list(self.notes),
        }


# --------------------------------------------------------------------- target
def _target_url(target: str) -> str:
    """Validate the URL, and refuse anything this adapter will not fetch."""
    text = str(target or "").strip()
    if not text:
        raise ValueError("posture needs the URL it should read")
    if any(ch.isspace() for ch in text):
        raise ValueError(f"refusing a URL with whitespace in it: {text!r}")
    if "#" in text:
        raise ValueError(
            "refusing a URL with a fragment: a fragment is never sent to a "
            "server, so the audit line would describe a different request than "
            "the one made"
        )
    parts = urlsplit(text)
    scheme = parts.scheme.lower()
    if scheme not in {"http", "https"}:
        raise ValueError(
            f"{text!r} is not an http(s) URL. Give the absolute URL of the "
            "service, e.g. https://app.example.com/"
        )
    if parts.username or parts.password:
        raise ValueError(
            "refusing a URL with credentials in it: this adapter sends no "
            "authentication, and a password in the URL would be written to the "
            "audit log where it could never be removed"
        )
    host = parts.hostname or ""
    if not host or ("." not in host and host != "localhost"):
        raise ValueError(f"{text!r} does not name a host this adapter can reach")
    try:
        parts.port
    except ValueError as trouble:
        raise ValueError(f"{text!r} has an unreadable port: {trouble}") from None
    path = parts.path or "/"
    query = f"?{parts.query}" if parts.query else ""
    return f"{scheme}://{parts.netloc}{path}{query}"


def _host_port(url: str) -> tuple[str, int]:
    parts = urlsplit(url)
    host = parts.hostname or ""
    port = parts.port or (443 if parts.scheme.lower() == "https" else 80)
    return host, int(port)


# ---------------------------------------------------------------- header rules
def _hsts_weak(value: str) -> bool:
    match = _MAX_AGE.search(value or "")
    if match is None:
        return True
    return int(match.group(1)) < _HSTS_FLOOR_S


def _csp_weak(value: str) -> bool:
    lowered = (value or "").lower()
    return "'unsafe-inline'" in lowered or "'unsafe-eval'" in lowered


def _nosniff_weak(value: str) -> bool:
    return (value or "").strip().lower() != "nosniff"


def _frame_weak(value: str) -> bool:
    return (value or "").strip().lower() not in {"deny", "sameorigin"}


def _referrer_weak(value: str) -> bool:
    lowered = (value or "").strip().lower()
    return "unsafe-url" in lowered or "no-referrer-when-downgrade" in lowered


def _coop_weak(value: str) -> bool:
    return (value or "").strip().lower() not in {
        "same-origin",
        "same-origin-allow-popups",
    }


#: A header present in name only. Anything not named here is judged by presence
#: alone - which is the honest reading of, say, ``Permissions-Policy``: this
#: adapter has no policy engine and will not pretend to have one.
_WEAK_RULES: Mapping[str, Callable[[str], bool]] = {
    "strict-transport-security": _hsts_weak,
    "content-security-policy": _csp_weak,
    "x-content-type-options": _nosniff_weak,
    "x-frame-options": _frame_weak,
    "referrer-policy": _referrer_weak,
    "cross-origin-opener-policy": _coop_weak,
}


def _judge(headers: Mapping[str, str]) -> tuple[tuple[str, ...], tuple[str, ...]]:
    """Which recommendations are absent, and which are present but weak."""
    missing: list[str] = []
    weak: list[str] = []
    for name, _ in RECOMMENDED_HEADERS:
        value = headers.get(name)
        if value is None or not value.strip():
            missing.append(name)
            continue
        rule = _WEAK_RULES.get(name)
        if rule is not None and rule(value):
            weak.append(name)
    return tuple(missing), tuple(weak)


# ------------------------------------------------------------------------ TLS
def _days_left(not_after: str, *, now: datetime | None = None) -> int | None:
    """Whole days until the certificate expires, or ``None`` if unreadable."""
    if not not_after:
        return None
    try:
        import ssl

        expires = datetime.fromtimestamp(ssl.cert_time_to_seconds(not_after), UTC)
    except (ValueError, OverflowError, OSError):
        return None
    return int(((now or datetime.now(UTC)) - expires).total_seconds() // -86400)


def _session(session: Any, verified: bool) -> TlsPosture:
    """Reduce one negotiated session (and its peer certificate) to facts."""
    certificate = session.getpeercert() or {}
    subject = dict(item[0] for item in certificate.get("subject", ()) if item)
    issuer = dict(item[0] for item in certificate.get("issuer", ()) if item)
    cipher = session.cipher()
    return TlsPosture(
        https=True,
        protocol=_text(session.version(), 20),
        cipher=_text(cipher[0] if cipher else "", 60),
        subject=_text(subject.get("commonName", ""), 120),
        issuer=_text(
            issuer.get("organizationName") or issuer.get("commonName", ""), 120
        ),
        not_after=_text(certificate.get("notAfter", ""), 60),
        days_remaining=_days_left(certificate.get("notAfter", "")),
        verified=verified,
    )


def observe_tls(host: str, port: int = 443, *, timeout_s: float = 10.0) -> TlsPosture:
    """Negotiate TLS once, and describe it. Never raises for a network fault.

    A verified handshake answers everything. When the trust store refuses the
    certificate, one further *unverified* handshake is made so the failure can
    be named: an expired or self-signed certificate is exactly what a posture
    check should surface, and "could not connect" would hide it.
    """
    import socket
    import ssl

    problem = ""
    try:
        context = ssl.create_default_context()
        with socket.create_connection((host, port), timeout=timeout_s) as raw:
            with context.wrap_socket(raw, server_hostname=host) as session:
                return _session(session, True)
    except ssl.SSLCertVerificationError as trouble:
        problem = _text(getattr(trouble, "verify_message", "") or trouble, 160)
    except ssl.SSLError as trouble:
        return TlsPosture(https=True, verified=False, problem=_text(trouble, 160))
    except OSError as trouble:
        return TlsPosture(https=True, verified=None, problem=_text(trouble, 160))

    try:
        relaxed = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        relaxed.check_hostname = False
        relaxed.verify_mode = ssl.CERT_NONE
        with socket.create_connection((host, port), timeout=timeout_s) as raw:
            with relaxed.wrap_socket(raw, server_hostname=host) as session:
                return replace(_session(session, False), problem=problem)
    except (ssl.SSLError, OSError):
        return TlsPosture(https=True, verified=False, problem=problem)


# -------------------------------------------------------------------- adapter
class PostureAdapter(ToolAdapter):
    """Read one URL's browser-trust headers and its TLS session."""

    name = BINARY

    def __init__(
        self,
        client: Any | None = None,
        tls: Callable[[str, int], TlsPosture] | None = None,
    ) -> None:
        """``client`` is an ``httpx.Client``-shaped object; tests inject both."""
        self._client = client
        self._tls = tls or observe_tls

    # -------------------------------------------------------------- to build
    def build_argv(self, target: str, **options: Any) -> list[str]:
        return [BINARY, "GET", _target_url(target)]

    # --------------------------------------------------------------- execute
    def _run_process(
        self,
        target: str,
        argv: list[str],
        command_text: str,
        context: ToolContext,
        **options: Any,
    ) -> CommandResult | ToolResult:
        """The request *is* the run.

        Overridden because this capability has no binary behind it. Every
        control above this call is the base class's: the kill switch, the
        authorization, the scope check, the guard, the audit entry written
        before execution, and the rate limit are not restated and cannot be
        skipped.
        """
        return self._request(argv)

    def _request(self, argv: list[str]) -> CommandResult:
        import httpx

        url = argv[2]
        host, port = _host_port(url)
        try:
            if self._client is None:
                with httpx.Client(
                    timeout=httpx.Timeout(15.0), follow_redirects=False
                ) as client:
                    observation = self._observe(client, url)
            else:
                observation = self._observe(self._client, url)
        except httpx.HTTPError as trouble:
            raise ToolExecutionError(
                f"{url} could not be reached: {trouble}. Nothing about this "
                "service's posture was observed."
            ) from trouble

        scheme = observation.pop("scheme")
        tls = self._tls(host, port) if scheme == "https" else TlsPosture()
        observation["tls"] = tls.describe()
        # The exchange succeeded, so the run's exit status is 0 whatever the
        # site answered: a 404 is an observation, not a failed measurement.
        return CommandResult(
            argv=tuple(argv),
            returncode=0,
            stdout=json.dumps(observation, sort_keys=True),
        )

    @staticmethod
    def _observe(client: Any, url: str) -> dict[str, Any]:
        """Open the response, read its head, and close it without the body."""
        parts = urlsplit(url)
        with client.stream("GET", url, headers=dict(REQUEST_HEADERS)) as response:
            raw = {
                str(name).lower(): str(value)
                for name, value in response.headers.items()
            }
            status = int(getattr(response, "status_code", 0) or 0)
        allowed = [name for name, _ in RECOMMENDED_HEADERS] + list(_KEEP_NAMES)
        kept = {
            name: _text(raw[name])
            for name in allowed
            if raw.get(name, "").strip()
        }
        if kept.get("location"):
            # A redirect target routinely carries a session token; the query and
            # the fragment are dropped before the value can reach the log.
            split = urlsplit(kept["location"])
            kept["location"] = _text(
                f"{split.scheme}://{split.netloc}{split.path}"
                if split.netloc
                else split.path
            )
        notes: list[str] = []
        if 300 <= status < 400 and kept.get("location"):
            notes.append(
                "the URL answered with a redirect: it was reported, not "
                "followed, and the target is in `location` with its query "
                "removed."
            )
        if status >= 400:
            notes.append(
                "the URL answered with an error status; these headers describe "
                "that answer, not a working page."
            )
        if parts.scheme.lower() != "https":
            notes.append(
                "the URL is plain HTTP: no TLS was negotiated, so nothing here "
                "speaks about transport security on this host."
            )
        return {
            "url": url,
            "scheme": parts.scheme.lower(),
            "status": status,
            "server": kept.get("server", ""),
            "location": kept.get("location", ""),
            "headers": kept,
            "notes": notes,
        }

    # ---------------------------------------------------------------- parse
    def parse(self, command: CommandResult) -> PostureReport:
        try:
            payload = json.loads(command.stdout or "{}")
        except json.JSONDecodeError as trouble:
            raise ToolExecutionError(
                f"the posture observation is not JSON ({trouble}); nothing can "
                "be read from it"
            ) from trouble
        if not isinstance(payload, dict):
            raise ToolExecutionError("the posture observation is not an object")

        url = payload.get("url")
        status = payload.get("status")
        headers = payload.get("headers")
        if not isinstance(url, str) or not url:
            raise ToolExecutionError("the posture observation names no URL")
        if isinstance(status, bool) or not isinstance(status, int) or not (
            100 <= status <= 599
        ):
            raise ToolExecutionError(
                f"the posture observation has no usable status code: {status!r}"
            )
        if not isinstance(headers, dict):
            raise ToolExecutionError("the posture observation has no header map")

        allowed = {name for name, _ in RECOMMENDED_HEADERS} | set(_KEEP_NAMES)
        kept: dict[str, str] = {}
        for name, value in headers.items():
            key = str(name).strip().lower()
            if key in kept or not isinstance(value, str):
                continue
            if key not in allowed:
                # Fail closed rather than widening the allow-list here: the
                # observation is ours, so an unexpected name means the shape
                # changed and a human should look before it is believed.
                raise ToolExecutionError(
                    f"the posture observation carries an unexpected header: {key!r}"
                )
            kept[key] = _text(value)

        missing, weak = _judge(kept)
        tls = self._tls_from(payload.get("tls"))
        notes = tuple(
            _text(note, 240) for note in (payload.get("notes") or ()) if note
        )
        if tls.problem:
            notes = notes + (f"TLS: {tls.problem}",)
        return PostureReport(
            url=_text(url, 300),
            status_code=status,
            server=kept.get("server", ""),
            location=kept.get("location", ""),
            headers=kept,
            missing_headers=missing,
            weak_headers=weak,
            tls=tls,
            notes=notes,
        )

    @staticmethod
    def _tls_from(payload: Any) -> TlsPosture:
        if not isinstance(payload, dict):
            return TlsPosture()
        days = payload.get("days_remaining")
        verified = payload.get("verified")
        return TlsPosture(
            https=bool(payload.get("https")),
            protocol=_text(payload.get("protocol"), 20),
            cipher=_text(payload.get("cipher"), 60),
            subject=_text(payload.get("subject"), 120),
            issuer=_text(payload.get("issuer"), 120),
            not_after=_text(payload.get("not_after"), 60),
            days_remaining=(
                days
                if isinstance(days, int) and not isinstance(days, bool)
                else None
            ),
            verified=verified if isinstance(verified, bool) else _NOT_NEGOTIATED,
            problem=_text(payload.get("problem"), 160),
        )

    # ------------------------------------------------------------- summarize
    def summarize(self, parsed: Any) -> dict[str, Any]:
        """Names, counts and dates - never a header value.

        An audit entry is a decision record, and a header value is the site's
        own text. What the entry keeps is what was absent, what was weak, and
        what TLS was negotiated, which is what a later reviewer re-checks.
        """
        if not isinstance(parsed, PostureReport):
            return {}
        return {
            "posture_url": parsed.url,
            "posture_status": parsed.status_code,
            "posture_server": parsed.server,
            "posture_missing_headers": list(parsed.missing_headers),
            "posture_weak_headers": list(parsed.weak_headers),
            "posture_present_headers": len(parsed.present_headers),
            "posture_redirect": parsed.redirect,
            "posture_tls_protocol": parsed.tls.protocol,
            "posture_tls_verified": parsed.tls.verified,
            "posture_tls_days_remaining": parsed.tls.days_remaining,
        }


def posture(target: str, context: ToolContext, **options: Any) -> ToolResult:
    """Convenience wrapper: ``posture(url, context)``."""
    return PostureAdapter().run(target, context, **options)

