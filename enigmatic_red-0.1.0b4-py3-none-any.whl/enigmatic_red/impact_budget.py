"""Time-boxed impact budgets — the pre-signed grant that replaces approvals.

A scan does not stop and ask a human before every intrusive step. Instead the
operator signs *one* budget that states, up front, how much impact the scan may
have and for how long:

* :attr:`BudgetLevel.READ_ONLY_ACTIVE` covers passive recon and active
  enumeration and nothing else. It is what a CI job or an autonomous agent gets.
* :attr:`BudgetLevel.SAFE_INTRUSIVE_PROF` additionally covers the intrusive but
  non-destructive class (a single-request injection probe, a login attempt with
  known test credentials).
* :attr:`BudgetLevel.CONTROLLED_POC` is the only level that reaches the
  ``exploit_safe`` class: one exact, non-destructive proof of concept, with the
  tightest defaults in the table (three targets, twenty minutes, twenty
  actions). It does *not* cover ``forbidden`` either.

No level can ever cover :attr:`~safety.guard.ActionClass.FORBIDDEN`; that
is a hard floor in :mod:`safety.guard` and stays unreachable from here. A budget
only *narrows* what the guard already allows.

The grant is a signed token (HMAC-SHA256, same construction as the audit chain):
tampering with the level, the TTL or the target count invalidates it, and it is
bound to one org so a token issued for one tenant cannot charge another. The
secret is the caller's business — read it from the OS keyring, never from a
committed file.

:class:`BudgetLedger` is the mutable half. It holds one budget, counts the
distinct targets and actions spent, and refuses beyond the grant:

* :class:`~safety.errors.ImpactNotPermitted` — the level does not reach the class;
* :class:`~safety.errors.BudgetExpired` — the TTL is gone;
* :class:`~safety.errors.BudgetExhausted` — targets or actions used up.

Every refusal is an :class:`~safety.errors.BudgetError`, which is itself an
:class:`~safety.errors.EnigmaticRedError`, so the tool layer can audit it and the
API layer can map it without special-casing.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import secrets
import threading
import time
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from enum import Enum
from typing import Any, Callable

from safety.errors import (
    BudgetError,
    BudgetExhausted,
    BudgetExpired,
    ImpactNotPermitted,
)
from safety.guard import ActionClass

__all__ = [
    "MIN_SECRET_BYTES",
    "TOKEN_VERSION",
    "BudgetLedger",
    "BudgetLevel",
    "BudgetSigner",
    "BudgetUsage",
    "ImpactBudget",
]

#: Bumped if the token layout ever changes; old tokens then fail closed.
TOKEN_VERSION = "v1"

#: HMAC-SHA256 with anything shorter is not a signature, it is decoration.
MIN_SECRET_BYTES = 32

#: Injectable clock so tests can age a budget without sleeping.
Clock = Callable[[], float]


class BudgetLevel(str, Enum):
    """What a budget is allowed to cover, and its default allowances."""

    READ_ONLY_ACTIVE = "read_only_active"
    SAFE_INTRUSIVE_PROF = "safe_intrusive_prof"
    CONTROLLED_POC = "controlled_poc"

    @property
    def ceiling(self) -> ActionClass:
        """The most severe action class this level permits."""
        if self is BudgetLevel.CONTROLLED_POC:
            return ActionClass.EXPLOIT_SAFE
        if self is BudgetLevel.SAFE_INTRUSIVE_PROF:
            return ActionClass.INTRUSIVE
        return ActionClass.ACTIVE

    @property
    def default_max_targets(self) -> int:
        if self is BudgetLevel.CONTROLLED_POC:
            # A proof of concept is proven on one target; three leaves room for
            # a retry against a second host the customer names.
            return 3
        return 25 if self is BudgetLevel.READ_ONLY_ACTIVE else 10

    @property
    def default_max_minutes(self) -> float:
        if self is BudgetLevel.CONTROLLED_POC:
            return 20.0
        return 60.0 if self is BudgetLevel.READ_ONLY_ACTIVE else 30.0

    @property
    def default_max_actions(self) -> int:
        if self is BudgetLevel.CONTROLLED_POC:
            # Single-shot validate, then verify: an exploit that needs twenty
            # attempts is a campaign, not a controlled PoC.
            return 20
        return 250 if self is BudgetLevel.READ_ONLY_ACTIVE else 120

    def permits(self, action_class: ActionClass) -> bool:
        """``True`` if this level reaches *action_class*.

        Forbidden is excluded explicitly rather than by rank so a future
        re-ordering of the enum cannot quietly widen a budget.
        """
        if action_class is ActionClass.FORBIDDEN:
            return False
        return action_class.rank <= self.ceiling.rank


def _iso(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat()


def _parse_iso(value: Any, *, field: str) -> datetime:
    if not isinstance(value, str):
        raise ValueError(f"budget payload field {field!r} must be an ISO-8601 string")
    try:
        parsed = datetime.fromisoformat(value)
    except ValueError as exc:
        raise ValueError(f"budget payload field {field!r} is not ISO-8601") from exc
    if parsed.tzinfo is None:
        raise ValueError(f"budget payload field {field!r} must be timezone-aware")
    return parsed.astimezone(timezone.utc)


@dataclass(frozen=True)
class ImpactBudget:
    """A signed, org-scoped, time-boxed allowance. Immutable by construction."""

    budget_id: str
    level: BudgetLevel
    org: str
    issued_at: datetime
    expires_at: datetime
    max_targets: int
    max_actions: int

    def __post_init__(self) -> None:
        if not self.budget_id:
            raise ValueError("budget_id must not be empty")
        if not self.org:
            raise ValueError("org must not be empty")
        if self.expires_at <= self.issued_at:
            raise ValueError("expires_at must be after issued_at")
        if self.max_targets < 1:
            raise ValueError("max_targets must be at least 1")
        if self.max_actions < 1:
            raise ValueError("max_actions must be at least 1")

    @property
    def ceiling(self) -> ActionClass:
        return self.level.ceiling

    def permits(self, action_class: ActionClass) -> bool:
        return self.level.permits(action_class)

    def ttl_seconds(self) -> float:
        return (self.expires_at - self.issued_at).total_seconds()

    def remaining_seconds(self, *, now: datetime | None = None) -> float:
        moment = now or datetime.now(timezone.utc)
        return max(0.0, (self.expires_at - moment).total_seconds())

    def expired(self, *, now: datetime | None = None) -> bool:
        return self.remaining_seconds(now=now) <= 0.0

    def to_payload(self) -> dict[str, Any]:
        """The signed body. Field order is irrelevant; JSON is sorted."""
        return {
            "budget_id": self.budget_id,
            "level": self.level.value,
            "org": self.org,
            "issued_at": _iso(self.issued_at),
            "expires_at": _iso(self.expires_at),
            "max_targets": self.max_targets,
            "max_actions": self.max_actions,
        }

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "ImpactBudget":
        try:
            level = BudgetLevel(payload["level"])
            budget_id = payload["budget_id"]
            org = payload["org"]
            max_targets = payload["max_targets"]
            max_actions = payload["max_actions"]
        except KeyError as exc:
            raise ValueError(f"budget payload is missing {exc.args[0]!r}") from exc
        if not isinstance(budget_id, str) or not isinstance(org, str):
            raise ValueError("budget payload identity fields must be strings")
        for name, value in (("max_targets", max_targets), ("max_actions", max_actions)):
            if not isinstance(value, int) or isinstance(value, bool):
                raise ValueError(f"budget payload field {name!r} must be an integer")
        return cls(
            budget_id=budget_id,
            level=level,
            org=org,
            issued_at=_parse_iso(payload.get("issued_at"), field="issued_at"),
            expires_at=_parse_iso(payload.get("expires_at"), field="expires_at"),
            max_targets=max_targets,
            max_actions=max_actions,
        )

    def describe(self) -> dict[str, Any]:
        """Non-secret summary for audit detail and reports."""
        return {
            "budget_id": self.budget_id,
            "level": self.level.value,
            "org": self.org,
            "ceiling": self.ceiling.value,
            "issued_at": _iso(self.issued_at),
            "expires_at": _iso(self.expires_at),
            "max_targets": self.max_targets,
            "max_actions": self.max_actions,
        }


class BudgetSigner:
    """Issues and verifies budget tokens for one org.

    The secret is the operator's; pass the value read from the OS keyring at
    startup, never a literal. Verification is constant-time and fails closed on
    any structural, integrity or scope problem — a forged token is indistinguishable
    from a corrupt one from the caller's side, which is the point.
    """

    def __init__(self, secret: str | bytes, *, clock: Clock = time.time) -> None:
        material = secret.encode("utf-8") if isinstance(secret, str) else bytes(secret)
        if len(material) < MIN_SECRET_BYTES:
            raise ValueError(
                f"budget signing secret must be at least {MIN_SECRET_BYTES} bytes "
                f"(got {len(material)}); generate one with: python -c "
                "\"import secrets;print(secrets.token_urlsafe(48))\""
            )
        self._secret = material
        self._clock = clock

    # -- issuing ---------------------------------------------------------
    def issue(
        self,
        level: BudgetLevel,
        *,
        org: str,
        budget_id: str | None = None,
        max_targets: int | None = None,
        max_minutes: float | None = None,
        max_actions: int | None = None,
    ) -> ImpactBudget:
        """Mint a budget and return it (call :meth:`sign` for the token)."""
        now = datetime.fromtimestamp(self._clock(), timezone.utc)
        minutes = level.default_max_minutes if max_minutes is None else float(max_minutes)
        if minutes <= 0:
            raise ValueError("max_minutes must be positive")
        return ImpactBudget(
            budget_id=budget_id or f"ib_{secrets.token_hex(8)}",
            level=level,
            org=org,
            issued_at=now,
            expires_at=now + timedelta(minutes=minutes),
            max_targets=level.default_max_targets if max_targets is None else int(max_targets),
            max_actions=level.default_max_actions if max_actions is None else int(max_actions),
        )

    def issue_token(self, level: BudgetLevel, *, org: str, **kwargs: Any) -> str:
        """Convenience: mint and sign in one step."""
        return self.sign(self.issue(level, org=org, **kwargs))

    # -- signing ---------------------------------------------------------
    def sign(self, budget: ImpactBudget) -> str:
        """``v1.<b64url(payload)>.<hex hmac>``."""
        body = json.dumps(
            budget.to_payload(), sort_keys=True, separators=(",", ":"), ensure_ascii=True
        ).encode("utf-8")
        encoded = base64.urlsafe_b64encode(body).decode("ascii").rstrip("=")
        signing_input = f"{TOKEN_VERSION}.{encoded}".encode("ascii")
        signature = hmac.new(self._secret, signing_input, hashlib.sha256).hexdigest()
        return f"{TOKEN_VERSION}.{encoded}.{signature}"

    # -- verifying -------------------------------------------------------
    def verify(self, token: str, *, org: str | None = None) -> ImpactBudget:
        """Check integrity, version and org scope; return the budget.

        Expiry is deliberately *not* checked here: a verified-but-expired budget
        is still useful evidence (it names itself in the refusal), and the ledger
        reports it as :class:`~safety.errors.BudgetExpired` rather than as forgery.
        """
        budget = self._verified_budget(token)
        if org is not None and budget.org != org:
            raise ValueError(
                f"budget {budget.budget_id} was issued for org {budget.org!r}, not {org!r}"
            )
        return budget

    def _verified_budget(self, token: str) -> ImpactBudget:
        if not isinstance(token, str):
            raise ValueError("budget token must be a string")
        parts = token.strip().split(".")
        if len(parts) != 3:
            raise ValueError("malformed budget token: expected 3 dot-separated segments")
        version, encoded, signature = parts
        if version != TOKEN_VERSION:
            raise ValueError(
                f"unsupported budget token version {version!r} (this build speaks {TOKEN_VERSION})"
            )
        signing_input = f"{version}.{encoded}".encode("ascii")
        expected = hmac.new(self._secret, signing_input, hashlib.sha256).hexdigest()
        if not hmac.compare_digest(expected, signature.lower()):
            raise ValueError("budget token signature does not verify")
        padding = "=" * (-len(encoded) % 4)
        try:
            raw = base64.urlsafe_b64decode(encoded + padding)
            payload = json.loads(raw.decode("utf-8"))
        except (ValueError, UnicodeDecodeError) as exc:
            raise ValueError("budget token payload is not valid base64 JSON") from exc
        if not isinstance(payload, dict):
            raise ValueError("budget token payload must be a JSON object")
        return ImpactBudget.from_payload(payload)


@dataclass(frozen=True)
class BudgetUsage:
    """A read-only snapshot of what a ledger has spent so far."""

    budget_id: str
    level: BudgetLevel
    targets_used: int
    max_targets: int
    actions_used: int
    max_actions: int
    remaining_seconds: float

    def as_dict(self) -> dict[str, Any]:
        """Serializable form for audit detail and the report layer."""
        return {
            "budget_id": self.budget_id,
            "level": self.level.value,
            "targets_used": self.targets_used,
            "max_targets": self.max_targets,
            "actions_used": self.actions_used,
            "max_actions": self.max_actions,
            "remaining_seconds": round(self.remaining_seconds, 3),
        }


class BudgetLedger:
    """The mutable half of an :class:`ImpactBudget`.

    One ledger holds one verified budget and counts what has been spent against
    it: the distinct targets touched and the number of actions run. It is the one
    place a budget is enforced, so the tool layer asks it *before* acting and
    charges it *when* acting; :meth:`check` answers without mutating, and
    :meth:`consume` re-validates and writes under a lock, so two threads cannot
    both slip past the last remaining action.

    Every refusal is a :class:`~safety.errors.BudgetError` subclass:

    * :class:`~safety.errors.ImpactNotPermitted` - the level does not reach the
      class (including the forbidden class, which no level ever reaches);
    * :class:`~safety.errors.BudgetExpired` - the TTL is gone;
    * :class:`~safety.errors.BudgetExhausted` - targets or actions used up.

    Counts never decrease: there is no ``reset``, because a budget that can be
    replayed is not a budget.
    """

    def __init__(self, budget: ImpactBudget, *, clock: Clock = time.time) -> None:
        if not isinstance(budget, ImpactBudget):
            raise TypeError(f"budget must be an ImpactBudget, not {type(budget).__name__}")
        self._budget = budget
        self._clock = clock
        self._lock = threading.Lock()
        self._targets: set[str] = set()
        self._actions = 0

    @classmethod
    def from_token(
        cls,
        token: str,
        signer: "BudgetSigner",
        *,
        org: str | None = None,
        clock: Clock = time.time,
    ) -> "BudgetLedger":
        """Verify a signed token and adopt the budget it carries."""
        return cls(signer.verify(token, org=org), clock=clock)

    # -- read-only views -------------------------------------------------
    @property
    def budget(self) -> ImpactBudget:
        return self._budget

    @property
    def targets_used(self) -> int:
        with self._lock:
            return len(self._targets)

    @property
    def actions_used(self) -> int:
        with self._lock:
            return self._actions

    def usage(self) -> BudgetUsage:
        """A snapshot of counts and time left, safe to log."""
        with self._lock:
            return self._usage_locked()

    def describe(self) -> dict[str, Any]:
        """Non-secret summary for audit detail and the report layer."""
        with self._lock:
            return {
                "budget": self._budget.describe(),
                "used": self._usage_locked().as_dict(),
            }

    # -- the one write ---------------------------------------------------
    def check(self, action_class: ActionClass, *, target: str | None = None) -> None:
        """Refuse now if the next action could not be charged. Mutates nothing.

        Advisory with respect to concurrency: another thread may spend the last
        slot between this call and :meth:`consume`. That is fine, because the
        charge itself is what enforces the budget.
        """
        key = self._target_key(target)
        with self._lock:
            self._validate(action_class, key, 1)

    def consume(
        self,
        action_class: ActionClass,
        *,
        target: str | None = None,
        count: int = 1,
    ) -> BudgetUsage:
        """Charge ``count`` action(s) against the budget and return the result."""
        key = self._target_key(target)
        if isinstance(count, bool) or not isinstance(count, int) or count < 1:
            raise ValueError("count must be a positive integer")
        with self._lock:
            self._validate(action_class, key, count)
            if key is not None:
                self._targets.add(key)
            self._actions += count
            return self._usage_locked()

    # -- internals -------------------------------------------------------
    @staticmethod
    def _target_key(target: str | None) -> str | None:
        """Normalise a target for distinct counting.

        Only surrounding whitespace is removed. Case is preserved on purpose:
        folding it could merge two distinct resources into one slot, which would
        widen the budget. Counting one host twice only narrows it.
        """
        if target is None:
            return None
        if not isinstance(target, str):
            raise TypeError(f"target must be a string or None, not {type(target).__name__}")
        key = target.strip()
        if not key:
            raise ValueError("target must not be blank")
        return key

    def _now(self) -> datetime:
        return datetime.fromtimestamp(self._clock(), timezone.utc)

    def _usage_locked(self) -> BudgetUsage:
        budget = self._budget
        return BudgetUsage(
            budget_id=budget.budget_id,
            level=budget.level,
            targets_used=len(self._targets),
            max_targets=budget.max_targets,
            actions_used=self._actions,
            max_actions=budget.max_actions,
            remaining_seconds=budget.remaining_seconds(now=self._now()),
        )

    def _validate(self, action_class: ActionClass, target: str | None, count: int) -> None:
        """Caller holds the lock. Order is deliberate: the floor comes first."""
        budget = self._budget
        if action_class is ActionClass.FORBIDDEN:
            raise self._refusal(
                ImpactNotPermitted,
                action_class,
                target,
                f"action class 'forbidden' is never covered by a budget "
                f"(budget {budget.budget_id} refused before the guard is consulted)",
            )
        if budget.expired(now=self._now()):
            raise self._refusal(
                BudgetExpired,
                action_class,
                target,
                f"budget {budget.budget_id} expired at {_iso(budget.expires_at)}",
            )
        if not budget.permits(action_class):
            raise self._refusal(
                ImpactNotPermitted,
                action_class,
                target,
                f"budget {budget.budget_id} ({budget.level.value}, ceiling "
                f"{budget.ceiling.value}) does not cover action class "
                f"{action_class.value}",
            )
        if (
            target is not None
            and target not in self._targets
            and len(self._targets) >= budget.max_targets
        ):
            raise self._refusal(
                BudgetExhausted,
                action_class,
                target,
                f"budget {budget.budget_id} is exhausted: {budget.max_targets} distinct "
                f"target(s) already touched, {target!r} would be one more",
            )
        if self._actions + count > budget.max_actions:
            raise self._refusal(
                BudgetExhausted,
                action_class,
                target,
                f"budget {budget.budget_id} is exhausted: {self._actions} of "
                f"{budget.max_actions} action(s) spent, {count} more requested",
            )

    def _refusal(
        self,
        error_type: type[BudgetError],
        action_class: ActionClass,
        target: str | None,
        message: str,
    ) -> BudgetError:
        """Build the refusal carrying the context the tool layer audits."""
        error = error_type(message)
        error.budget_id = self._budget.budget_id
        error.budget_level = self._budget.level.value
        error.action_class = action_class.value
        error.target = target
        return error
