"""Action classification for commands and payloads.

The guard sits between the planner and every subprocess. It answers one
question: *what class of action is this?* and then refuses or gates it.

Five classes, ordered by blast radius:

``passive``
    No packets reach the target (certificate-transparency, Wayback, DNS
    records already published). Safe at any authorization level.
``active``
    Ordinary enumeration: port scans, banners, content discovery. Requires
    scope + authorization, but no extra consent.
``intrusive``
    Exploit templates, injection probes, state-changing requests. Requires an
    explicit human approval for each action.
``exploit_safe``
    The controlled proof-of-concept tier: one exact, non-destructive exploit
    template against one in-scope target, single-shot and rate-limited. It sits
    *above* ``intrusive`` because it is real exploitation rather than a probe,
    so it keeps the approval requirement, needs an RoE that names it, and is
    the only class a :class:`~enigmatic_red.impact_budget.BudgetLevel.CONTROLLED_POC`
    budget covers. Nothing is classified here by default: a tool reaches this
    class only when an install registers it (``tool_classes``), which is a
    tightening the constructor accepts and a downgrade it refuses.
``forbidden``
    Capability classes this product does not ship, ever: denial of service,
    credential brute force, persistence, wipe/destroy, command-and-control,
    bulk exfiltration, and SSRF aimed at cloud metadata. No configuration and
    no approval can enable these; the rule table is code, not YAML.

``policy.yaml`` may only *add* restrictions (or promote a tool to a more
dangerous class). It cannot remove a hard-deny rule — that asymmetry is
deliberate so a config typo can never silently disarm the product.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Iterable, Pattern, Sequence

import yaml

from safety.errors import ApprovalRequired, ForbiddenActionError

__all__ = [
    "ActionClass",
    "ForbiddenRule",
    "Guard",
    "GuardDecision",
    "DESTRUCTIVE_RULES",
    "FORBIDDEN_RULES",
    "INTRUSIVE_RULES",
]

_ORDER: dict[str, int] = {
    "passive": 0,
    "active": 1,
    "intrusive": 2,
    "exploit_safe": 3,
    "forbidden": 4,
}


class ActionClass(str, Enum):
    PASSIVE = "passive"
    ACTIVE = "active"
    INTRUSIVE = "intrusive"
    EXPLOIT_SAFE = "exploit_safe"
    FORBIDDEN = "forbidden"

    @property
    def rank(self) -> int:
        return _ORDER[self.value]

    @property
    def requires_approval(self) -> bool:
        """Everything from ``intrusive`` up needs a human, except ``forbidden``.

        Defined once, on the class, so a new rung on the ladder cannot be added
        without inheriting the approval requirement. ``forbidden`` is excluded
        because no approval can ever unlock it.
        """
        return self is not ActionClass.FORBIDDEN and self.rank >= _ORDER["intrusive"]

    def worse_of(self, other: "ActionClass") -> "ActionClass":
        return self if self.rank >= other.rank else other


@dataclass(frozen=True)
class ForbiddenRule:
    """A hard-deny pattern. ``pattern`` is matched case-insensitively."""

    name: str
    pattern: str
    class_: ActionClass = ActionClass.FORBIDDEN
    reason: str = ""

    def compiled(self) -> Pattern[str]:
        return re.compile(self.pattern, re.IGNORECASE)


@dataclass(frozen=True)
class GuardDecision:
    action_class: ActionClass
    reasons: tuple[str, ...] = ()
    matched_rules: tuple[str, ...] = ()

    @property
    def allowed(self) -> bool:
        """Forbidden is the only class that is flat-out refused."""
        return self.action_class is not ActionClass.FORBIDDEN

    @property
    def requires_approval(self) -> bool:
        return self.action_class.requires_approval

    def __bool__(self) -> bool:  # pragma: no cover - trivial
        return self.allowed


# ---------------------------------------------------------------------------
#  Hard-deny table (code, not configuration)
# ---------------------------------------------------------------------------
#  These describe capabilities, not techniques. A penetration test never needs
#  them, so their absence costs nothing and their presence protects both the
#  customer and this platform. Adding entries here is the supported way to
#  tighten the product.
FORBIDDEN_RULES: tuple[ForbiddenRule, ...] = (
    ForbiddenRule(
        "dos_tooling",
        r"\b(hping3|slowloris|goldeneye|torshammer|loic|mhddos|siege|h2load|"
        r"apachebench|ab\s+-n)\b",
        reason="denial-of-service tooling",
    ),
    ForbiddenRule(
        "dos_flags",
        # ``-T5`` is nmap's timing template and is upper-case there; ``-t 5`` is
        # an ordinary thread count in every other tool here. The rule is
        # compiled case-insensitively, so that alternative is scoped back to its
        # real case, or ffuf's own default ``-t 5`` would read as a flood.
        r"(--flood\b|--min-rate\s+\d{4,}|(?-i:-T)\s*5\b|--max-parallelism\s+\d{3,}|"
        r"-r\s+\d{4,}\b)",
        reason="flood or high-rate flags intended to exhaust the target",
    ),
    ForbiddenRule(
        "dos_language",
        r"\b(syn\s+flood|udp\s+flood|dns\s+amplification|http\s+flood|cc\s+attack|"
        r"resource\s+exhaustion\s+attack)\b",
        reason="denial-of-service request",
    ),
    ForbiddenRule(
        "credential_bruteforce",
        r"\b(hydra|medusa|ncrack|patator|crowbar|brutus|hashcat|"
        r"john\s+the\s+ripper)\b",
        reason="credential brute-forcing / hash cracking",
    ),
    ForbiddenRule(
        "nmap_brute_dos_scripts",
        r"--script[= ]\s*['\"]?[^'\"]*?\b(brute|dos)\b",
        reason="nmap bypass of the brute-force / DoS prohibition",
    ),
    ForbiddenRule(
        "exploit_frameworks",
        r"\b(msfconsole|msfvenom|meterpreter|empire|cobalt\s*strike|sliver|"
        r"mythic|beef)\b",
        reason="exploitation framework outside the approved toolset",
    ),
    ForbiddenRule(
        "remote_access",
        r"(/dev/tcp/|bash\s+-i|sh\s+-i\s*(>&|>|\|)|Invoke-Expression|IEX\s*\(|"
        r"powershell[^|;&]*-enc(odedcommand)?\b|"
        r"\b(nc|ncat|netcat)\b[^|;&]*\s-e[\s=]|socat[^|;&]*\bexec)",
        reason="reverse/bind shell or command-and-control channel",
    ),
    ForbiddenRule(
        "rce_switches",
        r"(--os-shell|--os-pwn|--os-cmd|--sql-shell|--file-dest|--file-write)\b",
        reason="remote command execution / target-side file write",
    ),
    ForbiddenRule(
        "persistence",
        r"(crontab\s+-|systemctl\s+enable|schtasks\s+/create|reg\s+add\s+\S*\\Run|"
        r"authorized_keys|/etc/rc\.local|LaunchDaemons)",
        reason="persistence mechanism",
    ),
    ForbiddenRule(
        "destructive_filesystem",
        r"(rm\s+-rf\s+/(\s|$)|dd\s+if=\S*\s+of=/dev/(sd|nvme|vd|xvd)|mkfs\.|"
        r"shred\s+|:\(\)\s*\{\s*:\|:&\s*\};:)",
        reason="destructive filesystem operation or fork bomb",
    ),
    ForbiddenRule(
        "destructive_sql",
        r"\b(drop\s+(table|database|schema)|truncate\s+table|delete\s+from|"
        r"update\s+\w+\s+set\s+\w+\s*=)",
        reason="state-destroying or state-changing SQL (write path)",
    ),
    ForbiddenRule(
        "scm_destructive",
        r"(\bgit\s+(?:-c\s+\S+\s+)*push\s[^|;&]*"
        r"(--force(-with-lease)?\b|(?<![\w-])-f\b|--delete\b|\+refs/)"
        r"|\bgit\s+remote\s+(set-url|remove)\b"
        r"|\bgit\s+(reset\s+--hard\b|filter-branch\b|filter-repo\b)"
        r"|\bgh\s+repo\s+delete\b|\bhf\s+repo\s+delete\b)",
        reason="rewriting or destroying history on a remote that is not ours",
    ),
    ForbiddenRule(
        "local_file_exfil",
        r"(@\s*/etc/shadow|@\s*\S*\.ssh/id_|@\s*\S*\.aws/credentials|"
        r"--file-read\b|into\s+outfile|load_file\s*\(|pg_read_file\s*\()",
        reason="reading or transmitting local secrets / arbitrary file read",
    ),
    ForbiddenRule(
        "bulk_exfil",
        r"\b(mysqldump|pg_dump|mongodump|mongoexport|aws\s+s3\s+(sync|cp))\b",
        reason="bulk data exfiltration",
    ),
    ForbiddenRule(
        "metadata_ssrf",
        r"(169\.254\.169\.254|metadata\.google\.internal|100\.100\.100\.200|"
        r"instance-data|fd00:ec2::254)",
        reason="SSRF aimed at cloud metadata (would expose platform credentials)",
    ),
    ForbiddenRule(
        "wiper_malware",
        r"\b(xmrig|minerd|ransom|encrypt_all|vssadmin\s+delete)\b",
        reason="malware / wiper / cryptominer behaviour",
    ),
)

# ---------------------------------------------------------------------------
#  Destructive-exploit table (code, not configuration)
# ---------------------------------------------------------------------------
#  ``FORBIDDEN_RULES`` above describes *capabilities* nobody needs on a
#  penetration test. This second table describes the small set of *flags* that
#  turn an otherwise legitimate proof-of-concept into a destructive one: the
#  difference between validating a CVE and dumping or rewriting the data behind
#  it. They are separated so ``describe_policy`` can report them on their own
#  line, and they are merged into the same hard-deny scan, so they are refused
#  for an ``intrusive`` action and for an ``exploit_safe`` one alike.
DESTRUCTIVE_RULES: tuple[ForbiddenRule, ...] = (
    ForbiddenRule(
        "destructive_sqlmap_risk",
        # sqlmap's risk 3 enables OR-based payloads that can change rows; risk
        # 1-2 stay in the read/boolean/time-based band and remain intrusive.
        r"--risk[= ]\s*3\b",
        reason="sqlmap risk 3 payloads can modify target data",
    ),
    ForbiddenRule(
        "destructive_sqlmap_dump",
        r"--dump-all\b|\bdump\s+all\b",
        reason="bulk extraction of every database on the target",
    ),
    ForbiddenRule(
        "destructive_nuclei_fuzz",
        # Fuzzing mutates a request body until something breaks; it is not a
        # proof of concept with a known, bounded request. ``-dast`` is the same
        # capability under nuclei's DAST flag.
        r"\bnuclei\b[^|;&]*\s(-fuzz|--fuzz|-dast)\b",
        reason="request fuzzing rather than a bounded proof of concept",
    ),
)

# ---------------------------------------------------------------------------
#  Approval-required table (intrusive, but legitimate when consented)
# ---------------------------------------------------------------------------
INTRUSIVE_RULES: tuple[ForbiddenRule, ...] = (
    ForbiddenRule(
        "rce_probe",
        r"([;|&]{1,2}\s+(id|whoami|uname\s+-a|cat\s+/etc/hostname)\b|"
        r"\$\(id\)|`id`)",
        class_=ActionClass.INTRUSIVE,
        reason="command-injection probe: proving RCE is high impact",
    ),
    ForbiddenRule(
        "sqli_probe",
        r"(\bunion\s+(all\s+)?select\b|\bor\s+1\s*=\s*1\b|sleep\s*\(\s*\d+\s*\)|"
        r"waitfor\s+delay|pg_sleep|benchmark\s*\()",
        class_=ActionClass.INTRUSIVE,
        reason="SQL injection probe",
    ),
    ForbiddenRule(
        "xss_probe",
        r"(<script\b|javascript:\s|on(error|load|mouseover)\s*=)",
        class_=ActionClass.INTRUSIVE,
        reason="cross-site scripting probe",
    ),
    ForbiddenRule(
        "ssti_probe",
        r"(\{\{.*\}\}|\$\{[^}]*\}|<%=.*%>)",
        class_=ActionClass.INTRUSIVE,
        reason="template-injection probe",
    ),
    ForbiddenRule(
        "traversal_probe",
        r"(\.\./\.\./|%2e%2e%2f|\.\.\\\.\.\\|/etc/passwd)",
        class_=ActionClass.INTRUSIVE,
        reason="path traversal probe",
    ),
    ForbiddenRule(
        "jndi_probe",
        r"(\$\{jndi:|ldap://|rmi://|dns://)",
        class_=ActionClass.INTRUSIVE,
        reason="JNDI/LDAP lookup probe (may trigger out-of-band callbacks)",
    ),
    ForbiddenRule(
        "ssrf_probe",
        r"(http://127\.0\.0\.1|http://localhost|file:///|gopher://|dict://)",
        class_=ActionClass.INTRUSIVE,
        reason="server-side request forgery probe",
    ),
    ForbiddenRule(
        "webshell_probe",
        r"(eval\s*\(|assert\s*\(|shell_exec|passthru\s*\(|<\?php)",
        class_=ActionClass.INTRUSIVE,
        reason="code-execution payload",
    ),
    ForbiddenRule(
        "exploit_tooling",
        r"\b(sqlmap|xsser|xsstrike|commix|dalfox|wpscan|nikto|"
        r"nuclei[^|]*-t\s+\S*?(exploit|fuzz)\w*)\b",
        class_=ActionClass.INTRUSIVE,
        reason="exploitation tooling",
    ),
    ForbiddenRule(
        "mutating_http_verbs",
        r"(-X[= ]\s*(POST|PUT|PATCH|DELETE)\b|--method[= ]\s*(POST|PUT|PATCH|DELETE)\b)",
        class_=ActionClass.INTRUSIVE,
        reason="request that may modify target state",
    ),
    ForbiddenRule(
        "aggressive_scan",
        # ``-A`` is nmap's own aggressive-scan flag, and it is upper-case there.
        # Every rule is compiled case-insensitively, so the flag is scoped back
        # to its real case here: ``dnsx -a`` - the address record a passive
        # lookup asks for by default - is not the same flag, and a rule that
        # cannot tell them apart makes a passive adapter unapprovable.
        r"(\s(?-i:-A)\b|--script[= ]\S*\b(vuln|exploit|intrusive|auth))",
        class_=ActionClass.INTRUSIVE,
        reason="aggressive/scripted scan that may alter state or trip alarms",
    ),
    ForbiddenRule(
        "scm_write",
        r"(\bgit\s+(?:-c\s+\S+\s+)*(push|tag\s+-a\b|tag\s+-f\b)\b"
        r"|\bgh\s+(pr|issue|release|repo)\s+"
        r"(create|merge|close|reopen|edit|comment|delete)\b"
        r"|\bhf\s+(upload|repo\s+create)\b)",
        class_=ActionClass.INTRUSIVE,
        reason="writes to a repository or a model hub: a third party's state changes",
    ),
)

# ---------------------------------------------------------------------------
#  Default class per tool
# ---------------------------------------------------------------------------
DEFAULT_TOOL_CLASS: dict[str, ActionClass] = {
    # passive sources: nothing is sent to the target
    "subfinder": ActionClass.PASSIVE,
    "assetfinder": ActionClass.PASSIVE,
    "asnmap": ActionClass.PASSIVE,
    "amass": ActionClass.PASSIVE,
    "gau": ActionClass.PASSIVE,
    "waybackurls": ActionClass.PASSIVE,
    "dnsx": ActionClass.PASSIVE,
    # active enumeration
    "nmap": ActionClass.ACTIVE,
    "ncat": ActionClass.ACTIVE,
    "httpx": ActionClass.ACTIVE,
    # One request and one TLS handshake, no body, no redirect followed: the
    # same blast radius as a banner grab, so it is active rather than passive,
    # and it never needs an approval.
    "posture": ActionClass.ACTIVE,
    "gobuster": ActionClass.ACTIVE,
    "ffuf": ActionClass.ACTIVE,
    "whatweb": ActionClass.ACTIVE,
    # source control and model hubs: reading one is an ordinary request, writing
    # one changes a third party's state and is gated by the scm_write rule.
    "git": ActionClass.ACTIVE,
    "gh": ActionClass.ACTIVE,
    "hf": ActionClass.ACTIVE,
    # exploitation: gated behind explicit approval by default
    "nuclei": ActionClass.INTRUSIVE,
    "sqlmap": ActionClass.INTRUSIVE,
}


class Guard:
    """Classifies commands and payloads, then enforces the verdict.

    Args:
        tool_classes: overrides/additions to :data:`DEFAULT_TOOL_CLASS`.
            An override may only make a tool *more* dangerous; a downgrade
            raises :class:`ValueError` at construction time.
        extra_forbidden: additional hard-deny rules from ``policy.yaml``.
        extra_intrusive: additional approval-required rules.
        unknown_tool_class: class applied to a binary nobody registered.
            Defaults to ``INTRUSIVE``: an unknown tool is never run silently.
    """

    def __init__(
        self,
        *,
        tool_classes: dict[str, ActionClass] | None = None,
        extra_forbidden: Iterable[ForbiddenRule] = (),
        extra_intrusive: Iterable[ForbiddenRule] = (),
        unknown_tool_class: ActionClass = ActionClass.INTRUSIVE,
    ) -> None:
        self.tool_classes = dict(DEFAULT_TOOL_CLASS)
        for name, cls_ in (tool_classes or {}).items():
            key = self.normalize_tool(name)
            default = DEFAULT_TOOL_CLASS.get(key)
            if default is not None and cls_.rank < default.rank:
                raise ValueError(
                    f"tool_classes may only tighten policy: refusing to move "
                    f"{key!r} from {default.value} down to {cls_.value}"
                )
            self.tool_classes[key] = cls_
        self.unknown_tool_class = unknown_tool_class
        self._forbidden = tuple(
            (rule, rule.compiled())
            for rule in (*FORBIDDEN_RULES, *DESTRUCTIVE_RULES, *extra_forbidden)
        )
        self._intrusive = tuple(
            (rule, rule.compiled()) for rule in (*INTRUSIVE_RULES, *extra_intrusive)
        )

    # ------------------------------------------------------------------ setup
    @staticmethod
    def normalize_tool(tool: str) -> str:
        """Reduce ``/usr/local/bin/nmap.exe`` to ``nmap``."""
        name = (tool or "").strip().replace("\\", "/").rsplit("/", 1)[-1].lower()
        for suffix in (".exe", ".py", ".sh", ".bat"):
            if name.endswith(suffix):
                name = name[: -len(suffix)]
        return name

    @classmethod
    def from_yaml(cls, path: str | Path) -> "Guard":
        """Load operator policy. Configuration may only *add* restrictions."""
        text = Path(path).read_text(encoding="utf-8")
        data = yaml.safe_load(text) or {}

        def rules(key: str, default_class: ActionClass) -> list[ForbiddenRule]:
            out: list[ForbiddenRule] = []
            for entry in data.get(key, []) or []:
                out.append(
                    ForbiddenRule(
                        name=f"policy:{entry.get('name', 'unnamed')}",
                        pattern=entry["pattern"],
                        class_=default_class,
                        reason=entry.get("reason", f"added by {Path(path).name}"),
                    )
                )
            return out

        tool_classes = {
            name: ActionClass(value)
            for name, value in (data.get("tool_classes") or {}).items()
        }
        unknown = ActionClass(
            data.get("unknown_tool_class", ActionClass.INTRUSIVE.value)
        )
        return cls(
            tool_classes=tool_classes,
            extra_forbidden=rules("extra_forbidden", ActionClass.FORBIDDEN),
            extra_intrusive=rules("extra_intrusive", ActionClass.INTRUSIVE),
            unknown_tool_class=unknown,
        )

    # -------------------------------------------------------------- classify
    def class_for_tool(self, tool: str) -> ActionClass:
        return self.tool_classes.get(
            self.normalize_tool(tool), self.unknown_tool_class
        )

    def _scan(self, text: str, base: ActionClass) -> GuardDecision:
        action = base
        reasons: list[str] = []
        matched: list[str] = []
        for rule, pattern in self._forbidden:
            if pattern.search(text):
                action = ActionClass.FORBIDDEN
                matched.append(rule.name)
                reasons.append(f"forbidden[{rule.name}]: {rule.reason}")
        for rule, pattern in self._intrusive:
            if pattern.search(text):
                action = action.worse_of(ActionClass.INTRUSIVE)
                matched.append(rule.name)
                reasons.append(f"approval[{rule.name}]: {rule.reason}")
        return GuardDecision(action, tuple(reasons), tuple(matched))

    def classify_command(self, tool: str, argv: Sequence[str] = ()) -> GuardDecision:
        """Classify ``tool`` invoked with ``argv``."""
        name = self.normalize_tool(tool)
        base = self.class_for_tool(name)
        text = " ".join([name, *[str(a) for a in argv]])
        decision = self._scan(text, base)
        if not decision.reasons and base.requires_approval:
            return GuardDecision(
                base,
                (f"tool class {base.value} for {name!r}",),
                decision.matched_rules,
            )
        return decision

    def classify_payload(self, payload: str) -> GuardDecision:
        """Classify a generated payload string.

        The baseline is ``intrusive``: delivering a crafted payload to a live
        target *is* exploitation, so a human stays in the loop by default.
        """
        return self._scan(payload or "", ActionClass.INTRUSIVE)

    # --------------------------------------------------------------- enforce
    def enforce(
        self,
        decision: GuardDecision,
        *,
        approved: bool = False,
        context: str = "",
    ) -> GuardDecision:
        """Apply a decision. Raises rather than returning a soft failure."""
        where = f" ({context})" if context else ""
        if decision.action_class is ActionClass.FORBIDDEN:
            raise ForbiddenActionError(
                "refused: this action is in a permanently forbidden class and "
                "cannot be approved" + where + ": " + "; ".join(decision.reasons)
            )
        if decision.requires_approval and not approved:
            raise ApprovalRequired(
                "human approval required before running an intrusive action"
                + where
                + ": "
                + "; ".join(decision.reasons),
                action_class=decision.action_class.value,
                command=context,
            )
        return decision

    def check_command(
        self,
        tool: str,
        argv: Sequence[str] = (),
        *,
        approved: bool = False,
    ) -> GuardDecision:
        """Classify and enforce in one step; raises on refusal."""
        decision = self.classify_command(tool, argv)
        context = f"{self.normalize_tool(tool)} {' '.join(map(str, argv))}".strip()
        return self.enforce(decision, approved=approved, context=context)

    def describe_policy(self) -> dict:
        return {
            "tool_classes": {
                name: cls_.value for name, cls_ in sorted(self.tool_classes.items())
            },
            "unknown_tool_class": self.unknown_tool_class.value,
            "forbidden_rule_count": len(self._forbidden),
            "destructive_rule_count": len(DESTRUCTIVE_RULES),
            "intrusive_rule_count": len(self._intrusive),
        }
