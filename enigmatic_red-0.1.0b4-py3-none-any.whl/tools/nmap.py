"""nmap adapter.

Deliberately a *version-detection* wrapper. It never enables NSE scripts, OS
fingerprinting or aggressive timing by default: those belong to the intrusive
phase and must be requested explicitly (and then approved by the guard, which
classifies ``--script``/``-A`` as intrusive). ``-oX -`` writes the XML to
stdout, so a scan leaves no artifact on the host running it, and the raw
document that produced every finding is what gets parsed and (later) hashed
into evidence.
"""

from __future__ import annotations

import re
from typing import Any, Sequence

from tools.base import ToolAdapter, ToolContext, ToolResult
from tools.parsers import NmapScan, parse_nmap_xml
from tools.runner import CommandResult

__all__ = ["NmapAdapter", "scan"]

#: A port specification may only be digits, commas and ranges. Anything else
#: could smuggle an option into the port list.
_PORT_SPEC = re.compile(r"^[0-9]{1,5}(-[0-9]{1,5})?(,[0-9]{1,5}(-[0-9]{1,5})?)*$")


def _ports_argument(ports: str | Sequence[int]) -> str:
    if isinstance(ports, str):
        spec = ports.strip()
        if not _PORT_SPEC.match(spec):
            raise ValueError(f"refusing an unparseable port specification: {ports!r}")
        return spec
    numbers = sorted({int(port) for port in ports})
    if not numbers:
        raise ValueError("empty port list")
    for port in numbers:
        if not 0 < port < 65536:
            raise ValueError(f"{port} is not a valid TCP port")
    return ",".join(str(port) for port in numbers)


def _split_host_port(target: str) -> tuple[str, str]:
    """Fold ``host:port`` into ``(host, port)``; anything else through unchanged.

    nmap reads a *host*, so an asset spelled ``10.0.0.5:40366`` - the way every
    lab, and every high-port service anywhere, is written - is not a target it
    can parse: it exits 0 with an empty document and the mission records "no
    open service" for a service that is plainly up. The port belongs in ``-p``.

    Splitting is deliberately conservative, because a colon means something
    else in two of nmap's real target shapes:

    * a bare IPv6 address (``2001:db8::1``) is a host, not host-and-port;
    * ``[2001:db8::1]:443`` is host-and-port, and nmap wants it unbracketed;
    * a CIDR (``10.0.0.0/24``) has no colon at all.

    So a port is recognised only when the text after the *last* colon is all
    digits and what precedes it is either bracketed or colon-free.
    """
    text = target.strip()
    if text.startswith("["):
        close = text.find("]")
        if close != -1:
            host, tail = text[1:close], text[close + 1 :]
            if tail.startswith(":") and tail[1:].isdigit():
                return host, tail[1:]
            return text, ""  # bracketed v6 with no port, left for nmap to judge
    if text.count(":") != 1:
        return text, ""  # bare IPv6, CIDR or a plain name
    host, _, port = text.partition(":")
    if host and port.isdigit():
        return host, port
    return text, ""


class NmapAdapter(ToolAdapter):
    """``nmap -Pn -sV -oX -`` — reachable services and their versions."""

    name = "nmap"

    def build_argv(
        self,
        target: str,
        *,
        ports: str | Sequence[int] | None = None,
        service_detection: bool = True,
        skip_discovery: bool = True,
        top_ports: int | None = None,
        max_rate: float | None = None,
        host_timeout_s: int | None = None,
        extra_args: Sequence[str] = (),
    ) -> list[str]:
        """Build the argv.

        A target carrying a port (``app.example.com:8443``, ``10.0.0.5:40366``)
        is split: the host is passed as the host and the port becomes ``-p``,
        because nmap cannot read ``host:port`` and would otherwise report an
        empty document as "nothing open". An explicit ``ports`` argument wins
        over the one in the target - it is the more specific instruction.

        ``extra_args`` is passed through as data, but it is not a way around
        policy: the guard classifies the finished command line, so ``--script``
        and ``-A`` still require a human approval.
        """
        target = str(target).strip()
        if not target:
            raise ValueError("no target given to nmap")
        if target.startswith("-"):
            raise ValueError(f"refusing a target that looks like an option: {target!r}")

        target, target_port = _split_host_port(target)
        if ports is None and target_port:
            ports = target_port

        argv = ["nmap"]
        if skip_discovery:
            argv.append("-Pn")
        if service_detection:
            argv.append("-sV")
        argv += ["-oX", "-"]
        if ports is not None:
            argv += ["-p", _ports_argument(ports)]
        if top_ports is not None:
            argv += ["--top-ports", str(max(1, int(top_ports)))]
        if max_rate is not None:
            # An unbounded nmap can saturate a customer's uplink. Capping the
            # probe rate is courtesy with a real operational cost if omitted.
            argv += ["--max-rate", str(max(1, int(max_rate)))]
        if host_timeout_s is not None:
            argv += ["--host-timeout", f"{max(1, int(host_timeout_s))}s"]
        argv += [str(arg) for arg in extra_args]
        argv.append(target)
        return argv

    def parse(self, command: CommandResult) -> NmapScan:
        return parse_nmap_xml(command.stdout)

    def summarize(self, parsed: Any) -> dict[str, Any]:
        if isinstance(parsed, NmapScan):
            return parsed.describe()
        return {}


def scan(target: str, context: ToolContext, **options: Any) -> ToolResult:
    """Convenience wrapper: ``scan("app.example.com", context, ports=[80, 443])``."""
    return NmapAdapter().run(target, context, **options)
