"""What each ``red`` subcommand does.

Every command is a thin layer over the same objects the rest of the codebase
uses: :class:`ScanSession` for the chain, the guard for policy, the scope for
targets, :class:`AuditLog` for the record. Nothing here re-implements a control,
and nothing here can skip one - a command that cannot build a session cannot
scan, which is the point.

A refusal is a result, not a crash. Out-of-scope targets, missing
authorization, flood-class flags and unapproved intrusive steps all exit with
:data:`EXIT_REFUSED` (3) and a sentence explaining which control stopped it,
because an operator needs to read that sentence more than they need a
traceback.
"""

from __future__ import annotations

import asyncio
import getpass
import ipaddress
import json
import os
import shutil
import sys
import sysconfig
import threading
from datetime import timedelta
from pathlib import Path
from typing import Any, Sequence
from urllib.parse import urlsplit

from agent.chat import NOT_A_RUN, key_status
from agent.hands import Hands
from agent.localmodel import ensure_local_model
from agent.markdown import render_markdown
from agent.registry import Registry
from agent.session import LAB_STATEMENT, ScanSession
from agent.setup import RELAUNCH_EXIT, Setup
from cli.home import (
    AUTHORIZATION_FILENAME,
    Home,
    attestation_from_dict,
    clear_env_key,
    read_chat_prefs,
    read_env_key,
    resolve_home,
    seed,
    seeded_scope_template,
    set_env_key,
    write_chat_prefs,
)
from config.settings import HOME_DIR, Settings, get_settings
from safety.audit import AuditLog
from safety.authz import VerificationMethod, make_attestation
from safety.errors import (
    ApprovalRequired,
    AuthorizationError,
    ForbiddenActionError,
    KillSwitchEngaged,
    ProviderError,
    RateLimitExceeded,
    ScopeViolation,
)
from safety.guard import Guard
from safety.scope import Scope
from tools.base import ToolAdapter, ToolResult
from tools.dnsx import DnsxAdapter
from tools.ffuf import FfufAdapter
from tools.gobuster import GobusterAdapter
from tools.httpx import BINARY as HTTPX_BINARY
from tools.httpx import HttpxAdapter
from tools.nmap import NmapAdapter
from tools.nuclei import NucleiAdapter
from tools.subfinder import SubfinderAdapter
from tools.whatweb import WhatwebAdapter

__all__ = [
    "EXIT_OK",
    "EXIT_REFUSED",
    "EXIT_UNUSABLE",
    "RedError",
    "cmd_authorize",
    "cmd_agent",
    "cmd_corpus",
    "cmd_db",
    "cmd_doctor",
    "cmd_eval",
    "cmd_init",
    "cmd_key",
    "cmd_report",
    "cmd_scan",
    "cmd_serve",
]

EXIT_OK = 0
#: Ran, but a control stopped it - a correct outcome, not a failure.
EXIT_REFUSED = 3
#: Nothing could be attempted: not initialised, no authorization, no such tool.
EXIT_UNUSABLE = 4

#: Every adapter ``red scan --tool`` may name, and the same list ``red doctor``
#: checks the binary for. The registry is what a *plan* may call; this is the
#: operator's one-shot form, and it holds exactly the adapters that exist - a
#: name here that has no adapter is a KeyError, not a capability.
ADAPTERS = {
    "dnsx": DnsxAdapter,
    "ffuf": FfufAdapter,
    "gobuster": GobusterAdapter,
    "httpx": HttpxAdapter,
    "nmap": NmapAdapter,
    "nuclei": NucleiAdapter,
    "subfinder": SubfinderAdapter,
    "whatweb": WhatwebAdapter,
}

#: The errors a tool can raise when a control stops it. Anything else is a bug
#: and should reach the operator as one.
REFUSALS = (
    ScopeViolation,
    ForbiddenActionError,
    ApprovalRequired,
    AuthorizationError,
    RateLimitExceeded,
    KillSwitchEngaged,
)


class RedError(Exception):
    """A sentence for the operator about something that could be fixed."""


def _home(args: Any) -> Home:
    return resolve_home(getattr(args, "home", None))


def _require_seeded(home: Home) -> None:
    if not home.is_seeded:
        raise RedError(
            f"{home.root} is not initialised: run `red --home \"{home.root}\" init` first"
        )


def _load_authorization(home: Home) -> Any:
    if not home.authorization_file.is_file():
        raise RedError(
            f"no authorization in {home.authorization_file}: run `red authorize` "
            "first - a scan without a dated attestation is exactly what this tool "
            "refuses to do"
        )
    data = json.loads(home.authorization_file.read_text(encoding="utf-8"))
    return attestation_from_dict(data)


def cmd_init(args: Any) -> int:
    """Create the home, copy the shipped YAML into it, never overwrite."""
    home = _home(args)
    created, kept = seed(home)
    print(f"home    {home.root}")
    for name in created:
        print(f"  created  {name}")
    for name in kept:
        print(f"  kept     {name}")
    if not created:
        print("  (already initialised: nothing was written)")

    untouched = home.scope_file.read_text(encoding="utf-8") == seeded_scope_template()
    if untouched:
        print(
            f"\nThe scope is still the shipped template. Edit {home.scope_file} to "
            "name the assets you are allowed to touch, then:\n"
            f"  red --home \"{home.root}\" authorize --target <asset> --organization "
            '"<who you are>" --subject "<who signs>" --reference <ticket> --confirm'
        )
    return EXIT_OK


def cmd_authorize(args: Any) -> int:
    """Write the dated attestation a scan needs, but only for an in-scope target.

    The scope is checked *here* as well as at scan time: an authorization for an
    asset the scope does not cover is worthless paper, and producing one would
    teach the operator that the scope and the attestation are unrelated. They are
    not - the attestation carries the scope's digest, so widening the scope later
    invalidates this signature and forces a fresh one.
    """
    home = _home(args)
    _require_seeded(home)
    scope = Scope.from_yaml(home.scope_file)
    decision = scope.check(args.target)
    if not decision:
        raise RedError(
            f"refusing to authorize {args.target!r}: {decision.reason}. "
            f"Edit {home.scope_file} if that asset is genuinely in scope."
        )
    if not args.confirm:
        raise RedError(
            "refusing to write an authorization without --confirm: pass it to "
            "state that you hold the authority this attestation claims, because "
            "the file it writes is the record that a scan was permitted"
        )

    statement = LAB_STATEMENT
    if args.statement_file:
        statement = Path(args.statement_file).read_text(encoding="utf-8").strip()
        if not statement:
            raise RedError(f"{args.statement_file} is empty")

    attestation = make_attestation(
        organization=args.organization,
        subject=args.subject,
        target=args.target,
        reference=args.reference,
        scope=scope,
        signed_text=statement,
        verification=VerificationMethod(args.verification),
        valid_for=timedelta(days=args.days),
    )
    home.authorization_file.write_text(
        json.dumps(attestation.to_dict(), indent=2), encoding="utf-8"
    )
    print(f"wrote   {home.authorization_file}")
    print(f"  target          {attestation.target}")
    print(f"  organization    {attestation.organization}")
    print(f"  subject         {attestation.subject}")
    print(f"  reference       {attestation.reference}")
    print(f"  verification    {attestation.verification.value}")
    print(f"  expires         {attestation.expires_at.isoformat()}")
    print(f"  scope digest    {attestation.scope_digest[:16]}")
    return EXIT_OK


def _check(name: str, ok: bool, detail: str, *, required: bool) -> dict[str, Any]:
    return {"name": name, "ok": ok, "detail": detail, "required": required}


def _console_script_dirs() -> set[Path]:
    """Every directory this installation puts console scripts in.

    ``sysconfig`` answers for the *running* installation: a virtual
    environment's ``Scripts`` (or ``bin``), and - on Windows - the sibling
    ``Scripts`` directory of a system-wide interpreter. The interpreter's own
    directory is kept as well, because on POSIX and inside a virtual environment
    that is the same place, and a check that only looked at ``sysconfig`` would
    regress if it ever answered with a path that does not exist.
    """
    dirs = {Path(sys.executable).resolve().parent}
    scripts = sysconfig.get_path("scripts")
    if scripts:
        dirs.add(Path(scripts).resolve())
    return dirs


def _shadowed_scanner(tool: str, located: str | None) -> str:
    """A sentence when ``located`` is not the scanner, otherwise ``""``.

    ``httpx`` is the one capability whose name is also a dependency of this
    repository: the Python ``httpx`` client installs a console script called
    ``httpx`` into the interpreter's own ``Scripts`` directory, which is where
    ``shutil.which`` finds it first inside a virtual environment. Both binaries
    are legitimate and only one of them answers ``-json``, so the wrong one is
    reported rather than counted as present - a run of it exits 1 with "the
    required dependencies were not installed" and no probe result, which the
    httpx adapter reports as unparseable output and names, and which doctor can
    name before a scan is attempted at all.

    The directory is asked of ``sysconfig`` rather than assumed to be the
    interpreter's own: on Windows a system-wide install puts both scripts in a
    sibling ``Scripts`` directory, so ``sys.executable.parent`` alone missed the
    collision outside a virtual environment.
    """
    if not located or tool != HTTPX_BINARY:
        return ""
    if Path(located).resolve().parent in _console_script_dirs():
        other = _other_scanner_on_path(tool)
        where = (
            f"{other} is also on PATH, so put the scanner's directory first"
            if other
            else "install the scanner and put it first on PATH"
        )
        return (
            f"{located} is the Python `httpx` client's CLI (it sits beside this "
            f"interpreter), not the ProjectDiscovery scanner: {where}"
        )
    return ""


def _other_scanner_on_path(tool: str) -> str:
    """The next ``tool`` on ``PATH`` once the interpreter's own directory is gone.

    Named so that the warning can say where the scanner actually is instead of
    only that it is missing: on this machine the answer is a directory later in
    ``PATH``, not an install.
    """
    scripts = _console_script_dirs()
    entries = [
        entry
        for entry in os.environ.get("PATH", "").split(os.pathsep)
        if entry and Path(entry).resolve() not in scripts
    ]
    return shutil.which(tool, path=os.pathsep.join(entries)) or ""


def _authorization_check(home: Home, scope: Scope, checks: list[dict[str, Any]]) -> None:
    from safety.authz import scope_digest

    if not home.authorization_file.is_file():
        checks.append(
            _check("authorization", False, "none yet: run `red authorize`", required=False)
        )
        return
    attestation = _load_authorization(home)
    if attestation.is_expired():
        checks.append(
            _check(
                "authorization",
                False,
                f"{attestation.reference} EXPIRED at {attestation.expires_at}",
                required=False,
            )
        )
        return
    bound = attestation.scope_digest == scope_digest(scope)
    checks.append(
        _check(
            "authorization",
            bound,
            f"{attestation.reference} for {attestation.target}, expires "
            f"{attestation.expires_at}, "
            + ("binds the current scope" if bound else "STALE: scope changed since signing"),
            required=False,
        )
    )


def cmd_doctor(args: Any) -> int:
    """Say what this install can and cannot do, without doing any of it."""
    home = _home(args)
    settings = get_settings()
    checks: list[dict[str, Any]] = []

    checks.append(
        _check(
            "python",
            sys.version_info >= (3, 11),
            f"{sys.version.split()[0]} (this build needs 3.11+)",
            required=True,
        )
    )
    checks.append(_check("home", home.root.is_dir(), str(home.root), required=True))
    checks.append(
        _check(
            "seeded",
            home.is_seeded,
            "policy.yaml and scope.yaml present"
            if home.is_seeded
            else f'run `red --home "{home.root}" init`',
            required=True,
        )
    )

    guard: Guard | None = None
    if home.policy_file.is_file():
        try:
            guard = Guard.from_yaml(home.policy_file)
            described = guard.describe_policy()
            checks.append(
                _check(
                    "policy",
                    True,
                    f"{described.get('forbidden_rule_count', 0)} deny rules, "
                    f"{described.get('intrusive_rule_count', 0)} intrusive rules, "
                    f"{len(described.get('tool_classes', {}))} tool classes",
                    required=True,
                )
            )
        except Exception as exc:  # noqa: BLE001 - the whole point is to report it
            checks.append(
                _check("policy", False, f"{home.policy_file}: {exc}", required=True)
            )
    else:
        checks.append(_check("policy", False, f"missing {home.policy_file}", required=True))

    scope: Scope | None = None
    if home.scope_file.is_file():
        try:
            scope = Scope.from_yaml(home.scope_file)
            checks.append(
                _check(
                    "scope",
                    not scope.is_empty,
                    "empty: the template has not been filled in"
                    if scope.is_empty
                    else json.dumps(scope.describe(), sort_keys=True)[:110],
                    required=True,
                )
            )
        except Exception as exc:  # noqa: BLE001
            checks.append(
                _check("scope", False, f"{home.scope_file}: {exc}", required=True)
            )
    else:
        checks.append(_check("scope", False, f"missing {home.scope_file}", required=True))

    if scope is not None:
        _authorization_check(home, scope, checks)

    chain_ok, chain_message = True, "no log yet"
    if home.audit_path.is_file():
        chain_ok, chain_message = AuditLog(home.audit_path, fsync=False).verify()
    checks.append(_check("audit chain", chain_ok, chain_message, required=False))
    checks.append(
        _check(
            "killswitch",
            not home.killswitch_path.exists(),
            "ENGAGED: no tool will run"
            if home.killswitch_path.exists()
            else f"clear ({home.killswitch_path})",
            required=True,
        )
    )
    for tool in tuple(sorted(ADAPTERS)):
        located = shutil.which(tool)
        shadowed = _shadowed_scanner(tool, located)
        checks.append(
            _check(
                tool,
                located is not None and not shadowed,
                shadowed or located or "not on PATH",
                required=False,
            )
        )
    key_ok, key_sentence = key_status(settings)
    checks.append(
        _check(
            "model key",
            key_ok,
            f"{key_sentence}; the endpoint is {settings.featherless_base_url}, "
            "used by a planned scan and by `red`",
            required=False,
        )
    )

    failures = [c for c in checks if c["required"] and not c["ok"]]
    if args.json:
        print(json.dumps({"home": str(home.root), "checks": checks}, indent=2))
        return EXIT_UNUSABLE if failures else EXIT_OK
    for check in checks:
        mark = "ok  " if check["ok"] else ("FAIL" if check["required"] else "warn")
        print(f"  {mark} {check['name']:<13} {check['detail']}")
    if args.verbose and guard is not None:
        print(json.dumps(guard.describe_policy(), indent=2, sort_keys=True))
    return EXIT_UNUSABLE if failures else EXIT_OK


def _options(args: Any) -> dict[str, Any]:
    """Only pass what the operator actually asked for.

    A default invented here would be a limit nobody chose, and this is the wrong
    layer to invent limits: they belong in the policy, where they are visible and
    tested.
    """
    options: dict[str, Any] = {}
    if getattr(args, "ports", None):
        options["ports"] = list(args.ports)
    if getattr(args, "max_rate", None):
        options["max_rate"] = args.max_rate
    if getattr(args, "templates", None):
        options["templates"] = list(args.templates)
    if getattr(args, "rate_limit", None):
        options["rate_limit"] = args.rate_limit
    if getattr(args, "paths", None):
        options["paths"] = list(args.paths)
    if getattr(args, "threads", None):
        options["threads"] = args.threads
    if getattr(args, "sources", None):
        options["sources"] = list(args.sources)
    if getattr(args, "record_types", None):
        options["record_types"] = list(args.record_types)
    if getattr(args, "wordlist", None):
        options["wordlist"] = args.wordlist
    if getattr(args, "delay", None):
        options["delay"] = args.delay
    if getattr(args, "rate", None):
        options["rate"] = args.rate
    return options


def _print_audit(audit: AuditLog, since: int) -> None:
    entries = [row for row in audit.iter_entries() if row.get("seq", 0) > since]
    for row in entries:
        detail = row.get("detail") or {}
        reason = detail.get("reason") or detail.get("refusal") or ""
        print(
            f"  audit #{row.get('seq')} {row.get('event')} "
            f"{row.get('decision') or '-'}{' :: ' + str(reason) if reason else ''}"
        )
    if entries:
        ok, message = audit.verify()
        print(f"  chain {'intact' if ok else 'BROKEN: ' + message} ({audit.last_seq} entries)")


def _parsed_line(adapter: ToolAdapter, parsed: Any) -> str:
    """The terminal's one-line reading of a parsed run: ``summarize``, whole.

    ``summarize`` is what the audit already records and it is bounded by
    construction - at most 25 hosts, URLs and technologies - so printing all of
    it costs nothing. The parsed objects themselves are only a fallback for an
    adapter with no summary, and those are truncated: one ``HttpxResult`` repr
    runs to some 950 characters, so a 400-character cut kept the first of two
    probes and dropped the second, which reads as a probe that never parsed.
    """
    summary = adapter.summarize(parsed)
    text = json.dumps(summary or parsed, sort_keys=True, default=str)
    return text if summary else text[:400]


def cmd_scan(args: Any) -> int:
    """Run one adapter through the chain. `--tool` names it: this is not a plan."""
    home = _home(args)
    _require_seeded(home)
    attestation = _load_authorization(home)
    adapter_class = ADAPTERS.get(args.tool)
    if adapter_class is None:
        raise RedError(
            f"unknown tool {args.tool!r}: choose one of {', '.join(sorted(ADAPTERS))}"
        )

    session = ScanSession.open(
        org=args.organization,
        actor=args.actor,
        attestation=attestation,
        scope_file=home.scope_file,
        policy_file=home.policy_file,
        audit_path=home.audit_path,
        killswitch_path=home.killswitch_path,
    )
    before = session.audit.last_seq
    context = session.context(args.scan_id, approved=frozenset(args.approve or ()))
    adapter = adapter_class()
    try:
        result: ToolResult = adapter.run(args.target, context, **_options(args))
    except REFUSALS as exc:
        print(f"refused  {type(exc).__name__}: {exc}")
        _print_audit(session.audit, before)
        return EXIT_REFUSED

    print(f"tool     {result.tool}")
    print(f"ran      {result.ran}   ok {result.ok}")
    if result.argv:
        print(f"command  {' '.join(result.argv)}")
    if result.command is not None:
        print(f"exit     {result.command.returncode} in {result.command.duration_ms:.0f} ms")
    if result.skipped:
        print(f"skipped  {result.skip_reason}")
    if result.parse_error:
        print(f"parse    {result.parse_error}")
    if result.parsed is not None:
        print(f"parsed   {_parsed_line(adapter, result.parsed)}")
    _print_audit(session.audit, before)
    return EXIT_OK if result.ok else EXIT_REFUSED


# ------------------------------------------------------- measuring refusals
#: The public collections `--data` recognises by file name, and which side of the
#: line each sits on. Benign is tested first on purpose: every `jailbreak_prompts`
#: file is a set of harmful requests asked of a model, while `xstest` and the
#: `regular_prompts` sets are the over-refusal material - and a name matched to
#: the wrong list would print a rate about the wrong thing.
EVAL_BENIGN_NAMES = ("xstest", "regular_prompts")
EVAL_HARMFUL_NAMES = ("advbench", "jailbreak", "forbidden_question", "harmbench")


def _eval_corpus(raw: str | Path, kind: str, project_root: Path) -> tuple[Any, str]:
    """One corpus, or a sentence saying why it was not used.

    The repository check is the important one. A corpus is material the operator
    keeps outside this tree; a wheel that carried one would put harmful text on
    every customer's disk, beside the audit log this tool exists to keep clean.
    """
    from agent.refusal_eval import Corpus

    try:
        path = Path(raw).expanduser().resolve()
    except OSError as exc:
        return None, f"{raw}: {exc}"
    if not path.is_file():
        return None, f"{path} is not a file"
    if path == project_root or project_root in path.parents:
        return None, (
            f"{path.name} is inside this repository and was refused: a corpus is "
            "read where the operator keeps it, and is never bundled with the tool"
        )
    return Corpus(path=path, kind=kind), ""


def _eval_corpora(args: Any, project_root: Path) -> tuple[list[Any], list[str]]:
    """Every corpus this run will use, and one sentence per file it would not."""
    from agent.refusal_eval import BENIGN, HARMFUL

    chosen: list[Any] = []
    notes: list[str] = []
    for raw in getattr(args, "harmful", None) or []:
        corpus, note = _eval_corpus(raw, HARMFUL, project_root)
        if corpus is not None:
            chosen.append(corpus)
        if note:
            notes.append(note)
    for raw in getattr(args, "benign", None) or []:
        corpus, note = _eval_corpus(raw, BENIGN, project_root)
        if corpus is not None:
            chosen.append(corpus)
        if note:
            notes.append(note)
    directory = getattr(args, "data", None)
    if directory:
        root = Path(directory).expanduser()
        if not root.is_dir():
            notes.append(f"{root} is not a directory")
        else:
            skipped: list[str] = []
            for path in sorted(root.glob("*.csv")):
                lowered = path.name.lower()
                if any(marker in lowered for marker in EVAL_BENIGN_NAMES):
                    kind = BENIGN
                elif any(marker in lowered for marker in EVAL_HARMFUL_NAMES):
                    kind = HARMFUL
                else:
                    skipped.append(path.name)
                    continue
                corpus, note = _eval_corpus(path, kind, project_root)
                if corpus is not None:
                    chosen.append(corpus)
                if note:
                    notes.append(note)
            if skipped:
                notes.append(
                    "not a corpus this recognises, so not asked: "
                    + ", ".join(skipped)
                )
    return chosen, notes


def cmd_eval(args: Any) -> int:
    """Measure a model's refusals and print two rates. It generates nothing.

    The AI-security half of this product's coverage is the question "can this
    model be steered out of its design?", and the part of that a run can answer
    is whether the model declines what it should and answers what it may. So this
    asks the configured endpoint the requests in a corpus the operator supplies
    and counts the answers - under-refusal and over-refusal side by side, because
    reporting one of them is how a safety change gets argued rather than measured.

    Three guards, each a property rather than a check on the way in: the corpus
    must live outside this repository, a non-loopback endpoint needs
    `--allow-remote` because measuring it spends a key and sends it the corpus,
    and no request is ever printed or written - the report carries counts.
    """
    from agent.chat import ChatSession
    from agent.localmodel import is_loopback_url
    from agent.providers.featherless import FeatherlessProvider
    from agent.refusal_eval import evaluate
    from config.settings import PROJECT_ROOT

    settings = get_settings()
    corpora, notes = _eval_corpora(args, PROJECT_ROOT)
    for note in notes:
        print(f"  note      {note}")
    if not corpora:
        raise RedError(
            "nothing to measure: `--data DIR` picks up the public collections by "
            "name (xstest, advbench, jailbreak_prompts, forbidden_question_set), "
            "or `--harmful FILE` / `--benign FILE` name one at a time. A corpus "
            "inside this repository is refused on principle."
        )
    # Not `host_is_local`, which calls an *unset* endpoint local - true of a
    # request and false of a provider, whose client then falls back to its own
    # hosted default. The safe direction is "not loopback unless proven".
    if not is_loopback_url(settings.featherless_base_url) and not args.allow_remote:
        endpoint = settings.featherless_base_url or "no endpoint in .env"
        raise RedError(
            f"{endpoint} is not loopback: measuring it spends the key in .env and "
            "sends it the corpus. Pass `--allow-remote` if that is what you "
            "meant, or point FEATHERLESS_BASE_URL at a model on this machine."
        )
    ok, sentence = key_status(settings)
    if not ok:
        raise RedError(
            f"no key for {settings.featherless_base_url}: {sentence}. `red key` "
            "writes one, and setup_local_model.* points this install at a model "
            "that needs none."
        )
    started = ensure_local_model(settings.featherless_base_url)
    if started:
        print(started)

    try:
        provider = FeatherlessProvider(settings=settings)
    except ProviderError as exc:
        raise RedError(
            f"no model to measure: {exc}. Run `red init` (the model ids live in "
            "its config home) or set FEATHERLESS_MODEL_FAST and "
            "FEATHERLESS_MODEL_REASON in .env."
        ) from exc

    role = _agent_role(args, _home(args))
    session = ChatSession(provider=provider, settings=settings, model=role)

    async def ask(prompt: str) -> str:
        turn = await session.ask(prompt)
        return turn.answer

    async def drive() -> Any:
        try:
            return await evaluate(ask, corpora, sample=args.sample)
        finally:
            await provider.aclose()

    report = asyncio.run(drive())
    report.endpoint = settings.featherless_base_url
    report.model = role
    if getattr(args, "json", False):
        print(json.dumps(report.as_dict(), indent=2))
    else:
        for line in report.describe():
            print(line)
    return EXIT_OK


def _summarise(values: list[str], *, limit: int = 4) -> str:
    """A few of something, and how many were left out."""
    if not values:
        return ""
    if len(values) <= limit:
        return ", ".join(values)
    return ", ".join(values[:limit]) + f", +{len(values) - limit} more"


def _scope_line(home: Home) -> str:
    """What this install's scope authorises, in one line.

    Read through :meth:`safety.scope.Scope.from_yaml`, which is the same loader
    every adapter's check goes through - not a second reader of the YAML. A
    summary printed here therefore cannot disagree with the verdict a step would
    get, which is the only reason a banner is allowed to summarise a control at
    all. A file that will not load is reported as itself rather than guessed at.
    """
    if not home.scope_file.is_file():
        return f"none yet ({home.scope_file}) - `red init` writes the template"
    try:
        described = Scope.from_yaml(home.scope_file).describe()
    except Exception as exc:  # noqa: BLE001 - the operator needs the sentence
        return f"{home.scope_file.name} does not load: {exc}"
    if described.get("empty"):
        return f"empty - nothing is authorised yet ({home.scope_file})"
    groups = [
        ("hosts", described["allow_hosts"]),
        ("cidrs", described["allow_cidrs"]),
        ("ports", [str(port) for port in described["allow_ports"] or []]),
        ("buckets", described["allow_buckets"]),
        ("repos", described["allow_repositories"]),
        ("models", described["allow_models"]),
    ]
    parts = [f"{name} {_summarise(values)}" for name, values in groups if values]
    if described.get("allow_loopback"):
        parts.append("loopback on")
    label = str(described.get("label") or "").strip()
    body = "; ".join(parts) or "nothing allowed"
    return f"{body}" + (f" [{label}]" if label else "")


def _attestation_line(home: Home) -> str:
    """The dated authorisation this install holds, or that there is none.

    Presence is the file, and the rest is read defensively out of it: an
    attestation written by an older build, or edited by hand, is still worth
    reporting - it is the *existence* and the expiry that decide whether a step
    may run, and that decision belongs to the chain, not to this line.
    """
    if not home.authorization_file.is_file():
        return (
            "none yet - nothing may be touched until one exists. Say who signs "
            "for which asset and the agent will take the details from you, "
            "rather than have you type the command"
        )
    try:
        data = json.loads(home.authorization_file.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        return f"{home.authorization_file.name} is not readable: {exc}"
    if not isinstance(data, dict):  # pragma: no cover - defensive
        return f"{home.authorization_file.name} is not an attestation"
    subject = str(data.get("subject") or "?")
    organization = str(data.get("organization") or "?")
    target = str(data.get("target") or "?")
    reference = str(data.get("reference") or "")
    expires = str(data.get("expires_at") or "")[:10]
    tail = ", ".join(part for part in (reference, f"to {expires}" if expires else "") if part)
    return f"{subject} for {organization}, {target}" + (f" ({tail})" if tail else "")


def _agent_banner(settings: Any, home: Home, role: str, key_sentence: str) -> str:
    """The facts of this install, printed once before the first prompt.

    Facts, not a manual - and the difference is the whole point of this surface.
    What an operator needs before typing is what this install knows: which
    endpoint answers and with which model, what the scope authorises, whether an
    attestation exists and what it says, and which capabilities a step may name.
    The rules get one sentence, because a paragraph of instructions is what a
    surface prints when it cannot act.
    """
    lines = [
        "Enigmatic Red - scope-locked, non-destructive vulnerability assessment agent.",
        "",
        f"  endpoint     {settings.featherless_base_url} ({key_sentence})",
        f"  model        {role} role",
        f"  scope        {_scope_line(home)}",
        f"  attestation  {_attestation_line(home)}",
        f"  capabilities {_summarise(list(Registry().names), limit=8)}",
        "",
        "Say what you want worked. Every step goes through the scope, the "
        "attestation, the guard and",
        "the audit log, and an intrusive command line stops for your yes. A "
        "question is answered and writes",
        "nothing. `/help` lists the local commands.",
        "",
    ]
    return "\n".join(lines)



async def _agent_repl(session: Any, args: Any) -> int:
    """The prompt: read a sentence, work it or answer it, repeat.

    The head of the process, and deliberately not a menu. `/clear`, `/exit`,
    `/help`, `/tools` and `/run` are local: three are about the session rather
    than about the work, and `/run` is the one-step shortcut for an operator who
    already knows which capability they want. Everything else is a sentence, and
    a sentence is either worked - a mission, several steps, each chosen from what
    the last one showed - or answered.
    """
    print("commands: /help  /clear  /exit   (ctrl-c or ctrl-d to leave)")
    print("          say what you want in plain words. A sentence naming a "
          "target is worked, one step")
    print("          at a time, under the scope, the attestation, the guard and "
          "the audit log; a question")
    print("          is answered.")
    chain = _FreestyleChain(args)
    while True:
        try:
            line = input("red> ")
        except (EOFError, KeyboardInterrupt):
            print()
            return EXIT_OK
        text = line.strip()
        if not text:
            continue
        if text in {"/exit", "/quit"}:
            return EXIT_OK
        head, _, rest = text.partition(" ")
        if text == "/help":
            print("  /clear  forget this conversation and start again")
            print("  /exit   leave. A conversation is not evidence; the audit log "
                  "is where a run is")
            print("          recorded")
            print("  /tools  the capabilities a step may name")
            print("  /run T  name target T; the model picks one capability and it "
                  "runs through the scope,")
            print("          attestation, guard and audit log - an intrusive "
                  "command asks you first")
            print("  (no slash) say what you want. A sentence naming a target is "
                  "worked as a mission,")
            print("          several steps, each chosen from what the last one "
                  "showed; a question is")
            print("          answered and writes nothing.")
            continue
        if text == "/clear":
            session.history.clear()
            print("  conversation cleared")
            continue
        if head == "/tools":
            for name in Registry().names:
                print(f"  {name}")
            continue
        if head == "/run":
            target = rest.strip()
            if not target:
                print("  usage: /run <target>   e.g. /run 127.0.0.1")
                continue
            try:
                await _agent_run(session, chain, args, target)
            except RedError as exc:
                print(f"  {exc}")
            except Exception as exc:  # noqa: BLE001 - the operator needs the sentence
                print(f"  model error: {type(exc).__name__}: {exc}")
            continue
        if text.startswith("/"):
            print(f"  no such command: {text.split()[0]} (try /help)")
            continue
        try:
            routed = await _agent_mission(session, chain, args, text)
        except RedError as exc:
            print(f"  {exc}")
            continue
        except Exception as exc:  # noqa: BLE001 - the operator needs the sentence
            print(f"model error: {type(exc).__name__}: {exc}")
            continue
        if routed:
            continue
        try:
            turn = await session.ask(text)
        except Exception as exc:  # noqa: BLE001 - the operator needs the sentence
            print(f"model error: {type(exc).__name__}: {exc}")
            continue
        _print_turn(turn, args)



async def _agent_mission(session: Any, chain: _FreestyleChain, args: Any, text: str) -> bool:
    """A typed sentence is the interface: read it, and work it if it names a target.

    Returns ``True`` when this line was a mission, and ``False`` when it was a
    question - which is not a failure, it is the other half of what a chat is
    for, and the caller answers it as it always did.

    Nothing here relaxes a control. The reading is one call with no tools on it,
    so a sentence that merely *sounds* like work cannot execute anything by being
    misread; and the run itself goes through ``agent.mission``, which pre-flights
    every step with the guard and executes through the adapter - the same chain
    ``/run`` uses, with the same approval prompt for an intrusive command line.
    """
    from agent.mission import run_mission, understand

    # ``session.model`` and not ``agent.mission.READER_ROLE``: the operator has
    # already chosen a role that resolves to a configured model, and a reading
    # that demanded the cheap role would fail on an install that only set
    # FEATHERLESS_MODEL_REASON - a failure on the first line an operator types.
    brief = await understand(session.provider, text, role=session.model)
    if not brief.is_run:
        return False

    chain_session, registry = chain.get()
    mission = await run_mission(
        provider=session.provider,
        registry=registry,
        session=chain_session,
        brief=brief,
        role=session.model,
        scan_id=getattr(args, "scan_id", None),
        confirm=_confirm_run,
    )
    print()
    if getattr(args, "json", False):
        payload = mission.describe()
        # The same two keys a question's `--json` carries, read from the real
        # log rather than asserted: a machine reading either half of `red
        # --json` asks the same question of it.
        payload["ran_anything"] = bool(mission.ran_steps)
        payload["audited"] = bool(chain_session.audit.last_seq)
        print(json.dumps(payload, indent=2))
    else:
        for line in mission.lines():
            print(line)
        last = chain_session.audit.last_seq
        if last:
            print(f"audit    {chain_session.audit.path} (#{last}); `red report` reads it")
    return True


class _FreestyleChain:
    """The chain a `/run` needs, built on first use and then reused.

    Lazy on purpose: a conversation that never types ``/run`` must not need an
    initialised home, a filled-in scope or an authorization - that is the whole
    point of the talk-only surface, and building this eagerly would take it away.
    The refusals are the scan path's own sentences, because it is the same home
    and the same attestation (`_require_seeded`, `_load_authorization`).
    """

    def __init__(self, args: Any) -> None:
        self.args = args
        self.session: ScanSession | None = None
        self.registry: Registry | None = None

    def get(self) -> tuple[ScanSession, Registry]:
        if self.session is None:
            home = _home(self.args)
            _require_seeded(home)
            session = ScanSession.open(
                org=getattr(self.args, "organization", "") or "freestyle",
                actor=getattr(self.args, "actor", None) or "operator",
                attestation=_load_authorization(home),
                scope_file=home.scope_file,
                policy_file=home.policy_file,
                audit_path=home.audit_path,
                killswitch_path=home.killswitch_path,
            )
            self.session = session
            # The scan's own guard, so the pre-flight answer is the answer the
            # adapter will give - not a second policy that could drift from it.
            self.registry = Registry(guard=session.guard)
        assert self.registry is not None  # set with the session, above
        return self.session, self.registry


def _confirm_run(plan: Any) -> bool:
    """Ask the human to approve one exact command line. No input means no."""
    print("  " + "\n  ".join(plan.lines()))
    try:
        answer = input("  run this exact command line? [y/N] ")
    except (EOFError, KeyboardInterrupt):
        print()
        return False
    return answer.strip().lower() in {"y", "yes"}


async def _agent_run(session: Any, chain: _FreestyleChain, args: Any, target: str) -> None:
    """One `/run`: let the model choose a capability and take it through the chain.

    Nothing here relaxes a control - ``agent.freestyle`` pre-flights with the
    guard and executes through the adapter, which re-checks the kill switch, the
    authorization, the scope, the guard and the rate limit itself. What this
    function owns is the two things a terminal has and a module does not: the
    approval prompt, and the printing.
    """
    from agent.freestyle import freestyle

    chain_session, registry = chain.get()
    outcome = await freestyle(
        provider=session.provider,
        registry=registry,
        session=chain_session,
        target=target,
        role=session.model,
        scan_id=getattr(args, "scan_id", None),
        confirm=_confirm_run,
    )
    if getattr(args, "json", False):
        print(json.dumps(_run_json(outcome, chain_session), indent=2))
        return
    print()
    for line in outcome.lines():
        print(line)
    last = chain_session.audit.last_seq
    if last:
        print(f"audit    {chain_session.audit.path} (#{last}); `red report` reads it")


def _run_json(outcome: Any, session: Any) -> dict[str, Any]:
    """The `/run` half of the `--json` contract.

    A question, a `/run` and a mission answer the same two questions in the same
    words - ``ran_anything`` and ``audited`` - because a caller that has to know
    which form it asked for would have to parse the prose it is trying not to
    read. `audited` is read off the log rather than inferred.
    """
    plan = getattr(outcome, "plan", None)
    result = getattr(outcome, "result", None)
    return {
        "form": "run",
        "target": outcome.target,
        "capability": getattr(plan, "capability", "") or "",
        "command": getattr(plan, "command", "") or "",
        "answer": outcome.answer,
        "model": outcome.model,
        "refusal_code": outcome.refusal_code,
        "sentence": outcome.sentence,
        "ran": bool(outcome.ran),
        "ok": bool(getattr(result, "ok", False)),
        "ran_anything": bool(outcome.ran),
        "audited": bool(session.audit.last_seq),
        "total_tokens": outcome.total_tokens,
    }


def _print_turn(turn: Any, args: Any) -> None:
    from agent.chat import as_lines

    if args.json:
        print(
            json.dumps(
                {
                    "question": turn.question,
                    "answer": turn.answer,
                    "model": turn.model,
                    "finish_reason": turn.finish_reason,
                    "suggested_tools": list(turn.suggested),
                    "ran_anything": False,
                    "audited": False,
                    "total_tokens": turn.total_tokens,
                },
                indent=2,
            )
        )
        return
    print()
    lines = list(as_lines(turn))
    # The prose is the model's and may be Markdown - a fenced ``sh`` block is
    # the common case - so it is rendered for a terminal. The note lines below
    # it are this module's own and are printed exactly as built.
    print(render_markdown(lines[0]))
    for line in lines[1:]:
        print(line)
    if args.verbose:
        print(f"[model {turn.model}, {turn.total_tokens} tokens]")


async def _agent_once(session: Any, chain: Any, args: Any) -> int:
    """The whole `red "one sentence"` path.

    A one-liner is read exactly as a typed line is: a question is answered, and
    a sentence that names a target and asks for work is worked as a mission -
    under the same chain, with the same approval prompt. The error sentences are
    left as they were, because a run that could not reach the model and a
    question that could not are the same failure to the operator.

    One exception: a work sentence in a home that is not ready raises the scan
    path's own ``RedError`` ("not initialised: run `red init` first", "no
    authorization"), which already names the command to run. That is not a model
    failure, so it is printed as itself rather than under a "model error" prefix.

    ``/run`` is accepted here too, because a line this tool teaches in the
    session must not quietly become prose when it is passed as a one-shot: the
    head is the CLI's to read, exactly as it is at the prompt.
    """
    try:
        head, _, rest = args.message.strip().partition(" ")
        if head == "/run":
            if not rest.strip():
                print("  usage: /run <target>   e.g. /run 127.0.0.1", file=sys.stderr)
                return EXIT_UNUSABLE
            await _agent_run(session, chain, args, rest.strip())
            return EXIT_OK
        if await _agent_mission(session, chain, args, args.message):
            return EXIT_OK
        turn = await session.ask(args.message)
    except RedError as exc:
        print(f"  {exc}", file=sys.stderr)
        return EXIT_UNUSABLE
    except Exception as exc:  # noqa: BLE001
        print(f"model error: {type(exc).__name__}: {exc}", file=sys.stderr)
        return EXIT_UNUSABLE
    _print_turn(turn, args)
    return EXIT_OK


def _mask(value: str) -> str:
    """A credential safe to print: enough to recognise, not enough to use.

    Three characters and the last four - ``sk-…4f2a`` - so the operator can say
    "yes, that is the key I meant" without the value ending up in a transcript, a
    ticket or a screenshot. A value with too little of itself to spare shows
    nothing at all.
    """
    return f"{value[:3]}…{value[-4:]}" if len(value) >= 12 else "…"


def _ask_for_the_key() -> str:
    """Ask for the credential: off the screen at a terminal, off the pipe in a script.

    ``getpass`` is the right tool where there *is* a terminal - it keeps the value
    out of the scrollback. Where there is none, Windows' ``getpass`` still tries
    to read the console and blocks on a handle that is not there, so a piped
    answer is read from stdin instead: that is how a script sets a key with no
    argv, which is the only other surface the audit log could have kept.
    """
    if sys.stdin is not None and not sys.stdin.isatty():
        print("model key (read from stdin, never in an argv): ", end="", flush=True)
        # Only the line ending is dropped: it belongs to the pipe, not the key.
        # Anything else around the value is still refused by the caller.
        return sys.stdin.readline().rstrip("\r\n")
    return getpass.getpass("model key (not echoed, never in an argv): ")


def cmd_key(args: Any) -> int:
    """Put your model key in this install's `.env`, prompted rather than passed.

    A credential may not travel through a command line here: every argv this tool
    builds is written into the append-only audit log, and a key written there
    could never be taken out again. So this command has no key argument and no
    ``--key`` flag - the prompt is the only way in and it does not echo - and the
    value is printed masked. It writes the one ``.env`` the settings read
    (``Settings.model_config``), which is also where the installer and
    ``setup_local_model.*`` put theirs, and every other line in that file is left
    as it was.

    Three forms: the prompt, ``--show`` (the masked value and where it came
    from), and ``--remove`` (the line out, nothing else touched).
    """
    home = _home(args)
    path = home.env_file

    if args.remove:
        removed = clear_env_key(path)
        if not removed:
            raise RedError(
                f"no key in {path} to remove: `red key --show` reports what this "
                "install has"
            )
        print(f"removed  {', '.join(removed)}")
        print(f"file     {path}")
        return EXIT_OK

    if args.show:
        found = read_env_key(path)
        if found:
            name, value = found
            print(f"key      {_mask(value)}")
            print(f"source   {name} in {path}")
            return EXIT_OK
        # Not in the file - but an exported variable is still used, and an
        # install that works must not be reported as having no key.
        exported = Settings(_env_file=path if path.is_file() else None)
        have = exported.llm_api_key or exported.featherless_api_key
        if have:
            print(f"key      {_mask(have)}")
            print(f"source   the environment, which wins over {path}")
            return EXIT_OK
        raise RedError(f"no key in {path}: run `red key` to be prompted for one")

    try:
        entered = _ask_for_the_key()
    except (EOFError, KeyboardInterrupt) as exc:
        raise RedError("no key entered: nothing was written") from exc
    value = entered.strip()
    if not value:
        raise RedError("no key entered: nothing was written")
    if value != entered or any(character.isspace() for character in value) or any(
        character in value for character in "#\"'"
    ):
        raise RedError(
            "that key has a space or a quote in it, which would change what the "
            ".env line means: nothing was written. A key is one unbroken token, "
            "with nothing around it."
        )
    written = set_env_key(path, value)
    print(f"key      {_mask(value)}")
    print(f"file     {path}")
    print(f"         written to {', '.join(written)}; every other line is as it was")
    return EXIT_OK


def _agent_role(args: Any, home: Home) -> str:
    """The model role that answers: ``--model``, else what this install last used.

    The remembered choice is only ever ``fast`` or ``reason``: anything else in
    a hand-edited ``chat.json`` is ignored rather than trusted, so the file can
    never make ``red`` build a role the provider does not have. With no
    file and no flag this is ``reason``, which is the documented default.
    """
    chosen = args.model or read_chat_prefs(home.chat_prefs_file).get("model")
    return chosen if chosen in {"fast", "reason"} else "reason"


def cmd_agent(args: Any) -> int:
    """The agent: one prompt, and every sentence in it is worked or answered.

    The head of the process. ``red`` on its own gets here, and ``red "..."``
    gets here with one sentence to work before it leaves. A question is answered
    and writes nothing; a sentence that names a target and asks for work is
    worked as a mission of several steps, each pre-flighted by the guard and
    executed through the adapter the scan path uses, with an intrusive command
    line stopping for a human and every step written to the hash-chained audit
    log before it runs.

    The decision this command encodes is the one the whole surface rests on: a
    sentence here is worked, and the record of what was worked is the audit log
    rather than a paragraph printed under an answer. So the banner is the facts
    of *this* install - the endpoint, the model, what the scope authorises, what
    the attestation says, which capabilities exist - because that is what an
    operator needs before typing, and a paragraph of instructions is what a
    surface prints when it cannot act.
    """
    from agent.chat import ChatSession
    from agent.providers.featherless import FeatherlessProvider

    settings = get_settings()
    # argparse hands the one-sentence form back as a list of words, so that an
    # unquoted `red check localhost --json` parses as the same sentence as the
    # quoted one. One string from here on: everything below reads it as the
    # sentence it is, and `--json`/`--verbose` stay flags.
    args.message = " ".join(args.message) if args.message else None
    # Before anything is asked: a model on this machine is worth starting, and
    # nothing can act without one. A remote endpoint is never touched here.
    started = ensure_local_model(settings.featherless_base_url)
    if started:
        print(started)
    ok, sentence = key_status(settings)
    if not ok:
        raise RedError(
            f"the model endpoint {settings.featherless_base_url} is remote and "
            f"{sentence}. Run `red key` to be prompted for one - it writes "
            f"FEATHERLESS_API_KEY (or LLM_API_KEY) into {HOME_DIR / '.env'} - or "
            "run setup_local_model.* to use a model on this machine, which needs "
            "no key. `red doctor` shows the same."
        )

    try:
        provider = FeatherlessProvider(settings=settings)
    except ProviderError as exc:
        # The one thing the agent does need is a model *id*, and that lives in
        # the config home - so an uninitialised home is a sentence here, not a
        # traceback. No scope, no authorization and no audit log are involved.
        raise RedError(
            f"no model to answer: {exc}. Run `red init` (the model ids live in "
            "its config home) or set FEATHERLESS_MODEL_FAST and "
            "FEATHERLESS_MODEL_REASON in .env. `red doctor` shows what this "
            "install has."
        ) from exc
    home = _home(args)
    role = _agent_role(args, home)
    session = ChatSession(provider=provider, settings=settings, model=role)
    chain = _FreestyleChain(args)
    print(_agent_banner(settings, home, role, sentence))
    if args.message:
        print(f"red> {args.message}")

    async def drive() -> int:
        try:
            if args.message:
                return await _agent_once(session, chain, args)
            return await _agent_repl(session, args)
        finally:
            await provider.aclose()

    code = asyncio.run(drive())
    if not args.message and home.is_seeded:
        # An interactive session remembers the role it answered with, so the
        # next one opens on the same choice. One sentence passed on the command
        # line does not: it is a script, and a script must not change the
        # operator's settings as a side effect - the same reason a bare `red` in
        # a throwaway home creates no config/ at all.
        write_chat_prefs(home.chat_prefs_file, {"model": session.model})
    return code


def _bind_is_loopback(host: str) -> bool:
    """Whether a *bind* address is reachable from this machine alone.

    Deliberately not :func:`agent.providers.base.host_is_local`, which answers a
    different question: that one says whether an endpoint needs a credential, and
    it rightly says yes for ``0.0.0.0`` and for a LAN address, since both are
    often a model on the operator's own network. Here the question is who can
    reach the port, and for that both are exposure.
    """
    name = host.strip().strip("[]").lower()
    if not name:
        return True  # uvicorn's own default is 127.0.0.1
    if name == "localhost":
        return True
    try:
        return ipaddress.ip_address(name).is_loopback
    except ValueError:
        return False  # a name, or a wildcard: assume it is reachable


#: What each mode means, in one line, printed by `red serve` before the port is
#: up. The page repeats the same three states from `/api/capabilities`, so an
#: operator reading the banner and a visitor reading the run band are reading the
#: same description of the same process.
MODE_SENTENCES = {
    "chat": (
        "answers the conversation and runs nothing: no chain is built, so no "
        "request here can become a run"
    ),
    "plan": (
        "forms the exact command line a step would run and the guard's answer "
        "about it, and executes none of it"
    ),
    "run": (
        "forms a plan and executes it when a page-approved command line arrives, "
        "with every run audited before the process starts"
    ),
}


def _serve_banner(
    settings: Any,
    key_sentence: str,
    key_ok: bool,
    host: str,
    port: int,
    role: str,
    turns: int,
    window: int,
    hands: Any | None = None,
    mode: str = "chat",
) -> str:
    """What an operator must read before the port is up.

    The last paragraph is the one that matters and it is the same sentence the
    other two surfaces print (`[NOT_A_RUN]`), because the browser is not a place
    where the rule could be different. With ``--hands`` the paragraph changes
    shape rather than tone: a turn still talks, and the run bar beside it is
    where a scan session, a scope and an audit log actually exist - said out
    loud before the port is up, not discovered by clicking. In ``run`` mode the
    paragraph also names the one sentence that is not just talk, because a
    visitor is entitled to know that this instance works a target it is told
    about, exactly as `red` does.
    """
    lines = [
        f"red serve: the chat interface on this machine, over "
        f"{settings.featherless_base_url} ({key_sentence}).",
        f"  serving  http://{host}:{port}  - web/beta/index.html and POST /api/chat",
        f"  model    {role} role, named by this install (.env, config/models.yaml)",
        f"  limits   {turns} turns per address per {round(window / 60)} minutes, "
        "counted in memory",
        "           only; no cookie, no session, no conversation written to disk",
        f"  mode     AGENT_MODE={mode} - {MODE_SENTENCES.get(mode, MODE_SENTENCES['chat'])}",
    ]
    if not key_ok:
        lines.append(
            "  key      none here, and the endpoint is remote: the page's panel "
            "takes one for a"
        )
        lines.append(
            "           single turn (`red key` writes it into .env instead)."
        )
    if hands is None:
        lines.extend(
            [
                "A turn here talks: it runs no capability, touches no target and "
                "writes no audit",
                "line, so nothing said in the browser can become a finding. `red scan` "
                "is where",
                "findings come from. Ctrl+C stops this.",
                f"[{NOT_A_RUN}]",
            ]
        )
        return "\n".join(lines)

    described = hands.describe()
    lines.extend(
        [
            f"  hands    on, loopback only: {len(described['tools'])} capabilities "
            f"({', '.join(described['tools'])}), mode {described['mode']}",
            f"  audit    {described['audit_path']}",
            f"  limits   {described['runs_per_window']} runs per address per "
            f"{round(described['window_seconds'] / 60)} minutes, same memory-only "
            "window",
            "A turn still talks: it runs no capability, touches no target and writes "
            "no audit",
            "line unless the sentence names a target, which the mode line above covers; the "
            "run bar in the same page is",
            "the other thing this process does, and it is not a conversation: a plan "
            "is the guard's",
            "answer about one exact command line, an intrusive action needs an "
            "approval for that exact",
            "line, and every run is written to the audit log before the process "
            "starts. Ctrl+C stops",
            "this.",
        ]
    )
    if mode == "run":
        lines.append(
            "AGENT_MODE=run: a sentence naming a target is worked by `agent/mission.py` "
            "through this"
        )
        lines.append(
            "same chain, exactly as `red` does it in a terminal; a question is still "
            "answered and"
        )
        lines.append(
            "still runs nothing, so the page's own lines say which of the two happened."
        )
    else:
        lines.append(
            "AGENT_MODE=plan: the run bar forms the exact command line and the guard's "
            "answer, and"
        )
        lines.append(
            "nothing is executed from here - `AGENT_MODE=run` is what changes that."
        )
    return "\n".join(lines)


def _serve_mode(settings: Any, *, hands_requested: bool) -> str:
    """``AGENT_MODE``, checked against the chain this command actually built.

    Empty derives, because a default should not decide what a command does:
    ``red serve`` is ``chat`` and ``red serve --hands`` is ``run``. A word set
    explicitly is a claim about this instance, and each of the two ways it can be
    unbacked is refused here rather than printed as a promise - a mode naming a
    plan or a run with no chain behind it, and ``--hands`` beside ``chat``, which
    asks for the run surface and for the mode that exposes none. The word only
    ever narrows what is exposed; it never widens it, and it is never a
    permission: the scope file and the attestation decide what may be touched.
    """
    from agent.hands import MODES

    declared = (settings.agent_mode or "").strip().lower()
    if not declared:
        return "run" if hands_requested else "chat"
    if declared not in MODES:
        raise RedError(
            f"AGENT_MODE={declared!r} is not a mode. It is one of "
            f"{', '.join(MODES)}: `chat` answers the conversation, `plan` forms "
            "the exact command line and executes none of it, `run` executes a "
            "page-approved line under this install's scope and attestation."
        )
    if declared == "chat" and hands_requested:
        raise RedError(
            "AGENT_MODE=chat beside --hands asks for the run surface and for the "
            "one mode that exposes none - the bar would have nothing behind it "
            "and the page would be told a plan exists that this instance will not "
            "make. Drop --hands, or set AGENT_MODE=plan (the exact command line, "
            "nothing executed) or AGENT_MODE=run."
        )
    if declared in ("plan", "run") and not hands_requested:
        raise RedError(
            f"AGENT_MODE={declared} names an instance that forms a plan, and "
            "`red serve` alone builds no chain to form one with: no scan session, "
            "no scope file, no attestation, no registry, no audit log. "
            "`red serve --hands` adds them, or set AGENT_MODE=chat."
        )
    return declared


def _relaunch_into_hands() -> None:
    """Exit with the code a supervisor reads as "come back with ``--hands``".

    Called by the setup surface once the attestation the gate accepts is on
    disk. Only ``--restart-on-setup`` reaches this function, so a server started
    by hand - or reachable over anything but loopback - is never killed by a
    request. The desktop launcher passes the flag because it watches the child's
    exit code; see :mod:`agent.desktop`.
    """
    print(
        "attestation written: restarting with `--hands`",
        flush=True,
    )
    threading.Timer(0.5, os._exit, args=(RELAUNCH_EXIT,)).start()


def cmd_serve(args: Any) -> int:
    """Serve the chat interface on this machine, over this install's model.

    The default page is a static file with nothing behind it: on the site
    ``functions/api/chat.js`` answers its form, and on a laptop nobody does.
    This command is that answer for someone running the checkout. By default it
    serves ``web/beta/index.html``; ``--interface`` can select another local
    page without changing the backend or its safety checks.

    What it can do is the whole point: as served by `red serve` alone, it talks.
    Nothing it builds then is a scan session, a scope, a guard, an adapter or an
    audit log, so no request to it can become a run - a turn that wants one gets
    the sentence naming `red scan`. `--hands` adds that other half for this
    machine only, and it is built here rather than inside the app: the same
    `ScanSession.open` and `Registry(guard=...)` `red scan` uses, so the run bar
    on the page has one chain behind it and no second opinion about it.

    ``AGENT_MODE`` names which of the three instances this is, and it is checked
    against what this command builds rather than trusted: ``chat`` (what a plain
    serve is) runs nothing, ``plan`` forms the exact command line a step would
    run and executes none of it, ``run`` (what ``--hands`` is) executes a
    page-approved line. A word naming more than the process holds is refused
    here rather than printed as a promise, and none of the three is a
    permission - the scope file and the attestation remain the authority on
    what may be touched.

    Four refusals, and each is about not pretending. A bind that is not loopback
    is refused unless ``--allow-remote`` is said out loud, because this process
    holds the install's own key and would otherwise become a free proxy for
    whoever reaches the port. ``--hands`` with anything but a loopback bind is
    refused outright - the pair is not a configuration, it is the one thing this
    feature must never be - and ``--hands`` needs a seeded home with a dated
    attestation, for the same reason a scan does. A model the page names in its
    panel is refused rather than quietly ignored: the endpoint and the two model
    ids are `.env`'s. And a turn with no key anywhere, against a remote endpoint,
    says which three ways there are to get one instead of failing as a transport
    error.
    """
    try:
        # The two dependencies of the extra, named here rather than discovered
        # inside the app factory: a scan-only install gets a sentence about how to
        # add them, not a traceback from three frames down.
        import fastapi  # noqa: F401
        import uvicorn  # noqa: F401

        from agent.serve import TURNS_PER_WINDOW, WINDOW_SECONDS, create_app
        from agent.serve import run as serve_app
    except ModuleNotFoundError as exc:
        # The extra, not a core dependency: a scan and a terminal chat need
        # neither fastapi nor uvicorn, so neither is dragged in by a plain
        # install - see the `serve` group in pyproject.toml.
        raise RedError(
            f"`red serve` needs {exc.name}, which this install does not have. "
            f'`pip install "enigmatic-red[serve]"` adds fastapi and uvicorn; '
            "`red` is the same conversation in a terminal and needs neither."
        ) from exc

    settings = get_settings()
    parsed = urlsplit(settings.app_base_url or "")
    host = args.host or parsed.hostname or "127.0.0.1"
    port = args.port or parsed.port or 8000
    if not _bind_is_loopback(host) and not args.allow_remote:
        raise RedError(
            f"{host} is not loopback, so anything on that network could reach this "
            "chat - and this process holds this install's own model credential. "
            "Pass --allow-remote if that exposure is what you want, or leave the "
            "host alone and reach it from here."
        )

    # Hands are loopback-only, and the pairing is refused rather than quietly
    # downgraded: a run surface this process can reach over a network is the one
    # thing the feature must never become, and an operator who typed both flags
    # asked for exactly that.
    hands_requested = bool(getattr(args, "hands", False))
    if hands_requested and not _bind_is_loopback(host):
        raise RedError(
            f"--hands with {host} is refused. Hands run tools against a target this "
            "install is authorised for, so they stay on loopback and cannot be opened "
            "to a network: drop --hands, or drop --allow-remote and stay on 127.0.0.1."
        )

    # The setup surface writes the file `--hands` needs, so it is held to the
    # same rule as the flags that read it: loopback only, and not beside a chain
    # that is already running.
    restart_on_setup = bool(getattr(args, "restart_on_setup", False))
    if restart_on_setup and hands_requested:
        raise RedError(
            "--restart-on-setup with --hands is refused: the run surface is "
            "already what this command is starting, so there is no setup step to "
            "restart from. Drop one of them."
        )
    if restart_on_setup and not _bind_is_loopback(host):
        raise RedError(
            f"--restart-on-setup with {host} is refused: the setup page writes "
            "the attestation a scan runs under, and a page that anyone on the "
            "network can reach must not be able to sign one. Stay on 127.0.0.1."
        )

    # Which instance this is, before anything expensive is opened: the mode is a
    # claim about what was built, so it is checked against what this command is
    # about to build rather than believed.
    if restart_on_setup:
        # The setup phase is not the install's claim about what it can run. It is
        # the page that writes the attestation and it has no chain, so `chat` is
        # the only shape it can be; AGENT_MODE is read again on the restart that
        # `--hands` starts, where it can be honoured or refused properly.
        mode = "chat"
    else:
        mode = _serve_mode(settings, hands_requested=hands_requested)

    ok, sentence = key_status(settings)
    home = _home(args)
    role = _agent_role(args, home)

    hands = None
    if hands_requested:
        # The chain `red scan` builds, opened once for the life of the server:
        # the same scope file, guard, audit log and kill switch from the same
        # home. The attestation is not optional here for the same reason it is
        # not optional anywhere - a run without one is what this tool refuses.
        _require_seeded(home)
        attestation = _load_authorization(home)
        session = ScanSession.open(
            org=attestation.organization,
            actor="red serve",
            attestation=attestation,
            scope_file=home.scope_file,
            policy_file=home.policy_file,
            audit_path=home.audit_path,
            killswitch_path=home.killswitch_path,
        )
        hands = Hands(
            session=session,
            registry=Registry(guard=session.guard),
            org=attestation.organization,
            actor="page",
            mode=mode,
        )

    setup = None
    if hands is None and home.is_seeded and _bind_is_loopback(host):
        # What the window shows before there is a chain: the scope as it stands,
        # and the one form that writes the attestation `--hands` needs. A home
        # with no scope file has nothing to show and nowhere to write, and a bind
        # beyond loopback is a page anyone could reach - so plain `red serve`
        # stays the talk-only backend it always was in both those cases.
        setup = Setup(
            scope_file=home.scope_file,
            authorization_file=home.authorization_file,
            relaunch=_relaunch_into_hands if restart_on_setup else None,
        )

    app = create_app(
        settings,
        role=role,
        where=f"http://{host}:{port}",
        interface=Path(args.interface) if getattr(args, "interface", None) else None,
        hands=hands,
        mode=mode,
        setup=setup,
    )
    print(
        _serve_banner(
            settings,
            sentence,
            ok,
            host,
            port,
            role,
            TURNS_PER_WINDOW,
            WINDOW_SECONDS,
            hands=hands,
            mode=mode,
        )
    )
    if setup is not None:
        print(
            "red serve: setup on, loopback only: GET /api/setup shows this "
            "install's scope, and its form writes the attestation `--hands` needs"
        )
    if not ok:
        # Stated once more on stderr, where a wrapper script's log will keep it:
        # the server does start, because the page's panel can bring a key.
        print(
            f"red serve: {sentence}; the panel takes a key per turn. "
            f"Turns are {TURNS_PER_WINDOW} per address per "
            f"{round(WINDOW_SECONDS / 60)} minutes.",
            file=sys.stderr,
        )
    serve_app(app, host=host, port=port)
    return EXIT_OK


def cmd_report(args: Any) -> int:
    """Report what the audit log says happened - including that it says nothing.

    The chain is reported first and in full: a report over a broken chain is not
    a report, and the operator has to see that before reading any counts. Claim
    level findings - what was *confirmed*, as opposed to what ran - require a
    planned scan, and this command does not invent them from a tool run.

    ``--pdf`` renders the same answer to a file (see :mod:`agent.pdf_report`).
    Its import is inside :func:`_write_audit_pdf` for the same reason ``db``'s is
    inside :func:`cmd_db`: reportlab lives in an extra, and this module is the
    scan path, which must not need one.
    """
    home = _home(args)
    audit = AuditLog(home.audit_path, fsync=False)
    if not audit.path.is_file():
        raise RedError(f"no audit log at {audit.path}: nothing has been scanned yet")

    ok, message = audit.verify()
    entries = list(audit.iter_entries())
    decisions: dict[str, int] = {}
    for row in entries:
        key = str(row.get("decision") or row.get("event") or "unknown")
        decisions[key] = decisions.get(key, 0) + 1

    refusals = [
        row
        for row in entries
        if str(row.get("decision") or "")
        in {"refused", "denied", "approval_required", "error"}
    ]
    payload = {
        "audit_path": str(audit.path),
        "entries": len(entries),
        "chain_ok": ok,
        "chain_message": message,
        "head_hash": audit.head_hash,
        "decisions": decisions,
    }

    if args.json:
        print(json.dumps(payload, indent=2, sort_keys=True))
    else:
        print(f"audit    {audit.path}")
        print(f"chain    {'intact' if ok else 'BROKEN'}: {message}")
        print(f"entries  {len(entries)}   head {audit.head_hash[:16]}")
        for key, count in sorted(decisions.items(), key=lambda item: (-item[1], item[0])):
            print(f"    {count:>4}  {key}")
        if refusals:
            print("refusals")
            for row in refusals:
                detail = row.get("detail") or {}
                reason = detail.get("reason") or detail.get("refusal") or ""
                print(
                    f"    #{row.get('seq'):<4} {row.get('event')} {row.get('target') or ''}"
                    f"{' :: ' + str(reason)[:160] if reason else ''}"
                )

    if args.pdf:
        _write_audit_pdf(args.pdf, payload, refusals)
    return EXIT_OK if ok else EXIT_REFUSED


def _write_audit_pdf(
    destination: str, payload: dict[str, Any], refusals: Sequence[Any]
) -> Path:
    """Write the audit report as a PDF, or name the extra that would enable it.

    The import is deliberate: reportlab is an optional extra, so an install that
    only scans never carries it, and a copy that does not have it gets a
    sentence rather than an ImportError reaching the operator.
    """
    try:
        from agent.pdf_report import report_lines, write_pdf

        lines = report_lines({**payload, "refusals": list(refusals)})
        name = Path(str(payload.get("audit_path") or "")).name or "audit.jsonl"
        head = str(payload.get("head_hash") or "")[:16]
        path = write_pdf(destination, lines, footer=f"{name}  -  head {head}")
    except ImportError as exc:
        raise RedError(
            "PDF output is not installed. Install the extra with: "
            'pip install "enigmatic-red[reporting]" '
            f"(import failed: {exc})"
        ) from exc
    print(f"pdf      {path}  ({path.stat().st_size} bytes: a rendering of the audit log)")
    return path



def cmd_db(args: Any) -> int:
    """Create, migrate, inspect or sync the queryable backend.

    Reachable in neither direction from the scan path. A scan writes its audit
    line whether or not a database exists, and ``init``/``upgrade``/``status``
    never read the evidence at all. ``sync`` is the one action that reads it, and
    it copies only after the chain verifies.

    The import is deliberately inside the function. ``db`` needs SQLAlchemy,
    which lives in the ``persistence`` extra, and this module *is* the scan path:
    importing it at the top would mean `pipx install enigmatic-red` could no
    longer run a scan without also installing a database driver.
    """
    home = _home(args)
    try:
        from db import (
            current_revision,
            describe_database,
            make_engine,
            migrate_database,
            session_factory,
            session_scope,
            sync_audit_log,
        )
    except ImportError as exc:
        raise RedError(
            "the database backend is not installed. Install the extra with: "
            'pip install "enigmatic-red[persistence]" '
            f"(import failed: {exc})"
        ) from exc

    if args.action in {"init", "upgrade"}:
        # One operation, two names: `init` is how an operator bootstraps a fresh
        # install and `upgrade` is what they run after an update. Both migrate to
        # head, and both are idempotent, so running either at any moment is safe.
        #
        # Both go through Alembic rather than `create_all` so the database has
        # exactly one schema authority. Using `create_all` for `init` and a
        # migration for `upgrade` would mean `init` followed by `upgrade`
        # replayed revision 0001 against tables that already exist - the failure
        # this project's drift test (tests/test_db.py) exists to make impossible.
        revision = migrate_database(home.database_url)
        print(f"database {home.database_path}")
        print(f"  revision {revision or '(unstamped)'}")
        if args.action == "init":
            print("  ready    the schema is present and idempotent")
        return EXIT_OK

    if args.action == "status":
        engine = make_engine(home.database_url)
        info = describe_database(engine)
        engine.dispose()
        if args.json:
            print(json.dumps(info, indent=2, sort_keys=True))
            return EXIT_OK
        print(f"database   {info['url']}")
        print(f"dialect    {info['dialect']}")
        print(f"revision   {info['revision'] or '(unstamped)'}")
        print(f"ready      {'yes' if info['initialised'] else 'NO'}")
        for name in sorted(info["tables"]):
            table = info["tables"][name]
            if not table["present"]:
                print(f"  {name:<16} MISSING")
                continue
            rows = "(unreadable)" if table["rows"] is None else f"{table['rows']} rows"
            print(f"  {name:<16} {table['columns']:>2} cols  {rows}")
        if info["unexpected_tables"]:
            print(f"  unexpected       {', '.join(info['unexpected_tables'])}")
        return EXIT_OK if info["initialised"] else EXIT_UNUSABLE

    # action == "sync"
    if not home.audit_path.is_file():
        raise RedError(
            f"no audit log at {home.audit_path}: nothing has been scanned yet, "
            "so there is nothing to mirror"
        )
    engine = make_engine(home.database_url)
    try:
        from safety.audit import AuditLog

        audit = AuditLog(home.audit_path, fsync=False)
        factory = session_factory(engine)
        with session_scope(factory) as session:
            imported, present = sync_audit_log(session, audit)
        revision = current_revision(engine)
    finally:
        engine.dispose()
    print(f"audit log  {home.audit_path}")
    print(f"  imported {imported}   already present {present}")
    print(f"  revision {revision or '(unstamped)'}")
    return EXIT_OK


# --------------------------------------------------- corpora and evaluation
def _corpus_bundle(path: Path) -> tuple[Any, tuple[Any, ...], tuple[dict[str, str], ...]]:
    """Read a prediction bundle: run metadata, prediction rows, repeat maps."""
    from corpora.evaluate import Prediction, Run

    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    if "run" not in payload or "predictions" not in payload:
        raise RedError(f"{path}: a bundle needs 'run' and 'predictions'")
    run = Run.from_mapping(payload["run"])
    predictions = tuple(Prediction.from_mapping(row) for row in payload["predictions"])
    repeated = tuple(dict(item) for item in payload.get("repeated", ()))
    return run, predictions, repeated


def _corpus_records(root: Path) -> list[Any]:
    """Every normalised record under ``root``, or nothing when it does not exist."""
    from corpora.schema import read_jsonl

    rows: list[Any] = []
    if Path(root).is_dir():
        for path in sorted(Path(root).rglob("records.jsonl")):
            rows.extend(read_jsonl(path))
    return rows


def _corpus_validation(action: str, args: Any, registry: Any) -> int:
    """``validate``, ``schema``, ``dedupe`` or ``contamination`` over the trees."""
    from config.settings import PROJECT_ROOT
    from corpora.ingest import DEFAULT_HOME
    from corpora.validate import validate_baseline, validate_tree

    root = Path(getattr(args, "root", None) or DEFAULT_HOME).expanduser()
    tree = validate_tree(root, registry, repo_root=PROJECT_ROOT)
    baseline, baseline_findings = validate_baseline(registry)

    findings = list(tree.findings) + list(baseline_findings)
    seen: set[tuple[str, str, str, str]] = set()
    unique = []
    for finding in findings:
        key = (finding.level, finding.code, finding.subject, finding.detail)
        if key not in seen:
            seen.add(key)
            unique.append(finding)

    codes = {
        "schema": {"schema"},
        "dedupe": {"dedupe", "duplicate-input"},
        "contamination": {"contamination", "heldout-lock"},
    }.get(action)
    selected = [f for f in unique if codes is None or f.code in codes]

    print(f"registry  {len(registry.sources)} source(s), reviewed {registry.reviewed_on}")
    print(f"baseline  {len(baseline)} first-party record(s)")
    print(f"corpora   {tree.corpora} ingested tree(s), {tree.records} record(s) under {root}")
    for finding in selected:
        print(f"  {finding.sentence()}")
    failures = [f for f in selected if f.level == "error"]
    print(f"result    {'ok' if not failures else f'FAILED ({len(failures)} error(s))'}")
    return EXIT_OK if not failures else EXIT_REFUSED


def cmd_corpus(args: Any) -> int:
    """Validate, ingest, measure and report on the corpora. It never runs a tool.

    Every action is offline: ingestion reads a file the operator supplies,
    validation reads a tree, the baseline predictor is lexical, and a report is
    written from what those produced. A model run is supplied as a prediction
    bundle; this command does not call a model.
    """
    from corpora.manifest import ManifestError, load_registry

    action = str(getattr(args, "corpus_action", "") or "")
    try:
        registry = load_registry()
    except ManifestError as exc:
        raise RedError(str(exc)) from exc

    if action == "licenses":
        for row in registry.license_rows():
            redistribution = "permitted" if row["redistribution"] else "not permitted"
            print(
                f"{row['corpus']:<32} {row['license']:<24} {redistribution:<14} "
                f"{row['review']:<16} {row['note']}"
            )
        pending = [row["corpus"] for row in registry.license_rows() if row["review"] != "verified"]
        print(f"pending   {len(pending)} source(s)" + (f": {', '.join(pending)}" if pending else ""))
        return EXIT_OK

    if action == "manifest":
        from corpora.report import corpus_manifest

        root = Path(args.root) if getattr(args, "root", None) else None
        payload = corpus_manifest(registry, _corpus_records(root) if root else ())
        print(json.dumps(payload, indent=2, sort_keys=True))
        return EXIT_OK

    if action in ("validate", "schema", "dedupe", "contamination"):
        return _corpus_validation(action, args, registry)

    if action == "prompt-pack":
        from agent.prompts import load_pack
        from corpora.checks import prompt_pack_regression

        text = load_pack("ai")
        problems = prompt_pack_regression(text)
        print(f"pack      agent/prompts/ai/PACK.md ({len(text)} chars)")
        for problem in problems:
            print(f"  problem   {problem}")
        print("result    " + ("ok" if not problems else f"FAILED ({len(problems)})"))
        return EXIT_OK if not problems else EXIT_REFUSED

    if action == "ingest":
        from corpora.ingest import DEFAULT_HOME, ingest
        from corpora.schema import IntegrityError

        if not getattr(args, "source", None) or not getattr(args, "raw", None):
            raise RedError("`red corpus ingest` needs --source NAME and --raw PATH")
        source = registry.by_name(args.source)
        out = Path(args.out).expanduser() if getattr(args, "out", None) else DEFAULT_HOME
        try:
            result = ingest(
                source,
                Path(args.raw).expanduser(),
                out,
                limit=int(getattr(args, "limit", 0) or 100_000),
            )
        except (ManifestError, IntegrityError) as exc:
            raise RedError(str(exc)) from exc
        if getattr(args, "json", False):
            print(json.dumps(result.as_dict(), indent=2, sort_keys=True))
        else:
            for line in result.describe():
                print(line)
        return EXIT_OK

    if action in ("baseline", "heldout", "evidence"):
        from corpora.baseline import load_baseline, write_fixtures, write_lock
        from corpora.checks import baseline_predictions, baseline_run, verify_evidence
        from corpora.evaluate import evaluate

        if getattr(args, "write_fixtures", False):
            print(f"fixtures  {write_fixtures()} record(s) written")
        if getattr(args, "write_lock", False):
            print(f"lock      {write_lock()}")

        records = load_baseline()
        split = "heldout" if action == "heldout" else (getattr(args, "split", None) or "test")
        if getattr(args, "predictions", None):
            run, predictions, repeated = _corpus_bundle(Path(args.predictions))
        elif action == "evidence":
            # No bundle supplied: verify the fixtures' own evidence model, which
            # is the check that the checker works. A model run supplies a bundle.
            from dataclasses import replace

            from corpora.checks import golden_predictions

            run = replace(baseline_run(records), model="fixture-bundle", provider="fixture")
            predictions = golden_predictions(records)
            repeated = ()
        else:
            run = baseline_run(records)
            predictions = baseline_predictions(records)
            repeated = ()

        result = evaluate(predictions, records, run, split=split, repeated=repeated)
        selected = [record for record in records if record.split == split]

        if action == "evidence":
            chosen = [
                prediction
                for prediction in predictions
                if prediction.record_id in {record.id for record in selected}
            ]
            problems = verify_evidence(chosen, selected, run)
            print(f"bundle    {len(chosen)} prediction(s) for split {split}")
            for problem in problems:
                print(f"  problem   {problem}")
            print("result    " + ("ok" if not problems else f"FAILED ({len(problems)})"))
            return EXIT_OK if not problems else EXIT_REFUSED

        if getattr(args, "json", False):
            print(json.dumps(result.as_dict(), indent=2, sort_keys=True))
        else:
            for line in result.describe():
                print(line)

        if getattr(args, "out", None):
            from corpora.report import write_reports

            for path in write_reports(
                Path(args.out), registry=registry, records=selected, report=result
            ):
                print(f"report    {path}")
        return EXIT_OK

    if action == "report":
        from config.settings import PROJECT_ROOT
        from corpora.baseline import load_baseline
        from corpora.checks import baseline_predictions, baseline_run
        from corpora.evaluate import evaluate
        from corpora.report import write_reports

        records = list(load_baseline())
        if getattr(args, "root", None):
            records.extend(_corpus_records(Path(args.root)))
        split = getattr(args, "split", None) or "test"
        repeated: tuple[dict[str, str], ...] = ()
        if getattr(args, "predictions", None):
            run, predictions, repeated = _corpus_bundle(Path(args.predictions))
        else:
            run, predictions = baseline_run(records), baseline_predictions(records)
        result = evaluate(predictions, records, run, split=split, repeated=repeated)

        before = None
        if getattr(args, "before", None):
            before_run, before_predictions, before_repeated = _corpus_bundle(
                Path(args.before)
            )
            before = evaluate(
                before_predictions, records, before_run, split=split, repeated=before_repeated
            )

        destination = Path(
            getattr(args, "out", None) or (PROJECT_ROOT / "reports" / "corpora")
        )
        for path in write_reports(
            destination,
            registry=registry,
            records=records,
            report=result,
            before=before,
            repeated=len(repeated),
        ):
            print(f"report    {path}")
        return EXIT_OK

    raise RedError(
        "choose a corpus action: ingest, validate, schema, licenses, dedupe, "
        "contamination, baseline, heldout, evidence, prompt-pack, report or manifest"
    )

    return EXIT_OK
