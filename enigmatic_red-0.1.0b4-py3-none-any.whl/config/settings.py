"""Typed application settings.

One source of truth for configuration, loaded from environment variables and
``.env``. Nothing in the codebase reads ``os.environ`` directly — if a value
matters, it is a field here, so it is typed, documented and testable.

Secrets are optional in ``dev`` (the test suite must run without them) but
:meth:`Settings.require_secrets` refuses to start in ``prod`` without them. Which
secrets are critical depends on ``release_channel``: the ``beta`` build is
self-hosted and needs the model key only; the paid ``stable`` channel also needs
a session secret, and its billing secrets are archived in ``archive/billing/``.
"""

from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path
from typing import Literal
from urllib.parse import urlsplit

from pydantic import field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

#: Where the code lives. In a checkout this is also the tree ``tests/``,
#: ``web/``, ``archive/`` and ``requirements.txt`` sit in, so the name is kept
#: for the callers that mean exactly that.
PROJECT_ROOT = Path(__file__).resolve().parent.parent

#: The one environment variable read outside :class:`Settings`, and why it has
#: to be: the paths below are the defaults ``Settings`` itself is built from, so
#: they cannot be read *from* Settings without a circular default.
ENV_HOME_VAR = "ENIGMATIC_RED_HOME"


def _user_home(*, platform: str | None = None) -> Path:
    """The per-user home for an installed copy.

    ``%APPDATA%\\enigmatic-red`` on Windows, ``$XDG_CONFIG_HOME/enigmatic-red``
    (falling back to ``~/.config/enigmatic-red``) elsewhere: the same shape as
    any CLI's settings directory, and deliberately *not* inside the install
    directory. An audit log or an evidence file written into ``site-packages``
    is lost on the next upgrade and may not even be writable.

    ``platform`` exists so the two branches can be tested on either host; the
    environment is read from ``os.environ``, which is the only place in this
    module that touches it.
    """
    if (platform or os.name) == "nt":
        base = os.environ.get("APPDATA")
        root = Path(base) if base else Path.home() / "AppData" / "Roaming"
        return root / "enigmatic-red"
    base = os.environ.get("XDG_CONFIG_HOME")
    root = Path(base) if base else Path.home() / ".config"
    return root / "enigmatic-red"


def _resolve_home() -> Path:
    """Resolve the config home: explicit override, then checkout, then user.

    A checkout is recognised by the policy file the guard loads, not by a marker
    file of our own: if ``config/policy.yaml`` sits next to the code, this tree
    is what the tests and the capture script mean by "config", and an installed
    wheel - which has no such sibling-in-a-working-tree - resolves to the user
    directory instead.
    """
    override = os.environ.get(ENV_HOME_VAR)
    if override:
        return Path(override).expanduser()
    # A checkout is recognised by its packaging file, not by the policy: an
    # installed wheel *also* ships config/policy.yaml, so "the policy is there"
    # would resolve an install's home to site-packages - which is exactly the
    # mistake this function exists to avoid. pyproject.toml is the file that
    # only a source tree has (an editable install keeps it too, and keeps using
    # the tree, which is what an editable install is for).
    if (PROJECT_ROOT / "pyproject.toml").is_file() and (
        PROJECT_ROOT / "config" / "policy.yaml"
    ).is_file():
        return PROJECT_ROOT
    return _user_home()


#: Config home. ``red init`` seeds ``config/`` and ``data/`` underneath it.
HOME_DIR = _resolve_home()
CONFIG_DIR = HOME_DIR / "config"
DATA_DIR = HOME_DIR / "data"

__all__ = [
    "CONFIG_DIR",
    "DATA_DIR",
    "ENV_HOME_VAR",
    "HOME_DIR",
    "PROJECT_ROOT",
    "Settings",
    "get_settings",
]


class Settings(BaseSettings):
    """Environment-driven settings. Field names map to UPPER_SNAKE env vars."""

    model_config = SettingsConfigDict(
        env_file=str(HOME_DIR / ".env"),
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )

    # ----------------------------------------------------------------- brand
    #: One name for the company and the product: Enigmatic Red. There is no
    #: parent brand and no separate product wordmark to keep in step, so this is
    #: the only name to change. ``enigmaticred.com``.
    brand_name: str = "Enigmatic Red"
    #: The paid tier's name, reserved. Nothing sells it in the beta: the section
    #: it was sold in, its entitlement ladder and its Stripe config are in
    #: archive/billing/. The name is kept because the decision outlives the menu.
    subscription_name: str = "Enigmatic Red Subscription"
    #: The public marketing origin. ``app_base_url`` stays where *this*
    #: deployment is reachable; this is where the site is published. The page
    #: *is* the site root, so nothing is appended to it.
    site_url: str = "https://enigmaticred.com"

    # ------------------------------------------------------------- contact
    #: Contact details that do not exist yet stay ``None``: while a value here is
    #: empty the page must ship no link to it, so nothing can 404. Fill one in and
    #: ``tests/test_branding.py`` requires the page to carry it. See the
    #: "Outstanding before public launch" table in web/README.md.
    #:
    #: Set on 2026-10-19, because the mailbox exists: Cloudflare Email Routing on
    #: the zone publishes the domain's ``MX`` (``route1..3.mx.cloudflare.net``) and
    #: its SPF record, and forwards this address to the operator's inbox, so the
    #: page prints the address instead of an apology. It is an address at the
    #: site's own domain on purpose: the inbox the mail lands in is never
    #: published, and ``tests/test_settings.py`` fails if this one ever drifts off
    #: ``site_url``'s host.
    contact_email: str | None = "info@enigmaticred.com"
    social_linkedin: str | None = None
    social_github: str | None = None

    # ------------------------------------------------------------------ app
    #: Operator-facing name of the deployed product, for logs and panels.
    app_name: str = "Enigmatic Red"
    app_base_url: str = "http://127.0.0.1:8000"
    environment: Literal["dev", "test", "prod"] = "dev"
    #: "beta" is the self-hosted research build: no accounts are issued, so the
    #: model key is the only secret it has. "stable" is the paid product and also
    #: needs the session and billing secrets — archived in archive/billing/.
    release_channel: Literal["beta", "stable"] = "beta"
    log_level: str = "INFO"
    #: What this instance is allowed to do, in one word, so no page has to guess
    #: and no install can claim more than it holds. ``chat`` answers the
    #: conversation and runs nothing - the hosted site's shape, and what a plain
    #: ``red serve`` is whatever this says. ``plan`` may form the exact command
    #: line a step would run and show the guard's answer about it, and may not
    #: execute one. ``run`` may execute, under the same scope file, dated
    #: attestation, guard, audit log and kill switch a scan uses.
    #:
    #: Empty means "derive it": ``red serve`` is ``chat``, ``red serve --hands``
    #: is ``run``. A value set explicitly is a *claim*, and the command checks it
    #: against what that command actually built rather than trusting it - a mode
    #: naming work with no chain behind it is refused at startup, and so is
    #: ``--hands`` beside ``chat``, which asks for a run surface and for a mode
    #: that exposes none. The word only ever narrows what is exposed; it is never
    #: a permission, and ``safety/scope.py`` remains the authority on targets.
    agent_mode: Literal["chat", "plan", "run"] | None = None

    # ------------------------------------------------------------------ llm
    llm_provider: Literal["featherless"] = "featherless"
    #: The model credential, under the name most OpenAI-compatible hosts
    #: document. It is an *alias*, not a second setting: when
    #: ``FEATHERLESS_API_KEY`` is empty and this is set, the validator below
    #: copies it across, so ``red doctor``, the provider and the production
    #: secret check all read the one field and cannot disagree about whether a
    #: key exists. "BYOK" here means the operator's own key against their own
    #: endpoint - nothing is issued by this project and nothing is proxied.
    llm_api_key: str | None = None
    featherless_api_key: str | None = None
    featherless_base_url: str = "https://api.featherless.ai/v1"
    #: Leave blank to use the candidate list in ``config/models.yaml``.
    featherless_model_fast: str = ""
    featherless_model_reason: str = ""
    llm_timeout_s: float = 120.0
    llm_max_retries: int = 3
    llm_max_tokens: int = 4096
    llm_temperature: float = 0.2
    #: How hard a reasoning model should think, passed through to an
    #: OpenAI-compatible endpoint as ``reasoning_effort`` (``low``, ``medium``
    #: or ``high``). Empty means the endpoint's own default. The router speaks
    #: this; nothing else has to know the field exists.
    llm_reasoning_effort: str = ""
    #: Hard ceiling on tokens one scan may spend. The provider bills the
    #: operator per token, and a planner loop that never stops paying for
    #: reasoning will happily do it: this is the cost interlock.
    llm_scan_token_budget: int = 2_000_000

    # ------------------------------------------- what a chat turn may read
    #: Which of the read-only references' hosts this install will read, as a
    #: comma-separated list of bare hostnames - `api.github.com`, or
    #: `api.github.com,huggingface.co` to keep both. Empty, the default, means
    #: every host `agent/chat_refs.toml` names.
    #:
    #: It can only ever *narrow*: a host the reference table does not name is not
    #: a host, whatever this says, so setting it can never teach a chat a
    #: destination this product did not already read. The three references to
    #: this site's own pages are unaffected either way - they have no host, and a
    #: turn resolves them against the copy the install already holds.
    #:
    #: Nothing here decides what a *run* may touch. `safety/scope.py` remains the
    #: authority on targets, and this variable is not a permission.
    chat_reference_hosts: str = ""

    # ----------------------------------------------------------------- data
    database_url: str = f"sqlite+pysqlite:///{(DATA_DIR / 'enigmaticred.db').as_posix()}"
    jwt_secret: str | None = None
    audit_log_path: str = str(DATA_DIR / "audit" / "audit.jsonl")
    killswitch_sentinel_path: str = str(DATA_DIR / "KILLSWITCH")

    # --------------------------------------------------------------- safety
    safety_require_authorization: bool = True
    #: When true, a target must prove ownership (DNS TXT or an HTTP
    #: ``/.well-known/`` file matching the scope hash) before an action runs.
    #: The check lives in :class:`enigmatic_red.security_gates.OwnershipVerifier`
    #: and is wired into the registry by ``Registry.from_settings``; a private
    #: or loopback lab target is accepted only under
    #: ``safety_allow_loopback_targets``. Off by default, so an install that
    #: never opts in behaves exactly as before.
    safety_require_ownership_verification: bool = False
    #: Local-only convenience for testing against 127.0.0.1. False in prod.
    safety_allow_loopback_targets: bool = False
    safety_max_concurrent_jobs: int = 2
    safety_per_host_requests_per_second: float = 5.0
    safety_job_timeout_s: int = 900
    safety_scope_file: str = str(CONFIG_DIR / "scope.example.yaml")
    safety_policy_file: str = str(CONFIG_DIR / "policy.yaml")

    # ------------------------------------------- source control and model hubs
    #: Credentials for a code host and a model hub. Both are read here and handed
    #: to exactly one child process per run, through that child's *environment* -
    #: never its command line, because every run's argv is written into the
    #: append-only audit log and a token there could never be removed afterwards.
    #: Neither is needed to read a public repository or a public model.
    github_token: str | None = None
    hf_token: str | None = None
    #: The one directory an SCM push or a hub upload may take its content from.
    #: Empty - the default - disables both: this beta reads repositories and
    #: models, and publishes nothing from a path a model chose. Point it at a
    #: checkout you own when you want the write capabilities to exist at all.
    safety_write_root: str = ""

    # -------------------------------------------------------------- storage
    evidence_store_backend: Literal["local", "s3"] = "local"
    evidence_store_path: str = str(PROJECT_ROOT / "evidence")
    evidence_bucket: str = ""
    evidence_retention_days: int = 90

    # -------------------------------------------------------------- billing
    # The Stripe, Turnstile and SMTP fields that used to live here are archived:
    # the beta issues no accounts, takes no payment and sends no mail, so nothing
    # in this process can read them. They are preserved, with the exact restore
    # steps, in archive/billing/ (env.billing.example + README.md). `extra`
    # is "ignore", so a stale .env that still sets them is not an error.

    # ------------------------------------------------------------ validators
    @field_validator("log_level")
    @classmethod
    def _upper_log_level(cls, value: str) -> str:
        return value.upper()

    @field_validator("app_base_url", "site_url")
    @classmethod
    def _strip_trailing_slash(cls, value: str) -> str:
        return value.rstrip("/")

    @field_validator("site_url")
    @classmethod
    def _origin_only(cls, value: str) -> str:
        """The page *is* the site root, so this is an origin and nothing else.

        A path here would be a canonical URL for a page nobody serves, which is
        exactly the kind of thing a rename should not be able to introduce.
        """
        parts = urlsplit(value)
        if not parts.netloc or parts.path.rstrip("/"):
            raise ValueError(
                "site_url must be an origin like https://example.com: the page "
                "is the site root, so it has no path to append"
            )
        return value

    @field_validator(
        "contact_email",
        "social_linkedin",
        "social_github",
        "agent_mode",
        mode="before",
    )
    @classmethod
    def _empty_means_unset(cls, value: object) -> object:
        """`CONTACT_EMAIL=` in a .env means "not published yet", not ""."""
        if isinstance(value, str) and not value.strip():
            return None
        return value

    @model_validator(mode="after")
    def _one_key_under_two_names(self) -> "Settings":
        """``LLM_API_KEY`` is the same credential as ``FEATHERLESS_API_KEY``.

        The endpoint is OpenAI-compatible and whatever host stands behind it
        documents its key under one name or the other; accepting only one would
        make a working endpoint look unconfigured. Whichever is set, both fields
        hold it afterwards, so nothing downstream has to know about the alias.
        """
        if not (self.featherless_api_key or "").strip() and (
            self.llm_api_key or ""
        ).strip():
            self.featherless_api_key = self.llm_api_key
        elif (self.featherless_api_key or "").strip() and not self.llm_api_key:
            self.llm_api_key = self.featherless_api_key
        return self

    # -------------------------------------------------------------- helpers
    @property
    def is_prod(self) -> bool:
        return self.environment == "prod"

    @property
    def is_test(self) -> bool:
        return self.environment == "test"

    @property
    def scope_file(self) -> Path:
        return Path(self.safety_scope_file)

    @property
    def policy_file(self) -> Path:
        return Path(self.safety_policy_file)

    @property
    def audit_path(self) -> Path:
        return Path(self.audit_log_path)

    @property
    def killswitch_path(self) -> Path:
        return Path(self.killswitch_sentinel_path)

    @property
    def evidence_path(self) -> Path:
        return Path(self.evidence_store_path)

    @property
    def canonical_url(self) -> str:
        """The canonical public URL: the site root, since the page *is* the site.

        The page carries this in ``rel="canonical"`` and ``og:url`` by hand - it
        is static and cannot read settings - and
        ``tests/test_branding.py`` fails when the two disagree.
        """
        return f"{self.site_url}/"

    @property
    def beta_url(self) -> str:
        """The beta interface's own address: the chat page on its own subdomain.

        One deployment answers on more than one name. The apex serves the project
        page; ``beta.`` serves the chat interface at its root, which
        ``functions/_middleware.js`` decides by hostname. The page cannot read
        settings, so it carries this address by hand and
        ``tests/test_branding.py`` fails when the two disagree - the same
        agreement ``canonical_url`` has.
        """
        host = self.site_url.removeprefix("https://").removeprefix("http://")
        return f"https://beta.{host}/"

    @property
    def ctf_url(self) -> str:
        """The CTF page's own address: the announcement on its own subdomain.

        One deployment answers on more than one name, and the same CTF document
        is staged at ``/ctf/`` on all of them. Only this hostname's response has
        its live blocks spliced in (``functions/_middleware.js``), so this is the
        address the page links to and the address every other spelling redirects
        to. The page cannot read settings, so it carries the value by hand and
        ``tests/test_branding.py`` fails when the two disagree - the same
        agreement ``beta_url`` has.
        """
        host = self.site_url.removeprefix("https://").removeprefix("http://")
        return f"https://ctf.{host}/"

    @property
    def installer_repo_url(self) -> str:
        """The public repository the beta's downloads are also published in.

        The page's primary download button opens that repository's latest
        release, and the digest block names it, because an address on another
        host is allowed only when it is declared here: ``beta_url`` is the other
        one, and ``tests/test_branding.py`` holds the page to both.

        A constant rather than an environment value, unlike the addresses above:
        that repository carries this release's bytes, so a fork needs its own
        files *and* its own edit here - which is the point of naming it once.
        """
        return "https://github.com/Enigmatic-Red/enigmatic-red-installer"

    @property
    def models_file(self) -> Path:
        return CONFIG_DIR / "models.yaml"

    def require_secrets(self) -> None:
        """Fail fast at startup in production when a critical secret is absent.

        Called by API/worker entrypoints, never at import time, so tests and
        offline tooling can import settings freely. What counts as critical
        depends on the channel: the beta is self-hosted and needs the model key,
        while the paid product also needs a session secret. The billing secrets
        the stable branch used to demand are in archive/billing/README.md.
        """
        if not self.is_prod:
            return
        required = [("FEATHERLESS_API_KEY", self.featherless_api_key)]
        if self.release_channel == "stable":
            required.append(("JWT_SECRET", self.jwt_secret))
        missing = [name for name, value in required if not value]
        if missing:
            raise RuntimeError(
                "production requires these secrets: " + ", ".join(missing)
            )
        if self.jwt_secret and len(self.jwt_secret) < 32:
            raise RuntimeError("JWT_SECRET must be at least 32 characters in prod")

    def describe(self) -> dict:
        """Non-secret summary, safe to log or render in an admin panel."""
        return {
            "brand_name": self.brand_name,
            "subscription_name": self.subscription_name,
            "canonical_url": self.canonical_url,
            "app_name": self.app_name,
            "release_channel": self.release_channel,
            "environment": self.environment,
            "llm_provider": self.llm_provider,
            "featherless_base_url": self.featherless_base_url,
            "featherless_api_key_set": bool(self.featherless_api_key),
            "safety_require_authorization": self.safety_require_authorization,
            "safety_require_ownership_verification": (
                self.safety_require_ownership_verification
            ),
            "safety_max_concurrent_jobs": self.safety_max_concurrent_jobs,
            "safety_per_host_rps": self.safety_per_host_requests_per_second,
            "evidence_store_backend": self.evidence_store_backend,
        }


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Process-wide settings singleton. Tests may call ``cache_clear``."""
    return Settings()
