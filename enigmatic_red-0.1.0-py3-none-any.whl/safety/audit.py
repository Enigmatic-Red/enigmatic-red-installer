"""Append-only, hash-chained audit log.

Every decision this platform makes about a customer's infrastructure is
recorded: what was targeted, which tool ran, which class the guard assigned,
whether a human approved it, and what came back. Each entry carries the hash
of its predecessor, so removing or editing history is detectable —
:meth:`AuditLog.verify` walks the chain and reports the first break.

Writes are synchronous and fail closed: if the audit record cannot be
persisted, the action does not proceed. An unauditable scan is worse than a
refused one.

A log is not private to one process. The server, a scan and a ``red`` command
can hold the same file at once, and two writers that each resumed from their
own idea of the head would fork the chain and then blame each other for the
break. So :meth:`AuditLog.append` takes an exclusive lock on the file, re-reads
the committed head underneath it, and refuses to write at all when the tail it
finds is discontinuous or torn: burying a break under fresh entries would make
the log look intact while hiding the very event it exists to preserve.
"""

from __future__ import annotations

import hashlib
import json
import os
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator

from safety.errors import AuditError

__all__ = ["AuditEntry", "AuditLog", "GENESIS_HASH"]

GENESIS_HASH = "0" * 64

_HASH_FIELDS = (
    "seq",
    "timestamp",
    "event",
    "actor",
    "org",
    "target",
    "action",
    "action_class",
    "decision",
    "detail",
    "prev_hash",
)


def _canonical(payload: dict) -> str:
    """Deterministic JSON so a hash is reproducible across processes."""
    return json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str)


def _digest(payload: dict) -> str:
    return hashlib.sha256(_canonical(payload).encode("utf-8")).hexdigest()


#: How much of the file's tail an append re-reads to find the committed head.
#: Comfortably larger than a dense entry, small enough to stay O(1) as the log grows.
_TAIL_WINDOW = 64 * 1024

if os.name == "nt":  # pragma: no cover - exercised by the platform, not by a branch
    import msvcrt

    #: Windows range locks are *mandatory*: a lock on byte 0 makes every other
    #: process's ``read()`` fail with PermissionError, which would break
    #: ``verify`` and any command that merely opens the log while a scan writes.
    #: Lock a byte far past any real file instead - no entry ever lands there,
    #: so the lock excludes other writers without blocking a single reader.
    _LOCK_OFFSET = 1 << 62

    def _lock(handle: Any) -> None:
        handle.seek(_LOCK_OFFSET)
        msvcrt.locking(handle.fileno(), msvcrt.LK_LOCK, 1)

    def _unlock(handle: Any) -> None:
        handle.seek(_LOCK_OFFSET)
        msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)

else:  # pragma: no cover - exercised by the platform, not by a branch
    import fcntl

    # POSIX locks are advisory and whole-file, so readers are never impeded.
    def _lock(handle: Any) -> None:
        fcntl.flock(handle.fileno(), fcntl.LOCK_EX)

    def _unlock(handle: Any) -> None:
        fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


def _count_entries(path: Path) -> int:
    """Non-empty lines in a log, counted without parsing them.

    :meth:`AuditLog.iter_entries` stops on a torn line, and the count of a broken
    log is exactly what a seal has to record, so counting must not depend on the
    content being readable.
    """
    try:
        with path.open("r", encoding="utf-8", errors="replace") as handle:
            return sum(1 for line in handle if line.strip())
    except OSError as exc:
        raise AuditError(f"cannot count entries in {path}: {exc}") from exc


def _tail_entries(handle: Any) -> list[dict]:
    """The last one or two complete entries, read from the end of a binary handle.

    Reads at most :data:`_TAIL_WINDOW` bytes, so re-reading the head before every
    append stays cheap however long the log has grown. A window that starts
    mid-line simply drops that fragment; only the last two entries matter here.
    """
    handle.seek(0, os.SEEK_END)
    size = handle.tell()
    if size == 0:
        return []
    window = _TAIL_WINDOW
    while True:
        start = max(0, size - window)
        handle.seek(start)
        blob = handle.read()
        if blob and not blob.endswith(b"\n"):
            raise AuditError(
                "audit log ends mid-entry, so the last write was torn; "
                "refusing to append onto it"
            )
        lines = [line for line in blob.split(b"\n") if line.strip()]
        if start > 0 and lines:
            lines = lines[1:]
        if lines or start == 0:
            break
        # A single entry outgrew the window, so widening it is the only way to
        # find a complete line. Stopping here would append onto a stale head.
        window *= 2
    entries: list[dict] = []
    for raw in lines[-2:]:
        try:
            entries.append(json.loads(raw.decode("utf-8")))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise AuditError(f"audit log has an unreadable entry: {exc}") from exc
    return entries


@dataclass(frozen=True)
class AuditEntry:
    seq: int
    timestamp: str
    event: str
    prev_hash: str
    actor: str = "system"
    org: str | None = None
    target: str | None = None
    action: str | None = None
    action_class: str | None = None
    decision: str | None = None
    detail: dict[str, Any] = field(default_factory=dict)
    entry_hash: str = ""

    def hashless(self) -> dict[str, Any]:
        return {key: getattr(self, key) for key in _HASH_FIELDS}

    def compute_hash(self) -> str:
        return _digest(self.hashless())

    def to_json(self) -> str:
        data = self.hashless()
        data["entry_hash"] = self.entry_hash
        return _canonical(data)


class AuditLog:
    """A hash-chained JSONL log that resumes an existing file on startup.

    Args:
        path: destination file. Parent directories are created.
        fsync: flush and ``fsync`` every write (safer, slower). Leave on in
            production; tests may disable it.
        clock: time source, injectable for deterministic tests.
    """

    def __init__(
        self,
        path: str | Path,
        *,
        fsync: bool = True,
        clock: Any | None = None,
    ) -> None:
        self.path = Path(path)
        self.fsync = fsync
        self._clock = clock or (lambda: time.time())
        self._lock = threading.Lock()
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
        except OSError as exc:  # pragma: no cover - filesystem failure
            raise AuditError(f"cannot create audit directory: {exc}") from exc
        self._seq, self._prev_hash = self._resume()

    # ------------------------------------------------------------------ state
    def _resume(self) -> tuple[int, str]:
        """Continue an existing chain, or start a fresh one.

        A trailing line that does not parse is not fatal here: the constructor
        must not raise on a log it exists to report on, so the last complete
        entry becomes the head and :meth:`append` refuses to extend a torn tail.
        """
        if not self.path.exists() or self.path.stat().st_size == 0:
            return 0, GENESIS_HASH
        last: dict | None = None
        try:
            with self.path.open("r", encoding="utf-8") as handle:
                for line in handle:
                    stripped = line.strip()
                    if not stripped:
                        continue
                    try:
                        last = json.loads(stripped)
                    except json.JSONDecodeError:
                        break
        except OSError as exc:
            raise AuditError(
                f"audit log at {self.path} is unreadable: {exc}"
            ) from exc
        if last is None:
            return 0, GENESIS_HASH
        return int(last.get("seq", 0)), str(last.get("entry_hash", GENESIS_HASH))

    @property
    def last_seq(self) -> int:
        return self._seq

    @property
    def head_hash(self) -> str:
        return self._prev_hash

    # ----------------------------------------------------------------- append
    def append(
        self,
        event: str,
        *,
        actor: str = "system",
        org: str | None = None,
        target: str | None = None,
        action: str | None = None,
        action_class: str | None = None,
        decision: str | None = None,
        **detail: Any,
    ) -> AuditEntry:
        """Append one entry. Raises :class:`AuditError` if it cannot be stored.

        The head is re-read under the lock rather than trusted from construction
        time: another process may have appended since this instance resumed, and
        writing from a stale head is exactly how a chain forks.
        """
        with self._lock:
            try:
                handle = self.path.open("a+b")
            except OSError as exc:
                raise AuditError(f"cannot write audit entry: {exc}") from exc
            with handle:
                try:
                    _lock(handle)
                except OSError as exc:
                    raise AuditError(f"cannot lock audit log: {exc}") from exc
                try:
                    self._adopt_head(handle)
                    seq = self._seq + 1
                    draft = AuditEntry(
                        seq=seq,
                        timestamp=datetime.fromtimestamp(
                            self._clock(), tz=timezone.utc
                        ).isoformat(),
                        event=event,
                        prev_hash=self._prev_hash,
                        actor=actor,
                        org=org,
                        target=target,
                        action=action,
                        action_class=action_class,
                        decision=decision,
                        detail=detail,
                    )
                    entry = AuditEntry(
                        **{**draft.hashless(), "entry_hash": draft.compute_hash()}
                    )
                    try:
                        handle.write((entry.to_json() + "\n").encode("utf-8"))
                        handle.flush()
                        if self.fsync:
                            os.fsync(handle.fileno())
                    except OSError as exc:
                        raise AuditError(f"cannot write audit entry: {exc}") from exc
                    self._seq = seq
                    self._prev_hash = entry.entry_hash
                    return entry
                finally:
                    try:
                        _unlock(handle)
                    except OSError:  # pragma: no cover - handle already lost
                        pass

    def _adopt_head(self, handle: Any) -> None:
        """Adopt the head committed to disk, or refuse a chain that is already broken.

        Called with the file lock held. Refusing here is deliberate: an append
        onto a discontinuous chain would leave the break in place while adding
        entries that verify against their neighbours, which is worse than no
        entry at all.
        """
        tail = _tail_entries(handle)
        if len(tail) == 2:
            previous, last = tail
            if last.get("prev_hash") != previous.get("entry_hash"):
                raise AuditError(
                    f"audit chain is broken at seq {last.get('seq')}: prev_hash "
                    f"{last.get('prev_hash')} does not follow "
                    f"{previous.get('entry_hash')}; refusing to append"
                )
        if tail:
            last = tail[-1]
            self._seq = int(last.get("seq", 0))
            self._prev_hash = str(last.get("entry_hash", GENESIS_HASH))

    # ------------------------------------------------------------------- seal
    def seal(
        self,
        *,
        reason: str,
        archive_dir: str | Path | None = None,
    ) -> Path:
        """Archive a log whose chain is broken and continue on a fresh one.

        A break cannot be repaired: rewriting the segment would delete the very
        evidence the chain exists to preserve. What an install *can* do is keep
        the broken bytes untouched in an archive and open a new segment whose
        first entry names that archive, its digest and the break that caused it.
        Appending to the broken file is refused for exactly the reason sealing
        is offered: a break buried under fresh entries is worse than a standstill.

        Refuses when the chain is intact — rotating a sound log would drop
        continuity for no reason. Returns the archive path.
        """
        if not self.path.is_file():
            raise AuditError(f"no audit log at {self.path} to seal")
        destination_dir = (
            Path(archive_dir) if archive_dir else self.path.parent / "archive"
        )
        with self._lock:
            ok, message = self.verify()
            if ok:
                raise AuditError(
                    f"chain at {self.path} is intact ({message}); nothing to seal"
                )
            digest = hashlib.sha256(self.path.read_bytes()).hexdigest()
            entries = _count_entries(self.path)
            try:
                destination_dir.mkdir(parents=True, exist_ok=True)
                stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
                archive = destination_dir / f"audit-{stamp}-{digest[:12]}.jsonl"
                os.replace(self.path, archive)
            except OSError as exc:
                raise AuditError(f"cannot archive {self.path}: {exc}") from exc
            fresh = AuditLog(self.path, fsync=self.fsync, clock=self._clock)
            fresh.append(
                "audit.sealed",
                decision="archived",
                archive=str(archive),
                sha256=digest,
                entries=entries,
                break_message=message,
                reason=reason,
            )
            self._seq, self._prev_hash = fresh._seq, fresh._prev_hash
            return archive

    # ----------------------------------------------------------------- verify
    def iter_entries(self) -> Iterator[dict]:
        with self.path.open("r", encoding="utf-8") as handle:
            for line in handle:
                stripped = line.strip()
                if stripped:
                    yield json.loads(stripped)

    def verify(self) -> tuple[bool, str]:
        """Walk the chain. Returns ``(ok, message)`` naming the first break.

        An unreadable line is reported as a break, not raised: a torn write must
        come back as "this log is not trustworthy" from the command whose job is
        to say exactly that.
        """
        expected_prev = GENESIS_HASH
        expected_seq = 1
        try:
            handle = self.path.open("r", encoding="utf-8")
        except FileNotFoundError:
            return True, "ok: 0 entries, chain intact"
        except OSError as exc:
            return False, f"cannot read log: {exc}"
        with handle:
            for number, line in enumerate(handle, start=1):
                stripped = line.strip()
                if not stripped:
                    continue
                try:
                    raw = json.loads(stripped)
                except json.JSONDecodeError as exc:
                    return False, f"line {number} is unreadable: {exc}"
                if raw.get("prev_hash") != expected_prev:
                    return False, (
                        f"chain break at seq {raw.get('seq')}: prev_hash "
                        f"{raw.get('prev_hash')} does not follow {expected_prev}"
                    )
                stored = raw.get("entry_hash")
                recomputed = _digest({key: raw.get(key) for key in _HASH_FIELDS})
                if stored != recomputed:
                    return False, (
                        f"entry {raw.get('seq')} was modified: stored hash {stored} "
                        f"!= recomputed {recomputed}"
                    )
                if raw.get("seq") != expected_seq:
                    return False, (
                        f"sequence gap: expected {expected_seq}, found {raw.get('seq')}"
                    )
                expected_prev = stored
                expected_seq += 1
        return True, f"ok: {expected_seq - 1} entries, chain intact"

    def tail(self, n: int = 20) -> list[dict]:
        """The most recent ``n`` entries (oldest of the window first)."""
        if n <= 0:
            return []
        return list(deque(self.iter_entries(), maxlen=n))
