"""Freestyle: one target, one capability, through the real chain.

:mod:`agent.chat` is deliberately talk-only - it has no scope, guard, limiter or
audit log, because a turn that runs nothing has none of them to enforce. It is
what ``red serve`` answers with, and what the hosted Function mirrors; the
terminal is the agent, and it has the chain. Freestyle is the narrower run
surface beside it: the operator names one target, the model chooses **one** of
the registered capabilities for it, and that action is pre-flighted by the same
guard and executed by the same adapter a scan uses.

Three properties make that honest rather than merely convenient:

1. **The model reaches nothing new.** The functions it is offered are exactly
   :meth:`agent.registry.Registry.all_tool_specs` - the typed capabilities, each
   with its own closed JSON schema. There is no shell, no ``extra_args``, and a
   name that is not registered is refused by the registry with the list of names
   it *can* call.
2. **Nothing is decided here.** Pre-flight calls the guard; execution calls the
   adapter, which re-checks the kill switch, scope, attestation, guard and rate
   limit from scratch. This module cannot widen authority - only report early
   what the chain would answer anyway.
3. **A refusal is printed, not swallowed.** An out-of-scope target, an expired
   attestation and an intrusive step without approval each come back as a
   sentence naming the control that produced it, and the refused attempt is in
   the audit log beside the allowed ones.

The prompt is freestyle's own, and it is *not* :data:`agent.chat.CHAT_CONTRACT`:
that contract is written for an answer about the work, which is true of a chat
turn and not of a step that really runs. Keeping them apart is what stops this
module from changing the talk-only surface's promises.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Mapping, Sequence

from agent.providers.base import ChatMessage, ToolCall
from agent.registry import Preflight, Registry
from agent.session import ScanSession
from safety.errors import (
    ApprovalRequired,
    AuthorizationError,
    ForbiddenActionError,
    KillSwitchEngaged,
    RateLimitExceeded,
    ScopeViolation,
)
from tools.base import ToolResult

__all__ = [
    "AUDIT_NOTE",
    "CHAIN_REFUSALS",
    "FREESTYLE_CONTRACT",
    "Plan",
    "Proposal",
    "RunOutcome",
    "freestyle",
    "plan_for",
    "propose",
    "refusal_sentence",
]

#: The errors a control raises when it stops an action. Mirrors
#: :data:`cli.commands.REFUSALS`, and a test asserts the two stay equal: a class
#: that is a refusal in one surface and a crash in the other is a bug either way.
CHAIN_REFUSALS = (
    ScopeViolation,
    ForbiddenActionError,
    ApprovalRequired,
    AuthorizationError,
    RateLimitExceeded,
    KillSwitchEngaged,
)

#: The last line of every outcome: a run here *is* audited, unlike a chat turn,
#: and saying so beside the result is what keeps the two surfaces distinguishable
#: in a transcript an operator pastes somewhere.
AUDIT_NOTE = (
    "freestyle: this path is audited - the adapter wrote its decision to the "
    "hash-chained log before it ran, and `red report` shows the chain."
)

#: What the model is told when the operator names a target and asks for action.
#: Deliberately not the planner's prompt (no domain pack, no tier, no phase) and
#: deliberately not the chat contract (this surface *does* have capabilities).
FREESTYLE_CONTRACT = (
    "You are the planning half of Enigmatic Red's freestyle run. The operator "
    "named one target and asked what this install would do to it.\n"
    "\n"
    "- Choose **at most one** of the offered functions, with arguments, or call "
    "none and answer in text. One function, one action: there is no loop here.\n"
    "- The functions are the whole reach. You cannot name a shell command, a "
    "program, or a flag that is not in a function's schema, and trying to is "
    "refused rather than reinterpreted.\n"
    "- What you name is pre-flighted by the same guard a scan uses and then run "
    "**for real** against the target, so an action class marked as needing a "
    "human approval will stop and ask the operator before anything starts.\n"
    "- Authorised targets only. The scope and the signed attestation are "
    "enforced as the action runs; if the operator's target is outside them, say "
    "so in text instead of calling a function.\n"
    "- Prefer the smallest probe that answers the question. This is a "
    "non-destructive assessment: nothing here writes, uploads, deletes or "
    "persists anything on the target.\n"
)


@dataclass(frozen=True)
class Proposal:
    """What the model asked for, before any control has looked at it."""

    text: str
    call: ToolCall | None = None
    model: str = ""
    total_tokens: int = 0


@dataclass(frozen=True)
class Plan:
    """The verdict on a proposal: either an exact command line or a refusal.

    Every field is filled from :meth:`Registry.preflight`, so the sentence the
    operator reads is the one the model would have been handed.
    """

    target: str
    capability: str = ""
    command: str = ""
    action_class: str = ""
    allowed: bool = False
    approval_required: bool = False
    refusal_code: str = ""
    sentence: str = ""
    arguments: Mapping[str, Any] = field(default_factory=dict)

    def lines(self) -> tuple[str, ...]:
        """The plan as the operator reads it, before anything runs."""
        if not self.capability:
            return (f"plan     nothing named for {self.target}",)
        rows = [f"plan     {self.capability} -> {self.target}"]
        if self.command:
            rows.append(f"command  {self.command}")
        if self.action_class:
            rows.append(f"class    {self.action_class}")
        if self.approval_required:
            # Not a refusal: the guard permits this *given a human's yes*, which
            # is why the line says what is needed rather than what is forbidden.
            rows.append(
                "approval needed: this exact command line, from a human, now - "
                f"({self.sentence})"
            )
        elif not self.allowed:
            rows.append(f"refused  {self.refusal_code}: {self.sentence}")
        return tuple(rows)



@dataclass
class RunOutcome:
    """One freestyle request, end to end."""

    target: str
    plan: Plan | None = None
    answer: str = ""
    model: str = ""
    total_tokens: int = 0
    ran: bool = False
    result: ToolResult | None = None
    sentence: str = ""
    refusal_code: str = ""
    approval_requested: bool = False

    @property
    def executed(self) -> bool:
        """True only when the adapter was actually called."""
        return self.result is not None or self.ran

    def lines(self) -> tuple[str, ...]:
        """What the operator sees, in the order they need it.

        Ordered: what the model said, what was planned, what stopped it, and
        only then what ran - so a refusal can never be read as a result.
        """
        rows: list[str] = []
        if self.answer.strip():
            rows.extend(self.answer.strip().splitlines())
        if self.plan is not None:
            rows.extend(self.plan.lines())
        if self.sentence:
            rows.append(f"stopped  {self.sentence}")
        if self.ran:
            rows.append("[run] a control permitted this and the adapter was called.")
        if self.result is not None:
            rows.append(
                f"ran      {self.result.tool}   ok {self.result.ok}   "
                f"skipped {self.result.skipped}"
            )
            if self.result.argv:
                rows.append(f"command  {' '.join(self.result.argv)}")
            if self.result.command is not None:
                rows.append(
                    f"exit     {self.result.command.returncode} "
                    f"in {self.result.command.duration_ms:.0f} ms"
                )
            if self.result.skip_reason:
                rows.append(f"skipped  {self.result.skip_reason}")
            if self.result.parse_error:
                rows.append(f"parse    {self.result.parse_error}")
        elif not self.executed:
            rows.append(
                "[not run] nothing was executed: the lines above are the plan and "
                "the control's answer, not a result."
            )
        rows.append(f"[{AUDIT_NOTE}]")
        return tuple(rows)


async def propose(
    provider: Any,
    registry: Registry,
    target: str,
    *,
    role: str = "reason",
    history: Sequence[ChatMessage] = (),
) -> Proposal:
    """Ask the model which capability, if any, to use against ``target``.

    The function list is the registry's own, so the model's reach is stated by
    the code that enforces it. A provider failure propagates: a run that could
    not reach the model must not look like one that decided nothing.
    """
    messages = [
        ChatMessage.system(FREESTYLE_CONTRACT),
        *history,
        ChatMessage.user(
            f"The operator's target is: {target}\n"
            "Choose one function for it, or none and answer in text."
        ),
    ]
    result = await provider.chat(  # type: ignore[attr-defined]
        messages, tools=registry.all_tool_specs(), role=role
    )
    calls = tuple(getattr(result, "tool_calls", ()) or ())
    usage = getattr(result, "usage", None)
    return Proposal(
        text=str(getattr(result, "text", "") or ""),
        call=calls[0] if calls else None,
        model=str(getattr(result, "model", "") or ""),
        total_tokens=int(getattr(usage, "total_tokens", 0) or 0),
    )


def plan_for(registry: Registry, proposal: Proposal, *, target: str) -> Plan:
    """Pre-flight the proposal through the guard. Changes nothing.

    The target the *operator* named is the target that runs: a model that put a
    different host in the arguments is overruled here, in the operator's favour.
    """
    call = proposal.call
    if call is None:
        return Plan(target=target)
    arguments = {**dict(call.arguments), "target": target}
    flight: Preflight = registry.preflight(
        call.name, arguments, raw_arguments=call.raw_arguments
    )
    refusal = flight.refusal
    return Plan(
        target=target,
        capability=call.name,
        command=flight.command,
        action_class=flight.action_class,
        allowed=flight.ok,
        approval_required=(
            refusal is not None and refusal.code == "approval_required"
        ),
        refusal_code=(refusal.code if refusal is not None else ""),
        sentence=(refusal.reason if refusal is not None else ""),
        arguments=arguments,
    )


def refusal_sentence(exc: BaseException) -> tuple[str, str]:
    """A (code, sentence) pair for anything the chain raised."""
    code = type(exc).__name__
    if isinstance(exc, ScopeViolation):
        code = "out_of_scope"
    elif isinstance(exc, AuthorizationError):
        code = "not_authorized"
    elif isinstance(exc, ApprovalRequired):
        code = "approval_required"
    elif isinstance(exc, ForbiddenActionError):
        code = "forbidden"
    elif isinstance(exc, KillSwitchEngaged):
        code = "halted"
    elif isinstance(exc, RateLimitExceeded):
        code = "rate_limited"
    return code, str(exc)


async def freestyle(
    *,
    provider: Any,
    registry: Registry,
    session: ScanSession,
    target: str,
    role: str = "reason",
    scan_id: str | None = None,
    history: Sequence[ChatMessage] = (),
    confirm: Callable[[Plan], bool] | None = None,
) -> RunOutcome:
    """Name a target, choose one capability, and run it under every control.

    ``confirm`` is the human's approval for an intrusive command line: it is
    handed the plan and returns whether the operator agreed. With no ``confirm``
    an intrusive step is *not* run - it comes back as a plan the operator has to
    approve - which is why this surface can be scripted without losing the gate.

    The scope and the attestation are consulted *before* the approval prompt, so
    an unauthorised target costs a sentence rather than a question. Neither check
    is the enforcement: the adapter repeats both as it runs, because a plan is a
    request and not a permission.
    """
    proposal = await propose(
        provider, registry, target, role=role, history=tuple(history)
    )
    outcome = RunOutcome(
        target=target,
        answer=proposal.text,
        model=proposal.model,
        total_tokens=proposal.total_tokens,
    )
    if proposal.call is None:
        outcome.sentence = "the model named no capability for this target."
        return outcome

    plan = plan_for(registry, proposal, target=target)
    outcome.plan = plan
    if not plan.allowed and not plan.approval_required:
        outcome.refusal_code = plan.refusal_code
        outcome.sentence = plan.sentence
        return outcome

    # Early, read-only answers from the two controls that need the *target*
    # rather than the command line. Both are advisory here and re-run at
    # execution: a refusal now saves the operator an approval prompt.
    scope_decision = session.scope.check(target)
    if not scope_decision.allowed:
        outcome.refusal_code = "out_of_scope"
        outcome.sentence = (
            f"refusing {target!r}: {scope_decision.reason}. The scope is the "
            f"list of assets this install may touch."
        )
        return outcome
    try:
        session.gate.require(session.attestation, target, session.scope)
    except CHAIN_REFUSALS as exc:  # AuthorizationError, in practice
        outcome.refusal_code, outcome.sentence = refusal_sentence(exc)
        return outcome

    approved: frozenset[str] = frozenset()
    if plan.approval_required:
        outcome.approval_requested = True
        agreed = bool(confirm(plan)) if confirm is not None else False
        if not agreed:
            outcome.refusal_code = "approval_required"
            outcome.sentence = (
                "this action is intrusive and no human approved this exact "
                "command line, so nothing was run."
            )
            return outcome
        approved = frozenset({plan.command})

    context = session.context(scan_id, approved=approved)
    # ``target`` is passed to the registry as its own argument, so it must not
    # also ride inside the options dict: the adapter takes it positionally.
    options = {k: v for k, v in plan.arguments.items() if k != "target"}
    try:
        outcome.result = registry.execute(
            plan.capability, options, context=context, target=target
        )
    except CHAIN_REFUSALS as exc:
        # The adapter's own sentence is the one to print: it is the control
        # that actually stopped the action, not this module's summary of it.
        outcome.refusal_code, outcome.sentence = refusal_sentence(exc)
        return outcome
    outcome.ran = True
    return outcome

