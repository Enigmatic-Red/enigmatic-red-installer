"""Goals as deliverables, and the constraints read out before any planning.

A plan that is a list of checks answers "what will we run". It does not answer
"what will the operator be able to say afterwards", and the two come apart in
both directions:

* **A deliverable can be answered by evidence the plan never seeded.** The model
  chose a capability outside the seeded checks that speaks to the same kind of
  asset; the answer exists even though a seeded check of that kind is still
  open, and a route that only counts its own checks would keep asking.
* **A deliverable can settle empty.** "Nothing answers on the asset" is an
  answer, and it is a different thing from a check that never ran.

ARTEX (``Autumn-27/ARTEX``, AGPL-3.0; the upstream repository is no longer
public, so the readable mirror is ``BaaRai/ARTEX``) keeps its goal list separate
from the exploration graph for exactly this reason (``goals.go``): goals are
deliverables, the graph is the route to them, and "is the task goal met" is
judged against the deliverables rather than against the length of the queue.
This module is an independent Python implementation of that separation: no ARTEX
source, Go identifier or function body is carried, translated or paraphrased
here - what it reproduces is the published design contract named in
:mod:`agent.exploration`, which is where the quotation and its attribution live.
The shape is not even the same: these goals are derived from mission state that
is already audited, on every read, rather than held in a list of their own.

Nothing is stored. :func:`decompose` derives the goals from the mission state on
every read, the way :class:`agent.exploration.Route` derives its intents, so a
resumed mission re-derives the same goals from the same rows and
``SCHEMA_VERSION`` does not move. :func:`constraints` reads only the operator's
own sentence and the controls already in force; it cannot add one, and no
sentence it reads can widen anything.

What is deliberately *not* here:

* **No new authority.** A goal is a statement about what would answer the
  operator's question, not permission to go and get it. Every step still goes
  through ``Registry.preflight`` and ``Registry.execute``.
* **No model call.** Decomposition is a reading of a few rows and a sentence,
  not a second opinion about them: the same state always produces the same
  goals, which is what makes the judgement auditable.
* **No new kind of asset.** A goal's kind is the kind the check declares, so a
  goal can never point somewhere the plan could not have gone.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any

from agent.mission_state import CHECK_CATALOG, Check, MissionState, sanitize
from safety.errors import EnigmaticRedError

__all__ = [
    "MAX_CONSTRAINTS",
    "Constraint",
    "Goal",
    "GoalsError",
    "constraints",
    "decompose",
]

#: How many operator-stated limits one mission carries into planning. More than
#: a handful is a brief, not a sentence, and the rest of it is already in the
#: objective the reader extracted.
MAX_CONSTRAINTS = 3

#: What each target kind is *for*, in the operator's terms. A goal is named by
#: what it would let the operator say, never by the function that would find it.
_DELIVERABLE = {
    "host": "what the asset itself exposes over the network",
    "url": "what the web surface exposes",
    "repository": "what the repository publishes to a reader",
    "model": "what the model card and its checks publish",
}

#: Words that turn a clause of the operator's sentence into a limit rather than
#: a target. Matched on word boundaries, so "note" is not a "no".
_LIMIT_WORDS = (
    "do not",
    "don't",
    "dont",
    "must not",
    "mustn't",
    "never",
    "without",
    "avoid",
    "except",
    "only",
    "no",
    "not",
    "read-only",
    "readonly",
    "non-destructive",
    "leave",
    "skip",
)

_LIMIT = re.compile(
    r"(?<![a-z0-9])(" + "|".join(re.escape(word) for word in _LIMIT_WORDS) + r")(?![a-z0-9])",
    re.IGNORECASE,
)

#: A clause longer than this is a paragraph, not something an operator meant as
#: a limit; the quote is bounded anyway.
_CLAUSE_CHARS = 200


class GoalsError(EnigmaticRedError):
    """The mission state cannot be read as goals."""


@dataclass(frozen=True)
class Goal:
    """One deliverable, and what the chain says about it so far.

    Args:
        id: ``g1``, ``g2``... in the order the plan first reaches the kind.
        statement: what answering it would let the operator say.
        kind: the target kind (see :data:`agent.mission_state.CHECK_CATALOG`).
        capabilities: the checks that speak to it, in priority order.
        met_by: evidence sequence numbers from *any* capability of this kind,
            including one the plan never seeded.
        pending: capabilities still open, so the goal is not settled yet.
    """

    id: str
    statement: str
    kind: str
    capabilities: tuple[str, ...]
    met_by: tuple[int, ...] = ()
    pending: tuple[str, ...] = ()

    @property
    def state(self) -> str:
        """``open``, ``answered`` or ``closed-empty``.

        ``closed-empty`` is a result: every check on this deliverable settled
        without producing evidence, which is how "nothing is there" is reported
        without being confused with "we did not look".
        """
        if self.pending:
            return "open"
        return "answered" if self.met_by else "closed-empty"

    def line(self) -> str:
        if self.state == "answered":
            row = f"  [x] {self.id} {self.statement}"
            if self.met_by:
                row += " (evidence " + ", ".join(str(seq) for seq in self.met_by) + ")"
            return row
        if self.state == "closed-empty":
            return f"  [-] {self.id} {self.statement} (settled, nothing found)"
        return f"  [ ] {self.id} {self.statement} (open: " + ", ".join(self.pending) + ")"

    def describe(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "statement": self.statement,
            "kind": self.kind,
            "capabilities": list(self.capabilities),
            "met_by": list(self.met_by),
            "pending": list(self.pending),
            "state": self.state,
        }


@dataclass(frozen=True)
class Constraint:
    """One limit carried into planning, and where it came from.

    Args:
        code: ``scope``, ``destructive`` or ``operator``.
        rule: the limit itself, in the operator's words where they said it.
        source: where it came from, so a reader can go and check.
    """

    code: str
    rule: str
    source: str

    def line(self) -> str:
        return f"  - {self.rule} ({self.source})"

    def describe(self) -> dict[str, Any]:
        return {"code": self.code, "rule": self.rule, "source": self.source}


def _kind_of(capability: str, check: Check | None = None) -> str:
    """The target kind a capability addresses, as the check or the catalogue says."""
    if check is not None and check.kind:
        return str(check.kind)
    return str(CHECK_CATALOG.get(capability, ("", "host"))[1])


def decompose(state: MissionState) -> tuple[Goal, ...]:
    """Read the mission state as deliverables.

    The grouping is by target kind, because that is the only grouping the state
    actually knows: a host deliverable is answered by any host-kind check, and
    two URL checks are two routes to the same question. Evidence is matched by
    capability through the catalogue, so a run the plan never seeded still
    counts towards the deliverable it speaks to.
    """
    order: list[str] = []
    capabilities: dict[str, list[str]] = {}
    pending: dict[str, list[str]] = {}

    def reach(kind: str) -> None:
        if kind not in capabilities:
            order.append(kind)
            capabilities[kind] = []
            pending[kind] = []

    for check in sorted(state.checks, key=lambda row: (row.priority, row.id)):
        kind = _kind_of(check.capability, check)
        reach(kind)
        if check.capability not in capabilities[kind]:
            capabilities[kind].append(check.capability)
        if check.status == "pending" and check.capability not in pending[kind]:
            pending[kind].append(check.capability)

    answered: dict[str, list[int]] = {}
    for row in state.evidence:
        capability = str(row.capability)
        kind = _kind_of(capability)
        reach(kind)
        if capability not in capabilities[kind]:
            capabilities[kind].append(capability)
        answered.setdefault(kind, []).append(int(row.seq))

    return tuple(
        Goal(
            id=f"g{index}",
            statement=_DELIVERABLE.get(kind, f"what the {kind} exposes"),
            kind=kind,
            capabilities=tuple(capabilities[kind]),
            met_by=tuple(sorted(answered.get(kind, ()))),
            pending=tuple(pending[kind]),
        )
        for index, kind in enumerate(order, start=1)
    )


def _clauses(sentence: str) -> list[str]:
    """Split an operator's sentence into the clauses a limit could live in.

    Split on semicolons, newlines and sentence ends, never on a bare full stop:
    ``127.0.0.1`` is a host, not four sentences, and a limit that lost its
    subject is worse than one quoted with too much around it.
    """
    return [
        part.strip(" ,;:.")
        for part in re.split(r"(?:;\s*|\n+|\.\s+)", sentence)
        if part.strip(" ,;:.")
    ]


def constraints(brief: Any, state: MissionState | None = None) -> tuple[Constraint, ...]:
    """The limits this mission plans under, read before the first step.

    Two kinds, and both are already true when they are read:

    * the structural ones the chain enforces - the anchor, non-destructiveness -
      stated so the model does not have to infer them from a refusal;
    * the operator's own limiting clauses, quoted rather than paraphrased,
      because a paraphrase of "don't touch 3306" is where a limit gets lost.

    Args:
        brief: the reading of the sentence (anything with a ``sentence``).
        state: the mission state, for the anchor it recorded.
    """
    rows: list[Constraint] = []
    target = str(getattr(brief, "target", "") or "") or (
        str(state.target) if state is not None else ""
    )
    if target:
        rows.append(
            Constraint(
                "scope",
                f"steps act on {target} and services, paths or files derived "
                "from it; anything else is reported as a lead, never probed",
                "this surface",
            )
        )
    rows.append(
        Constraint(
            "destructive",
            "nothing is written, uploaded, deleted or persisted on the target",
            "the contract",
        )
    )

    found: list[str] = []
    for clause in _clauses(str(getattr(brief, "sentence", "") or "")):
        if not _LIMIT.search(clause) or len(clause) > _CLAUSE_CHARS:
            continue
        rule = sanitize(clause, 160)
        if rule and rule not in found:
            found.append(rule)
    for rule in found[:MAX_CONSTRAINTS]:
        rows.append(Constraint("operator", rule, "the operator's sentence"))
    return tuple(rows)
