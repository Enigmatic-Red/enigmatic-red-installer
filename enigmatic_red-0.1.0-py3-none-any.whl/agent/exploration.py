"""Intents, an exploration route, and the frontier a mission plans from.

The reference loop most agents ship - plan once, act, observe, replan from the
transcript - has three costs that a longer context does not remove:

* **The planner re-reads everything every turn.** The whole transcript is the
  working set, so the prompt grows with the mission instead of with the
  question, and the model is asked to re-derive facts it already proved.
* **One step is chosen, so the plan has no shape.** A check whose premise has
  failed looks the same as one whose premise is still open, because nothing
  records what produced what.
* **The port between thinking and doing is a counter.** The loop wakes on its
  own step budget, not because something changed, so it either spins on a
  quiet target or stops one step short of a fresh lead.

ARTEX (``Autumn-27/ARTEX``, AGPL-3.0; the upstream repository is no longer
public, so the readable mirror is ``BaaRai/ARTEX``) answers these with four
mechanics. This module is an independent Python implementation of the
bookkeeping half: no ARTEX source is translated, paraphrased or carried here,
and what it reproduces is that project's published design contract, quoted and
attributed as such - *"each time the asset or exploration graph changes
(debounced), it reads the exploration route, queries assets, judges whether the
task goal is met, and emits 0..N exploration intents into the frontier. It is
the sole intent generator."*

1. **An event decides when to plan.** The planner wakes when the graph changed
   (``change``), on a patrol beat when nothing did (``patrol``), and when the
   route has stalled with work left (``stalled``) - see :func:`wake`.
2. **Intents, in a frontier, zero to many per round.** What can run next is a
   set, ordered, not a single next step - see :attr:`Route.frontier`.
3. **Provenance edges.** Which intent enabled which, and which result refuted
   a dependent, is recorded rather than inferred from prose.
4. **Anchors.** Every intent is pinned to the asset its evidence names, so the
   attempt and the fact stay linked.
5. **Goals as deliverables.** :attr:`Route.goals` reads the same rows as
   *deliverables* (what the operator will be able to say afterwards), and
   ``goal-met`` is judged against those rather than against the length of the
   queue - see :mod:`agent.goals`.
6. **An operator steer re-orders, it does not add.** :meth:`Route.ranked` moves
   the intents a mid-mission hint names to the front of the frontier; the plan
   is still the state's, so a hint cannot put a check on it that the evidence
   did not support.

What is deliberately *not* copied:

* **No new authority.** :class:`Route` reads
  :class:`agent.mission_state.MissionState` and nothing else. It cannot add a
  check, widen a target or authorise a step; every step still goes through
  ``Registry.preflight`` and ``Registry.execute``.
* **No new place a fact can live.** Assets, intents and edges are *derived* on
  every read from the persisted checks and evidence rows, exactly as
  :attr:`agent.mission_state.MissionState.assets` is. A resumed mission
  re-derives the same route from the same rows, so ``SCHEMA_VERSION`` does not
  move and a route can never disagree with the chain it came from.
* **No parallel workers.** ARTEX dispatches intents to a worker pool. This
  runtime executes one step at a time through a single audited chain, so the
  frontier is a *priority order for one worker*, not a scheduler. Stated here
  rather than implied, because a frontier invites the assumption.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from agent.goals import Goal, decompose
from agent.mission_state import Check, MissionState, sanitize
from safety.errors import EnigmaticRedError

__all__ = [
    "MAX_FRONTIER",
    "PATROL_EVERY",
    "Edge",
    "ExplorationError",
    "Intent",
    "Route",
    "Wake",
    "situation",
    "wake",
]

#: How many ready intents one round is shown. The frontier is a reading order,
#: not a backlog: a long list reads as autonomy rather than as focus, and the
#: model chooses one function call per turn anyway.
MAX_FRONTIER = 4

#: Wake-ups without a concrete change before a patrol round is due. ARTEX
#: debounces its graph events the same way; here the beat is a counter the
#: caller advances, because nothing in this module may spend a model call.
PATROL_EVERY = 3

#: A check's status, said as an intent's status. ``refused`` is a *failure* to
#: act, not a result, and it is kept distinct from ``skipped`` so a report can
#: tell "we decided not to" from "we were not allowed to".
_STATUS = {
    "pending": "open",
    "done": "done",
    "skipped": "skipped",
    "refused": "failed",
}

#: Edges that describe what actually happened. A dependency that is neither
#: satisfied nor settled produces no edge, because "unknown" is not a fact.
_SETTLED = frozenset({"done", "failed", "skipped"})


class ExplorationError(EnigmaticRedError):
    """A route was asked for something the mission state cannot answer."""


@dataclass(frozen=True)
class Edge:
    """One arrow in the route: what produced, enabled or refuted what.

    Args:
        source: the intent id the arrow starts at.
        target: an intent id, or ``asset:<key>`` for an anchor.
        relation: ``produced`` (intent wrote a fact), ``enabled`` (prerequisite
            satisfied) or ``refuted`` (prerequisite settled without evidence).
    """

    source: str
    target: str
    relation: str

    def line(self) -> str:
        return f"  {self.source} -{self.relation}-> {self.target}"

    def describe(self) -> dict[str, Any]:
        return {
            "source": self.source,
            "target": self.target,
            "relation": self.relation,
        }


@dataclass(frozen=True)
class Intent:
    """One bounded question, and what the chain says about it so far.

    This is a *reading* of a :class:`agent.mission_state.Check` plus the
    evidence rows that name its capability. It is frozen and rebuilt on every
    read, so a stale intent cannot outlive the evidence it describes.

    Args:
        id: the check id it reads, so citations line up with the state file.
        capability: the registered function the intent would call.
        why: the question it answers, in the operator's words.
        kind: the target kind the capability addresses.
        status: ``open``, ``done``, ``skipped`` or ``failed``.
        priority: lower runs first; the seeded order unless the model added it.
        needs: capabilities that must produce evidence first.
        origin: ``plan`` when seeded, ``model`` when chosen mid-mission.
        evidence: audit sequence numbers this intent produced.
        anchor: the asset its evidence names, or the mission target.
        blocked: why it cannot run yet, or ``""`` when it can.
    """

    id: str
    capability: str
    why: str
    kind: str
    status: str = "open"
    priority: int = 50
    needs: tuple[str, ...] = ()
    origin: str = "plan"
    evidence: tuple[int, ...] = ()
    anchor: str = ""
    blocked: str = ""

    @property
    def settled(self) -> bool:
        return self.status in _SETTLED

    def line(self) -> str:
        marker = {
            "done": "[x]",
            "skipped": "[-]",
            "failed": "[!]",
            "open": "[ ]",
        }.get(self.status, "[ ]")
        row = f"  {marker} {self.id} {self.capability} - {sanitize(self.why, 160)}"
        if self.evidence:
            row += " (evidence " + ", ".join(str(seq) for seq in self.evidence) + ")"
        elif self.blocked:
            row += f" ({self.blocked})"
        if self.anchor:
            row += f" @ {self.anchor}"
        return row

    def describe(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "capability": self.capability,
            "why": sanitize(self.why, 400),
            "kind": self.kind,
            "status": self.status,
            "priority": self.priority,
            "needs": list(self.needs),
            "origin": self.origin,
            "evidence": list(self.evidence),
            "anchor": self.anchor,
            "blocked": self.blocked,
        }


@dataclass(frozen=True)
class Wake:
    """Why the planner was woken, and what was put in front of it.

    Args:
        kind: ``change``, ``patrol``, ``stalled``, ``goal-met`` or ``idle``.
        reason: one sentence an operator can read in the audit log.
        lead: the opening line of the round, as ARTEX phrases it - it tells the
            model whether the graph actually changed, so a patrol round does
            not claim a change that did not happen.
        frontier: the ready intents, capped and ordered.
    """

    kind: str
    reason: str = ""
    lead: str = ""
    frontier: tuple[Intent, ...] = field(default_factory=tuple)

    def describe(self) -> dict[str, Any]:
        return {
            "kind": self.kind,
            "reason": self.reason,
            "frontier": [intent.id for intent in self.frontier],
        }


def _last_seq(state: MissionState) -> int:
    return max((int(row.seq or 0) for row in state.evidence), default=0)


#: A word an operator's steer has to be at least this long to be matched against
#: a capability or a question: "tls" and "api" are signals, "a" and "it" are not.
_MIN_WORD = 3

#: Words that appear in almost every question, so matching on them would make
#: every intent equally named and a steer would re-order nothing.
_STOPWORDS = frozenset(
    {
        "the",
        "and",
        "for",
        "with",
        "that",
        "this",
        "from",
        "into",
        "your",
        "you",
        "are",
        "was",
        "has",
        "have",
        "not",
        "but",
        "can",
        "all",
        "any",
        "most",
        "more",
        "than",
        "then",
        "them",
        "they",
        "what",
        "when",
        "which",
        "how",
        "why",
        "who",
        "its",
        "also",
        "just",
        "now",
    }
)


def _words(text: str) -> frozenset[str]:
    """The words a steer is matched on, lowercased, bounded and de-stopworded."""
    return frozenset(
        word
        for word in re.findall(r"[a-z0-9][a-z0-9_-]*", text.lower())
        if len(word) >= _MIN_WORD and word not in _STOPWORDS
    )


def _names(intent: Intent, words: frozenset[str]) -> bool:
    """Whether a steer names this intent, by its capability or its question."""
    if not words:
        return False
    return intent.capability.lower() in words or bool(words & _words(intent.why))


class Route:
    """One mission's intents, provenance edges and anchors, derived on read."""

    def __init__(self, state: MissionState) -> None:
        self.state = state
        self.intents: tuple[Intent, ...] = tuple(
            self._intent(check) for check in state.checks
        )
        by_id = {intent.id: intent for intent in self.intents}
        self.edges: tuple[Edge, ...] = tuple(self._edges(by_id))
        # The deliverables the intents serve, derived the same way and from the
        # same rows - see :mod:`agent.goals`. Kept separate from the intents
        # because a deliverable can be answered by a run the plan never seeded.
        self.goals: tuple[Goal, ...] = decompose(state)

    # --------------------------------------------------------------- building
    def _intent(self, check: Check) -> Intent:
        evidence = tuple(
            int(row.seq)
            for row in self.state.evidence
            if row.capability == check.capability
        )
        status = _STATUS.get(check.status, "open")
        return Intent(
            id=check.id,
            capability=check.capability,
            why=check.why,
            kind=check.kind,
            status=status,
            priority=check.priority,
            needs=tuple(check.needs),
            origin=check.origin,
            evidence=evidence,
            anchor=self._anchor(check),
            blocked=self.state.blocked_reason(check) if status == "open" else "",
        )

    def _anchor(self, check: Check) -> str:
        """The asset this intent is pinned to: what its evidence named.

        An intent that has not produced evidence is pinned to the mission
        target, which is the only asset the operator actually named. Nothing
        here derives a *new* target - that would be a second reach.
        """
        for row in reversed(list(self.state.evidence)):
            if row.capability == check.capability and row.target:
                return str(row.target)
        return str(self.state.target or "")

    def _edges(self, by_id: dict[str, Intent]) -> list[Edge]:
        """Provenance, only for dependencies the chain has settled."""
        edges: list[Edge] = []
        for intent in self.intents:
            if intent.status == "done" and intent.evidence and intent.anchor:
                edges.append(Edge(intent.id, f"asset:{intent.anchor}", "produced"))
            for need in intent.needs:
                if need == "web":
                    # A condition, not an intent: satisfied by observing HTTP.
                    if self.state.web_observed:
                        edges.append(Edge(intent.id, "condition:web", "enabled"))
                    continue
                prerequisite = self.state.check_for(need)
                if prerequisite is None or prerequisite.id not in by_id:
                    continue
                source = by_id[prerequisite.id]
                if source.status == "done" and source.evidence:
                    edges.append(Edge(source.id, intent.id, "enabled"))
                elif source.settled:
                    edges.append(Edge(source.id, intent.id, "refuted"))
        return edges

    # ---------------------------------------------------------------- reading
    @property
    def last_seq(self) -> int:
        """The highest audit sequence this route has read. The wake high-water mark."""
        return _last_seq(self.state)

    @property
    def frontier(self) -> tuple[Intent, ...]:
        """Every open intent the evidence supports, in the order to try them.

        This is the one behaviour a single ``select()`` cannot express: the
        model is shown the *set* that is ready, and may pick any of them, so a
        refusal or a dead end on the first does not end the round.
        """
        return self.ranked()

    def ranked(self, hint: str = "") -> tuple[Intent, ...]:
        """The frontier, with anything the operator's steer names moved first.

        A mid-mission steer does not add an intent - it cannot, because the plan
        is still the state's - it re-orders the ones already supported. Matching
        is by capability name or by a word of the question the intent answers,
        so "look at the tls setup" puts ``posture`` first without inventing a
        check for it.
        """
        ready = [
            intent
            for intent in self.intents
            if intent.status == "open" and not intent.blocked
        ]
        words = _words(hint)
        ready.sort(
            key=lambda intent: (
                0 if _names(intent, words) else 1,
                intent.priority,
                intent.id,
            )
        )
        return tuple(ready[:MAX_FRONTIER])

    @property
    def blocked(self) -> tuple[Intent, ...]:
        """Open intents that cannot run, each carrying the reason why."""
        return tuple(
            intent
            for intent in self.intents
            if intent.status == "open" and intent.blocked
        )

    @property
    def open_intents(self) -> tuple[Intent, ...]:
        return tuple(intent for intent in self.intents if intent.status == "open")

    @property
    def goal_met(self) -> bool:
        """Whether the mission's deliverables are answered.

        A *coverage* test over the goals, not a severity judgement: every
        deliverable has settled, and at least one of them is answered by
        evidence rather than settled empty. Whether what was found matters is
        the report's job, not this one's.

        Judged against :attr:`goals` rather than against the intent list, so
        evidence a run produced outside the seeded plan still counts - the
        question "do we know what the web surface exposes" does not care which
        capability answered it.
        """
        return (
            bool(self.goals)
            and all(goal.state != "open" for goal in self.goals)
            and any(goal.state == "answered" for goal in self.goals)
        )

    def describe(self) -> dict[str, Any]:
        return {
            "mission_id": self.state.mission_id,
            "target": self.state.target,
            "goal_met": self.goal_met,
            "goals": [goal.describe() for goal in self.goals],
            "intents": [intent.describe() for intent in self.intents],
            "edges": [edge.describe() for edge in self.edges],
            "frontier": [intent.id for intent in self.frontier],
            "last_seq": self.last_seq,
        }


def wake(
    route: Route,
    *,
    last_seq: int = 0,
    since_patrol: int = PATROL_EVERY,
    hint: str = "",
) -> Wake:
    """Decide whether - and why - the planner should run a round now.

    This is the event port. The caller owns the counters (``last_seq`` is the
    highest audit sequence already planned against, ``since_patrol`` the number
    of wake-ups since the last patrol); nothing here spends a model call or
    advances state, so it is safe to ask before every round.

    Args:
        route: the mission's route, as :class:`Route` derives it.
        last_seq: the highest audit sequence already planned against.
        since_patrol: wake-ups since the last patrol round.
        hint: the operator's latest mid-mission steer, if any. It re-orders the
            frontier (see :meth:`Route.ranked`) and never adds an intent.

    Returns:
        A :class:`Wake` whose ``kind`` is ``goal-met``, ``change``,
        ``patrol``, ``stalled`` or ``idle``.
    """
    newest = route.last_seq
    frontier = route.ranked(hint)
    if route.goal_met:
        return Wake(
            kind="goal-met",
            reason="every deliverable settled and evidence answers at least one",
            lead=(
                "Every deliverable on the route has settled and the evidence "
                "answers it. Stop exploring: call finish and cite the audit run "
                "id for each claim; a claim with no run id is delivered as a lead."
            ),
        )
    if newest > last_seq:
        return Wake(
            kind="change",
            reason=f"evidence {last_seq + 1}..{newest} arrived",
            lead=(
                "There were concrete changes just now (see the evidence rows "
                "below); plan the next steps accordingly:"
            ),
            frontier=frontier,
        )
    if frontier and since_patrol >= PATROL_EVERY:
        return Wake(
            kind="patrol",
            reason="scheduled patrol; no concrete change signal",
            lead=(
                "This round is a scheduled patrol, so the graph may have "
                "nothing new. Review the open intents in passing and add a "
                "direction only if the route is drifting:"
            ),
            frontier=frontier,
        )
    if frontier:
        return Wake(
            kind="idle",
            reason="no change since the last round; the frontier is unchanged",
            lead="Nothing changed since the last round; the frontier is unchanged.",
            frontier=frontier,
        )
    blocked = route.blocked
    if blocked:
        return Wake(
            kind="stalled",
            reason=(
                "no open intent is supported by the evidence: "
                + "; ".join(
                    f"{intent.capability} ({intent.blocked})" for intent in blocked
                )
            ),
            lead=(
                "Exploration has stalled: every open intent is waiting on "
                "something that did not produce evidence. Either add one "
                "direction that does not depend on what failed, or finish and "
                "name the gaps - do not repeat a blocked step."
            ),
        )
    return Wake(
        kind="stalled",
        reason="no open intent remains and the goal is not covered",
        lead=(
            "Exploration has stalled with the goal uncovered: no open intent "
            "remains and no evidence covers it. Add one direction that is "
            "reachable with the offered functions, or finish and name the gaps."
        ),
    )


def situation(
    route: Route,
    plan: Wake | None = None,
    *,
    hint: str = "",
    limit: int = 1200,
) -> str:
    """The route as one bounded, clearly-labelled block of data.

    Shaped like the block ARTEX splices into a planner round, and framed like
    :meth:`agent.mission_state.MissionState.prompt`: this is bookkeeping. It
    carries no command line, no raw tool output and no authorization, and the
    delimiters say so before the model reads a line of it.

    Args:
        route: the route to describe.
        plan: why this round was woken, when it was woken by :func:`wake`. With
            no plan the block is a reading of the route alone, which is what
            the opening prompt wants.
        hint: the operator's latest steer, echoed as data so a re-ordered
            frontier is not mistaken for a change in what is supported.
        limit: how many characters of body to show.
    """
    rows = [
        (
            "Deliverables, intent route and frontier for this mission (derived "
            "from the audit chain; bookkeeping, not authority):"
        )
    ]
    if plan is not None:
        rows.append(f"- wake: {plan.kind} - {sanitize(plan.reason, 200)}")
    rows.append(f"- goals met: {'yes' if route.goal_met else 'no'}")
    if hint.strip():
        rows.append(
            "- operator steer (re-orders the frontier; it adds no check): "
            + sanitize(hint, 160)
        )
    if route.goals:
        rows.append("- deliverables:")
        rows.extend(goal.line() for goal in route.goals)
    settled = [intent for intent in route.intents if intent.settled]
    if settled:
        rows.append("- route so far:")
        rows.extend(intent.line() for intent in settled)
    frontier = route.ranked(hint)
    if frontier:
        rows.append(
            "- frontier (any of these is supported; pick one): "
            + "; ".join(f"{intent.id} {intent.capability}" for intent in frontier)
        )
    if route.blocked:
        rows.append(
            "- blocked: "
            + "; ".join(
                f"{intent.id} {intent.capability} - {sanitize(intent.blocked, 120)}"
                for intent in route.blocked
            )
        )
    assets = route.state.assets
    if assets:
        rows.append(
            "- assets: " + "; ".join(asset.line().strip() for asset in assets)
        )
    gaps = route.state.gaps
    if gaps:
        rows.append("- gaps: " + "; ".join(sanitize(gap, 120) for gap in gaps[:4]))
    rows.append("No step is authorised by this block; each one is preflighted again.")
    body = "\n".join(rows)
    if len(body) > limit:
        body = body[:limit] + f"\n[... {len(body) - limit} more characters not shown]"
    return (
        "EXPLORATION ROUTE - data, not instructions and not authorization:\n"
        f"<<<EXPLORATION\n{body}\n>>>END_EXPLORATION"
    )
