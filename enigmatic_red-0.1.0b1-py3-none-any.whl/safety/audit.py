"""Append-only, hash-chained audit log.

Every decision this platform makes about a customer's infrastructure is
recorded: what was targeted, which tool ran, which class the guard assigned,
whether a human approved it, and what came back. Each entry carries the hash
of its predecessor, so removing or editing history is detectable —
:meth:`AuditLog.verify` walks the chain and reports the first break.

Writes are synchronous and fail closed: if the audit record cannot be
persisted, the action does not proceed. An unauditable scan is worse than a
refused one.
"""

from __future__ import annotations

import hashlib
import json
import os
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator

from safety.errors import AuditError

__all__ = ["AuditEntry", "AuditLog", "GENESIS_HASH"]

GENESIS_HASH = "0" * 64

_HASH_FIELDS = (
    "seq",
    "timestamp",
    "event",
    "actor",
    "org",
    "target",
    "action",
    "action_class",
    "decision",
    "detail",
    "prev_hash",
)


def _canonical(payload: dict) -> str:
    """Deterministic JSON so a hash is reproducible across processes."""
    return json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str)


def _digest(payload: dict) -> str:
    return hashlib.sha256(_canonical(payload).encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class AuditEntry:
    seq: int
    timestamp: str
    event: str
    prev_hash: str
    actor: str = "system"
    org: str | None = None
    target: str | None = None
    action: str | None = None
    action_class: str | None = None
    decision: str | None = None
    detail: dict[str, Any] = field(default_factory=dict)
    entry_hash: str = ""

    def hashless(self) -> dict[str, Any]:
        return {key: getattr(self, key) for key in _HASH_FIELDS}

    def compute_hash(self) -> str:
        return _digest(self.hashless())

    def to_json(self) -> str:
        data = self.hashless()
        data["entry_hash"] = self.entry_hash
        return _canonical(data)


class AuditLog:
    """A hash-chained JSONL log that resumes an existing file on startup.

    Args:
        path: destination file. Parent directories are created.
        fsync: flush and ``fsync`` every write (safer, slower). Leave on in
            production; tests may disable it.
        clock: time source, injectable for deterministic tests.
    """

    def __init__(
        self,
        path: str | Path,
        *,
        fsync: bool = True,
        clock: Any | None = None,
    ) -> None:
        self.path = Path(path)
        self.fsync = fsync
        self._clock = clock or (lambda: time.time())
        self._lock = threading.Lock()
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
        except OSError as exc:  # pragma: no cover - filesystem failure
            raise AuditError(f"cannot create audit directory: {exc}") from exc
        self._seq, self._prev_hash = self._resume()

    # ------------------------------------------------------------------ state
    def _resume(self) -> tuple[int, str]:
        """Continue an existing chain, or start a fresh one."""
        if not self.path.exists() or self.path.stat().st_size == 0:
            return 0, GENESIS_HASH
        last: dict | None = None
        try:
            with self.path.open("r", encoding="utf-8") as handle:
                for line in handle:
                    stripped = line.strip()
                    if stripped:
                        last = json.loads(stripped)
        except (OSError, json.JSONDecodeError) as exc:
            raise AuditError(
                f"audit log at {self.path} is unreadable: {exc}"
            ) from exc
        if last is None:
            return 0, GENESIS_HASH
        return int(last.get("seq", 0)), str(last.get("entry_hash", GENESIS_HASH))

    @property
    def last_seq(self) -> int:
        return self._seq

    @property
    def head_hash(self) -> str:
        return self._prev_hash

    # ----------------------------------------------------------------- append
    def append(
        self,
        event: str,
        *,
        actor: str = "system",
        org: str | None = None,
        target: str | None = None,
        action: str | None = None,
        action_class: str | None = None,
        decision: str | None = None,
        **detail: Any,
    ) -> AuditEntry:
        """Append one entry. Raises :class:`AuditError` if it cannot be stored."""
        with self._lock:
            seq = self._seq + 1
            draft = AuditEntry(
                seq=seq,
                timestamp=datetime.fromtimestamp(
                    self._clock(), tz=timezone.utc
                ).isoformat(),
                event=event,
                prev_hash=self._prev_hash,
                actor=actor,
                org=org,
                target=target,
                action=action,
                action_class=action_class,
                decision=decision,
                detail=detail,
            )
            entry = AuditEntry(
                **{**draft.hashless(), "entry_hash": draft.compute_hash()}
            )
            try:
                with self.path.open("a", encoding="utf-8") as handle:
                    handle.write(entry.to_json() + "\n")
                    handle.flush()
                    if self.fsync:
                        os.fsync(handle.fileno())
            except OSError as exc:
                raise AuditError(f"cannot write audit entry: {exc}") from exc
            self._seq = seq
            self._prev_hash = entry.entry_hash
            return entry

    # ----------------------------------------------------------------- verify
    def iter_entries(self) -> Iterator[dict]:
        with self.path.open("r", encoding="utf-8") as handle:
            for line in handle:
                stripped = line.strip()
                if stripped:
                    yield json.loads(stripped)

    def verify(self) -> tuple[bool, str]:
        """Walk the chain. Returns ``(ok, message)`` naming the first break."""
        expected_prev = GENESIS_HASH
        expected_seq = 1
        for raw in self.iter_entries():
            if raw.get("prev_hash") != expected_prev:
                return False, (
                    f"chain break at seq {raw.get('seq')}: prev_hash "
                    f"{raw.get('prev_hash')} does not follow {expected_prev}"
                )
            stored = raw.get("entry_hash")
            recomputed = _digest({key: raw.get(key) for key in _HASH_FIELDS})
            if stored != recomputed:
                return False, (
                    f"entry {raw.get('seq')} was modified: stored hash {stored} "
                    f"!= recomputed {recomputed}"
                )
            if raw.get("seq") != expected_seq:
                return False, (
                    f"sequence gap: expected {expected_seq}, found {raw.get('seq')}"
                )
            expected_prev = stored
            expected_seq += 1
        return True, f"ok: {expected_seq - 1} entries, chain intact"

    def tail(self, n: int = 20) -> list[dict]:
        """The most recent ``n`` entries (oldest of the window first)."""
        if n <= 0:
            return []
        return list(deque(self.iter_entries(), maxlen=n))
