"""Programmatic scope enforcement.

This module is the authority on whether a target may be touched. It is
deliberately independent of the LLM: nothing the model emits can widen scope,
because every adapter must obtain a :class:`ScopeDecision` immediately before
execution (and the sandbox egress proxy repeats the check at the network
layer, as a backstop the model cannot talk past).

Two rules are non-configurable, on purpose:

1. Cloud metadata endpoints (``169.254.169.254`` and friends) are **always**
   denied. They are the highest-value SSRF target on any cloud host and their
   exposure would leak the platform's own credentials, not the tenant's.
2. **Deny always beats allow.**

Hostname matching is exact unless a wildcard entry is used:

* ``api.example.com``  matches only ``api.example.com``
* ``*.example.com``    matches ``a.example.com`` and ``a.b.example.com``,
  but **not** the apex ``example.com``

When a hostname is scoped and CIDRs are supplied, *every* address the name
resolves to must fall inside an allowed CIDR. Requiring all addresses (rather
than any) closes split-horizon / DNS-rebinding bypasses where an attacker
returns one in-scope and one out-of-scope answer.

Three kinds of target are not network endpoints, and none of them is resolved
or connected to *here* - this module only decides whether the name is on the
list:

* ``s3://bucket``          a storage bucket, matched by bare name;
* ``github.com/owner/name`` a source repository, matched as
  ``host/owner/name`` against ``allow_repositories``;
* ``hf://owner/name``      a model on a hub, matched as ``owner/name`` against
  ``allow_models``. A bare ``owner/name`` is read as a model id too, but only
  by a scope that names models at all - otherwise it is a path, and refused.

A wildcard there is a trailing ``owner/*`` and never a bare ``*``. A
repository or a model has no address, so neither can be checked against a
CIDR: they are authorized by their own list or not at all.
"""

from __future__ import annotations

import ipaddress
import re
import socket
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Callable, Iterable, Sequence
from urllib.parse import urlsplit

import yaml

__all__ = ["ResolvedTarget", "Scope", "ScopeDecision", "TargetKind"]

Resolver = Callable[[str], Sequence[str]]

#: Networks that may never be targeted, under any configuration.
_ALWAYS_DENY_NETS: tuple[ipaddress.IPv4Network | ipaddress.IPv6Network, ...] = (
    ipaddress.ip_network("169.254.0.0/16"),   # AWS/GCP/Azure/OpenStack metadata
    ipaddress.ip_network("100.100.100.200/32"),  # Alibaba Cloud metadata
    ipaddress.ip_network("192.0.0.192/32"),   # Oracle Cloud metadata
    ipaddress.ip_network("fd00:ec2::254/128"),  # AWS IPv6 metadata
    ipaddress.ip_network("fe80::/10"),        # link-local v6 (metadata path)
)

#: Hostnames that may never be targeted, under any configuration.
_ALWAYS_DENY_HOSTS: frozenset[str] = frozenset(
    {
        "metadata.google.internal",
        "metadata.goog",
        "metadata",
        "instance-data",
    }
)

#: Loopback, allowed only when the scope explicitly opts in.
_LOOPBACK_NETS: tuple[ipaddress.IPv4Network | ipaddress.IPv6Network, ...] = (
    ipaddress.ip_network("127.0.0.0/8"),
    ipaddress.ip_network("::1/128"),
)

#: Implied port per scheme, so ``https://host/`` is checked as port 443.
_DEFAULT_PORTS: dict[str, int] = {"http": 80, "https": 443}

#: Schemes that name a repository or a hub model rather than a network service.
_REPO_SCHEMES: frozenset[str] = frozenset({"repo", "git"})
_MODEL_SCHEMES: frozenset[str] = frozenset({"hf", "model", "models"})

#: Code hosts a repository target may name. A repository is never resolved and
#: never connected to by this module; the host is one of these strings or the
#: target is not a repository at all.
_REPO_HOSTS: frozenset[str] = frozenset(
    {"github.com", "gitlab.com", "codeberg.org", "bitbucket.org"}
)

#: One path segment of an owner or a repository name, as the hosts allow them.
_SEGMENT = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]*$")

#: ``huggingface.co/owner/name``. A bare ``owner/name`` is only read as a model
#: when the target says so with a scheme, because it is indistinguishable from a
#: path - and ``10.0.0.0/24`` would otherwise match.
_HUB_HOST = "huggingface.co"


class TargetKind(str, Enum):
    IP = "ip"
    CIDR = "cidr"
    HOSTNAME = "hostname"
    URL = "url"
    BUCKET = "bucket"
    REPOSITORY = "repository"
    MODEL = "model"


def _default_resolver(host: str) -> tuple[str, ...]:
    """Resolve a hostname to its distinct addresses using the system resolver."""
    seen: list[str] = []
    for info in socket.getaddrinfo(host, None, proto=socket.IPPROTO_TCP):
        addr = info[4][0]
        if addr not in seen:
            seen.append(addr)
    return tuple(seen)


def _normalize_ip(text: str) -> ipaddress.IPv4Address | ipaddress.IPv6Address:
    """Parse an address and unmap ``::ffff:x.x.x.x`` so metadata checks hold."""
    ip = ipaddress.ip_address(text.strip().strip("[]"))
    if isinstance(ip, ipaddress.IPv6Address) and ip.ipv4_mapped is not None:
        return ip.ipv4_mapped
    return ip


def _in_nets(ip: ipaddress._BaseAddress, nets: Iterable[ipaddress._BaseNetwork]) -> bool:
    return any(ip in net for net in nets)


def _segments(body: str) -> list[str]:
    """Path segments, with a trailing ``.git`` dropped and empties removed."""
    parts = [part for part in body.strip().strip("/").split("/") if part]
    if parts and parts[-1].endswith(".git"):
        parts[-1] = parts[-1][: -len(".git")]
        if not parts[-1]:
            parts.pop()
    return parts


def _asset_kind(
    body: str, *, allow_bare: bool = False
) -> tuple[TargetKind, str] | None:
    """Classify a scheme-stripped target as a repository or a hub model.

    ``None`` means "neither" - the caller falls through to the network kinds
    rather than guessing. A wildcard is never accepted here: ``owner/*`` is
    something a *scope entry* may say, never a target.

    Args:
        body: the target with any scheme removed, e.g. ``github.com/acme/app``.
        allow_bare: read a two-segment ``owner/name`` as a model id. Only set
            when the target carried a model scheme (``hf://owner/name``),
            because a bare ``owner/name`` is otherwise indistinguishable from a
            path - and ``10.0.0.0/24`` matches the same shape.
    """
    parts = _segments(body)
    if len(parts) == 3 and parts[0].lower() == _HUB_HOST:
        # The host has already said this is a model, so the two segments that
        # remain are an owner and a name and nothing else could be meant.
        parts = parts[1:]
        allow_bare = True
    elif len(parts) == 3 and parts[0].lower() in _REPO_HOSTS:
        if not (_SEGMENT.match(parts[1]) and _SEGMENT.match(parts[2])):
            return None
        return TargetKind.REPOSITORY, f"{parts[0].lower()}/{parts[1]}/{parts[2]}"
    if len(parts) != 2 or not allow_bare:
        return None
    if not all(_SEGMENT.match(part) for part in parts):
        return None
    return TargetKind.MODEL, f"{parts[0]}/{parts[1]}"


def _slash_target(host: str, *, allow_bare: bool = False) -> tuple[TargetKind, str]:
    """A target containing ``/``: a CIDR, a repository, or a hub model.

    Raises :class:`ValueError` when it is none of the three, so
    ``example.com/path`` is refused with a sentence instead of becoming a CIDR
    that fails later, during a check.

    Args:
        allow_bare: read a two-segment ``owner/name`` as a model id. The Scope
            sets this only when it names models at all, because a bare
            ``owner/name`` is otherwise indistinguishable from a path - and
            ``10.0.0.0/24`` has the same shape, which is why the network check
            comes first either way.
    """
    try:
        ipaddress.ip_network(host, strict=False)
    except ValueError:
        pass
    else:
        return TargetKind.CIDR, host
    found = _asset_kind(host, allow_bare=allow_bare)
    if found is not None:
        return found
    raise ValueError(
        f"{host!r} is neither a CIDR nor a repository on a known code host or a "
        f"hub model id. Name one as github.com/owner/name or hf://owner/name"
    )


@dataclass(frozen=True)
class ResolvedTarget:
    """A normalized view of whatever the operator or model handed us."""

    raw: str
    kind: TargetKind
    host: str
    port: int | None = None
    scheme: str | None = None
    ips: tuple[str, ...] = ()

    @property
    def display(self) -> str:
        return f"{self.host}:{self.port}" if self.port else self.host


@dataclass(frozen=True)
class ScopeDecision:
    """The verdict. Truthiness mirrors ``allowed`` for convenient branching."""

    allowed: bool
    reason: str
    target: ResolvedTarget | None = None
    matched_rule: str | None = None

    def __bool__(self) -> bool:  # pragma: no cover - trivial
        return self.allowed

    @classmethod
    def deny(
        cls,
        reason: str,
        target: ResolvedTarget | None = None,
        matched_rule: str | None = None,
    ) -> "ScopeDecision":
        return cls(False, reason, target, matched_rule)

    @classmethod
    def allow(
        cls,
        reason: str,
        target: ResolvedTarget,
        matched_rule: str,
    ) -> "ScopeDecision":
        return cls(True, reason, target, matched_rule)


class Scope:
    """An allowlist/denylist pair with hard-coded metadata protections.

    Args:
        allow_hosts: exact hostnames and ``*.wildcard`` entries.
        allow_cidrs: IPv4/IPv6 CIDRs considered in-scope.
        allow_ports: if set, only these TCP ports may be touched.
        deny_hosts: hostnames refused even if also allowed (deny wins).
        deny_cidrs: networks refused even if also allowed (deny wins).
        allow_buckets: object-storage bucket names in scope (S3/GCS/Azure).
        allow_repositories: code repositories in scope, as
            ``github.com/owner/name``. A trailing ``owner/*`` covers every
            repository that owner has, and is the only wildcard accepted.
        allow_models: hub models in scope, as ``owner/name``.
        deny_repositories: repositories refused even if also allowed.
        deny_models: models refused even if also allowed.
        allow_loopback: opt in to 127.0.0.0/8 and ::1 (local testing).
        resolve_hostnames: resolve names to IPs so CIDR rules can apply.
        resolver: injectable name resolver (tests use this to stay offline).
        strict_ip_when_cidrs_present: when ``allow_cidrs`` is non-empty,
            require that *every* resolved address also falls inside it.
            Recommended ``True`` for multi-tenant deployments.
    """

    def __init__(
        self,
        *,
        allow_hosts: Iterable[str] = (),
        allow_cidrs: Iterable[str] = (),
        allow_ports: Iterable[int | str] | None = None,
        deny_hosts: Iterable[str] = (),
        deny_cidrs: Iterable[str] = (),
        allow_buckets: Iterable[str] = (),
        allow_repositories: Iterable[str] = (),
        allow_models: Iterable[str] = (),
        deny_repositories: Iterable[str] = (),
        deny_models: Iterable[str] = (),
        allow_loopback: bool = False,
        resolve_hostnames: bool = True,
        resolver: Resolver | None = None,
        strict_ip_when_cidrs_present: bool = True,
        label: str = "scope",
    ) -> None:
        self.label = label
        self.allow_hosts = self._clean_hosts(allow_hosts)
        self.deny_hosts = self._clean_hosts(deny_hosts)
        self.allow_cidrs = self._clean_nets(allow_cidrs)
        self.deny_cidrs = self._clean_nets(deny_cidrs)
        self.allow_buckets = frozenset(
            b.strip().lower() for b in allow_buckets if b and b.strip()
        )
        self.allow_repositories = self._clean_assets(
            allow_repositories, where="allow_repositories"
        )
        self.deny_repositories = self._clean_assets(
            deny_repositories, where="deny_repositories"
        )
        self.allow_models = self._clean_assets(allow_models, where="allow_models")
        self.deny_models = self._clean_assets(deny_models, where="deny_models")
        self.allow_ports = (
            None
            if not allow_ports
            else frozenset(int(p) for p in allow_ports if str(p).strip() != "")
        )
        self.allow_loopback = allow_loopback
        self.resolve_hostnames = resolve_hostnames
        self.strict_ip_when_cidrs_present = strict_ip_when_cidrs_present
        self._resolve: Resolver = resolver or _default_resolver

    # ------------------------------------------------------------------ build
    @staticmethod
    def _clean_assets(values: Iterable[str], *, where: str) -> frozenset[str]:
        """Normalize ``owner/name`` and ``host/owner/name`` scope entries.

        A wildcard is accepted only as the *last* segment (``acme/*``). A bare
        ``*`` or ``*/*`` is refused, for the same reason ``_clean_hosts``
        refuses ``*``: it would authorize every repository half the internet
        holds, and a scope is a list of things you can name.
        """
        out: set[str] = set()
        for raw in values:
            if raw is None or not str(raw).strip():
                continue
            text = str(raw).strip().strip("/").lower()
            parts = _segments(text)
            star = [index for index, part in enumerate(parts) if part == "*"]
            named = parts[:-1] if star else parts
            if (
                len(parts) not in (2, 3)
                or len(star) > 1
                or (star and star != [len(parts) - 1])
                or not all(_SEGMENT.match(part) for part in named)
                or (len(parts) == 3 and parts[0] not in _REPO_HOSTS)
            ):
                raise ValueError(
                    f"{where} entry {raw!r} must be 'owner/name', 'owner/*', "
                    f"'github.com/owner/name' or 'github.com/owner/*'"
                )
            out.add("/".join(parts))
        return frozenset(out)

    @staticmethod
    def _clean_hosts(values: Iterable[str]) -> frozenset[str]:
        out: set[str] = set()
        for raw in values:
            if not raw or not str(raw).strip():
                continue
            host = str(raw).strip().lower().rstrip(".")
            if host == "*":
                raise ValueError(
                    "bare '*' is not a valid scope entry: it would authorize "
                    "the entire internet. Use explicit hostnames or CIDRs."
                )
            out.add(host)
        return frozenset(out)

    @staticmethod
    def _clean_nets(values: Iterable[str]) -> tuple[ipaddress._BaseNetwork, ...]:
        nets: list[ipaddress._BaseNetwork] = []
        for raw in values:
            if not raw or not str(raw).strip():
                continue
            nets.append(ipaddress.ip_network(str(raw).strip(), strict=False))
        return tuple(nets)

    @classmethod
    def from_dict(cls, data: dict | None, *, label: str = "scope") -> "Scope":
        data = data or {}
        return cls(
            allow_hosts=data.get("allow_hosts", ()),
            allow_cidrs=data.get("allow_cidrs", ()),
            allow_ports=data.get("allow_ports") or None,
            deny_hosts=data.get("deny_hosts", ()),
            deny_cidrs=data.get("deny_cidrs", ()),
            allow_buckets=data.get("allow_buckets", ()),
            allow_repositories=data.get("allow_repositories", ()),
            allow_models=data.get("allow_models", ()),
            deny_repositories=data.get("deny_repositories", ()),
            deny_models=data.get("deny_models", ()),
            allow_loopback=bool(data.get("allow_loopback", False)),
            resolve_hostnames=bool(data.get("resolve_hostnames", True)),
            strict_ip_when_cidrs_present=bool(
                data.get("strict_ip_when_cidrs_present", True)
            ),
            label=data.get("label", label),
        )

    @classmethod
    def from_yaml(cls, path: str | Path) -> "Scope":
        path = Path(path)
        with path.open("r", encoding="utf-8") as handle:
            data = yaml.safe_load(handle) or {}
        return cls.from_dict(data, label=path.stem)

    @property
    def is_empty(self) -> bool:
        """An empty scope authorizes nothing. This is the safe default."""
        return not (
            self.allow_hosts
            or self.allow_cidrs
            or self.allow_buckets
            or self.allow_repositories
            or self.allow_models
            or self.allow_loopback
        )

    def describe(self) -> dict:
        return {
            "label": self.label,
            "allow_hosts": sorted(self.allow_hosts),
            "allow_cidrs": [str(n) for n in self.allow_cidrs],
            "allow_ports": None if self.allow_ports is None else sorted(self.allow_ports),
            "deny_hosts": sorted(self.deny_hosts),
            "deny_cidrs": [str(n) for n in self.deny_cidrs],
            "allow_buckets": sorted(self.allow_buckets),
            "allow_repositories": sorted(self.allow_repositories),
            "allow_models": sorted(self.allow_models),
            "deny_repositories": sorted(self.deny_repositories),
            "deny_models": sorted(self.deny_models),
            "allow_loopback": self.allow_loopback,
            "empty": self.is_empty,
        }

    @staticmethod
    def _asset_target(
        raw: str, body: str, scheme: str, *, bare: bool = False
    ) -> ResolvedTarget:
        """Normalize a scheme-carrying repository or hub-model target."""
        found = _asset_kind(body, allow_bare=bare)
        if found is None:
            raise ValueError(
                f"{raw!r} is not a repository on a known code host, and not a "
                f"hub model id"
            )
        kind, name = found
        return ResolvedTarget(raw=raw, kind=kind, host=name, scheme=scheme)

    # ------------------------------------------------------------------ parse
    def parse(self, raw: str, port: int | None = None) -> ResolvedTarget:
        """Normalize a raw target string into a :class:`ResolvedTarget`.

        Accepts ``host``, ``host:port``, ``http(s)://host[:port]/path``,
        ``1.2.3.4``, ``10.0.0.0/24``, ``[::1]:8080``, ``s3://bucket``,
        ``github.com/owner/name`` and ``hf://owner/name``.
        Raises :class:`ValueError` when nothing usable can be extracted.
        """
        text = (raw or "").strip()
        if not text:
            raise ValueError("empty target")

        scheme: str | None = None
        host_part = text
        explicit_port: int | None = port

        if "://" in text:
            parts = urlsplit(text)
            scheme = (parts.scheme or "").lower()
            if scheme in {"s3", "gs", "gcs", "az", "azure"}:
                bucket = (parts.netloc or parts.path.lstrip("/")).split("/")[0]
                if not bucket:
                    raise ValueError(f"no bucket name in {raw!r}")
                return ResolvedTarget(
                    raw=text, kind=TargetKind.BUCKET, host=bucket.lower(), scheme=scheme
                )
            if scheme in _REPO_SCHEMES or scheme.startswith("git+"):
                return self._asset_target(text, f"{parts.netloc}{parts.path}", scheme)
            if scheme in _MODEL_SCHEMES:
                return self._asset_target(
                    text, f"{parts.netloc}{parts.path}", scheme, bare=True
                )
            host_part = parts.hostname or ""
            if parts.port:
                explicit_port = parts.port
            elif scheme in _DEFAULT_PORTS:
                # A scheme implies a port. Recording it keeps allow_ports
                # meaningful for URLs like ``https://host/`` that name none.
                explicit_port = _DEFAULT_PORTS[scheme]
        elif text.count(":") == 1:
            head, _, tail = text.partition(":")
            if tail.isdigit() and head:
                host_part, explicit_port = head, int(tail)

        host = host_part.strip().strip("[]").lower().rstrip(".")
        if not host:
            raise ValueError(f"could not determine host from target {raw!r}")

        ips: tuple[str, ...] = ()
        if "/" in host:
            # A bare ``owner/name`` is read as a model id only for a scope that
            # names models at all: otherwise it is a path, and it is refused.
            found_kind, found_host = _slash_target(
                host, allow_bare=bool(self.allow_models or self.deny_models)
            )
            if found_kind is not TargetKind.CIDR:
                # A repository or a model has no address to resolve and no
                # service to connect to: it is a name matched against a list.
                return ResolvedTarget(
                    raw=text, kind=found_kind, host=found_host, scheme=scheme
                )
            kind = found_kind
        else:
            try:
                ips = (str(_normalize_ip(host)),)
                kind = TargetKind.IP
            except ValueError:
                kind = TargetKind.HOSTNAME
                if self.resolve_hostnames:
                    ips = self._safe_resolve(host)

        return ResolvedTarget(
            raw=text, kind=kind, host=host, port=explicit_port, scheme=scheme, ips=ips
        )

    def _safe_resolve(self, host: str) -> tuple[str, ...]:
        """Resolve, downgrading any DNS failure to "no addresses known"."""
        try:
            return tuple(self._resolve(host))
        except Exception:  # noqa: BLE001 - resolver failures are expected input
            return ()

    # ------------------------------------------------------------------ match
    @staticmethod
    def _match_host_rule(rules: Iterable[str], host: str) -> str | None:
        for rule in sorted(rules):
            if _host_matches(rule, host):
                return rule
        return None

    @staticmethod
    def _match_asset_rule(rules: Iterable[str], value: str) -> str | None:
        """Match ``owner/name`` or ``host/owner/name`` against scope entries.

        A rule matches exactly, or by its last segment being ``*`` - which
        covers whatever follows the final ``/``, so ``github.com/acme/*`` covers
        every repository that owner has. The wildcard never matches an empty
        remainder: ``acme/`` is not a repository.
        """
        for rule in sorted(rules):
            if rule == value:
                return rule
            prefix = rule[:-1]
            if rule.endswith("/*") and value.startswith(prefix) and len(value) > len(prefix):
                return rule
        return None

    def _ips_allowed(self, target: ResolvedTarget) -> bool:
        """True when every known address sits inside ``allow_cidrs``.

        Vacuously true when this scope configures no CIDRs at all.
        """
        if not self.allow_cidrs:
            return True
        if target.kind is TargetKind.CIDR:
            candidate = ipaddress.ip_network(target.host, strict=False)
            return any(candidate.subnet_of(n) for n in self.allow_cidrs)
        if not target.ips:
            return False  # cannot verify -> fail closed
        for addr in target.ips:
            if not _in_nets(_normalize_ip(addr), self.allow_cidrs):
                return False
        return True

    def _port_allowed(self, port: int | None) -> bool:
        if self.allow_ports is None or port is None:
            return True
        return port in self.allow_ports

    def _check_asset(self, target: ResolvedTarget) -> ScopeDecision:
        """Repositories and hub models: an allow list, a deny list, nothing else.

        Neither has an address to resolve, a port to filter or a CIDR to be
        checked against, so the metadata and loopback protections below cannot
        apply and are not consulted: ``deny`` still beats ``allow``.
        """
        repository = target.kind is TargetKind.REPOSITORY
        kind = "repository" if repository else "model"
        allowed = self.allow_repositories if repository else self.allow_models
        denied = self.deny_repositories if repository else self.deny_models

        deny_rule = self._match_asset_rule(denied, target.host)
        if deny_rule:
            return ScopeDecision.deny(
                f"{kind} matches deny rule {deny_rule!r}", target, f"deny:{deny_rule}"
            )
        allow_rule = self._match_asset_rule(allowed, target.host)
        if allow_rule:
            return ScopeDecision.allow(
                f"{kind} is on the allow list", target, f"{kind}:{allow_rule}"
            )
        return ScopeDecision.deny(
            f"{kind} {target.host!r} is not on the allow list", target
        )

    # ------------------------------------------------------------------ check
    def check(self, raw: str, port: int | None = None) -> ScopeDecision:
        """Decide whether ``raw`` may be touched. Never raises on bad input."""
        try:
            target = self.parse(raw, port)
        except ValueError as exc:
            return ScopeDecision.deny(f"unparseable target: {exc}")

        if target.kind is TargetKind.BUCKET:
            if target.host in self.allow_buckets:
                if self._match_host_rule(self.deny_hosts, target.host):
                    return ScopeDecision.deny(
                        f"bucket {target.host!r} matches a deny rule", target, "deny:host"
                    )
                return ScopeDecision.allow(
                    "bucket is on the allow list", target, f"bucket:{target.host}"
                )
            return ScopeDecision.deny(
                f"bucket {target.host!r} is not on the allow list", target
            )

        if target.kind in (TargetKind.REPOSITORY, TargetKind.MODEL):
            return self._check_asset(target)

        # 1. Hard denies that no configuration can override.
        if target.host in _ALWAYS_DENY_HOSTS:
            return ScopeDecision.deny(
                f"{target.host} is a cloud metadata endpoint; permanently out of scope",
                target,
                "always-deny:host",
            )
        for addr in target.ips:
            if _in_nets(_normalize_ip(addr), _ALWAYS_DENY_NETS):
                return ScopeDecision.deny(
                    f"resolves to metadata/link-local address {addr}; "
                    "permanently out of scope",
                    target,
                    "always-deny:net",
                )

        # 2. Deny beats allow.
        denied = self._match_host_rule(self.deny_hosts, target.host)
        if denied:
            return ScopeDecision.deny(
                f"host matches deny rule {denied!r}", target, f"deny:{denied}"
            )
        for addr in target.ips:
            if _in_nets(_normalize_ip(addr), self.deny_cidrs):
                return ScopeDecision.deny(
                    f"address {addr} matches a deny CIDR", target, "deny:cidr"
                )

        # 3. Loopback is strictly opt-in.
        if not self.allow_loopback:
            for addr in target.ips:
                if _in_nets(_normalize_ip(addr), _LOOPBACK_NETS):
                    return ScopeDecision.deny(
                        f"{addr} is loopback and this scope does not opt in "
                        "(set allow_loopback: true for local testing)",
                        target,
                        "deny:loopback",
                    )

        # 4. Allow.
        host_rule = self._match_host_rule(self.allow_hosts, target.host)
        if host_rule:
            if not self._ips_allowed(target):
                return ScopeDecision.deny(
                    f"host matches {host_rule!r} but its addresses are not inside "
                    "allow_cidrs (or could not be resolved)",
                    target,
                    f"allow:{host_rule}",
                )
            if not self._port_allowed(target.port):
                return ScopeDecision.deny(
                    f"port {target.port} is not in allow_ports", target, "deny:port"
                )
            return ScopeDecision.allow(
                f"host matches allow rule {host_rule!r}", target, f"allow:{host_rule}"
            )

        if target.kind in (TargetKind.IP, TargetKind.CIDR) and self.allow_cidrs:
            if self._ips_allowed(target):
                if not self._port_allowed(target.port):
                    return ScopeDecision.deny(
                        f"port {target.port} is not in allow_ports", target, "deny:port"
                    )
                return ScopeDecision.allow(
                    f"{target.host} is inside an allowed CIDR", target, "allow:cidr"
                )
            return ScopeDecision.deny(
                f"{target.host} is outside the allowed CIDRs", target, "deny:cidr"
            )

        if target.kind is TargetKind.HOSTNAME and not target.ips:
            return ScopeDecision.deny(
                f"{target.host} does not resolve and matches no allow rule", target
            )

        return ScopeDecision.deny(
            f"no allow rule matches {target.display!r} "
            f"(scope {self.label!r} grants {len(self.allow_hosts)} host(s), "
            f"{len(self.allow_cidrs)} cidr(s))",
            target,
        )

    def check_or_raise(self, raw: str, port: int | None = None) -> ScopeDecision:
        """Wrapper that raises :class:`ScopeViolation` instead of returning False."""
        from safety.errors import ScopeViolation

        decision = self.check(raw, port)
        if not decision.allowed:
            raise ScopeViolation(f"target {raw!r} refused: {decision.reason}")
        return decision

    def check_many(self, targets: Iterable[str]) -> dict[str, ScopeDecision]:
        return {t: self.check(t) for t in targets}


def _host_matches(rule: str, host: str) -> bool:
    """Match ``host`` against one scope rule.

    ``*.example.com`` matches ``a.example.com`` and ``a.b.example.com`` but
    not the apex ``example.com``; a plain entry matches only itself.
    """
    if rule.startswith("*."):
        suffix = rule[2:]
        return host.endswith("." + suffix)
    return host == rule

