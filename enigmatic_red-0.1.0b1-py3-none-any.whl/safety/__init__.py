"""Enigmatic Red — safety core.

Everything in this package is *policy*, not advice. The LLM planner may ask,
but only this layer decides. Each tool adapter must obtain a
:class:`safety.scope.ScopeDecision` immediately before spawning a process.
"""

from safety.audit import AuditEntry, AuditLog
from safety.authz import (
    ATTESTATION_STATEMENT,
    Attestation,
    AuthorizationGate,
    VerificationMethod,
    make_attestation,
    scope_digest,
)
from safety.errors import (
    ApprovalRequired,
    AuditError,
    AuthorizationError,
    EnigmaticRedError,
    ForbiddenActionError,
    KillSwitchEngaged,
    RateLimitExceeded,
    ScopeViolation,
    ToolConfigurationError,
    ToolExecutionError,
    ToolOutputError,
)
from safety.guard import (
    FORBIDDEN_RULES,
    INTRUSIVE_RULES,
    ActionClass,
    ForbiddenRule,
    Guard,
    GuardDecision,
)
from safety.killswitch import KillSwitch
from safety.ratelimit import RateLimiter, TokenBucket
from safety.scope import ResolvedTarget, Scope, ScopeDecision, TargetKind

__all__ = [
    "ATTESTATION_STATEMENT",
    "ActionClass",
    "ApprovalRequired",
    "Attestation",
    "AuditEntry",
    "AuditError",
    "AuditLog",
    "AuthorizationError",
    "AuthorizationGate",
    "EnigmaticRedError",
    "FORBIDDEN_RULES",
    "ForbiddenActionError",
    "ForbiddenRule",
    "Guard",
    "GuardDecision",
    "INTRUSIVE_RULES",
    "KillSwitch",
    "KillSwitchEngaged",
    "RateLimitExceeded",
    "RateLimiter",
    "ResolvedTarget",
    "Scope",
    "ScopeDecision",
    "ScopeViolation",
    "TargetKind",
    "TokenBucket",
    "ToolConfigurationError",
    "ToolExecutionError",
    "ToolOutputError",
    "VerificationMethod",
    "make_attestation",
    "scope_digest",
]
