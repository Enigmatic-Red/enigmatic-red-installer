"""Written-authorization attestation gate.

An agent that scans whatever a stranger types is a red team, not an assessment
tool: unauthorised by construction, and pointed at somebody else's target.
This module is the product's legal and ethical interlock: it refuses every
active action until a specific, dated, signed authorization covering the
requested target has been recorded and independently verified.

Nothing here is advisory. :meth:`AuthorizationGate.require` raises; callers do
not get to continue.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass, field
from datetime import datetime, timedelta, timezone
from enum import Enum
from typing import Any

from safety.errors import AuthorizationError
from safety.scope import Scope

__all__ = [
    "ATTESTATION_STATEMENT",
    "Attestation",
    "AuthorizationGate",
    "VerificationMethod",
    "make_attestation",
    "scope_digest",
]

#: The exact statement a customer must agree to. It is stored verbatim with
#: every scan so we can later prove *what* was asserted, not merely that a
#: checkbox was ticked.
ATTESTATION_STATEMENT = (
    "I confirm that I am authorized to conduct security testing against the "
    "targets listed in this scope, that I am either the owner of those assets "
    "or hold current written permission from the owner, and that I understand "
    "testing is limited to non-destructive proof-of-concept verification. I "
    "accept that this attestation is recorded, timestamped and retained."
)


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


class VerificationMethod(str, Enum):
    """How the authorization claim was corroborated."""

    NONE = "none"                    # self-attested only
    DNS_TXT = "dns_txt"              # domain control proven via TXT record
    HTTP_FILE = "http_file"          # control proven via /.well-known/<token>
    CLOUD_IAM = "cloud_iam"          # account control proven via provider API
    MANUAL_REVIEW = "manual_review"  # a human reviewed an uploaded document


@dataclass(frozen=True)
class Attestation:
    """A dated record of who authorized what, and how we know."""

    organization: str
    subject: str
    target: str
    reference: str
    signed_text: str
    signed_at: datetime
    scope_digest: str
    verification: VerificationMethod = VerificationMethod.NONE
    verified_at: datetime | None = None
    expires_at: datetime | None = None
    verification_evidence: dict[str, Any] = field(default_factory=dict)

    @property
    def statement_digest(self) -> str:
        return hashlib.sha256(self.signed_text.encode("utf-8")).hexdigest()

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["verification"] = self.verification.value
        for key in ("signed_at", "verified_at", "expires_at"):
            value = data.get(key)
            data[key] = value.isoformat() if isinstance(value, datetime) else None
        data["statement_digest"] = self.statement_digest
        return data

    def is_expired(self, now: datetime | None = None) -> bool:
        if self.expires_at is None:
            return False
        return (now or _utcnow()) >= self.expires_at


def scope_digest(scope: Scope) -> str:
    """Stable fingerprint of a scope, so an attestation binds to exact scope.

    Editing the scope later invalidates every existing attestation, which
    forces a fresh signature rather than silently widening what was agreed.
    """
    payload = json.dumps(scope.describe(), sort_keys=True)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def make_attestation(
    *,
    organization: str,
    subject: str,
    target: str,
    reference: str,
    scope: Scope,
    signed_text: str = ATTESTATION_STATEMENT,
    valid_for: timedelta | None = timedelta(days=90),
    verification: VerificationMethod = VerificationMethod.NONE,
    now: datetime | None = None,
) -> Attestation:
    """Build the record written by the P0 intake form.

    The caller passes the *customer's* statement text; we never synthesise
    consent on their behalf.
    """
    stamp = now or _utcnow()
    if not subject.strip() or not organization.strip():
        raise AuthorizationError("attestation requires a named subject and organization")
    if not reference.strip():
        raise AuthorizationError(
            "attestation requires a reference to the written authorization "
            "(contract, ticket or email-thread id)"
        )
    if len(signed_text.strip()) < 40:
        raise AuthorizationError("attestation text is too short to be meaningful")
    return Attestation(
        organization=organization.strip(),
        subject=subject.strip(),
        target=target.strip(),
        reference=reference.strip(),
        signed_text=signed_text.strip(),
        signed_at=stamp,
        scope_digest=scope_digest(scope),
        verification=verification,
        verified_at=stamp if verification is not VerificationMethod.NONE else None,
        expires_at=None if valid_for is None else stamp + valid_for,
    )


class AuthorizationGate:
    """Decides whether active tooling may run for a given target.

    Args:
        required: master switch. Defaults to ``True``; ``False`` exists *only*
            for the offline test suite. Nothing in the product constructs it
            that way.
        require_verification: when ``True``, self-attested records
            (``VerificationMethod.NONE``) are rejected. A public multi-tenant
            deployment must leave this on.
        max_age_days: refuse attestations older than this.
    """

    def __init__(
        self,
        *,
        required: bool = True,
        require_verification: bool = True,
        max_age_days: int = 180,
    ) -> None:
        self.required = required
        self.require_verification = require_verification
        self.max_age_days = max_age_days

    def check(
        self,
        attestation: Attestation | None,
        target: str,
        scope: Scope,
        *,
        now: datetime | None = None,
    ) -> tuple[bool, str]:
        """Return ``(ok, reason)``. Pure decision function, no side effects."""
        if not self.required:
            return True, "authorization gate disabled (test mode)"

        if attestation is None:
            return False, (
                "no written-authorization attestation on file for this scan; "
                "active tooling is blocked (P0 intake not completed)"
            )

        stamp = now or _utcnow()

        if attestation.is_expired(stamp):
            return False, f"attestation expired at {attestation.expires_at.isoformat()}"

        age = stamp - attestation.signed_at
        if age > timedelta(days=self.max_age_days):
            return False, (
                f"attestation is {age.days} days old; "
                f"maximum age is {self.max_age_days} days"
            )

        if (
            self.require_verification
            and attestation.verification is VerificationMethod.NONE
        ):
            return False, (
                "attestation is self-reported only; target control must be "
                "verified (DNS TXT, HTTP file or cloud IAM) before scanning"
            )

        if attestation.scope_digest != scope_digest(scope):
            return False, (
                "scope changed after this attestation was signed; the customer "
                "must re-attest to the current scope"
            )

        # The requested target must itself be in scope: an attestation can
        # never authorize something the scope file excludes.
        decision = scope.check(target)
        if not decision.allowed:
            return False, f"requested target is not in scope: {decision.reason}"

        return True, (
            f"authorization verified via {attestation.verification.value} "
            f"(ref {attestation.reference}, signed {attestation.signed_at.isoformat()})"
        )

    def require(
        self,
        attestation: Attestation | None,
        target: str,
        scope: Scope,
        *,
        now: datetime | None = None,
    ) -> Attestation:
        """Raise :class:`AuthorizationError` unless active work is permitted."""
        ok, reason = self.check(attestation, target, scope, now=now)
        if not ok:
            raise AuthorizationError(f"authorization refused for {target!r}: {reason}")
        assert attestation is not None  # implied by check() above
        return attestation
