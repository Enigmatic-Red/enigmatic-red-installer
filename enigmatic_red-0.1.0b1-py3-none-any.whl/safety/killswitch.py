"""Operator kill switch.

The single most important control during an incident: stop everything, now,
without redeploying. The switch is deliberately both in-memory *and*
file-backed — the file sentinel survives a restart, so "halt" cannot be
undone by a crash loop.

Scope of a halt is either ``global`` (the whole platform) or an organization
id (one tenant misbehaving does not stop everyone else).
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field
from pathlib import Path

from safety.errors import KillSwitchEngaged

__all__ = ["KillSwitch"]

GLOBAL = "global"


@dataclass
class Halt:
    scope: str
    reason: str
    engaged_by: str
    engaged_at: float = field(default_factory=time.time)

    def to_dict(self) -> dict:
        return {
            "scope": self.scope,
            "reason": self.reason,
            "engaged_by": self.engaged_by,
            "engaged_at": self.engaged_at,
        }


class KillSwitch:
    """Global and per-organization halt control.

    Args:
        sentinel_path: file that, when present, forces a global halt. Read on
            every check so an operator can ``touch`` it from a shell.
    """

    def __init__(self, sentinel_path: str | Path | None = None) -> None:
        self.sentinel_path = Path(sentinel_path) if sentinel_path else None
        self._lock = threading.Lock()
        self._halts: dict[str, Halt] = {}

    # ------------------------------------------------------------------ state
    def engage(self, reason: str, *, scope: str = GLOBAL, by: str = "operator") -> Halt:
        halt = Halt(scope=scope, reason=reason, engaged_by=by)
        with self._lock:
            self._halts[scope] = halt
        return halt

    def release(self, *, scope: str = GLOBAL) -> bool:
        with self._lock:
            return self._halts.pop(scope, None) is not None

    def _sentinel_present(self) -> bool:
        return self.sentinel_path is not None and self.sentinel_path.exists()

    def is_engaged(self, org: str | None = None) -> bool:
        if self._sentinel_present():
            return True
        with self._lock:
            return GLOBAL in self._halts or (org is not None and org in self._halts)

    def check(self, org: str | None = None) -> None:
        """Raise :class:`KillSwitchEngaged` if work must stop."""
        if self._sentinel_present():
            raise KillSwitchEngaged(
                f"kill switch engaged: sentinel file {self.sentinel_path} exists "
                "(remove it to resume)"
            )
        with self._lock:
            halt = self._halts.get(GLOBAL) or (
                self._halts.get(org) if org is not None else None
            )
        if halt is not None:
            raise KillSwitchEngaged(
                f"kill switch engaged for {halt.scope!r} by {halt.engaged_by}: "
                f"{halt.reason}"
            )

    def state(self) -> dict:
        with self._lock:
            halts = {scope: halt.to_dict() for scope, halt in self._halts.items()}
        return {
            "engaged": bool(halts) or self._sentinel_present(),
            "sentinel_path": str(self.sentinel_path) if self.sentinel_path else None,
            "sentinel_present": self._sentinel_present(),
            "halts": halts,
        }
