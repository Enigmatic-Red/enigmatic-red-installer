"""Exception hierarchy for Enigmatic Red.

Every safety refusal raises a subclass of :class:`EnigmaticRedError` so callers
can distinguish "the model asked for something forbidden" from "the tool
crashed". The API layer maps these to HTTP status codes and never leaks
internal detail to tenants.

A catch-all in application code that wants "anything this product refused or
failed at" should catch :class:`EnigmaticRedError`; a catch-all for "anything at
all went wrong, including our own bugs" should catch :class:`Exception`.
"""

from __future__ import annotations


class EnigmaticRedError(Exception):
    """Base class for every error this product raises deliberately."""


class ScopeViolation(EnigmaticRedError):
    """A target fell outside the authorized scope. Refused before execution."""


class AuthorizationError(EnigmaticRedError):
    """No valid written-authorization attestation covers this scan."""


class ForbiddenActionError(EnigmaticRedError):
    """The requested action is in the hard-deny class and will never run.

    Covers denial-of-service, credential brute force, persistence, wiper and
    bulk-exfiltration capability. Not overridable by config or by approval.
    """


class ApprovalRequired(EnigmaticRedError):
    """Intrusive but permitted class: needs an explicit human approval token."""

    def __init__(self, message: str, *, action_class: str, command: str) -> None:
        super().__init__(message)
        self.action_class = action_class
        self.command = command


class RateLimitExceeded(EnigmaticRedError):
    """Global or per-host throttle refused the request."""


class KillSwitchEngaged(EnigmaticRedError):
    """Operator halted execution (global or per-org)."""


class ToolExecutionError(EnigmaticRedError):
    """A tool adapter failed to run or returned an unusable result."""


class AuditError(EnigmaticRedError):
    """The audit log could not be written. Fail closed — never continue."""


class ProviderError(EnigmaticRedError):
    """The LLM provider failed or returned an unusable response."""


class PersistenceError(EnigmaticRedError):
    """The database could not be opened, migrated or written.

    Raised by :mod:`db.session`. It is deliberately *not* a subclass of
    :class:`AuditError`: the hash-chained log in ``safety.audit`` is the
    evidence and has to be written whether or not a database exists, so a
    failure in the queryable mirror must never be reported as a failure to
    record the decision itself.
    """


class ToolConfigurationError(EnigmaticRedError):
    """A tool adapter has invalid or incomplete configuration.

    Raised when a tool's configuration is missing required settings,
    contains invalid values, or fails validation before execution.
    This error prevents tool execution until configuration is corrected.
    """


class ToolOutputError(EnigmaticRedError):
    """A tool adapter produced output that could not be parsed or validated.

    Raised when tool output is malformed, incomplete, or fails schema
    validation. The tool may have executed successfully but its results
    are unusable for downstream processing.
    """
