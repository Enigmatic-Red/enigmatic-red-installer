"""Rate limiting and concurrency control.

Scanning is noisy. Two independent limits protect the customer's
infrastructure (and this platform's reputation) from becoming the incident:

* a per-host token bucket, so a single target never sees a burst;
* a global concurrency cap, so a busy tenant cannot starve the worker pool.

Both use an injectable clock so the unit tests run instantly and
deterministically instead of sleeping.
"""

from __future__ import annotations

import random
import threading
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Callable, Iterator

from safety.errors import RateLimitExceeded

__all__ = ["RateLimiter", "TokenBucket"]


@dataclass
class TokenBucket:
    """A classic token bucket: ``capacity`` burst, refilled continuously."""

    capacity: float
    refill_per_second: float
    tokens: float = 0.0
    updated_at: float = field(default_factory=time.monotonic)

    def __post_init__(self) -> None:
        if self.tokens == 0.0:
            self.tokens = self.capacity

    def _refill(self, now: float) -> None:
        elapsed = max(0.0, now - self.updated_at)
        if elapsed:
            self.tokens = min(
                self.capacity, self.tokens + elapsed * self.refill_per_second
            )
            self.updated_at = now

    def wait_time(self, now: float, amount: float = 1.0) -> float:
        """Seconds until ``amount`` tokens are available (0.0 if now)."""
        self._refill(now)
        if self.tokens >= amount:
            return 0.0
        if self.refill_per_second <= 0:
            return float("inf")
        return (amount - self.tokens) / self.refill_per_second

    def take(self, now: float, amount: float = 1.0) -> bool:
        """Consume tokens if available; returns whether it succeeded."""
        if self.wait_time(now, amount) > 0.0:
            return False
        self.tokens -= amount
        return True


class RateLimiter:
    """Per-host throttling plus a worker concurrency cap.

    Args:
        per_host_rps: sustained requests per second against any one host.
        burst: bucket capacity (defaults to one second's worth, minimum 1).
        global_rps: optional ceiling across all hosts.
        max_concurrency: how many tool processes may run at once.
        jitter: maximum random delay (seconds) before work starts, so parallel
            scanners do not synchronise into an obvious signature.
        clock: monotonic time source (injected by tests).
        sleep: sleep function (injected by tests).
    """

    def __init__(
        self,
        *,
        per_host_rps: float = 5.0,
        burst: float | None = None,
        global_rps: float | None = None,
        max_concurrency: int = 2,
        jitter: float = 0.25,
        clock: Callable[[], float] = time.monotonic,
        sleep: Callable[[float], None] = time.sleep,
    ) -> None:
        self.per_host_rps = max(0.0, per_host_rps)
        self.burst = burst if burst is not None else max(1.0, self.per_host_rps)
        self.global_rps = global_rps
        self.max_concurrency = max(1, max_concurrency)
        self.jitter = max(0.0, jitter)
        self._clock = clock
        self._sleep = sleep
        self._lock = threading.Lock()
        self._buckets: dict[str, TokenBucket] = {}
        self._global = (
            None if global_rps is None else TokenBucket(max(1.0, global_rps), global_rps)
        )
        if self._global is not None:
            self._global.updated_at = self._clock()
        self._active = 0

    # ------------------------------------------------------------------ state
    @property
    def active(self) -> int:
        return self._active

    def _bucket(self, host: str) -> TokenBucket:
        key = host.lower()
        if key not in self._buckets:
            self._buckets[key] = TokenBucket(
                self.burst, self.per_host_rps, updated_at=self._clock()
            )
        return self._buckets[key]

    def wait_time(self, host: str) -> float:
        """Seconds until one request against ``host`` may proceed."""
        with self._lock:
            now = self._clock()
            waits = [self._bucket(host).wait_time(now)]
            if self._global is not None:
                waits.append(self._global.wait_time(now))
            return max(waits)

    def acquire(
        self, host: str, *, amount: float = 1.0, max_wait: float = 30.0
    ) -> float:
        """Block until a request against ``host`` is permitted.

        Returns the seconds actually slept. Raises :class:`RateLimitExceeded`
        when the required wait exceeds ``max_wait`` — failing loudly beats a
        scanner silently stalling for hours.
        """
        with self._lock:
            now = self._clock()
            bucket = self._bucket(host)
            waits = [bucket.wait_time(now, amount)]
            if self._global is not None:
                waits.append(self._global.wait_time(now, amount))
            delay = max(waits)

        if delay == float("inf"):
            raise RateLimitExceeded(
                f"rate limit for {host!r} cannot be satisfied (rate is zero)"
            )
        if delay > max_wait:
            raise RateLimitExceeded(
                f"rate limit for {host!r} needs {delay:.1f}s "
                f"(limit is {self.per_host_rps}/s); exceeds the "
                f"{max_wait:.0f}s budget"
            )
        if delay > 0:
            self._sleep(delay)

        with self._lock:
            now = self._clock()
            self._bucket(host).take(now, amount)
            if self._global is not None:
                self._global.take(now, amount)
        return delay

    def jittered_pause(self) -> float:
        """Sleep a random small amount; returns the pause length."""
        if self.jitter <= 0:
            return 0.0
        pause = random.uniform(0.0, self.jitter)
        self._sleep(pause)
        return pause

    # ------------------------------------------------------------ concurrency
    def acquire_slot(self) -> None:
        """Claim one concurrency slot, or raise if the pool is full."""
        with self._lock:
            if self._active >= self.max_concurrency:
                raise RateLimitExceeded(
                    f"worker concurrency cap reached "
                    f"({self._active}/{self.max_concurrency} jobs in flight)"
                )
            self._active += 1

    def release_slot(self) -> None:
        with self._lock:
            self._active = max(0, self._active - 1)

    @contextmanager
    def slot(self, host: str, *, max_wait: float = 30.0) -> Iterator[float]:
        """Combined throttle: take a slot, wait out the bucket, add jitter."""
        self.acquire_slot()
        try:
            waited = self.acquire(host, max_wait=max_wait)
            self.jittered_pause()
            yield waited
        finally:
            self.release_slot()

    def describe(self) -> dict:
        return {
            "per_host_rps": self.per_host_rps,
            "burst": self.burst,
            "global_rps": self.global_rps,
            "max_concurrency": self.max_concurrency,
            "jitter": self.jitter,
            "active": self._active,
            "tracked_hosts": len(self._buckets),
        }
