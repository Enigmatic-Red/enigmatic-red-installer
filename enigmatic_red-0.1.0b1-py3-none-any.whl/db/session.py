"""The engine and session seam: one place that opens the database.

Nothing else in the project calls :func:`sqlalchemy.create_engine`. That is the
same discipline ``config.settings`` applies to the environment and
``agent.session`` applies to the enforcement chain: the resource is constructed
in exactly one place, so a test can point it at a temporary file, a deployment
can point it at Postgres, and neither has to reach into a module that made its
own connection.

Two things this module deliberately does *not* do:

* **It never creates the schema implicitly.** :func:`init_database` is an
  explicit call. A library that runs ``CREATE TABLE`` on import is a library
  that turns a typo in a connection string into a fresh empty database that
  answers every query with zero rows - the most expensive kind of wrong answer.
  The ``red db init`` command is what calls it.
* **It does not import anything from the scan path.** ``db`` sits beside
  ``safety`` and ``tools``, not inside them; SQLAlchemy is not a dependency of
  the core install (``pyproject.toml`` keeps it in the ``persistence`` extra),
  so nothing an operator runs to *scan* may import this module.
"""

from __future__ import annotations

from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path
from typing import TYPE_CHECKING, Any

from sqlalchemy import create_engine, func, inspect, select, text
from sqlalchemy.engine import Engine, make_url
from sqlalchemy.orm import Session, sessionmaker

from db.models import AuditRecord, Base, Scan
from safety.errors import PersistenceError

if TYPE_CHECKING:  # pragma: no cover - import cycle guard for type checkers only
    from safety.audit import AuditLog

__all__ = [
    "SCHEMA_REVISION",
    "TABLES",
    "current_revision",
    "describe_database",
    "ensure_database_directory",
    "init_database",
    "make_engine",
    "migrate_database",
    "session_factory",
    "session_scope",
    "sync_audit_log",
]

#: Tables in the order an operator should read them: the thing that happened,
#: then what it produced, then the record of it.
TABLES = ("scans", "findings", "jobs", "authorizations", "audit_records")

#: The revision Alembic stamps, and the name ``red db status`` reports.
SCHEMA_REVISION = "0001_initial_schema"


def ensure_database_directory(database_url: str) -> None:
    """Create the directory a SQLite file lives in, or explain why not.

    A path is only a path for SQLite; for Postgres the "database" is a name, not
    a file, and trying to ``mkdir`` it would create a directory named after the
    database in the working tree. ``:memory:`` is skipped for the same reason.

    Public because Alembic needs it as well: ``alembic upgrade head`` against a
    fresh install would otherwise fail with ``unable to open database file``
    before it ever reached a migration, and the fix belongs in one place rather
    than in a second copy inside ``db/migrations/env.py``.
    """
    url = make_url(database_url)
    if url.get_backend_name() != "sqlite":
        return
    target = url.database
    if not target or target == ":memory:":
        return
    parent = Path(target).expanduser().parent
    try:
        parent.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        raise PersistenceError(
            f"cannot create the database directory {parent}: {exc}"
        ) from exc


def make_engine(database_url: str, *, echo: bool = False) -> Engine:
    """Build the engine for ``database_url``, creating its directory if needed.

    ``echo`` is passed through so SQLAlchemy can be asked to log its SQL, which
    is how a test can prove a query was really a query rather than a client-side
    filter.
    """
    ensure_database_directory(database_url)
    try:
        return create_engine(database_url, echo=echo)
    except Exception as exc:  # noqa: BLE001 - the driver's message is the useful part
        raise PersistenceError(f"cannot open {database_url}: {exc}") from exc


def init_database(database_url: str, *, echo: bool = False) -> Engine:
    """Create every table this package declares, then return the engine.

    Idempotent: ``create_all`` only issues ``CREATE TABLE`` for tables that are
    absent, so running it against an initialised database changes nothing. It
    does *not* alter an existing table - changing a column is what the Alembic
    migration in ``db/migrations`` is for.

    This is the programmatic path: tests and embedding code use it because it
    needs no migration tooling, while ``red db init`` and ``red db upgrade`` both
    go through Alembic so a deployed database has a stamped revision.
    ``tests/test_db.py`` asserts the two produce the same schema, which is what
    makes using either one safe.
    """
    engine = make_engine(database_url, echo=echo)
    Base.metadata.create_all(engine)
    return engine


def session_factory(engine: Engine) -> sessionmaker:
    """A :class:`~sqlalchemy.orm.session.Session` factory bound to ``engine``.

    One session per unit of work, never shared between threads: SQLAlchemy
    sessions are not thread-safe, and the M5 queue is threaded.

    ``expire_on_commit=False`` so an object handed back to a caller after a
    commit is still readable - the default would make ``scan.findings`` raise
    ``DetachedInstanceError`` the moment the session closed, which is a trap for
    exactly the reporting code this layer exists to serve.
    """
    return sessionmaker(bind=engine, expire_on_commit=False)


@contextmanager
def session_scope(factory: sessionmaker) -> Iterator[Session]:
    """A transactional session: commit on success, roll back on any exception.

    The rollback is in the ``except`` rather than the ``finally`` so a failure
    raised inside the block cannot be masked by cleanup, and a half-written unit
    of work is never committed by a later ``close()``.
    """
    session = factory()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


def migrate_database(database_url: str, *, revision: str = "head") -> str | None:
    """Run the Alembic migrations up to ``revision``, then report what is applied.

    Alembic is driven through its Python API with a :class:`Config` built here
    rather than through a committed ``alembic.ini``, so that an *installed* copy
    migrates correctly: ``alembic.ini`` lives at the project root and is not
    package data, so a wheel has no ini file to point at. ``script_location`` is
    resolved from this package instead, which is where the migrations actually
    are.

    Returns the revision now stamped on the database.
    """
    try:
        from alembic import command
        from alembic.config import Config
    except ImportError as exc:  # pragma: no cover - covered by the CLI's message
        raise PersistenceError(
            "alembic is not installed, so migrations cannot run: "
            'pip install "enigmatic-red[persistence]"'
        ) from exc

    ensure_database_directory(database_url)
    config = Config()
    config.set_main_option("script_location", str(Path(__file__).parent / "migrations"))
    # Passed as an explicit attribute rather than as `sqlalchemy.url`, so that
    # env.py can tell "a caller decided this" apart from "an ini file happens to
    # say so". An explicit argument wins over the environment here for the same
    # reason it does in `ScanSession.open`: the caller has already decided where
    # its database lives, and it should not have to mutate global state to say
    # so. Without this, `red --home X db init` would silently write to whatever
    # DATABASE_URL the operator's shell happened to export.
    config.attributes["database_url"] = database_url
    # Stated rather than left to the default: an absent separator is the legacy
    # behaviour, which this Alembic deprecates, and a DeprecationWarning is an
    # error in this project's test configuration.
    config.set_main_option("path_separator", "os")
    try:
        command.upgrade(config, revision)
    except Exception as exc:  # noqa: BLE001 - Alembic's message is the useful part
        raise PersistenceError(f"migration of {database_url} failed: {exc}") from exc

    engine = make_engine(database_url)
    try:
        return current_revision(engine)
    finally:
        engine.dispose()


def _row_count(session: Session, table_name: str) -> int:
    """``SELECT count(*)`` for one table, issued as a real aggregate query."""
    table = Base.metadata.tables[table_name]
    return int(session.execute(select(func.count()).select_from(table)).scalar_one())


def current_revision(engine: Engine) -> str | None:
    """The Alembic revision stamped on this database, or ``None`` if unstamped.

    ``None`` is a meaningful answer, not an error: a database created by
    :func:`init_database` (``create_all``) is a real, usable database that no
    migration has stamped, and a status command that hid that would make the two
    paths indistinguishable right up until someone ran a migration on the wrong
    one.
    """
    if "alembic_version" not in inspect(engine).get_table_names():
        return None
    with engine.connect() as connection:
        rows = connection.execute(text("SELECT version_num FROM alembic_version")).fetchall()
    if not rows:
        return None
    return str(rows[0][0])


def describe_database(engine: Engine) -> dict[str, Any]:
    """What is actually in the database, for ``red db status``.

    Reports the tables it *found*, not the tables this package declares: the
    point of a status command is to describe the database that exists, so a
    missing table has to show up as missing rather than be assumed. A table that
    is present but unreadable reports ``rows: None`` instead of failing the whole
    command - one broken table should not hide the state of the others.
    """
    inspector = inspect(engine)
    present = set(inspector.get_table_names())
    factory = session_factory(engine)
    tables: dict[str, Any] = {}
    for name in TABLES:
        if name not in present:
            tables[name] = {"present": False, "columns": 0, "rows": None}
            continue
        try:
            with session_scope(factory) as session:
                rows: int | None = _row_count(session, name)
        except Exception:  # noqa: BLE001 - a count that fails is reported, not fatal
            rows = None
        tables[name] = {
            "present": True,
            "columns": len(inspector.get_columns(name)),
            "rows": rows,
        }
    return {
        "url": str(engine.url),
        "dialect": engine.dialect.name,
        "revision": current_revision(engine),
        "tables": tables,
        "unexpected_tables": sorted(present - set(TABLES) - {"alembic_version"}),
        "initialised": set(TABLES) <= present,
    }


def sync_audit_log(
    session: Session,
    audit: "AuditLog",
    *,
    scan_id: str | None = None,
) -> tuple[int, int]:
    """Mirror an :class:`~safety.audit.AuditLog` into ``audit_records``.

    Returns ``(imported, already_present)``.

    The chain is verified *before* anything is written. A database that holds a
    fork of a broken chain is worse than an empty one: it would answer "what
    happened" with history that the signed file does not support, so a chain
    that does not verify is refused outright rather than imported with a warning.

    Idempotent, which is the property that makes it safe to run on a schedule:
    an entry whose ``seq`` is already a row is counted and skipped, so a second
    run over an appended log imports only the new lines. The ``entry_hash``
    unique constraint is the backstop for a log that was rewritten rather than
    appended to.

    ``scan_id`` is the fallback link. A log entry carries no scan column, so the
    row is linked from ``detail["scan_id"]`` when the entry has one, else from
    this argument - and only when the referenced scan actually exists, because a
    dangling ``scan_id`` would be a claim about a scan the database cannot show.
    """
    ok, message = audit.verify()
    if not ok:
        raise PersistenceError(
            f"refusing to import {audit.path}: {message}. The chain is the "
            "evidence; a mirror of a broken chain would be a second, unsupported "
            "story about the same events."
        )

    imported = 0
    present = 0
    for raw in audit.iter_entries():
        seq = int(raw["seq"])
        if session.get(AuditRecord, seq) is not None:
            present += 1
            continue

        detail = raw.get("detail") or {}
        linked = detail.get("scan_id") or scan_id
        if linked and session.get(Scan, linked) is None:
            # Not an error: the log outlives any single database, and an entry
            # for a scan recorded before this table existed is still history.
            linked = None

        session.add(
            AuditRecord(
                seq=seq,
                timestamp=str(raw.get("timestamp") or ""),
                event=str(raw.get("event") or ""),
                actor=str(raw.get("actor") or "system"),
                org=raw.get("org"),
                target=raw.get("target"),
                action=raw.get("action"),
                action_class=raw.get("action_class"),
                decision=raw.get("decision"),
                detail=detail,
                prev_hash=str(raw.get("prev_hash") or ""),
                entry_hash=str(raw.get("entry_hash") or ""),
                scan_id=linked,
            )
        )
        imported += 1
    return imported, present
