"""M4 persistence: the queryable backend behind the evidence.

Importing this package is what pulls SQLAlchemy in, which is exactly why it is
kept out of the scan path and out of the core install. Deployments that want a
database install the extra::

    pip install "enigmatic-red[persistence]"

The surface is deliberately small - a schema, one place that opens a connection,
and one function that mirrors the hash-chained audit log into it - so that the
question "what does the database do?" has a short answer: it stores what the
tool did, and it can prove the record it stored still matches the file.
"""

from __future__ import annotations

from db.models import (
    AuditRecord,
    Authorization,
    Base,
    Finding,
    Job,
    Scan,
    utcnow_iso,
)
from db.session import (
    SCHEMA_REVISION,
    TABLES,
    current_revision,
    describe_database,
    ensure_database_directory,
    init_database,
    make_engine,
    migrate_database,
    session_factory,
    session_scope,
    sync_audit_log,
)

__all__ = [
    "SCHEMA_REVISION",
    "TABLES",
    "AuditRecord",
    "Authorization",
    "Base",
    "Finding",
    "Job",
    "Scan",
    "current_revision",
    "describe_database",
    "ensure_database_directory",
    "init_database",
    "make_engine",
    "migrate_database",
    "session_factory",
    "session_scope",
    "sync_audit_log",
    "utcnow_iso",
]
