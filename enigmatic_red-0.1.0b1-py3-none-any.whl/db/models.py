"""The persistence schema: scans, their findings, their jobs, and their record.

This is the M4 milestone. Everything the tool decides about a customer's
infrastructure eventually has to be answerable as a query - *which* scans ran
against *which* asset last quarter, *what* was found and at what severity,
*which* job is still queued, and *what* the hash-chained log says about all of
it - and a directory of JSONL files answers none of those without a custom
reader per question. So the log stays exactly as it is (it is the evidence, and
appending to it must never depend on a database being up) and this layer is a
*queryable mirror* of it, plus the tables the log never had.

Three decisions are worth stating, because each of them is a place where the
obvious alternative is wrong:

* **Timestamps are ISO-8601 UTC strings, not ``DateTime`` columns.**
  ``safety.audit`` hashes its entries over an ISO string, so the timestamp of an
  audit record is not a moment, it is *bytes that a signature covers* - a
  ``DateTime`` column would round-trip it through a driver and back into a
  different string, which is how a verified chain starts reporting as broken.
  The other tables use strings too, so one convention holds everywhere. ISO-8601
  UTC also sorts lexicographically, so ordering by time still works.

* **``seq`` is the primary key of ``audit_records``, and ``entry_hash`` is
  unique.** The chain's own numbering is the identity the hash commits to, and
  an entry hash that appears twice means history was imported twice. Both
  constraints make that a loud ``IntegrityError`` rather than a silent
  duplicate that a later count would report as extra history.

* **Nothing here can relax a control.** This module declares columns; it makes
  no decision. The guard, the scope, the rate limiter and the kill switch are
  unchanged and unaware of it, and no scan-path module imports it.

SQLAlchemy is written against the 1.4 line the project pins, using only its
non-deprecated API (``sqlalchemy.orm.declarative_base``, not the legacy
``sqlalchemy.ext.declarative`` alias), because the suite runs with
``filterwarnings = ["error::DeprecationWarning"]`` and a legacy call would be a
hard error rather than a warning.
"""

from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import (
    JSON,
    Column,
    Float,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
)
from sqlalchemy.orm import declarative_base, relationship

__all__ = [
    "AuditRecord",
    "Authorization",
    "Base",
    "FINDING_SEVERITIES",
    "FINDING_STATUSES",
    "Finding",
    "JOB_STATES",
    "Job",
    "SCAN_STATUSES",
    "Scan",
    "utcnow_iso",
]

#: The declarative base every table in this package hangs off. Alembic's
#: ``env.py`` points ``target_metadata`` at :attr:`Base.metadata` so a migration
#: is generated from *these* classes rather than from a second description of
#: the schema that would drift from it.
Base = declarative_base()


def utcnow_iso() -> str:
    """UTC now as an ISO-8601 string - the same shape ``safety.audit`` writes.

    ``datetime.now(timezone.utc)`` rather than ``datetime.utcnow()``: the latter
    returns a naive value and is deprecated in 3.12, so it would be a future
    ``DeprecationWarning`` treated as an error by this project's pytest config.
    """
    return datetime.now(timezone.utc).isoformat()


#: Vocabularies kept as plain strings with a documented set rather than a
#: database ``ENUM``: SQLite implements one as a ``VARCHAR`` plus a ``CHECK``
#: that a later migration cannot widen without rebuilding the table, and the
#: guard already refuses unknown values at the point they are written.
SCAN_STATUSES = ("pending", "running", "succeeded", "failed", "refused", "aborted")
JOB_STATES = ("queued", "running", "succeeded", "failed", "cancelled")
FINDING_SEVERITIES = ("info", "low", "medium", "high", "critical")
FINDING_STATUSES = ("observed", "confirmed", "refuted", "reported")


class Scan(Base):
    """One scan of one asset: the row every other table hangs off.

    ``id`` is the ``scan_id`` the audit log records, so a row here and a line in
    the log name the same thing and a report can join them. It is a string
    because it is operator-supplied (``red scan --scan-id``) and because a
    sortable integer would imply the tool assigns them in order, which it does
    not.
    """

    __tablename__ = "scans"

    id = Column(String(64), primary_key=True)
    organization = Column(String(200), nullable=False, default="")
    actor = Column(String(120), nullable=False, default="")
    target = Column(String(255), nullable=False)
    tool = Column(String(64), nullable=False)
    status = Column(String(16), nullable=False, default="pending")
    scope_label = Column(String(120), nullable=False, default="")
    #: The attestation that authorised this scan. The attestation itself is in
    #: ``authorizations``; this is the reference a human quotes in a report.
    attestation_ref = Column(String(120), nullable=False, default="")
    llm_provider = Column(String(64), nullable=False, default="")
    llm_model = Column(String(160), nullable=False, default="")
    #: The same numbers the planner loop enforces, recorded so a scan that hit
    #: its ceiling can be told apart from one that finished.
    token_budget = Column(Integer, nullable=False, default=0)
    token_spend = Column(Integer, nullable=False, default=0)
    started_at = Column(String(40), nullable=False, default=utcnow_iso)
    finished_at = Column(String(40), nullable=True)
    notes = Column(Text, nullable=False, default="")

    findings = relationship(
        "Finding", back_populates="scan", cascade="all, delete-orphan"
    )
    jobs = relationship("Job", back_populates="scan", cascade="all, delete-orphan")
    records = relationship("AuditRecord", back_populates="scan")

    __table_args__ = (Index("ix_scans_target_started", "target", "started_at"),)

    def __repr__(self) -> str:  # pragma: no cover - debugging aid
        return f"<Scan {self.id} {self.tool} {self.status} target={self.target!r}>"


class Finding(Base):
    """One thing a scan observed, at the severity it was assessed at.

    ``status`` is the honesty column, and it is why this is not just
    ``findings``-with-a-title: ``observed`` is what a tool's output says,
    ``confirmed`` is what was reproduced, ``refuted`` is what was checked and
    did not hold. Collapsing those three into "found" is precisely the claim
    inflation ``agent/prompts`` and the report path are written to prevent, so
    the schema keeps them apart.
    """

    __tablename__ = "findings"

    id = Column(Integer, primary_key=True, autoincrement=True)
    scan_id = Column(
        String(64),
        ForeignKey("scans.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    title = Column(String(300), nullable=False)
    severity = Column(String(16), nullable=False, default="info")
    cvss_score = Column(Float, nullable=True)
    cvss_vector = Column(String(200), nullable=False, default="")
    host = Column(String(255), nullable=False, default="")
    port = Column(Integer, nullable=True)
    protocol = Column(String(16), nullable=False, default="")
    service = Column(String(120), nullable=False, default="")
    cwe = Column(String(32), nullable=False, default="")
    description = Column(Text, nullable=False, default="")
    #: Where the proof lives - a path under the evidence store, never the bytes
    #: themselves: evidence is large, has its own retention policy, and must not
    #: be duplicated into a database that is backed up differently.
    evidence_ref = Column(String(300), nullable=False, default="")
    status = Column(String(24), nullable=False, default="observed")
    created_at = Column(String(40), nullable=False, default=utcnow_iso)

    scan = relationship("Scan", back_populates="findings")

    def __repr__(self) -> str:  # pragma: no cover - debugging aid
        return f"<Finding {self.severity} {self.title!r} scan={self.scan_id}>"


class Job(Base):
    """A unit of queued work (the M5 queue), recorded where it can be inspected.

    ``scan_id`` is nullable on purpose. The queue's own bookkeeping - a refresh
    job, a retention sweep - is work that is not a scan, and forcing it to name
    one would either invent a scan row or drop the record of the run.
    """

    __tablename__ = "jobs"

    id = Column(String(64), primary_key=True)
    scan_id = Column(
        String(64),
        ForeignKey("scans.id", ondelete="CASCADE"),
        nullable=True,
        index=True,
    )
    kind = Column(String(64), nullable=False, default="scan")
    state = Column(String(16), nullable=False, default="queued")
    attempts = Column(Integer, nullable=False, default=0)
    worker = Column(String(120), nullable=False, default="")
    error = Column(Text, nullable=False, default="")
    enqueued_at = Column(String(40), nullable=False, default=utcnow_iso)
    started_at = Column(String(40), nullable=True)
    finished_at = Column(String(40), nullable=True)

    scan = relationship("Scan", back_populates="jobs")

    def __repr__(self) -> str:  # pragma: no cover - debugging aid
        return f"<Job {self.id} {self.kind} {self.state}>"


class Authorization(Base):
    """The dated attestation a scan was run under, kept beside the scan.

    ``safety.authz`` owns the signature and the scope digest; this is the row
    that lets an auditor ask "what authority covered this scan" and get an
    answer without the operator's home directory. ``scope_digest`` is stored
    because it is what makes widening the scope invalidate the signature - a
    report can then show the scope that was signed *for*, not the one that is
    on disk today.
    """

    __tablename__ = "authorizations"

    reference = Column(String(120), primary_key=True)
    organization = Column(String(200), nullable=False, default="")
    subject = Column(String(200), nullable=False, default="")
    target = Column(String(255), nullable=False, default="")
    scope_label = Column(String(120), nullable=False, default="")
    scope_digest = Column(String(64), nullable=False, default="")
    signed_text = Column(Text, nullable=False, default="")
    #: The ``VerificationMethod`` value, as a string so a new method does not
    #: need a migration.
    verification = Column(String(32), nullable=False, default="manual_review")
    issued_at = Column(String(40), nullable=False, default=utcnow_iso)
    expires_at = Column(String(40), nullable=True)
    created_at = Column(String(40), nullable=False, default=utcnow_iso)

    def __repr__(self) -> str:  # pragma: no cover - debugging aid
        return f"<Authorization {self.reference} expires={self.expires_at}>"


class AuditRecord(Base):
    """One entry of the hash-chained log, mirrored as a row.

    The columns are the eleven ``_HASH_FIELDS`` of ``safety.audit`` plus the
    stored ``entry_hash``, so a row can be re-hashed from itself and checked
    against the chain: the table cannot quietly become a different story from
    the file. ``scan_id`` is *derived* - a log entry has no scan column - and is
    filled from ``detail["scan_id"]`` when that is present, which is why it is
    nullable.

    ``prev_hash`` and ``entry_hash`` are kept even though they are redundant
    with the file, because the point of this table is that a query can be run
    without the file, and a chain you cannot verify from the table alone is a
    chain you have to trust.
    """

    __tablename__ = "audit_records"

    #: The chain's own numbering. Not autoincrement: the number is assigned by
    #: the log, and a row that renumbered it would be a different entry.
    seq = Column(Integer, primary_key=True, autoincrement=False)
    timestamp = Column(String(40), nullable=False)
    event = Column(String(120), nullable=False)
    actor = Column(String(120), nullable=False, default="system")
    org = Column(String(200), nullable=True)
    target = Column(String(255), nullable=True)
    action = Column(String(200), nullable=True)
    action_class = Column(String(32), nullable=True)
    decision = Column(String(32), nullable=True, index=True)
    detail = Column(JSON, nullable=False, default=dict)
    prev_hash = Column(String(64), nullable=False)
    entry_hash = Column(String(64), nullable=False, unique=True)
    scan_id = Column(
        String(64),
        ForeignKey("scans.id", ondelete="SET NULL"),
        nullable=True,
        index=True,
    )
    imported_at = Column(String(40), nullable=False, default=utcnow_iso)

    scan = relationship("Scan", back_populates="records")

    def __repr__(self) -> str:  # pragma: no cover - debugging aid
        return f"<AuditRecord #{self.seq} {self.event} {self.decision or '-'}>"
