"""Alembic's migration environment.

The two things that matter here, and why:

* **The URL comes from the application, not from ``alembic.ini``.**
  :func:`resolve_url` prefers ``DATABASE_URL`` and otherwise asks
  :func:`config.settings.get_settings`, so a migration targets exactly the
  database the application would open. An ini file holding its own connection
  string is a second source of truth, and the failure it produces - migrating a
  test database while production waits - is silent.

* **``target_metadata`` is ``db.models.Base.metadata``.** Autogenerate compares
  the models against the database, so the migrations are generated *from the
  schema the code declares* rather than from someone's memory of it.

``red db init`` uses ``db.session.init_database`` (``create_all``) and this
Alembic tree is what stamps and evolves a deployed database. ``tests/test_db.py``
compares the two, so a model change that is missing its migration fails the
suite instead of surfacing as a runtime error on a customer's install.
"""

from __future__ import annotations

import os
import sys
from logging.config import fileConfig
from pathlib import Path

from alembic import context
from sqlalchemy import engine_from_config, pool

# `alembic` is normally run from the project root with prepend_sys_path = ., but
# a caller that imports this module directly (a test, or a tool) has not
# necessarily put the root on sys.path yet.
ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from config.settings import get_settings  # noqa: E402
from db.models import Base  # noqa: E402
from db.session import ensure_database_directory  # noqa: E402

config = context.config

if config.config_file_name is not None:
    # disable_existing_loggers=False because an in-process caller (the test
    # suite runs migrations through Alembic's API) would otherwise have the
    # application's loggers switched off as a side effect of running a
    # migration - a confusing failure in an unrelated test.
    fileConfig(config.config_file_name, disable_existing_loggers=False)

#: What autogenerate diffs the database against.
target_metadata = Base.metadata


def resolve_url() -> str:
    """The database to migrate. Precedence, highest first:

    1. ``config.attributes["database_url"]`` - a caller who passed a URL
       explicitly (that is how ``red --home X db init`` and the test suite target
       the database they mean). An explicit argument outranks the environment,
       the same rule ``ScanSession.open`` documents for paths.
    2. ``DATABASE_URL`` - an operator pointing *this run* somewhere specific.
    3. ``settings.database_url`` - the application's own value, which is what a
       bare ``alembic upgrade head`` from the project root should use.

    ``alembic.ini`` ships with ``sqlalchemy.url`` empty and is not consulted:
    this function always supplies a URL, so a committed connection string could
    never take effect by surprise.
    """
    explicit = config.attributes.get("database_url")
    if explicit:
        return str(explicit)
    env_url = os.environ.get("DATABASE_URL")
    if env_url:
        return env_url
    return get_settings().database_url


def run_migrations_offline() -> None:
    """Emit SQL to stdout instead of running it.

    ``literal_binds`` is required because there is no connection to bind against,
    which is why this path cannot be used to run a migration that needs real
    parameter binding.
    """
    context.configure(
        url=resolve_url(),
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
        compare_type=True,
    )
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    """Run the migrations against a real connection.

    ``ensure_database_directory`` is called first because a first-ever
    ``upgrade head`` on a fresh install would otherwise die with "unable to open
    database file" - SQLite will create the *file* but never its parent
    directory.
    """
    url = resolve_url()
    ensure_database_directory(url)
    section = config.get_section(config.config_ini_section) or {}
    section["sqlalchemy.url"] = url
    connectable = engine_from_config(
        section, prefix="sqlalchemy.", poolclass=pool.NullPool
    )
    with connectable.connect() as connection:
        context.configure(
            connection=connection,
            target_metadata=target_metadata,
            compare_type=True,
        )
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
