"""The one description of the site this product publishes.

Everything that needs to know a path on the published site reads it here: what
`web/publish.py` stages, and what address `agent/chat_tools.py` composes for the
references that read this site's own pages. A literal in either place was a
second description of the same site, and the two had already drifted apart once -
`/api/capabilities` was named in the Function's runner and in the reference
table, and neither of them was the file that serves it.

Three fields per surface, and each answers a question one of the consumers asks:

``path``
    What a browser asks for, site-absolute and with the trailing slash a
    directory-shaped page needs. This is what a reference's template becomes, so
    it is the address a reader is *composed* from - never one a model sent.
``source``
    Where it lives under ``web/``, or empty for something a route answers. A
    document is a file, a tree is a directory of generated pages, and a route is
    neither: it is the Function, and nothing on disk is staged for it.
``key``
    The name it goes by in this repository. ``agent/chat_refs.toml`` names it
    rather than typing the path, which is what keeps a rename to one edit.

``web/publish.py`` stages what has a ``source``, and stages nothing for a route.
``tests/test_publish.py`` holds the staged tree against this table in both
directions - a surface with no bytes behind the path it names, and a staged file
no surface claims, are both failures rather than surprises in production.
"""

from __future__ import annotations

from dataclasses import dataclass

__all__ = [
    "DOCUMENTS",
    "ROUTES",
    "SURFACES",
    "TREES",
    "by_key",
]


@dataclass(frozen=True)
class Surface:
    """One thing this site serves, and where it is built from."""

    #: The name it goes by here, and the name `agent/chat_refs.toml` refers to it
    #: by. Lower case, one word where possible.
    key: str
    #: The path a browser asks for. Leading slash, and the trailing slash a page
    #: served as a directory has - both halves matter, because this string is
    #: substituted into a reference's template and resolved against the origin.
    path: str
    #: What a reader finds there, in one line.
    what: str
    #: Where it lives under ``web/``: a file for a document, a directory for a
    #: tree, and empty for a route the Function answers.
    source: str = ""
    #: The file at the root of ``source`` a tree must have, so a staged tree that
    #: would answer 404 at its own URL is caught by the build rather than by a
    #: visitor. Empty for a document or a route.
    entry: str = ""

    @property
    def is_a_document(self) -> bool:
        """Whether this is one file copied to the deploy root as written."""
        return bool(self.source) and not self.entry

    @property
    def is_a_tree(self) -> bool:
        """Whether this is a directory of generated pages, staged whole."""
        return bool(self.entry)


#: Every surface, in the order the site's own navigation reads: the landing page,
#: the pages a visitor is sent to from the footer, then the collection and the
#: interface, then the one route.
#:
#: This site's own read-only references resolve their template from here - so a
#: rename is one edit, and a reference cannot point at a page that is not in this
#: table.
SURFACES: tuple[Surface, ...] = (
    Surface(
        key="home",
        path="/",
        what="the landing page",
        source="index.html",
    ),
    Surface(
        key="not_found",
        path="/404.html",
        what="the page a missing URL answers with",
        source="404.html",
    ),
    Surface(
        key="terms",
        path="/terms.html",
        what="the terms the beta is offered under",
        source="terms.html",
    ),
    Surface(
        key="privacy",
        path="/privacy.html",
        what="what this site does and does not collect",
        source="privacy.html",
    ),
    Surface(
        key="coverage",
        path="/scope/",
        what="the coverage page: what is covered, partly covered and refused",
        source="scope/index.html",
    ),
    Surface(
        key="writeups",
        path="/writeups/",
        what="the write-ups index and one page per piece",
        source="writeups",
        entry="index.html",
    ),
    Surface(
        key="beta",
        path="/beta/",
        what="the chat interface, and the only application here",
        source="beta",
        entry="index.html",
    ),
    Surface(
        key="capabilities",
        path="/api/capabilities",
        what="the capability table, answered by the Function",
    ),
)

#: The three kinds, kept apart where a consumer means exactly one of them.
DOCUMENTS: tuple[Surface, ...] = tuple(item for item in SURFACES if item.is_a_document)
TREES: tuple[Surface, ...] = tuple(item for item in SURFACES if item.is_a_tree)
ROUTES: tuple[Surface, ...] = tuple(item for item in SURFACES if not item.source)


def by_key(key: str) -> Surface:
    """The surface with this name, or a `KeyError` naming it."""
    for item in SURFACES:
        if item.key == key:
            return item
    raise KeyError(key)
