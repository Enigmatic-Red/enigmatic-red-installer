"""The ``red`` command line.

``red init`` seeds a configuration home, ``red authorize`` writes the dated
attestation that permits one target, ``red doctor`` reports what the install can
do, ``red scan`` runs an adapter through the full enforcement chain and
``red report`` prints what the hash-chained audit log recorded.

Everything here is a thin layer over the same objects the rest of the codebase
uses, so the CLI cannot do anything the library does not already enforce.
"""

from __future__ import annotations

__all__ = ["main"]


def main(argv: list[str] | None = None) -> int:
    """Lazy re-export, so importing the package does not build the parser."""
    from cli.main import main as entry

    return entry(argv)
