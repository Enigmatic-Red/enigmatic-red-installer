"""Where an install keeps its configuration, and how `red init` seeds it.

Two directories matter, and they are not the same directory once the tool is
installed rather than run from a checkout:

* the *shipped* config - the policy, the scope template, the tier ladder, the
  domain map - which travels inside the wheel as package data and must be
  treated as read-only; and
* the *home* config - the copy the operator edits, alongside the audit log, the
  evidence and the authorization - which must live outside the install
  directory, because a wheel that writes its audit log into ``site-packages``
  loses it on the next upgrade.

``red init`` copies the first into the second. Every command takes the home as
``--home`` (default: ``ENIGMATIC_RED_HOME``, else the checkout, else the user
directory), so a test - or an operator with two environments - never has to
touch global state to say where it is working.
"""

from __future__ import annotations

import config as config_package
import json
import shutil
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

from config.settings import ENV_HOME_VAR, HOME_DIR
from safety.authz import Attestation, VerificationMethod

__all__ = [
    "AUTHORIZATION_FILENAME",
    "CHAT_PREFS_FILENAME",
    "DATABASE_FILENAME",
    "DEFAULT_CONFIG_FILES",
    "ENV_FILENAME",
    "ENV_HOME_VAR",
    "Home",
    "KEY_NAMES",
    "attestation_from_dict",
    "clear_env_key",
    "read_chat_prefs",
    "read_env_key",
    "resolve_home",
    "seeded_scope_template",
    "set_env_key",
    "shipped_config_dir",
    "write_chat_prefs",
]

#: Every YAML the wheel ships and an install therefore needs a copy of.
DEFAULT_CONFIG_FILES = (
    "domains.yaml",
    "models.yaml",
    "plans.yaml",
    "policy.yaml",
    "scope.example.yaml",
)

#: The operator's editable scope, created from the template by `red init`.
SCOPE_FILENAME = "scope.yaml"
AUTHORIZATION_FILENAME = "authorization.json"
AUDIT_FILENAME = "audit.jsonl"

#: The M4 database, under the home's ``data/`` beside the audit log and the
#: evidence. The name matches the default ``database_url`` in
#: ``config/settings.py``, so a checkout resolves to one file whether the
#: connection comes from settings or from ``--home``.
DATABASE_FILENAME = "enigmaticred.db"

#: The environment file ``Settings`` is configured with, in the home. `red key`
#: writes the model credential here, which is also where the installer and
#: ``setup_local_model.*`` put theirs.
ENV_FILENAME = ".env"

#: The model credential under both names a host may document it: the two are
#: *aliases* of one credential (``config/settings.py`` copies whichever is set
#: into the other), so `red key` writes the names the file already carries and a
#: file can never hold two different keys with the losing one still winning.
KEY_NAMES = ("LLM_API_KEY", "FEATHERLESS_API_KEY")

#: `red`'s remembered choices - which role answered last - as JSON under
#: ``config/`` beside the scope. An operator's preference about *this* install,
#: which is why it is not under ``data/``: nothing here is a finding, a run or
#: evidence, and the key is never written to it (that stays in ``.env``).
CHAT_PREFS_FILENAME = "chat.json"

# There is deliberately no conversation directory. `data/chat/` held one, and it
# was removed with `/history` and `/resume`: what this tool keeps is the audit
# log, which holds the steps that ran rather than the sentences that were said.
# The one thing a session remembers is the role it answered with, below.


@dataclass(frozen=True)
class Home:
    """Resolved paths for one install. Nothing here creates anything."""

    root: Path

    @property
    def config(self) -> Path:
        return self.root / "config"

    @property
    def data(self) -> Path:
        return self.root / "data"

    @property
    def policy_file(self) -> Path:
        return self.config / "policy.yaml"

    @property
    def scope_file(self) -> Path:
        return self.config / SCOPE_FILENAME

    @property
    def authorization_file(self) -> Path:
        return self.config / AUTHORIZATION_FILENAME

    @property
    def audit_path(self) -> Path:
        return self.data / "audit" / AUDIT_FILENAME

    @property
    def killswitch_path(self) -> Path:
        return self.data / "KILLSWITCH"

    @property
    def database_path(self) -> Path:
        """The M4 database belonging to *this* home.

        Derived from the home rather than read from ``database_url`` so that
        ``--home`` keeps meaning what it means for every other command: the
        database a command touches is the one belonging to the install it was
        pointed at. Reading the global setting here would make
        ``red --home /tmp/scratch db init`` write into the developer's real
        database, which is the one mistake this flag exists to prevent.
        """
        return self.data / DATABASE_FILENAME

    @property
    def database_url(self) -> str:
        """The SQLAlchemy URL for :attr:`database_path`.

        Built here rather than in ``db.session`` so that ``db`` keeps one
        contract - it takes URLs - and so the same construction as
        ``config/settings.py``'s own default is used in both places. ``as_posix``
        matters on Windows: a backslash path would parse as an escape sequence
        inside the URL.
        """
        return f"sqlite+pysqlite:///{self.database_path.as_posix()}"

    @property
    def env_file(self) -> Path:
        """The `.env` this home reads: exactly the file ``Settings`` is given.

        ``.env`` at the root of the home rather than under ``config/``, because
        that is the path ``Settings.model_config`` names and the one the
        installer and ``setup_local_model.*`` write to. ``tests/test_paths.py``
        pins that the two agree.
        """
        return self.root / ENV_FILENAME

    @property
    def is_seeded(self) -> bool:
        """Seeded means the guard has a policy and the operator has a scope."""
        return self.policy_file.is_file() and self.scope_file.is_file()

    @property
    def chat_prefs_file(self) -> Path:
        """`red`'s remembered choices for this install."""
        return self.config / CHAT_PREFS_FILENAME

def read_chat_prefs(path: Path) -> dict[str, Any]:
    """The choices `red` remembers, or ``{}``.

    A file that is missing, empty or not JSON is *not* an error: a first run has
    no preferences, and one corrupted file must not stop a chat from starting.
    Only a small dict of choices is ever read - never a credential, which lives
    in ``.env`` and nowhere else.
    """
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def write_chat_prefs(path: Path, prefs: dict[str, Any]) -> None:
    """Remember the choices as JSON, creating the config directory if needed."""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(prefs, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def resolve_home(explicit: str | Path | None = None) -> Home:
    """The home for this invocation: ``--home``, then the environment, then settings.

    The order matters for testing: an explicit ``--home`` has to beat the
    environment, so a test can point one command at a temporary directory in
    the same process that another command is using the real one.
    """
    if explicit:
        return Home(Path(explicit).expanduser().resolve())
    return Home(HOME_DIR)


def _key_lines(lines: list[str]) -> list[tuple[int, str, str]]:
    """``(index, name, value)`` for every line that sets one of the key names.

    A commented line is not a setting: ``# LLM_API_KEY=...`` is a template's
    example, and rewriting it would be editing the operator's file to say
    something they did not.
    """
    found: list[tuple[int, str, str]] = []
    for index, line in enumerate(lines):
        if line.lstrip().startswith("#") or "=" not in line:
            continue
        name, value = line.split("=", 1)
        if name.strip() in KEY_NAMES:
            found.append((index, name.strip(), value.strip()))
    return found


def read_env_key(path: Path) -> tuple[str, str] | None:
    """``(name, value)`` of the credential in this file, or ``None``.

    A line that holds no value is not a credential, so the empty
    ``LLM_API_KEY=`` of a file copied from ``.env.example`` does not hide a
    ``FEATHERLESS_API_KEY`` further down.
    """
    if not path.is_file():
        return None
    for _index, name, value in _key_lines(path.read_text(encoding="utf-8").splitlines()):
        if value:
            return name, value
    return None


def set_env_key(path: Path, value: str) -> list[str]:
    """Write ``value`` as this file's model key. Returns the names written.

    Every other line is left exactly as it was: an ``.env`` may carry settings
    this command knows nothing about, and losing one would be worse than failing.

    The value goes into every name the file already carries a value under, which
    is what stops a stale alias from outranking it - ``FEATHERLESS_API_KEY`` wins
    over ``LLM_API_KEY`` in ``Settings``, so writing only the second name would
    leave the *old* key in force. When the file names the keys but has no value
    in them, the value goes into ``LLM_API_KEY`` if that line exists - the name
    this project's own docs use - else into the one line there is; a file with
    neither name gets ``LLM_API_KEY`` appended.
    """
    text = path.read_text(encoding="utf-8") if path.is_file() else ""
    lines = text.splitlines()
    present = _key_lines(lines)
    carried = [(index, name) for index, name, existing in present if existing]
    written: list[str] = []
    if carried:
        for index, name in carried:
            lines[index] = f"{name}={value}"
            written.append(name)
    else:
        names = [name for _index, name, _existing in present]
        name = names[0] if names and "LLM_API_KEY" not in names else "LLM_API_KEY"
        target = next((index for index, found, _v in present if found == name), None)
        if target is None:
            lines.append(f"{name}={value}")
        else:
            lines[target] = f"{name}={value}"
        written.append(name)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return written


def clear_env_key(path: Path) -> list[str]:
    """Delete the line(s) carrying the credential. Returns the names removed.

    Never creates the file, and never removes a line that holds no value: the
    empty ``LLM_API_KEY=`` of a file copied from ``.env.example`` is the
    template's line, and deleting it would be editing the operator's file to say
    something it did not.
    """
    if not path.is_file():
        return []
    lines = path.read_text(encoding="utf-8").splitlines()
    carried = _key_lines(lines)
    removed = [name for _index, name, value in carried if value]
    if not removed:
        return []
    drop = {index for index, _name, value in carried if value}
    kept = [line for index, line in enumerate(lines) if index not in drop]
    path.write_text(("\n".join(kept) + "\n") if kept else "", encoding="utf-8")
    return removed


def shipped_config_dir() -> Path:
    """The read-only copies that travel inside the wheel."""
    return Path(config_package.__file__).resolve().parent


def seeded_scope_template() -> str:
    """The scope template, with its header intact so the operator reads it."""
    return (shipped_config_dir() / "scope.example.yaml").read_text(encoding="utf-8")


def seed(home: Home) -> tuple[list[str], list[str]]:
    """Create the home's directories and copy in anything missing.

    Returns ``(created, kept)``. Existing files are never overwritten: the scope
    is the operator's, and silently replacing the policy a running install is
    enforcing would be the worst possible failure mode for a tool like this.
    """
    created: list[str] = []
    kept: list[str] = []
    for directory in (home.config, home.data / "audit", home.data / "evidence"):
        if not directory.exists():
            directory.mkdir(parents=True, exist_ok=True)
            created.append(str(directory))

    source = shipped_config_dir()
    for name in DEFAULT_CONFIG_FILES:
        target = home.config / name
        if target.exists():
            kept.append(name)
            continue
        origin = source / name
        if origin.is_file():
            shutil.copy2(origin, target)
            created.append(name)

    if home.scope_file.exists():
        kept.append(SCOPE_FILENAME)
    else:
        home.scope_file.write_text(seeded_scope_template(), encoding="utf-8")
        created.append(SCOPE_FILENAME)
    return created, kept


def attestation_from_dict(data: dict[str, Any]) -> Attestation:
    """Rebuild an attestation from ``Attestation.to_dict`` output.

    ``to_dict`` is for humans and reports - it adds a ``statement_digest`` the
    dataclass does not take and stringifies the three timestamps - so the
    round-trip has to undo exactly those two things and nothing is assumed about
    the rest.
    """
    fields = dict(data)
    fields.pop("statement_digest", None)
    for key in ("signed_at", "verified_at", "expires_at"):
        value = fields.get(key)
        fields[key] = datetime.fromisoformat(value) if isinstance(value, str) else value
    verification = fields.get("verification")
    if isinstance(verification, str):
        fields["verification"] = VerificationMethod(verification)
    return Attestation(**fields)
