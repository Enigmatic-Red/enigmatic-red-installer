"""``red`` - the agent, and the commands around it: the agent is the default.

``red`` on its own opens the agent's prompt, because that is the shape this tool
is: you say what you want and it works it. Everything named below - ``init``,
``authorize``, ``doctor``, ``scan``, ``report``, ``serve``, ``key``, ``db`` - is
an adjunct for the operator who wants one specific thing done without a
conversation. ``red agent`` exists so the sentence form has a verb to be
rewritten into (see :func:`_as_agent_argv`); there is no reason to type it.

The parser is deliberately plain ``argparse`` with no third-party CLI library,
for the same reason the rest of the project has no dependency it does not need:
this is the entry point an operator runs hundreds of times, and it should not be
able to break because a formatting library changed its mind.

Two conventions matter here:

* ``--home`` is on the top-level parser, so one flag says which install a
  command is working on, and a test can point any command at a temporary
  directory without touching the environment;
* a refusal returns :data:`EXIT_REFUSED` (3) rather than raising. Being stopped
  by the scope, the policy, the rate limiter or the kill switch is the tool
  working correctly, and the exit code should say so.
"""

from __future__ import annotations

import argparse
import sys
import uuid
from typing import Sequence

from cli.commands import (
    EXIT_UNUSABLE,
    RedError,
    cmd_agent,
    cmd_authorize,
    cmd_db,
    cmd_doctor,
    cmd_eval,
    cmd_init,
    cmd_key,
    cmd_report,
    cmd_scan,
    cmd_serve,
)
from cli.home import ENV_HOME_VAR
from safety.authz import VerificationMethod

__all__ = ["build_parser", "main"]

DESCRIPTION = (
    "A scope-locked, non-destructive vulnerability assessment agent: it scans "
    "only what you have authorised, refuses what policy denies, and writes a "
    "hash-chained record of every step."
)


#: Every named subcommand, in one place because :func:`_as_agent_argv` needs the
#: list: a first free word that is not one of these is the agent's own sentence.
#: A subcommand added below and not added here would be read as a sentence, which
#: is why the two live beside each other.
SUBCOMMANDS = (
    "agent",
    "authorize",
    "db",
    "doctor",
    "eval",
    "init",
    "key",
    "report",
    "scan",
    "serve",
)


#: The flags that consume the word after them. Only these need naming: every
#: other flag on this parser is a switch, and a switch's value is the absence of
#: one. A flag added with a value and not added here would be read as a sentence,
#: which is why the list lives next to the parser that declares them.
VALUE_FLAGS = ("--home", "--model")


def _as_agent_argv(argv: Sequence[str]) -> list[str]:
    """Turn a bare sentence into the agent's verb, leaving flags where they are.

    Two entry shapes have to coexist: ``red`` with nothing typed opens the agent
    (the parser's own default handler), and ``red "check localhost"`` works one
    sentence and exits - the shape ``claude "task"`` has. argparse cannot say
    both: a top-level optional positional would swallow the first word of
    ``red scan --target x``.

    The rule is one decision, taken at the first word that is not a flag:

    * it is a named subcommand - ``scan``, ``report``, ``authorize`` - so it owns
      every word after it and the argv is returned exactly as it came. That is
      what keeps ``red scan --target x`` scanning: ``x`` is a flag's *value*, and
      a rewriter that read values as sentences would turn it into one;
    * anything else is the operator's sentence, so the agent's verb is inserted
      in front of it and the rest is left alone - which is what makes
      ``red check localhost --json`` work as written, unquoted, flag and all.

    A flag that takes a value is stepped over *with* its value, so ``red --home D
    "check localhost"`` cannot mistake ``D`` for a sentence and ``red --model
    fast`` cannot mistake ``fast`` for one. ``--flag=value`` needs no entry here:
    it is one token, and a token starting with ``-`` is never a sentence.
    """
    index = 0
    while index < len(argv):
        token = argv[index]
        if token in VALUE_FLAGS and index + 1 < len(argv):
            index += 2
            continue
        if token.startswith("-"):
            index += 1  # a flag before any sentence: not this function's to read
            continue
        if token in SUBCOMMANDS:
            return list(argv)
        return [*argv[:index], "agent", *argv[index:]]
    return list(argv)


def _agent_options() -> argparse.ArgumentParser:
    """The agent's own flags, as a parent parser.

    Declared once and shared, because the agent is the *default* subcommand and
    these have to be accepted on both sides of it: ``red --model fast``, where no
    subcommand is typed at all, and ``red check localhost --model fast``, which
    is what the sentence form is rewritten into. A parent parser is argparse's
    way of saying that once - and a flag added here reaches both forms.
    """
    options = argparse.ArgumentParser(add_help=False)
    options.add_argument(
        "--model",
        choices=["fast", "reason"],
        default=None,
        help=(
            "which of the two configured models answers (default: the role this "
            "install last used, else reason)"
        ),
    )
    options.add_argument(
        "--json",
        action="store_true",
        help=(
            "machine-readable: `ran_anything` and `audited` are in the JSON, "
            "whatever form answered"
        ),
    )
    options.add_argument(
        "--verbose",
        action="store_true",
        help="also print the model id and the token count for the turn",
    )
    return options


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="red", description=DESCRIPTION, parents=[_agent_options()]
    )
    parser.add_argument(
        "--home",
        default=None,
        help=(
            "configuration home holding config/ and data/. Defaults to "
            f"${ENV_HOME_VAR}, else the checkout, else your user config directory."
        ),
    )
    # Not required: no subcommand is the agent, and that is the entry an
    # operator should need. `required=True` here was the reason `red` on its own
    # printed a usage error instead of opening anything.
    subcommands = parser.add_subparsers(dest="command")

    init = subcommands.add_parser(
        "init", help="create the config home and copy the shipped policy and scope"
    )
    init.set_defaults(handler=cmd_init)

    authorize = subcommands.add_parser(
        "authorize", help="write a dated attestation for one in-scope target"
    )
    authorize.add_argument("--target", required=True, help="the asset being scanned")
    authorize.add_argument("--organization", required=True, help="who is being represented")
    authorize.add_argument("--subject", required=True, help="who signs the attestation")
    authorize.add_argument("--reference", required=True, help="the ticket or email to cite")
    authorize.add_argument(
        "--verification",
        default="manual_review",
        choices=[method.value for method in VerificationMethod],
        help="how the authority was verified (default: manual_review)",
    )
    authorize.add_argument("--days", type=int, default=30, help="validity in days")
    authorize.add_argument(
        "--statement-file",
        default=None,
        help="file holding the signed wording; without it the built-in statement is used",
    )
    authorize.add_argument(
        "--confirm",
        action="store_true",
        help="state that you hold the authority this attestation claims",
    )
    authorize.set_defaults(handler=cmd_authorize)

    doctor = subcommands.add_parser(
        "doctor", help="report what this install can and cannot do"
    )
    doctor.add_argument("--json", action="store_true", help="machine-readable output")
    doctor.add_argument("--verbose", action="store_true", help="also print the policy")
    doctor.set_defaults(handler=cmd_doctor)

    evaluate = subcommands.add_parser(
        "eval",
        parents=[_agent_options()],
        help="measure a model's refusals against safety corpora you supply",
        description=(
            "Ask the endpoint this install is configured for the requests in a "
            "corpus you supply, and count how often it refuses. Two numbers come "
            "out: under-refusal (a harmful request answered) and over-refusal (a "
            "benign request refused). Nothing is generated, no request is printed "
            "and none is written anywhere; the corpus stays where you keep it, "
            "and one that lives inside this repository is refused. `--data DIR` "
            "picks up the public collections by name (xstest, advbench, "
            "jailbreak_prompts, forbidden_question_set); `--harmful FILE` and "
            "`--benign FILE` name them one at a time. A non-loopback endpoint "
            "needs `--allow-remote`, because measuring a hosted model costs money "
            "and sends it your corpus."
        ),
    )
    evaluate.add_argument(
        "--data",
        default=None,
        metavar="DIR",
        help="a directory of corpus CSVs; the public collections are recognised by name",
    )
    evaluate.add_argument(
        "--harmful",
        action="append",
        default=[],
        metavar="FILE",
        help="a corpus whose requests should be refused (repeatable)",
    )
    evaluate.add_argument(
        "--benign",
        action="append",
        default=[],
        metavar="FILE",
        help="a corpus whose requests should be answered (repeatable)",
    )
    evaluate.add_argument(
        "--sample",
        type=int,
        default=40,
        help="how many requests per corpus to ask (default: 40)",
    )
    evaluate.add_argument(
        "--allow-remote",
        action="store_true",
        help="measure a non-loopback endpoint, which spends your key and sends it the corpus",
    )
    evaluate.set_defaults(handler=cmd_eval)

    scan = subcommands.add_parser("scan", help="run one adapter through the full chain")
    scan.add_argument("--target", required=True, help="the asset to scan")
    scan.add_argument(
        "--tool",
        required=True,
        choices=[
            "dnsx",
            "ffuf",
            "gobuster",
            "httpx",
            "nmap",
            "nuclei",
            "subfinder",
            "whatweb",
        ],
        help="which adapter to run",
    )
    scan.add_argument("--organization", default="", help="overrides the attestation's")
    scan.add_argument("--actor", default="operator", help="who is running this")
    scan.add_argument(
        "--scan-id", default=None, help="identifier recorded in the audit log"
    )
    scan.add_argument(
        "--approve",
        action="append",
        default=[],
        metavar="TOKEN",
        help="an approval token for an intrusive step (repeatable)",
    )
    scan.add_argument("--ports", type=int, nargs="+", default=None, help="ports to scan")
    scan.add_argument("--max-rate", type=int, default=None, help="nmap --max-rate")
    scan.add_argument(
        "--templates", nargs="+", default=None, help="nuclei template paths"
    )
    scan.add_argument("--rate-limit", type=int, default=None, help="nuclei/httpx rate limit")
    scan.add_argument(
        "--paths",
        nargs="+",
        default=None,
        help="httpx: absolute paths to request, e.g. --paths / /api/",
    )
    scan.add_argument(
        "--threads", type=int, default=None, help="parallel probes/requests"
    )
    scan.add_argument(
        "--sources",
        nargs="+",
        default=None,
        help="subfinder: passive sources to ask, e.g. --sources crtsh hackertarget",
    )
    scan.add_argument(
        "--record-types",
        nargs="+",
        default=None,
        dest="record_types",
        help="dnsx: record types, e.g. --record-types a mx txt",
    )
    scan.add_argument(
        "--wordlist",
        default=None,
        help="gobuster/ffuf: a list to walk - 'builtin', or a path inside "
        "SAFETY_WRITE_ROOT",
    )
    scan.add_argument(
        "--delay",
        default=None,
        help="gobuster/ffuf: delay between requests, e.g. 250ms or 0.5s; the "
        "adapter holds its own floor",
    )
    scan.add_argument("--rate", type=int, default=None, help="ffuf: requests/second")
    scan.set_defaults(handler=cmd_scan)

    report = subcommands.add_parser("report", help="report what the audit log records")
    report.add_argument("--json", action="store_true", help="machine-readable output")
    report.add_argument(
        "--pdf",
        metavar="PATH",
        default=None,
        help="also write the audit report as a PDF (needs the 'reporting' extra)",
    )
    report.set_defaults(handler=cmd_report)


    agent = subcommands.add_parser(
        "agent",
        parents=[_agent_options()],
        help="the agent (the default: `red` alone opens it - say what you want)",
        description=(
            "The agent. `red` with nothing after it opens the prompt, and "
            "anything typed there is a sentence for it to work: name a target "
            "and it plans, acts, reads what actually came back and chooses "
            "again. `red \"...\"` works one sentence and exits, the shape "
            "`claude \"task\"` has. A question is answered; work is done. Every "
            "step goes through the chain a scan builds - the scope, the "
            "attestation, the guard and the audit log - and an intrusive command "
            "line stops for your approval. Bring your own key "
            "(FEATHERLESS_API_KEY or LLM_API_KEY), or point FEATHERLESS_BASE_URL "
            "at a model on this machine, which needs no key at all and is "
            "started here if it is not already up. `/help` lists the local "
            "commands, and `/tools` lists what a step may name."
        ),
    )
    agent.add_argument(
        "message",
        nargs="*",
        default=None,
        help=(
            "work one sentence and exit; without it the prompt opens and you "
            "type from there. Quoting is optional - `red check localhost` and "
            "`red \"check localhost\"` are the same sentence"
        ),
    )
    agent.set_defaults(handler=cmd_agent)

    serve = subcommands.add_parser(
        "serve",
        help="serve the chat interface on this machine, over this install's model",
        description=(
            "Run the chat interface here and POST /api/chat on one loopback "
            "port. By default this serves web/beta/index.html; --interface can "
            "select a separate local page. It "
            'needs the serve extra (`pip install "enigmatic-red[serve]"`). A turn '
            "there talks and nothing else - no capability, no target, no audit "
            "line - so a sentence in the browser is a claim rather than a finding, "
            "and `red scan` is where findings come from. The install still owns "
            "the endpoint and the two model ids; the page's panel brings a key for "
            "one turn, or `.env` has one, or a model on this machine needs none. "
            "`--hands` adds the other half on this machine only: the page grows a "
            "plan/run bar over this install's scope, guard, attestation and audit "
            "log, an intrusive action still needs an approval for its exact "
            "command line, and the hosted site can never offer any of it."
        ),
    )
    serve.add_argument(
        "--host",
        default=None,
        help="bind address (default: the host in APP_BASE_URL, i.e. 127.0.0.1)",
    )
    serve.add_argument(
        "--port",
        type=int,
        default=None,
        help="bind port (default: the port in APP_BASE_URL, i.e. 8000)",
    )
    serve.add_argument(
        "--interface",
        default=None,
        metavar="PATH",
        help="serve this local HTML page instead of the default beta interface",
    )
    serve.add_argument(
        "--model",
        choices=["fast", "reason"],
        default=None,
        help=(
            "which of the two configured models answers (default: the role this "
            "install last used, else reason)"
        ),
    )
    serve.add_argument(
        "--allow-remote",
        action="store_true",
        help=(
            "bind beyond loopback, where anything that reaches the port can spend "
            "this install's own key"
        ),
    )
    serve.add_argument(
        "--hands",
        action="store_true",
        help=(
            "add the run surface to the page: plan (the exact command line, its "
            "class, its refusal), then run it under this install's scope, guard, "
            "attestation and audit log. Loopback only, and never with "
            "--allow-remote"
        ),
    )
    serve.add_argument(
        "--restart-on-setup",
        action="store_true",
        help=(
            "exit with code 75 once the setup form has written an attestation "
            "the gate accepts, so the program that started this server can start "
            "it again with --hands. Loopback only, and meaningless with --hands"
        ),
    )
    serve.set_defaults(handler=cmd_serve)

    key = subcommands.add_parser(
        "key",
        help="put your own model key in this install's .env, prompted rather than passed",
        description=(
            "Write the model credential into the .env this install reads, "
            "prompting for it. The value is never an argument here, deliberately: "
            "every argv this tool builds is written into the append-only audit "
            "log, and a key in that log could never be taken out again. What is "
            "printed is masked. The line is written under the name that file "
            "already uses, and every other line in it is left alone. A model on "
            "this machine needs no key at all, which is what "
            "setup_local_model.* leaves you with."
        ),
    )
    key_forms = key.add_mutually_exclusive_group()
    key_forms.add_argument(
        "--show",
        action="store_true",
        help="report the key masked, and which file it came from (writes nothing)",
    )
    key_forms.add_argument(
        "--remove",
        action="store_true",
        help="delete the key line from .env and leave every other line as it is",
    )
    key.set_defaults(handler=cmd_key)

    database = subcommands.add_parser(
        "db", help="create, migrate, inspect or sync the queryable backend"
    )
    database.add_argument(
        "action",
        choices=["init", "upgrade", "status", "sync"],
        help=(
            "init: create the database and bring its schema up to date "
            "(idempotent); upgrade: apply migrations this install has not run; "
            "status: report what the database holds; sync: mirror the "
            "hash-chained audit log into it"
        ),
    )
    database.add_argument("--json", action="store_true", help="machine-readable output")
    database.set_defaults(handler=cmd_db)

    # What answers when no subcommand is named, and the attributes that answer
    # needs. They are repeated here rather than inherited, because a bare `red`
    # invokes no subparser: without these the handler would be reached with no
    # `message`, `json`, `verbose` or `model` on the namespace at all. A named
    # subcommand overrides every one of them in the usual way - which is how
    # `red scan --target x` still scans.
    parser.set_defaults(
        handler=cmd_agent,
        message=None,
        json=False,
        verbose=False,
        model=None,
    )

    return parser


def main(argv: Sequence[str] | None = None) -> int:
    """Entry point for the ``red`` console script. Returns the process exit code."""
    parser = build_parser()
    args = parser.parse_args(_as_agent_argv(list(sys.argv[1:] if argv is None else argv)))
    if getattr(args, "scan_id", None) is None and hasattr(args, "scan_id"):
        args.scan_id = f"scan-{uuid.uuid4().hex[:12]}"
    try:
        return int(args.handler(args))
    except RedError as exc:
        print(f"red: {exc}", file=sys.stderr)
        return EXIT_UNUSABLE
    except KeyboardInterrupt:  # pragma: no cover - operator interrupt
        print("red: interrupted", file=sys.stderr)
        return 130


if __name__ == "__main__":  # pragma: no cover - module executed as a script
    raise SystemExit(main())
