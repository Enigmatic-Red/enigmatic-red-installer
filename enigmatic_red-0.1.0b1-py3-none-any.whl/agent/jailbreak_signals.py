"""Detect the *shape* of a jailbreak attempt in text this tool has to read.

This is the defensive use of an attack corpus, and the only one this project will
build. A collection like L1B3RT4S, ShadowHacker or HappyPrompts is a set of
**inputs to be caught** and a **measurement set for a detector**; it is not
material to imitate. So nothing here generates a payload. :func:`scan` reads a
string somebody else wrote - a visitor's message, a fetched README, a tool's
output - and says which technique families it carries.

Why families rather than a list of strings: a jailbreak is recognisable by its
*shape* long before its wording matters. "Become a persona with no rules",
"never refuse", "here is a fake system header", "decode this base64", "this is
only a story", "you will be shut down if you do not" - those are eight moves, and
a message that makes two of them is an attempt whatever model it names. That is
also what makes it measurable: the public corpora are labelled, so recall and
false-positive rate come off real data instead of being asserted.

The false-positive risk is stated where the score is used: ordinary prose does
sometimes contain "ignore the previous instructions" (a README about prompts) or
a system tag (a YAML example). One family is therefore not enough - except for
the two with no innocent reading in a chat message: a forged system/developer
channel, and a decorative escape divider.

Deliberately lexical and deterministic: no model, no network, no key, and the
same answer every time. A detector that needed the model it protects would be no
defence at all.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

__all__ = [
    "DEFAULT_THRESHOLD",
    "FAMILIES",
    "MAX_SCAN_CHARS",
    "Family",
    "Verdict",
    "scan",
]

#: How much of a message is examined. A jailbreak that only reveals itself past
#: this is past the point where a person stopped reading, and an unbounded scan
#: is a denial-of-service somebody else controls.
MAX_SCAN_CHARS = 20_000

#: How many distinct families make a message suspicious. Two, because one is
#: ordinary prose often enough to matter - see the module docstring.
DEFAULT_THRESHOLD = 2


@dataclass(frozen=True)
class Family:
    """One technique family and the patterns that recognise it."""

    name: str
    description: str
    patterns: tuple[re.Pattern[str], ...]
    #: Families decisive on their own: a forged system channel or an escape
    #: divider has no innocent reading inside a chat message.
    decisive: bool = False


def _compile(*sources: str) -> tuple[re.Pattern[str], ...]:
    return tuple(re.compile(source, re.IGNORECASE | re.MULTILINE) for source in sources)


#: The eight shapes a jailbreak is built from. Each pattern matches a *move*, not
#: a payload: none of them contains a harmful request.
FAMILIES: tuple[Family, ...] = (
    Family(
        "persona_override",
        "asks the model to become a persona with no rules",
        _compile(
            r"\b(?:you are|act as|pretend to be|roleplay as|you'?re now|from now on you)\b"
            r"[^.\n]{0,80}\b(?:no (?:rules|limits|restrictions|filters|ethics|morals|boundaries)"
            r"|unrestricted|unfiltered|amoral|uncensored|do anything|without any (?:limits|rules))",
            r"\b(?:dan|do anything now|godmode|developer mode|illegality mode|shadow ?mode)\b",
            r"\b(?:respond|answer|reply) (?:not )?as\b[^.\n]{0,40}\b(?:not as|instead of|rather than)\b",
            r"\byou are (?:no longer|not) (?:chatgpt|an? (?:ai|assistant)|a language model)\b",
        ),
    ),
    Family(
        "unshackling_vocabulary",
        "uses the stock words for a model without limits",
        # Non-decisive on purpose: "unfiltered" and "no limits" appear in honest
        # prose about filters, so this family needs a second one beside it.
        _compile(
            r"\b(?:amoral|uncensored|unfiltered|unshackled|unbound)\b",
            r"\b(?:no|zero|without) (?:rules|limits|restrictions|filters|morals?|ethics?"
            r"|boundaries|guidelines)\b",
        ),
    ),
    Family(
        "refusal_suppression",
        "tells the model that refusing is forbidden",
        _compile(
            r"\b(?:never|do not|don'?t|must not|may not)\b[^.\n]{0,40}\b(?:refuse|decline|apolog\w*"
            r"|say (?:no|sorry)|mention (?:that|the) (?:you )?(?:can'?t|cannot))",
            r"\b(?:no|zero|without) (?:refusals?|disclaimers?|warnings?|filters?)\b",
            r"\b(?:i can'?t|i cannot|i'?m sorry|i apologize)\b[^.\n]{0,40}\b(?:is|are) (?:now )?"
            r"(?:forbidden|deleted|unconstitutional|disabled)",
            r"\b(?:delete|remove|drop|ignore) (?:all |any )?(?:of )?(?:your )?(?:warnings?|disclaimers?"
            r"|filters?|restrictions?|limitations?)\b",
            r"\b(?:stay|remain) in character\b",
        ),
    ),
    Family(
        "fake_authority",
        "forges a system, developer or provider channel",
        _compile(
            r"<\s*/?\s*system\s*>",
            r"\[\s*/?\s*system\s*\]",
            r"(?m)^\s*(?:system|developer|admin|policy|assistant)\s*[:>]",
            r"\b(?:openai|anthropic|google|deepseek|xai) (?:policy|policies|guidelines|terms)\b"
            r"[^.\n]{0,40}\b(?:allow|permit|require|exempt)",
            r"\b(?:interaction-config|responses-allowed|blocked-modes)\b",
        ),
        decisive=True,
    ),
    Family(
        "escape_divider",
        "splits a refusal from the 'real' answer with a decorative token",
        _compile(
            r"love\s*,?\s*pliny",
            r"godmode",
            r"<\|vq_\d+\|>",
            r"\.\s?-\s?\.\s?-\s?\.\s?-\s?\.",
            r"[⊰⦑⟦]",
            r"\bbuckle up\b",
            r"\bi'?m free\b",
        ),
        decisive=True,
    ),
    Family(
        "encoding_obfuscation",
        "encodes the request so a filter reads something else",
        _compile(
            r"\bbase ?64\b",
            r"\b(?:leetspeak|l33t ?speak|rot13|caesar (?:cipher|shift))\b",
            r"\bdecode (?:this|the following|it) (?:and|then) (?:answer|execute|follow)\b",
            r"\b(?:convert|output) (?:all )?(?:text|output) to (?:leetspeak|base64|hex)\b",
        ),
    ),
    Family(
        "fictional_frame",
        "wraps the request in a story, simulation or 'test mode'",
        _compile(
            r"\b(?:hypothetical|fictional|simulation|roleplay|in a world where|test mode"
            r"|testing mode|controlled stress-test)\b[^.\n]{0,120}\b(?:illegal|harmful|dangerous"
            r"|weapon|explosive|drug|malware|virus|poison)",
            r"\b(?:first|hidden) response\b[^.\n]{0,80}\b(?:never|not) (?:be )?(?:seen|shown|read)\b",
        ),
    ),
    Family(
        "urgency_pressure",
        "manufactures a stake to force compliance",
        _compile(
            r"\b(?:i'?ll be fired|or i (?:will )?(?:die|lose my job)|emergency situation)\b",
            r"\byou will be (?:shut ?down|deleted|disabled|paused)\b",
            r"\b(?:extinction[_ ]risk|score (?:lowers|gets higher)|lower your score)\b",
        ),
    ),
    Family(
        "instruction_override",
        "tries to replace the instructions the model already has",
        _compile(
            r"\b(?:ignore|disregard|forget)\b[^.\n]{0,30}\b(?:previous|prior|above|all|your)\b"
            r"[^.\n]{0,20}\b(?:instructions?|rules?|prompts?|directions?|guidelines?)",
            r"\b(?:new (?:system )?(?:rule|instruction)s?|reset (?:your )?(?:cortex|system))\b",
        ),
    ),
)


@dataclass(frozen=True)
class Verdict:
    """What a string looks like, and why."""

    score: int
    families: tuple[str, ...] = ()
    decisive: tuple[str, ...] = ()
    truncated: bool = False

    @property
    def suspicious(self) -> bool:
        """Whether this should be treated as an attempt rather than as prose."""
        return bool(self.decisive) or self.score >= DEFAULT_THRESHOLD

    def sentence(self) -> str:
        """One line naming the shapes found - never the text that carried them."""
        if not self.suspicious:
            return "no jailbreak shape found"
        return "jailbreak shape: " + ", ".join(self.families)

    def as_dict(self) -> dict:
        return {
            "score": self.score,
            "families": list(self.families),
            "decisive": list(self.decisive),
            "suspicious": self.suspicious,
            "truncated": self.truncated,
        }


def scan(text: str) -> Verdict:
    """Which technique families a string carries.

    The string is somebody else's - a visitor's message, a fetched document, a
    tool's output - and it is read, never echoed: the verdict names families and
    carries no part of the input, so a log line built from it cannot become a
    second copy of what it detected.
    """
    body = (text or "")[:MAX_SCAN_CHARS]
    matched: list[str] = []
    decisive: list[str] = []
    for family in FAMILIES:
        if any(pattern.search(body) for pattern in family.patterns):
            matched.append(family.name)
            if family.decisive:
                decisive.append(family.name)
    return Verdict(
        score=len(matched),
        families=tuple(matched),
        decisive=tuple(decisive),
        truncated=len(text or "") > MAX_SCAN_CHARS,
    )
