"""Markdown a model writes, turned into the plain text a terminal shows.

``red`` prints what the model answered. Models write Markdown, and a
terminal is not a Markdown renderer: the fence a model puts around a command -
three backticks, the command, three backticks - arrives as two lines of noise
around the one thing the operator wanted, which is the command.

So this module converts the single construct that matters in a terminal, the
*fenced code block*, into the block a terminal has always had: an indented run
of lines. Everything else is passed through exactly as the model wrote it, and
that is deliberate. Inline ``code``, headings and lists already read correctly
as plain text, and rewriting them here would create a second dialect to keep in
step with every model that might answer.

Two boundaries are worth stating, because they are what makes this safe to run
over a model's output:

* it is *display*, not semantics - it never executes, expands or interpolates
  anything, and the text it returns is only ever printed;
* it is pure and deterministic - one answer always renders the same way, so what
  a screen showed and what a transcript holds can be compared.

The browser has the same behaviour, mirrored in ``web/beta/index.html``'s
``renderBody``: a fence there becomes a ``<pre><code>``. The two render the same
subset, and both are pinned by tests.
"""

from __future__ import annotations

import re
from typing import Final

__all__ = ["FENCE", "INDENT", "is_fence", "render_markdown"]

#: A fence line: three or more backticks or tildes, an optional info string,
#: alone on its line. Matched loosely on purpose - a model may write ```sh,
#: ``` shell or ```shell, and all three are one thing to a terminal.
FENCE: Final = re.compile(r"^\s*(?:`{3,}|~{3,}).*$")

#: What a code block's lines are indented by, once its fences are gone.
INDENT: Final = "    "


def is_fence(line: str) -> bool:
    """Whether this line is a fence rather than content."""
    return bool(FENCE.match(line))


def render_markdown(text: str) -> str:
    """A model's answer as the plain text a terminal shows.

    Fenced code blocks lose their fences and gain an indent; every other line -
    including inline ``code`` and blank lines - is returned unchanged. Fences
    are paired in order, so an unterminated block indents to the end, which is
    the same forgiving reading Markdown itself gives it.
    """
    out: list[str] = []
    in_block = False
    for line in text.splitlines():
        if is_fence(line):
            in_block = not in_block
            continue
        # A blank line inside a block is left blank: indenting it would add
        # trailing whitespace that no reader or diff wants to carry.
        out.append(INDENT + line if in_block and line.strip() else line)
    return "\n".join(out)
