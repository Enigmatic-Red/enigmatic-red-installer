"""Bring a model on this machine up, so an opened prompt can act.

The agent's first prompt is only useful if something answers it. The installer
starts ``ollama serve`` when it sets the machine up, but that process does not
survive a reboot, and an operator who opens the agent afterwards would get a
prompt and then a connection failure - which is the opposite of opening it and
having it work.

So this is the one thing the agent does *before* it asks anything: if the
endpoint in ``.env`` is on this machine, nothing is listening on its port and
``ollama`` is installed, start it and wait for the port. A remote endpoint is
never touched - that is somebody else's process and somebody else's uptime - and
nothing here is a control: failing to start is reported as a sentence and the
prompt still opens, because a model that is down is not a reason to hide the
scope and the audit log.

The probe is a TCP connect rather than an HTTP request on purpose. It answers
"is anything listening", it needs no client and no credential, and it cannot be
confused by something in front of the port that answers 401 or 404 - what is
being waited for is the service, not a particular route on it.

Deliberately parallel to ``installer/launcher.py``'s ``ollama_is_up`` and
``start_ollama``. The two cannot share code: the installer runs *before* this
package exists on the machine, and the package is installed after the installer
has finished. ``tests/test_localmodel.py`` pins the behaviour they must agree on.
"""

from __future__ import annotations

import ipaddress
import os
import shutil
import socket
import subprocess
import time
from pathlib import Path
from urllib.parse import urlsplit

__all__ = [
    "DEFAULT_OLLAMA_PORT",
    "START_TIMEOUT_S",
    "endpoint_address",
    "ensure_local_model",
    "is_loopback_url",
    "is_up",
    "ollama_binary",
]

#: How long a TCP connect is given before the port counts as down. Short: the
#: question is whether a service is listening on a local address, which either
#: accepts at once or is not there.
PROBE_SECONDS = 0.4

#: How long ``ollama serve`` is given to bind its port before we stop waiting.
#: The installer is equally patient, for the same reason: a cold start on a
#: loaded machine is slow, and a slow start is not a failure.
START_TIMEOUT_S = 20.0

#: Where ``ollama serve`` listens unless told otherwise.
DEFAULT_OLLAMA_PORT = 11434

#: Set this to anything but ``""`` or ``0`` and nothing is ever started. It
#: exists for exactly one reason: the suite must never start a service (see
#: ``BETA.md``'s promise, and ``tests/conftest.py``, which sets it), and an
#: operator on a shared machine may want the same. Starting a model is a
#: convenience, so the escape hatch is a variable rather than a flag: there is
#: no command line here to put one on.
NO_START_VARIABLE = "RED_NO_MODEL_START"


def _disabled() -> bool:
    """Whether this process has been told not to start anything."""
    return os.environ.get(NO_START_VARIABLE, "").strip() not in ("", "0")


def endpoint_address(base_url: str) -> tuple[str, int] | None:
    """The ``(host, port)`` an endpoint URL names, or ``None`` if it names none."""
    parts = urlsplit(base_url if "//" in base_url else f"//{base_url}")
    host = parts.hostname or ""
    if not host:
        return None
    try:
        port = parts.port
    except ValueError:
        return None
    if port is None:
        port = 443 if parts.scheme == "https" else 80
    return host, int(port)


def _is_loopback(host: str) -> bool:
    """Whether a host is this machine and nothing else.

    Deliberately tighter than :func:`agent.providers.base.host_is_local`, which
    answers "does this endpoint need a credential" and says yes for a LAN
    address too - a model on the operator's own network. Here the question is
    whether *we* may start the process, and the answer is yes only for an
    address that cannot be anybody else's machine.
    """
    name = host.strip().strip("[]").lower()
    if name in {"", "localhost"}:
        return True
    try:
        return ipaddress.ip_address(name).is_loopback
    except ValueError:
        return False  # a name, or a wildcard: somebody else's process


def is_loopback_url(base_url: str) -> bool:
    """Whether an endpoint is this machine - and an unset one is **not**.

    Deliberately stricter than :func:`agent.providers.base.host_is_local`, which
    answers "does this need a credential" and treats an empty URL as local
    because nothing remote is reachable from it. That is true of a request, and
    false of a *provider*: with no endpoint set the client falls back to its own
    hosted default, so an empty value is the most remote thing there is. A guard
    written against ``host_is_local`` therefore passes a call it meant to stop -
    measured, on a run that reached a hosted endpoint and retried a read timeout.
    """
    address = endpoint_address(base_url)
    return address is not None and _is_loopback(address[0])


def is_up(base_url: str) -> bool:
    """Whether anything is listening on the endpoint's host and port."""
    address = endpoint_address(base_url)
    if address is None:
        return False
    try:
        with socket.create_connection(address, timeout=PROBE_SECONDS):
            return True
    except OSError:
        return False


def ollama_binary() -> str | None:
    """``ollama`` on PATH, or where the Windows installer leaves it."""
    found = shutil.which("ollama")
    if found:
        return found
    guess = (
        Path(os.environ.get("LOCALAPPDATA", ""))
        / "Programs"
        / "Ollama"
        / "ollama.exe"
    )
    return str(guess) if guess.is_file() else None


def ensure_local_model(base_url: str) -> str:
    """Start the model on this machine if it is configured and not up.

    Returns a sentence for the operator when something was done or went wrong,
    and ``""`` when there was nothing to do - which is the common case: a remote
    endpoint, a service already listening, or nothing installed to start. Every
    one of those is a reason to say nothing rather than a reason to stop.
    """
    if _disabled():
        return ""  # a test, or an operator who said not to start anything
    address = endpoint_address(base_url)
    if address is None or not _is_loopback(address[0]):
        return ""  # somebody else's process, so somebody else's uptime
    if is_up(base_url):
        return ""
    binary = ollama_binary()
    if binary is None:
        return (
            f"  model        nothing is listening on {base_url} and `ollama` is "
            "not installed:\n"
            "               the prompt opens, and a step will fail until a model "
            "answers.\n"
            "               `setup_local_model.*` puts one here, and `red doctor` "
            "says what this\n"
            "               install has."
        )
    environment = dict(os.environ)
    if address[1] != DEFAULT_OLLAMA_PORT:
        environment["OLLAMA_HOST"] = f"{address[0]}:{address[1]}"
    try:
        subprocess.Popen(
            [binary, "serve"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
            env=environment,
            creationflags=getattr(subprocess, "DETACHED_PROCESS", 0),
        )
    except OSError as exc:
        return f"  model        could not start `{binary} serve`: {exc}"
    deadline = time.monotonic() + START_TIMEOUT_S
    while time.monotonic() < deadline:
        if is_up(base_url):
            return f"  model        started `{binary} serve` for {base_url}"
        time.sleep(0.2)
    return (
        f"  model        started `{binary} serve`, and nothing bound {base_url} "
        f"within {int(START_TIMEOUT_S)}s"
    )
