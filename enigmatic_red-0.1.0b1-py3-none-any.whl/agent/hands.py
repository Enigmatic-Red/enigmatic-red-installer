"""``red serve --hands`` - the page's run surface, on this machine, and the
approval that gates it.

``web/beta/index.html`` posts to the host that served it, so a checkout served
by ``red serve`` had one half of the product: the conversation. This module is
the other half, and it is *opt-in* and *local*, because it is where the things a
hosted site can never have actually live:

* a :class:`agent.session.ScanSession` - the scope file, the guard, the dated
  attestation, the append-only audit log and the kill switch - plus a
  :class:`agent.registry.Registry` whose guard is that session's own guard;
* a plan is the scope's own answer about the target plus
  :meth:`~agent.registry.Registry.preflight` and nothing else, so what the page
  shows *before* anything is pressed is the exact argv that would run, its
  action class, and the refusal it would get;
* a run is :meth:`~agent.registry.Registry.execute` with
  :meth:`~agent.session.ScanSession.context`, so the adapter re-checks the kill
  switch, the authorization, the scope, the guard and the limiter for itself. A
  plan is a request, not a permission;
* an intrusive action is approved by *exact command line* - the rule
  ``red scan --approve`` already uses - and an approval for a different line
  authorises nothing. A forbidden class cannot be approved however many times
  the page asks;
* ``ran_anything`` and ``audited`` are read off what happened, not promised: the
  run is audited before the process starts, so a refusal after the fact still
  leaves the attempt on the record.

Three sentences that keep this honest, and each is enforced rather than stated:

* **The hosted site has none of this and never will**: no scope file, no
  attestation, no audit log, no subprocess, no credential. So the button lives
  here, and the page asks ``GET /api/capabilities`` what it is talking to. A
  site that answered ``runs: true`` would be making exactly the claim this
  project exists not to make.
* **The page is the same file on both surfaces.** Nothing is forked for the
  local build: the run bar renders only when that probe says a chain is there.
* **A bind beyond loopback has no hands at all.** ``--allow-remote`` and
  ``--hands`` together are refused by the command, not quietly downgraded: this
  process can run tools against an authorised target, and the one thing that
  must never happen is that capability becoming reachable from a network.

``AGENT_MODE`` names how much of this surface an instance exposes, and it can only
ever *narrow*: ``plan`` mounts these routes and refuses to execute, so the exact
argv and the guard's answer - which is what a plan is - are the answer and nothing
runs; ``run`` executes. ``chat`` never builds this class at all. A mode asking for
more than the process holds is refused by the command rather than downgraded here,
and in no mode does the word become a permission: the scope file, the attestation
and the guard decide what runs, in all three.

A sentence naming a target, typed into the composer, is the third way in, and it
is the terminal's own behaviour: ``red`` reads such a sentence with no tools
on the call and works it. Here it is :meth:`Hands.brief` and :meth:`Hands.mission`,
in ``run`` mode only, under *this* session and *this* registry - the chain
``red scan`` builds. Every step is pre-flighted, audited before it runs, and an
intrusive step needs the exact command line the page approved it as; with no
approval that step does not run.

    red serve --hands                  # loopback only, same page, run bar appears
    red scan --tool nmap --target ...  # the same chain, in a terminal
"""

# No ``from __future__ import annotations`` here, deliberately - the same reason
# ``agent/serve.py`` gives for doing without it: FastAPI reads these endpoint
# signatures at run time, and a postponed annotation on ``request`` would not
# resolve to the ``Request`` imported inside ``Hands.mount``. It would instead be
# treated as a field to validate, so a documented POST body would answer 422 and
# ``Hands.answer`` would never run at all. ``tests/test_hands.py`` is what holds
# this: every route here is driven with the body the class docstring documents.
import json
import time
from typing import Any

from agent.registry import Registry
from agent.session import ScanSession
from safety.errors import (
    ApprovalRequired,
    AuthorizationError,
    ForbiddenActionError,
    KillSwitchEngaged,
    RateLimitExceeded,
    ScopeViolation,
    ToolExecutionError,
)

__all__ = [
    "MAX_OUTPUT",
    "MODES",
    "REFUSALS",
    "RUNS_PER_WINDOW",
    "STATUS",
    "WINDOW_SECONDS",
    "Hands",
    "Runs",
]

#: The modes an instance can be in, named by ``AGENT_MODE``. ``chat`` is the
#: hosted site's shape and the default for a command that builds no chain; the
#: other two are this module's, and the difference between them is whether a
#: page-approved command line may execute.
MODES = ("chat", "plan", "run")

#: Runs per client address per window, counted in memory. Deliberately its own
#: budget, separate from the conversation's five turns: this one spends the
#: target's patience and the customer's audit log, not a model's tokens.
RUNS_PER_WINDOW = 5
WINDOW_SECONDS = 600

#: Characters of each stream handed back to the page. The runner already caps
#: what it keeps; this is the smaller, page-shaped cap for what is *rendered*.
MAX_OUTPUT = 4000

#: The errors a control raises when it stops a run. Anything else is a bug and
#: reaches the page as one, which is the same split ``red scan`` makes.
REFUSALS = (
    ScopeViolation,
    ForbiddenActionError,
    ApprovalRequired,
    AuthorizationError,
    RateLimitExceeded,
    KillSwitchEngaged,
)

#: Pre-flight code -> HTTP status. The status is about what the page should do
#: next: fix the request (400), ask a human for *this exact command* (409), or
#: stop (403/404).
STATUS = {
    "bad_arguments": 400,
    "bad_target": 400,
    "unknown_capability": 404,
    "approval_required": 409,
    "forbidden": 403,
    "unauthorized": 403,
    "out_of_scope": 403,
}


class Runs:
    """Runs per client address per wall-clock window, in memory only.

    The same shape as the conversation's counter and for the same reason: this
    backend answers one operator on loopback, so the count exists to keep the
    page's own sentence true rather than to defend a service. Restarting resets
    it, which is honest - a new process has no window yet.
    """

    def __init__(
        self, limit: int = RUNS_PER_WINDOW, seconds: int = WINDOW_SECONDS
    ) -> None:
        self.limit = limit
        self.seconds = seconds
        self._seen: dict[str, list[float]] = {}

    def take(self, client: str) -> tuple[bool, int]:
        """Count this run. Returns ``(allowed, runs_left_after_it)``."""
        if self.limit <= 0:
            return True, 0
        now = time.monotonic()
        kept = [at for at in self._seen.get(client, []) if now - at < self.seconds]
        allowed = len(kept) < self.limit
        if allowed:
            kept.append(now)
        self._seen[client] = kept
        return allowed, max(0, self.limit - len(kept))

    def left_for(self, client: str) -> int:
        """How many runs this address has left, without spending one."""
        if self.limit <= 0:
            return 0
        now = time.monotonic()
        kept = [at for at in self._seen.get(client, []) if now - at < self.seconds]
        return max(0, self.limit - len(kept))

    def sentence(self) -> str:
        return (
            f"this address has used all {self.limit} runs in the current "
            f"{round(self.seconds / 60)}-minute window"
        )


class Hands:
    """The run surface: one chain, two routes, and no third way in.

    Args:
        session: the scan session this surface runs under. Its scope, guard,
            attestation, audit log and kill switch are the enforcement; nothing
            here can widen them.
        registry: the registered capabilities, built with *this* session's guard
            so the answer a plan shows is the answer a run receives.
        org, actor: who the audit log says asked. ``actor`` defaults to the page
            rather than the operator's login name: the log records that the
            browser asked, and the attestation names the human who authorised it.
        runs, window: the run budget, see :data:`RUNS_PER_WINDOW`.
    """

    def __init__(
        self,
        *,
        session: ScanSession,
        registry: Registry,
        org: str = "",
        actor: str = "page",
        runs: int = RUNS_PER_WINDOW,
        window: int = WINDOW_SECONDS,
        mode: str = "run",
    ) -> None:
        if mode not in MODES:
            raise ValueError(f"{mode!r} is not a mode: {', '.join(MODES)}")
        if mode == "chat":
            # Asking for the run surface in the one mode that exposes none is a
            # contradiction, and `cli.commands` refuses it before getting here.
            # This is the same refusal for a caller that did not: an object that
            # mounts a run surface it will not run is worse than no object.
            raise ValueError(
                "hands in chat mode would expose a run surface and run nothing; "
                "do not build them, or pick plan or run"
            )
        self.session = session
        self.registry = registry
        self.org = org
        self.actor = actor or "page"
        self.mode = mode
        self.runs = Runs(runs, window)

    # ------------------------------------------------------------- what it is
    def describe(self) -> dict[str, Any]:
        """What the page is told it may do, in the page's own vocabulary."""
        return {
            "mode": self.mode,
            # Plan is real in either mode: the exact argv and the guard's answer
            # are the scope's and the registry's, not this word's.
            "plan": True,
            "runs": self.mode == "run",
            "audited": True,
            "actor": self.actor,
            "org": self.org,
            "audit_path": str(self.session.audit.path),
            "audit_seq": self.session.audit.last_seq,
            "tools": list(self.registry.names),
            "capability_details": {
                capability.name: {
                    "summary": capability.summary,
                    "parameters": capability.parameters,
                    "target_kind": capability.target_kind,
                }
                for capability in self.registry.capabilities
            },
            "classes": {
                name: self.registry.class_for(name).value
                for name in self.registry.names
            },
            "needs_approval": [
                name
                for name in self.registry.names
                if self.registry.requires_approval(name)
            ],
            "runs_per_window": self.runs.limit,
            "window_seconds": self.runs.seconds,
            "note": (
                "every run is audited before the process starts; an intrusive "
                "action needs the exact command line it was approved as"
            ),
        }

    # ---------------------------------------------------------------- routing
    def mount(self, app: Any) -> None:
        """Add ``POST /api/plan``, ``POST /api/run`` and ``GET /api/hands``.

        Mounted by :func:`agent.serve.create_app` only when the command was
        asked for hands, so the routes do not exist on a talk-only backend and a
        request to either is a 404 there rather than a quiet refusal.

        ``Request`` is imported here rather than at the top of the module because
        ``agent.hands`` is imported by ``cli.commands``, which has to work without
        the ``serve`` extra installed. It is used as the *annotation* rather than
        ``Any``, and that is not cosmetic: FastAPI reads any other annotation as a
        request-body field, so ``async def plan(request: Any)`` accepts
        ``{"request": ...}`` and answers ``422`` to the documented body - which is
        what ``tests/test_hands.py`` caught. The annotation is the class object
        itself, so FastAPI has no forward reference to resolve and the local
        binding is enough.
        """
        from fastapi import Request

        @app.get("/api/hands")
        def explain() -> Any:
            """What this surface is, for anyone who opens the route."""
            from fastapi.responses import JSONResponse

            return JSONResponse(
                {
                    **self.describe(),
                    "routes": {
                        "plan": 'POST {"tool": "nmap", "target": "127.0.0.1", '
                        '"options": {}}',
                        "run": 'POST {"tool": "nmap", "target": "127.0.0.1", '
                        '"options": {}, "approve": ["<the exact command line>"]}',
                    },
                    "equivalent": "red scan --tool <tool> --target <target>",
                }
            )

        @app.post("/api/plan")
        async def plan(request: Request) -> Any:
            """What would run: the exact command line, its class, its refusal."""
            return await self.answer(request, act=False)

        @app.post("/api/run")
        async def run(request: Request) -> Any:
            """Do it, under this session's chain, and write it down."""
            return await self.answer(request, act=True)

    # ------------------------------------------------------------- a sentence
    async def brief(
        self,
        provider: Any,
        text: str,
        *,
        history: Any = (),
        role: str = "reason",
    ) -> Any | None:
        """Read one sentence: is it work, and on what? Runs nothing.

        ``None`` means two different things and both are real - this instance is
        not in ``run`` mode, or the sentence was a question - and neither of them
        has spent anything, which is why this half is separate from
        :meth:`mission`. The reading carries no tools, so it cannot act by being
        wrong (the same reason :func:`agent.mission.understand` carries none), and
        a sentence that turns out to be a question must not spend a run.
        """
        from agent.mission import understand

        if self.mode != "run":
            return None
        reading = await understand(provider, text, history=history, role=role)
        return reading if reading.is_run else None

    async def mission(
        self,
        *,
        provider: Any,
        brief: Any,
        history: Any = (),
        role: str = "reason",
        approved: Any = None,
    ) -> dict[str, Any]:
        """Work a reading to the end of its budget, under this session's chain.

        ``approved`` is the page's Confirm: the exact command lines a human
        agreed to, in the shape ``POST /api/run`` takes. It is handed to the loop
        as the ``confirm`` decision, so an intrusive step is shown its plan and
        runs only if *that* line is in the set - a mission cannot spend an
        approval it was not given, and no approval means no.

        Everything here is the scan chain's own: the scope and the attestation
        are checked before the first step (:func:`agent.mission.run_mission`),
        every step is pre-flighted against this registry, and the adapter audits
        before it spawns. ``ran_anything`` and ``audited`` are read off the audit
        log afterwards rather than asserted, which is what makes them worth
        printing.
        """
        from agent.mission import run_mission

        allowed_lines = self._approved(approved) or frozenset()
        before = self.session.audit.last_seq
        scan_id = f"serve-{time.strftime('%Y%m%dT%H%M%S')}-{before + 1}"
        worked = await run_mission(
            provider=provider,
            registry=self.registry,
            session=self.session,
            brief=brief,
            history=history,
            role=role,
            scan_id=scan_id,
            confirm=lambda plan: bool(plan.command)
            and plan.command.strip() in allowed_lines,
        )
        return {
            "answer": (
                worked.summary
                or worked.sentence
                or worked.stop_reason
                or "the mission stopped without a summary"
            ),
            "lines": list(worked.lines()),
            "mission": worked.describe(),
            "steps": len(worked.steps),
            "ran_anything": bool(worked.ran_steps),
            "audited": self.session.audit.last_seq > before,
            "audit_seq": self.session.audit.last_seq,
            "audit_path": str(self.session.audit.path),
            "total_tokens": worked.total_tokens,
            "model": worked.model,
            "stop_reason": worked.stop_reason,
        }



    # ------------------------------------------------------------- one request
    async def answer(self, request: Any, *, act: bool) -> Any:
        """Plan or run one named capability against one named target.

        Everything a request can get wrong is refused before a tool exists, in
        the same words ``red scan`` uses, and the two refusals that matter are
        about claims rather than prose: an approval authorises *one exact
        command line*, and a plan is never treated as one.
        """
        from fastapi.responses import JSONResponse

        content_type = (request.headers.get("content-type") or "").lower()
        if "application/json" not in content_type:
            return self._refuse(
                415,
                'this endpoint takes JSON: send {"tool": "nmap", '
                '"target": "127.0.0.1"}',
            )
        try:
            body = await request.json()
        except Exception:  # noqa: BLE001 - every parse failure is the same 400
            return self._refuse(400, "the request body is not valid JSON")
        if not isinstance(body, dict):
            return self._refuse(400, "the request body is not a JSON object")

        tool = str(body.get("tool") or "").strip()
        if not tool:
            return self._refuse(
                400,
                "nothing to do: name a tool. This scan can call: "
                f"{', '.join(self.registry.names)}",
            )
        if tool not in self.registry:
            return self._refuse(
                404,
                f"{tool!r} is not a registered capability. This scan can call: "
                f"{', '.join(self.registry.names)}",
            )
        target = body.get("target")
        if not isinstance(target, str) or not target.strip():
            return self._refuse(400, "nothing to do: name a target")
        options = body.get("options") or {}
        if not isinstance(options, dict):
            return self._refuse(
                400, "options must be a JSON object of the documented keys"
            )
        approved = self._approved(body.get("approve"))
        if approved is None:
            return self._refuse(
                400,
                'approve must be a list of exact command lines, or absent: send '
                '{"approve": ["<the command a plan printed>"]}',
            )

        arguments: dict[str, Any] = {"target": target.strip()}
        arguments.update({str(key): value for key, value in options.items()})

        # The scope, before anything else: the adapter re-checks it at run time
        # (`ToolAdapter._assert_in_scope`), and a plan that said "would run"
        # about a target this install was never authorised for would be the one
        # kind of wrong this page must not be. It costs no process to ask.
        allowed_target = self.session.scope.check(target.strip())
        if not allowed_target.allowed:
            return self._refuse(
                403,
                allowed_target.reason,
                target=target.strip(),
                command="",
                action_class="",
                refusal={
                    "code": "out_of_scope",
                    "reason": allowed_target.reason,
                    "matched_rules": (
                        [allowed_target.matched_rule]
                        if allowed_target.matched_rule
                        else []
                    ),
                    "action_class": "",
                },
                lines=[f"refused: {allowed_target.reason}"],
            )

        # Pre-flight first, in *both* modes, and it is the whole of plan mode:
        # the guard's answer about this exact argv is the answer the run will
        # get one step later, so the page can show the truth before the button.
        flight = self.registry.preflight(tool, arguments, approved_commands=approved)
        described = flight.describe()

        if not act:
            return JSONResponse(
                content={
                    **described,
                    "planned": True,
                    "target": target.strip(),
                    "ran_anything": False,
                    "audited": False,
                    "runs_left_in_window": self.runs.left_for(self._client(request)),
                    "lines": self._plan_lines(flight),
                }
            )

        if not flight.ok:
            refusal = flight.refusal
            code = refusal.code if refusal is not None else "forbidden"
            return self._refuse(
                STATUS.get(code, 403),
                refusal.reason if refusal is not None else "this action cannot run",
                command=flight.command,
                action_class=described["action_class"],
                refusal=described.get("refusal"),
                lines=self._plan_lines(flight),
            )

        if act and self.mode != "run":
            # The mode narrows, it never authorises: the plan above is still the
            # real argv and the guard's real answer, and this refuses to take the
            # next step rather than pretend a page's Confirm could buy an
            # execution this instance was never put in a mode to make.
            return self._refuse(
                403,
                f"AGENT_MODE={self.mode}: this instance forms a plan and does not "
                "execute one, so nothing ran - the command line above is what "
                "would. `AGENT_MODE=run` beside `red serve --hands` is how an "
                "operator lets a page-approved line run on this machine.",
                command=flight.command,
                action_class=described["action_class"],
                lines=self._plan_lines(flight),
            )

        client = self._client(request)
        allowed, left = self.runs.take(client)
        if not allowed:
            return self._refuse(
                429,
                f"{self.runs.sentence()}; nothing was run.",
                retry_after=self.runs.seconds,
            )

        before = self.session.audit.last_seq
        scan_id = f"serve-{time.strftime('%Y%m%dT%H%M%S')}-{before + 1}"
        try:
            result = self.registry.execute(
                tool,
                arguments,
                context=self.session.context(
                    scan_id, approved=approved, actor=self.actor
                ),
            )
        except REFUSALS as exc:
            # A control stopped it. The attempt is on the record - the adapter
            # audits before it runs anything - so ``audited`` is read back off
            # the log rather than asserted.
            return self._refuse(
                self._status_for(exc),
                f"{type(exc).__name__}: {exc}",
                command=flight.command,
                action_class=described["action_class"],
                audited=self.session.audit.last_seq > before,
                lines=[f"$ {flight.command}", f"refused: {type(exc).__name__}: {exc}"],
            )
        except ToolExecutionError as exc:
            return self._refuse(
                502,
                f"the tool could not run: {exc}",
                command=flight.command,
                action_class=described["action_class"],
                audited=self.session.audit.last_seq > before,
            )

        return JSONResponse(
            content={
                **described,
                "planned": False,
                "target": target.strip(),
                # Read off what happened: a capability with no binary on this
                # machine is reported as not tested rather than as absent, which
                # is the same distinction the landing page makes.
                "ran_anything": result.ran,
                "audited": self.session.audit.last_seq > before,
                "audit_seq": result.audit_seq,
                "skipped": result.skipped,
                "skip_reason": result.skip_reason,
                "parse_error": result.parse_error,
                "returncode": result.command.returncode if result.command else None,
                "duration_ms": (
                    round(result.command.duration_ms, 1) if result.command else None
                ),
                "timed_out": bool(result.command and result.command.timed_out),
                "output_capped_at": MAX_OUTPUT,
                "stdout": self._output(result, "stdout"),
                "stderr": self._output(result, "stderr"),
                "parsed": self._jsonable(result.parsed),
                "runs_left_in_window": left,
                "lines": self._run_lines(flight, result),
            }
        )

    # ---------------------------------------------------------------- helpers
    def _refuse(self, status: int, sentence: str, **extra: Any) -> Any:
        """The hosted Function's error shape, so one client reads both surfaces.

        ``ran_anything`` and ``audited`` default to what is true of every
        refusal that happens *before* a tool exists - nothing ran, nothing was
        written - and a caller that has seen the log says otherwise explicitly.
        """
        from fastapi.responses import JSONResponse

        retry_after = extra.pop("retry_after", None)
        content = {"error": sentence, "ran_anything": False, "audited": False, **extra}
        headers = {"retry-after": str(retry_after)} if retry_after else None
        return JSONResponse(status_code=status, content=content, headers=headers)

    @staticmethod
    def _status_for(exc: Exception) -> int:
        """A control's refusal, in the status the page acts on."""
        if isinstance(exc, ApprovalRequired):
            return 409
        if isinstance(exc, (ScopeViolation, AuthorizationError, KillSwitchEngaged)):
            return 403
        if isinstance(exc, ForbiddenActionError):
            return 403
        return 429

    @staticmethod
    def _client(request: Any) -> str:
        return request.client.host if request.client else "local"

    @staticmethod
    def _approved(raw: Any) -> frozenset[str] | None:
        """The approvals this request carries, or ``None`` if it is malformed.

        A bare string is accepted as one line because that is what a page with
        one Confirm button has; everything else must be a list of strings.
        Whitespace is stripped, because the token is compared against the exact
        command a plan printed, and a stray newline pasted after it is the same
        authorisation, not a different one.
        """
        if raw is None or raw == []:
            return frozenset()
        if isinstance(raw, str):
            raw = [raw]
        if not isinstance(raw, list) or not all(isinstance(item, str) for item in raw):
            return None
        return frozenset(item.strip() for item in raw if item.strip())

    @staticmethod
    def _plan_lines(flight: Any) -> list[str]:
        """What a plan says, in the words the terminal's refusal uses."""
        lines = [f"$ {flight.command}" if flight.command else "nothing would run"]
        if flight.decision is not None:
            lines.append(f"class: {flight.decision.action_class.value}")
        if not flight.ok and flight.refusal is not None:
            lines.append(f"refused: {flight.refusal.reason}")
        elif flight.approved:
            lines.append("intrusive: already approved for this exact command line")
        elif flight.decision is not None and flight.decision.requires_approval:
            lines.append(
                "intrusive: a human must approve this exact command line before "
                "it runs"
            )
        return lines

    @staticmethod
    def _run_lines(flight: Any, result: Any) -> list[str]:
        """What the run says afterwards, from the argv that really ran."""
        lines = [f"$ {' '.join(result.argv) or flight.command}"]
        if result.skipped:
            lines.append(f"not run: {result.skip_reason or 'the adapter skipped it'}")
            return lines
        command = result.command
        if command is not None:
            lines.append(
                f"rc {command.returncode} in {round(command.duration_ms, 1)} ms "
                f"({len(command.stdout)} bytes out, {len(command.stderr)} bytes err)"
            )
        if result.parse_error:
            lines.append(f"the output could not be read: {result.parse_error}")
        return lines

    @staticmethod
    def _output(result: Any, name: str) -> str:
        if result.command is None:
            return ""
        return (getattr(result.command, name) or "")[:MAX_OUTPUT]

    @staticmethod
    def _jsonable(value: Any) -> Any:
        """Parsed data, or ``None`` when it is not JSON - the page renders text."""
        if value is None:
            return None
        try:
            json.dumps(value)
        except (TypeError, ValueError):
            return None
        return value
