"""``red serve`` - the chat interface, on this machine, over this install's model.

The interface posted to the host that served it, so the beta's page works on the
site (where ``functions/api/chat.js`` answers ``/api/chat``) and has no backend
at all on a laptop - a static server serves the page and the box is dead. This
module is that backend, and nothing else: a same-origin FastAPI app bound to
``127.0.0.1`` by default, serving ``web/beta`` and answering ``POST /api/chat``.

As served by ``red serve`` alone, it *runs* nothing, which is the same promise
``red`` and the hosted Function make and the reason all three can be one
product:

* the conversation is :class:`agent.chat.ChatSession` itself - the contract, the
  history, the turn - not a second implementation of it;
* the lines under the answer are :func:`agent.chat.as_lines`, so a tool call is
  reported as a suggestion, a target question carries :data:`agent.chat.TARGET_NOTE`,
  and ``[NOT_A_RUN]`` closes every answer exactly as it does in the terminal;
* ``ran_anything`` and ``audited`` are ``False`` because this module imports no
  adapter, no guard, no scope and no audit log - there is nothing here that
  could run a step, which is stronger than a rule promising it will not.

``red serve --hands`` is the one way that changes, and it changes *beside* this
module rather than inside it: the command builds :class:`agent.hands.Hands` -
which does hold the scope, the guard, the attestation and the audit log - and
passes it in, and this factory calls its ``mount``. The chat route below is
untouched by that and still runs nothing, the hand-built routes do not exist at
all without it, and ``GET /api/capabilities`` is how the page learns which of
the two it is talking to instead of guessing. The hosted site answers that probe
with ``runs: false``, forever: it has no scope file, no attestation, no audit
log and no key of ours to run anything with.

What it does take seriously that a static server cannot: the page it serves says
five turns per visitor per ten minutes, so this backend counts them - one window
per client address, in memory, gone when the process stops. Nothing else is
stored: no cookie, no session, no conversation on disk.

The install still owns what the page cannot decide. The visitor's key
(``x-llm-key``) is used for the turn, and the install's own ``.env`` key is used
when the browser sent none; a model on this machine needs neither. A panel choice
that names another provider or another model is refused with a sentence instead of
being quietly dropped on the floor, because the endpoint and the models are
``.env``'s and ``config/models.yaml``'s to name.

    pip install "enigmatic-red[serve]"      # fastapi + uvicorn
    red serve                               # http://127.0.0.1:8000
"""

# No ``from __future__ import annotations`` here, deliberately: FastAPI reads the
# endpoint signatures at run time, and a postponed annotation on ``request`` would
# not resolve to the ``Request`` imported inside the factory - it would be treated
# as a field to validate, and a plain POST would be a 422 instead of a turn.
import time
from pathlib import Path
from typing import Any, Callable

from agent.chat import ChatSession, as_lines, chat_system_prompt, key_status
from agent.providers.base import ChatMessage
from config.settings import PROJECT_ROOT, Settings, get_settings
from safety.errors import ProviderError

__all__ = [
    "INTERFACE",
    "MAX_HISTORY",
    "MAX_MESSAGE",
    "TURNS_PER_WINDOW",
    "WINDOW_SECONDS",
    "create_app",
    "run",
]

#: The interface and the art it names, served from the working tree rather than
#: ``web/dist``: that one is generated, gitignored, and stale by default.
INTERFACE = PROJECT_ROOT / "web" / "beta" / "index.html"
ASSETS = PROJECT_ROOT / "web" / "assets"

#: The two numbers the served page states, and therefore the two this backend has
#: to keep: ``Five turns per visitor per ten minutes``.
TURNS_PER_WINDOW = 5
WINDOW_SECONDS = 600

#: What the composer holds, and how much of the conversation is re-sent - the two
#: limits the hosted Function applies, so a turn that works there works here.
MAX_MESSAGE = 2000
MAX_HISTORY = 8

#: ``hostedFacts`` and this surface say different things about the same key: the
#: host holds none, this install holds its own. The page's label for the choice it
#: offers is reused so the two surfaces answer the same request shape.
SITE_PROVIDER = "site"
SITE_PROVIDER_LABEL = "this install's own endpoint"


class _Windows:
    """Turns per client address per wall-clock window, in memory only.

    Deliberately not a persistent limiter: this backend is bound to loopback and
    answers one operator, so the count exists to keep the page's own sentence true
    rather than to defend a service. Restarting resets it, which is honest - the
    page says "this window", and a new process has no window yet.
    """

    def __init__(self, limit: int = TURNS_PER_WINDOW, seconds: int = WINDOW_SECONDS) -> None:
        self.limit = limit
        self.seconds = seconds
        self._seen: dict[str, list[float]] = {}

    def take(self, client: str) -> tuple[bool, int]:
        """Count this turn. Returns ``(allowed, turns_left_after_it)``."""
        if self.limit <= 0:
            return True, 0
        now = time.monotonic()
        kept = [at for at in self._seen.get(client, []) if now - at < self.seconds]
        allowed = len(kept) < self.limit
        if allowed:
            kept.append(now)
        self._seen[client] = kept
        return allowed, max(0, self.limit - len(kept))

    def sentence(self) -> str:
        return (
            f"this address has used all {self.limit} turns in the current "
            f"{round(self.seconds / 60)}-minute window"
        )


def _provider_for(settings: Settings, key: str) -> Any:
    """This install's own endpoint, with the visitor's key when they brought one.

    Built per turn and closed at the end of it, because the key travels in the
    request: a cache keyed by credential is a place a credential can outlive the
    turn that carried it.
    """
    from agent.providers.featherless import FeatherlessProvider

    return FeatherlessProvider(settings=settings, api_key=key or None)


def _history(raw: Any) -> list[ChatMessage]:
    """The turns of this conversation the page re-sent, nothing else.

    A visitor's browser is the store here, so everything in ``history`` arrived
    from outside: only the two roles this surface has are read, a non-string or
    empty body is dropped, and no more than :data:`MAX_HISTORY` turns are kept -
    the same shape ``functions/api/chat.js`` accepts.
    """
    if not isinstance(raw, list):
        return []
    messages: list[ChatMessage] = []
    for entry in raw[-MAX_HISTORY:]:
        if not isinstance(entry, dict):
            continue
        content = entry.get("content")
        if not isinstance(content, str) or not content.strip():
            continue
        role = str(entry.get("role") or "")
        if role == "user":
            messages.append(ChatMessage.user(content.strip()))
        elif role == "assistant":
            messages.append(ChatMessage.assistant(content.strip()))
    return messages


async def _close(provider: Any) -> None:
    """Release the per-turn client. A provider without one is not an error."""
    close = getattr(provider, "aclose", None)
    if close is not None:
        await close()


def create_app(
    settings: Settings | None = None,
    *,
    role: str = "reason",
    where: str = "",
    turns: int = TURNS_PER_WINDOW,
    window: int = WINDOW_SECONDS,
    provider_factory: Callable[[Settings, str], Any] | None = None,
    interface: Path | None = None,
    hands: Any | None = None,
    mode: str | None = None,
) -> Any:
    """The app, built rather than served, so a test can drive it without a port.

    ``provider_factory`` is how the suite stays offline: it is handed the resolved
    settings and the key of the turn and returns whatever answers ``chat``.
    ``interface`` and ``where`` exist for the same reason - a test can point the
    app at a page it wrote and at an address it can predict.

    ``hands`` is the run surface, or ``None``. It is *taken*, not imported: the
    command that was asked for hands builds one (see :mod:`agent.hands`) and
    this factory only calls its ``mount``, which is why this module can still
    promise that it holds nothing able to run a step. With ``None`` the run
    routes do not exist and ``/api/capabilities`` says so.

    ``mode`` is the one word an instance answers with - ``chat``, ``plan`` or
    ``run``, checked against what the command really built by
    ``cli.commands`` before it gets here. With hands it is hands' own mode that
    is reported, because that is the one execution obeys; without hands only
    ``chat`` can be built, and asking for more raises here rather than being
    printed as a claim with nothing behind it.
    """
    from fastapi import FastAPI, Request
    from fastapi.responses import JSONResponse, Response
    from fastapi.staticfiles import StaticFiles

    resolved = settings or get_settings()
    page = Path(interface) if interface else INTERFACE
    make_provider = provider_factory or _provider_for
    counter = _Windows(turns, window)
    address = where or "http://127.0.0.1:8000"
    from agent.providers.featherless import load_models_config

    model_config = load_models_config(resolved.models_file)
    if hands is None:
        if mode not in (None, "chat"):
            raise ValueError(
                f"mode {mode!r} without hands: there is no chain here to plan or "
                "run a step with, so the only shape this app can be is `chat`"
            )
        instance_mode = "chat"
    else:
        # Hands' own word wins, because that is the one execution obeys: a
        # display that disagreed with it would be the one kind of wrong this
        # probe exists to prevent.
        instance_mode = getattr(hands, "mode", None) or mode or "chat"

    app = FastAPI(
        title="Enigmatic Red chat, on this machine",
        docs_url=None,
        redoc_url=None,
        openapi_url=None,
    )

    def refuse(status: int, sentence: str) -> Any:
        """The hosted Function's error shape, so one client reads both surfaces."""
        return JSONResponse(
            status_code=status,
            content={"error": sentence, "ran_anything": False, "audited": False},
        )

    def interface_body() -> Any:
        # Bytes, not text: the served page is then the file on disk whatever the
        # platform does with line endings, which is what the docstring below claims.
        try:
            return Response(content=page.read_bytes(), media_type="text/html")
        except OSError as exc:
            return refuse(503, f"no interface at {page}: {exc}")

    @app.get("/")
    @app.get("/beta/")
    @app.get("/beta/index.html")
    def home() -> Any:
        """The chat interface, byte for byte the file `web/publish.py` ships."""
        return interface_body()

    if ASSETS.is_dir():  # the icons the page's <head> names; art, not logic
        app.mount("/assets", StaticFiles(directory=str(ASSETS)), name="assets")

    @app.get("/api/capabilities")
    def capabilities() -> Any:
        """What this backend can do, so a page renders the truth it has.

        The one question the interface must not guess at: whether there is a
        chain behind the form. ``red serve --hands`` mounts one; the hosted
        Function answers ``runs: false``; the same bytes of HTML answer both -
        which is why this probe is what a deployment's *shape* means. With no
        hands there are no run routes at all, so ``runs: false`` here describes
        the app rather than promising something about it.

        ``mode`` is that shape in one word - ``chat``, ``plan`` or ``run`` - and
        it is not a second source of truth: with hands it is the mode hands
        itself is in, and without them it is ``chat`` because nothing else could
        be built. So a page reads the shape rather than inferring it, and the
        three states a run bar can be in are three answers, not three guesses.
        """
        model_profiles = {}
        role_config = model_config.get("roles") or {}
        for profile in ("fast", "reason"):
            configured = role_config.get(profile) or {}
            candidates = configured.get("candidates") or []
            model_id = (
                getattr(resolved, f"featherless_model_{profile}", "")
                or (candidates[0] if candidates else "Configured locally")
            )
            model_profiles[profile] = {
                "model": model_id,
                "temperature": float(configured.get("temperature", resolved.llm_temperature)),
                "max_tokens": int(configured.get("max_tokens", resolved.llm_max_tokens)),
            }

        if hands is not None:
            return JSONResponse(
                {
                    "chat": True,
                    "model_role": role,
                    "model_profiles": model_profiles,
                    **hands.describe(),
                }
            )
        return JSONResponse(
            {
                "chat": True,
                "model_role": role,
                "model_profiles": model_profiles,
                # No chain, so no mode but this one - and `create_app` refuses to
                # be built claiming otherwise.
                "mode": instance_mode,
                "runs": False,
                "plan": False,
                "audited": False,
                "runs_nothing": True,
                "why": (
                    "this backend answers the conversation and nothing else; "
                    "`red serve --hands` adds the run surface on this machine - "
                    "a scope file, a dated attestation, an audit log and a tool "
                    "that really runs - and no deployment of the static site "
                    "has any of those, so it never answers `runs: true`. "
                    "AGENT_MODE names which instance answered: here it is "
                    "`chat`, which runs nothing and cannot be widened by a "
                    "word, only by installing the chain."
                ),
                "equivalent": "red scan --tool <tool> --target <target>",
            }
        )

    @app.get("/api/chat")
    def explain() -> Any:
        """What this route takes, for anyone who opens it in a browser."""
        return JSONResponse(
            {
                "route": "/api/chat",
                "takes": 'POST {"message": "...", "history": [...]} with x-llm-key',
                "serves": [str(page), "/assets"],
                "endpoint": resolved.featherless_base_url,
                # True when this route cannot run anything. A question is never a
                # run; a sentence naming a target *is* worked when this instance
                # is in `run` mode with hands behind it, which is the same thing
                # `red` does in a terminal.
                "runs_nothing": instance_mode != "run",
                "mode": instance_mode,
                "ran_anything": False,
                "audited": False,
                # Whether a *run* surface is mounted somewhere else in this app,
                # and what it will do with it.
                "hands": hands is not None,
            }
        )

    @app.post("/api/chat")
    async def chat(request: Request) -> Any:
        """One turn: the conversation goes out, the model's words come back.

        Every refusal here happens before a provider exists, and the two that
        matter are about claims rather than text: a provider or a model this
        install does not have is named as such instead of being quietly dropped,
        and a key the endpoint needs is asked for instead of being invented.

        One turn is a conversation and nothing else, with one exception: on an
        instance in ``run`` mode with hands behind it, a sentence that names a
        target is ``red``'s own - read with no tools on the call, and worked
        through the chain a scan builds. Everything else, and every instance
        without that chain, is answered.
        """
        content_type = (request.headers.get("content-type") or "").lower()
        if "application/json" not in content_type:
            return refuse(415, 'this endpoint takes JSON: send {"message": "..."}')

        try:
            body = await request.json()
        except Exception:  # noqa: BLE001 - every parse failure is the same 400
            return refuse(400, "the request body is not valid JSON")
        if not isinstance(body, dict):
            return refuse(400, "the request body is not a JSON object")

        # The visitor's key first: the page keeps it in the tab and sends it per
        # turn, and it is the one credential this backend never holds between
        # requests. The install's own key in `.env` is the fallback, and a model
        # on this machine needs neither.
        supplied = (request.headers.get("x-llm-key") or "").strip()
        key = supplied or resolved.llm_api_key or resolved.featherless_api_key or ""
        if not key:
            ok, sentence = key_status(resolved)
            if not ok:
                return refuse(
                    401,
                    f"{sentence}: `red key` writes one into .env, the panel takes "
                    "one for a single turn, and `setup_local_model.*` points this "
                    "install at a model on this machine, which needs none.",
                )

        chosen = str(body.get("provider") or SITE_PROVIDER).strip().lower()
        if chosen != SITE_PROVIDER:
            return refuse(
                400,
                f"this backend answers over {resolved.featherless_base_url} and "
                f"nothing else, so the panel's {chosen!r} choice names no endpoint "
                "here: set FEATHERLESS_BASE_URL in .env instead, or use the site's "
                "own chat, which posts to the providers it offers.",
            )
        named = str(body.get("model") or "").strip()
        if named:
            return refuse(
                400,
                f"the model is the install's to name, not the page's: {named!r} "
                "would be sent nowhere. This install answers with the ids in "
                "config/models.yaml and .env (FEATHERLESS_MODEL_FAST, "
                "FEATHERLESS_MODEL_REASON); `red --model fast|reason` picks "
                "between them in a terminal.",
            )
        selected_role = body.get("role", role)
        if not isinstance(selected_role, str) or selected_role not in {"fast", "reason"}:
            return refuse(
                400,
                "the model role must be one configured profile: `fast` or `reason`.",
            )

        text = body.get("message")
        if not isinstance(text, str) or not text.strip():
            return refuse(400, "nothing to answer: the message was empty")
        text = text.strip()
        if len(text) > MAX_MESSAGE:
            return refuse(
                400,
                f"the message is {len(text)} characters; the composer holds "
                f"{MAX_MESSAGE}",
            )
        client = request.client.host if request.client else "local"
        allowed, left = counter.take(client)
        if not allowed:
            return JSONResponse(
                status_code=429,
                content={
                    "error": f"{counter.sentence()}; nothing was run.",
                    "ran_anything": False,
                    "audited": False,
                },
                headers={"retry-after": str(counter.seconds)},
            )

        history = _history(body.get("history"))
        provider: Any = None
        try:
            provider = make_provider(resolved, key)
            session = ChatSession(
                provider=provider,
                settings=resolved,
                model=selected_role,
                system=chat_system_prompt(resolved, surface="serve", where=address),
            )
            session.history[:] = history
            # A sentence that names a target is read before it is answered, and
            # on an instance that may run it is *worked* rather than talked
            # about: the same pair `red` uses, behind hands' own session,
            # registry, guard and audit log. The reading carries no tools, so a
            # question cannot act by being misread; a run spends one of hands'
            # runs as well as this turn; and a mode that will not execute never
            # reaches here at all, because `Hands.brief` answers `None` for it.
            if hands is not None:
                reading = await hands.brief(
                    provider, text, history=history, role=selected_role
                )
                if reading is not None:
                    runs_allowed, _left = hands.runs.take(client)
                    if not runs_allowed:
                        return JSONResponse(
                            status_code=429,
                            content={
                                "error": (
                                    f"{hands.runs.sentence()}; nothing was run."
                                ),
                                "ran_anything": False,
                                "audited": False,
                            },
                            headers={"retry-after": str(hands.runs.seconds)},
                        )
                    worked = await hands.mission(
                        provider=provider,
                        brief=reading,
                        history=history,
                        role=selected_role,
                        approved=body.get("approve"),
                    )
                    mission: dict[str, Any] = {
                        "answer": worked["answer"],
                        "model": worked["model"],
                        "provider": SITE_PROVIDER,
                        "provider_label": SITE_PROVIDER_LABEL,
                        "reasoning": None,
                        "execution": None,
                        "prior_messages": len(history),
                        "finish_reason": "mission",
                        "total_tokens": worked["total_tokens"],
                        "suggested": [],
                        # Read off the audit log by hands rather than promised
                        # here, and deliberately no `[NOT_A_RUN]` line: this turn
                        # really ran something, and the lines are the mission's.
                        "ran_anything": worked["ran_anything"],
                        "audited": worked["audited"],
                        "audit_seq": worked["audit_seq"],
                        "mode": instance_mode,
                        "mission": worked["mission"],
                        "stop_reason": worked["stop_reason"],
                        "lines": worked["lines"],
                    }
                    if counter.limit > 0:
                        mission["turns_left_in_window"] = left
                    return JSONResponse(content=mission)
            turn = await session.ask(text)
        except ProviderError as exc:
            return refuse(503, f"no model to answer with: {exc}")
        except Exception as exc:  # noqa: BLE001 - never a bare 500 to the page
            return refuse(502, f"the model call failed: {type(exc).__name__}: {exc}")
        finally:
            if provider is not None:
                await _close(provider)

        payload: dict[str, Any] = {
            "answer": turn.answer,
            "model": turn.model,
            "provider": SITE_PROVIDER,
            "provider_label": SITE_PROVIDER_LABEL,
            # The dials and the model are the install's here, not the page's, so
            # they come back unset rather than echoed as a choice this backend
            # would have refused above.
            "reasoning": None,
            "execution": None,
            "prior_messages": len(history),
            "finish_reason": turn.finish_reason,
            "total_tokens": turn.total_tokens,
            "suggested": list(turn.suggested),
            "ran_anything": False,
            "audited": False,
            "lines": list(as_lines(turn)),
        }
        if counter.limit > 0:
            payload["turns_left_in_window"] = left
        return JSONResponse(content=payload)

    if hands is not None:
        # The run surface, built by the command that was asked for it. Its
        # routes are added here and nowhere else, so this probe and those routes
        # cannot disagree: no hands, no routes.
        hands.mount(app)

    #: Exposed for the suite, which reads the counter rather than inferring the
    #: limit from a sequence of 429s.
    app.state.windows = counter
    return app


def run(app: Any, host: str = "127.0.0.1", port: int = 8000) -> None:
    """Serve until interrupted: uvicorn's loop, this app, nothing reloaded."""
    import uvicorn

    uvicorn.run(app, host=host, port=port, log_level="warning")
