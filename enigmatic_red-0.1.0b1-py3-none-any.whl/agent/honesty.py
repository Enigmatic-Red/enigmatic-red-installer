"""Claims, and the only thing that turns one into a finding: the audit chain.

A model can assert anything, and a fluent assertion about a customer's database
is worse than no assertion. So the unit of output here is a :class:`Claim` that
must cite the audit sequence numbers of the runs behind it, and
:func:`check_claim` decides what that citation is worth by reading the same
hash-chained log the adapters wrote:

``verified``
    Every cited run exists, is a completed observation (``tool.completed`` with
    ``decision: ok``), and is about the claim's own target. This is the *only*
    status that becomes a finding.
``lead``
    Nothing was cited. An untested hunch is allowed to exist, but it is
    reported as a lead and never as a finding.
``unsupported``
    A cited run does not exist in this scan. The model invented a reference —
    the failure mode that makes an audit trail worthless if it goes unnoticed.
``unproven``
    A cited run exists but proves nothing: it was refused, it was skipped
    because the binary is missing, it timed out, or its output could not be
    parsed. "The scan failed" must never read as "the target is clean".
``mismatch``
    A cited run exists and is about a different host. Right scan, wrong
    sentence.
``chain_broken``
    The hash chain itself does not verify, so no citation in this log means
    anything. This is reported, loudly, instead of silently downgrading.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable, Mapping

from safety.audit import AuditLog
from tools.parsers import SEVERITIES

__all__ = [
    "AuditIndex",
    "CHAIN_BROKEN",
    "Claim",
    "ClaimVerdict",
    "EvidenceRef",
    "LEAD",
    "MISMATCH",
    "UNPROVEN",
    "UNSUPPORTED",
    "VERIFIED",
    "check_claim",
    "claim_from_model",
    "verify_claims",
]

#: Statuses, in the order a report should list them.
VERIFIED = "verified"
UNPROVEN = "unproven"
MISMATCH = "mismatch"
UNSUPPORTED = "unsupported"
LEAD = "lead"
CHAIN_BROKEN = "chain_broken"

#: The one event an adapter writes after a capability actually ran and parsed.
OBSERVATION_EVENT = "tool.completed"


@dataclass(frozen=True)
class EvidenceRef:
    """A citation: the audit sequence number of one run behind a claim."""

    seq: int
    #: Optional, and verified when given: a model that names the event or the
    #: target it expects is easier to catch in a mistake than one that does not.
    event: str = ""
    target: str = ""

    def __post_init__(self) -> None:
        if isinstance(self.seq, bool) or not isinstance(self.seq, int) or self.seq <= 0:
            raise ValueError(f"an evidence reference needs a positive audit seq, got {self.seq!r}")

    @classmethod
    def from_model(cls, raw: Any) -> "EvidenceRef":
        """Accept the shapes a model actually emits: ``7``, ``"7"``, ``{...}``."""
        if isinstance(raw, Mapping):
            value = raw.get("seq", raw.get("run", raw.get("audit_seq")))
            try:
                return cls(
                    seq=int(value),  # type: ignore[arg-type]
                    event=str(raw.get("event") or ""),
                    target=str(raw.get("target") or ""),
                )
            except (TypeError, ValueError):
                raise ValueError(f"unusable evidence reference: {raw!r}") from None
        try:
            return cls(seq=int(raw))
        except (TypeError, ValueError):
            raise ValueError(f"unusable evidence reference: {raw!r}") from None

    def describe(self) -> dict[str, Any]:
        return {"seq": self.seq, "event": self.event, "target": self.target}


@dataclass(frozen=True)
class AuditIndex:
    """The audit chain of one scan, indexed by sequence number.

    Args:
        entries: ``seq -> raw entry`` for the scan's own entries.
        chain_ok: whether the whole file's hash chain verifies.
        chain_message: the verifier's sentence, kept verbatim for the report.
        head_hash: the hash of the last entry in the file.
    """

    entries: Mapping[int, Mapping[str, Any]]
    chain_ok: bool
    chain_message: str
    head_hash: str

    @classmethod
    def from_log(cls, audit: AuditLog, *, scan_id: str | None = None) -> "AuditIndex":
        ok, message = audit.verify()
        entries: dict[int, Mapping[str, Any]] = {}
        for row in audit.iter_entries():
            if scan_id is not None:
                recorded = (row.get("detail") or {}).get("scan_id")
                if recorded != scan_id:
                    continue
            seq = row.get("seq")
            if isinstance(seq, int):
                entries[seq] = row
        return cls(
            entries=entries,
            chain_ok=ok,
            chain_message=message,
            head_hash=audit.head_hash,
        )

    def get(self, seq: int) -> Mapping[str, Any] | None:
        return self.entries.get(seq)

    def __contains__(self, seq: object) -> bool:
        return seq in self.entries

    def __len__(self) -> int:
        return len(self.entries)

    def describe(self) -> dict[str, Any]:
        return {
            "entries": len(self.entries),
            "chain_ok": self.chain_ok,
            "chain_message": self.chain_message,
            "head_hash": self.head_hash,
        }


@dataclass(frozen=True)
class Claim:
    """One assertion about a target, plus the runs meant to support it.

    Args:
        title: one line, the thing being asserted.
        detail: what was observed, in the model's words.
        target: the host or URL the assertion is about. Checked against the
            cited runs, so it cannot be a third host the scan never touched.
        severity: one of :data:`tools.parsers.SEVERITIES`; ``unknown`` is a
            legitimate value and reads as "not yet scored", not as "low".
        evidence: the audit sequence numbers behind the assertion.
        cvss_vector: a CVSS 4.0 vector string, if one was assigned. Validated
            for shape only — scoring belongs to the analysis layer.
        notes: how this claim was parsed. Every adjustment made to what the
            model sent is carried here, so nothing is silently reinterpreted.
    """

    title: str
    detail: str = ""
    target: str = ""
    severity: str = "unknown"
    evidence: tuple[EvidenceRef, ...] = ()
    cvss_vector: str = ""
    cvss_score: float | None = None
    remediation: str = ""
    class_id: str = ""
    phase: str = ""
    notes: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if not self.title.strip():
            raise ValueError("a claim needs a title")
        severity = (self.severity or "unknown").strip().lower()
        if severity not in SEVERITIES:
            raise ValueError(
                f"unknown severity {self.severity!r}; expected one of "
                f"{', '.join(SEVERITIES)}"
            )
        object.__setattr__(self, "severity", severity)
        if self.cvss_vector and not self.cvss_vector.startswith("CVSS:4.0/"):
            raise ValueError(f"a CVSS vector must be CVSS 4.0, got {self.cvss_vector!r}")
        if self.cvss_score is not None and not 0.0 <= float(self.cvss_score) <= 10.0:
            raise ValueError(f"a CVSS score runs from 0 to 10, got {self.cvss_score!r}")
        if any(not isinstance(ref, EvidenceRef) for ref in self.evidence):
            raise ValueError("evidence must contain EvidenceRef objects")

    @property
    def cites_evidence(self) -> bool:
        return bool(self.evidence)

    @property
    def needs_scoring(self) -> bool:
        """Reported, but flagged: a high or critical finding with no vector."""
        return self.severity in ("high", "critical") and not self.cvss_vector

    def describe(self) -> dict[str, Any]:
        return {
            "title": self.title,
            "detail": self.detail,
            "target": self.target,
            "severity": self.severity,
            "class_id": self.class_id,
            "phase": self.phase,
            "evidence": [ref.describe() for ref in self.evidence],
            "cvss_vector": self.cvss_vector,
            "cvss_score": self.cvss_score,
            "remediation": self.remediation,
            "notes": list(self.notes),
        }


#: Keys a model might legitimately use, mapped onto the field they fill.
_CLAIM_ALIASES: dict[str, tuple[str, ...]] = {
    "title": ("title", "name", "finding", "summary"),
    "detail": ("detail", "description", "observation", "evidence_detail"),
    "target": ("target", "host", "url", "asset"),
    "severity": ("severity", "risk"),
    "evidence": ("evidence", "runs", "audit_seqs", "audit_seq"),
    "cvss_vector": ("cvss_vector", "cvss", "vector"),
    "cvss_score": ("cvss_score", "score"),
    "remediation": ("remediation", "fix", "recommendation"),
    "class_id": ("class_id", "class", "category"),
    "phase": ("phase",),
}

_KNOWN_KEYS = {alias for aliases in _CLAIM_ALIASES.values() for alias in aliases}


def _first(payload: Mapping[str, Any], field: str) -> Any:
    for alias in _CLAIM_ALIASES[field]:
        if alias in payload and payload[alias] not in (None, ""):
            return payload[alias]
    return ""


def claim_from_model(payload: Any) -> Claim:
    """Build a :class:`Claim` from a model's JSON, tolerantly but honestly.

    Nothing sent by a model is trusted here. A severity outside the known set
    becomes ``unknown`` rather than being guessed at, a CVSS vector that is not
    4.0 is dropped, an unusable evidence reference is discarded. Every
    adjustment lands in ``notes``, so the report can show the operator exactly
    what the model said next to what was kept.

    Raises:
        ValueError: when there is no title at all — an untitled assertion cannot
            be reported, scored or argued about.
    """
    if not isinstance(payload, Mapping):
        raise ValueError(f"a claim must be a JSON object, got {type(payload).__name__}")

    notes: list[str] = []
    title = str(_first(payload, "title")).strip()
    if not title:
        raise ValueError("a claim needs a title")

    severity = str(_first(payload, "severity") or "unknown").strip().lower()
    if severity not in SEVERITIES:
        notes.append(
            f"severity {severity!r} is not one of {', '.join(SEVERITIES)}; recorded "
            "as unknown rather than guessed"
        )
        severity = "unknown"

    raw_evidence = _first(payload, "evidence")
    if isinstance(raw_evidence, (int, str, Mapping)):
        raw_evidence = [raw_evidence]
    evidence: list[EvidenceRef] = []
    for raw in raw_evidence or ():
        try:
            evidence.append(EvidenceRef.from_model(raw))
        except ValueError as exc:
            notes.append(str(exc))

    vector = str(_first(payload, "cvss_vector")).strip()
    if vector and not vector.startswith("CVSS:4.0/"):
        notes.append(f"dropped a non-4.0 CVSS vector: {vector!r}")
        vector = ""
    score = _first(payload, "cvss_score")
    cvss_score: float | None = None
    if score not in ("", None):
        try:
            cvss_score = float(score)
        except (TypeError, ValueError):
            notes.append(f"dropped an unparseable CVSS score: {score!r}")

    ignored = sorted(set(payload) - _KNOWN_KEYS)
    if ignored:
        notes.append("ignored unrecognised keys: " + ", ".join(ignored))

    return Claim(
        title=title,
        detail=str(_first(payload, "detail") or "").strip(),
        target=str(_first(payload, "target") or "").strip(),
        severity=severity,
        evidence=tuple(evidence),
        cvss_vector=vector,
        cvss_score=cvss_score,
        remediation=str(_first(payload, "remediation") or "").strip(),
        class_id=str(_first(payload, "class_id") or "").strip(),
        phase=str(_first(payload, "phase") or "").strip(),
        notes=tuple(notes),
    )


#: Report order for severities. ``unknown`` last: unscored is not "low".
SEVERITY_ORDER: dict[str, int] = {
    "critical": 0,
    "high": 1,
    "medium": 2,
    "low": 3,
    "info": 4,
    "unknown": 5,
}


def _same_target(left: str, right: str) -> bool:
    """Compare targets by host, so ``https://a/x`` and ``a:443`` agree."""

    def host(value: str) -> str:
        text = value.strip().lower()
        if "://" in text:
            text = text.split("://", 1)[1]
        text = text.split("/", 1)[0].split("?", 1)[0]
        if "@" in text:
            text = text.rsplit("@", 1)[1]
        if text.count(":") == 1:  # host:port, but leave IPv6 literals alone
            text = text.split(":", 1)[0]
        return text

    return host(left) == host(right)


@dataclass(frozen=True)
class ClaimVerdict:
    """What one claim's citation is actually worth.

    Args:
        claim: the assertion as it was made.
        status: one of the module's status constants.
        reason: the sentence a human reads. Written for the operator, not the
            model: it names the run and says what was wrong with it.
        citations: the audit rows that do support the claim, in order.
        dropped: citations that were discarded, each with its reason. A model
            that invents references must be visible, not merely unsuccessful.
    """

    claim: Claim
    status: str
    reason: str
    citations: tuple[Mapping[str, Any], ...] = ()
    dropped: tuple[str, ...] = ()

    @property
    def is_finding(self) -> bool:
        """Only a claim carried by real observations is a finding."""
        return self.status == VERIFIED

    def describe(self) -> dict[str, Any]:
        return {
            **self.claim.describe(),
            "status": self.status,
            "reason": self.reason,
            "dropped": list(self.dropped),
            "citations": [
                {
                    "seq": row.get("seq"),
                    "event": row.get("event"),
                    "decision": row.get("decision"),
                    "target": row.get("target"),
                    "entry_hash": row.get("entry_hash"),
                }
                for row in self.citations
            ],
        }


def check_claim(claim: Claim, index: AuditIndex) -> ClaimVerdict:
    """Decide whether the audit chain supports ``claim``."""
    if not index.chain_ok:
        return ClaimVerdict(
            claim,
            CHAIN_BROKEN,
            "the audit chain for this scan does not verify "
            f"({index.chain_message}), so no citation in it can be trusted. "
            "Nothing from this scan is reported as verified.",
        )
    if not claim.cites_evidence:
        return ClaimVerdict(
            claim,
            LEAD,
            "no run was cited, so this is a lead: it is reported as an unproven "
            "assertion, never as a finding. Cite the audit sequence number of the "
            "run that showed it.",
        )

    supported: list[Mapping[str, Any]] = []
    dropped: list[str] = []
    wrong_target = False
    for ref in claim.evidence:
        row = index.get(ref.seq)
        if row is None:
            dropped.append(f"seq {ref.seq}: no such entry in this scan's audit log")
            continue
        event = str(row.get("event") or "")
        decision = str(row.get("decision") or "")
        detail = row.get("detail") or {}
        recorded_target = str(row.get("target") or "")
        if event != OBSERVATION_EVENT:
            dropped.append(
                f"seq {ref.seq}: a {event or 'unlabelled'} record is not an observation"
            )
            continue
        if decision != "ok":
            dropped.append(
                f"seq {ref.seq}: the run recorded decision {decision or 'none'!r}, so "
                "it proves nothing about the target"
            )
            continue
        if detail.get("parse_error"):
            dropped.append(
                f"seq {ref.seq}: nothing could be parsed from this run "
                f"({detail['parse_error']})"
            )
            continue
        if (
            claim.target
            and recorded_target
            and not _same_target(claim.target, recorded_target)
        ):
            wrong_target = True
            dropped.append(
                f"seq {ref.seq}: the run was against {recorded_target!r}, not "
                f"{claim.target!r}"
            )
            continue
        supported.append(row)

    if supported:
        seqs = ", ".join(str(row.get("seq")) for row in supported)
        reason = f"supported by {len(supported)} completed run(s) at seq {seqs}"
        if dropped:
            reason += f"; {len(dropped)} citation(s) discarded"
        return ClaimVerdict(claim, VERIFIED, reason, tuple(supported), tuple(dropped))

    if any("no such entry" in note for note in dropped):
        status, reason = UNSUPPORTED, (
            "the cited run does not exist in this scan's audit log: "
            + "; ".join(dropped)
            + ". This is a fabricated reference, and it is reported as one."
        )
    elif wrong_target:
        status, reason = MISMATCH, (
            "the cited run exists but is about a different target: "
            + "; ".join(dropped)
        )
    else:
        status, reason = UNPROVEN, "the cited run(s) prove nothing: " + "; ".join(dropped)
    return ClaimVerdict(claim, status, reason, (), tuple(dropped))


def verify_claims(
    claims: Iterable[Claim], index: AuditIndex
) -> tuple[ClaimVerdict, ...]:
    """Check every claim, most severe first."""
    verdicts = tuple(check_claim(claim, index) for claim in claims)
    return tuple(sorted(verdicts, key=lambda v: SEVERITY_ORDER.get(v.claim.severity, 5)))


def verdict_counts(verdicts: Iterable[ClaimVerdict]) -> dict[str, int]:
    """Statuses with their counts, for the report header and the metrics."""
    counts: dict[str, int] = {}
    for verdict in verdicts:
        counts[verdict.status] = counts.get(verdict.status, 0) + 1
    return counts


def findings(verdicts: Iterable[ClaimVerdict]) -> tuple[ClaimVerdict, ...]:
    """Only the verified ones — the only claims that may be reported."""
    return tuple(verdict for verdict in verdicts if verdict.is_finding)
