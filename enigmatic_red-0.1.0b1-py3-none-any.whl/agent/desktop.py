"""Launch the Windows desktop workspace over the local, audited agent server."""

from __future__ import annotations

import argparse
import ctypes
import json
import os
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any


def _show_error(message: str) -> None:
    if sys.platform == "win32":
        ctypes.windll.user32.MessageBoxW(None, message, "Enigmatic Red Agent", 0x10)
    else:
        print(message, file=sys.stderr)


def _port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as listener:
        listener.bind(("127.0.0.1", 0))
        return int(listener.getsockname()[1])


def _server_ready(address: str, process: subprocess.Popen[Any], deadline: float) -> None:
    while time.monotonic() < deadline:
        if process.poll() is not None:
            raise RuntimeError(
                "The local agent stopped before it became ready. Complete scope "
                "and authorization setup, then check the agent-ui.log file."
            )
        try:
            with urllib.request.urlopen(address + "/api/capabilities", timeout=1) as response:
                status = json.load(response)
        except (urllib.error.URLError, OSError):
            time.sleep(0.25)
            continue

        if (
            not isinstance(status, dict)
            or status.get("plan") is not True
            or status.get("runs") is not True
            or status.get("audited") is not True
            or not isinstance(status.get("tools"), list)
            or not status["tools"]
        ):
            raise RuntimeError("The local server did not confirm an audited run surface.")
        return
    raise RuntimeError("The local agent did not become ready within two minutes.")


def _stop(process: subprocess.Popen[Any]) -> None:
    if process.poll() is not None:
        return
    process.terminate()
    try:
        process.wait(timeout=10)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait()


def _server_command(red: Path, home: Path, port: int, interface: Path) -> list[str]:
    return [
        str(red),
        "--home",
        str(home),
        "serve",
        "--hands",
        "--host",
        "127.0.0.1",
        "--port",
        str(port),
        "--interface",
        str(interface),
    ]


def run(home: Path) -> None:
    try:
        import webview
    except ImportError as exc:
        raise RuntimeError(
            "The desktop window package is missing. Run EnigmaticRed-Setup.exe "
            "again to repair this install."
        ) from exc

    package_root = Path(__file__).resolve().parent.parent
    interface = package_root / "web" / "agent" / "index.html"
    red = Path(sys.executable).with_name("red.exe" if os.name == "nt" else "red")
    if not red.is_file():
        raise RuntimeError(f"The installed agent command is missing: {red}")
    if not interface.is_file():
        raise RuntimeError(f"The desktop interface is missing: {interface}")

    port = _port()
    address = f"http://127.0.0.1:{port}"
    log_path = home / "logs" / "agent-ui.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)
    command = _server_command(red, home, port, interface)

    with log_path.open("a", encoding="utf-8") as log:
        process = subprocess.Popen(
            command,
            stdin=subprocess.DEVNULL,
            stdout=log,
            stderr=subprocess.STDOUT,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        try:
            _server_ready(address, process, time.monotonic() + 120)
            webview.create_window(
                "Enigmatic Red Agent",
                address,
                width=1280,
                height=820,
                min_size=(760, 560),
                background_color="#0c0d0f",
            )
            webview.start(gui="edgechromium")
        finally:
            _stop(process)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="Enigmatic Red Agent")
    parser.add_argument("--home", required=True, type=Path)
    args = parser.parse_args(argv)
    try:
        run(args.home.expanduser())
    except Exception as exc:
        _show_error(
            f"{exc}\n\nIf the error mentions WebView2, install the Microsoft "
            "Edge WebView2 Runtime. Agent startup details are in "
            f"{args.home.expanduser() / 'logs' / 'agent-ui.log'}."
        )
        return 1
    return 0


if __name__ == "__main__":  # pragma: no cover - launched by the Start Menu shortcut
    raise SystemExit(main())
