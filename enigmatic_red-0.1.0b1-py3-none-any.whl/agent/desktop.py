"""Launch the Windows desktop workspace over the local, audited agent server."""

from __future__ import annotations

import argparse
import ctypes
import json
import os
import socket
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any

from agent.setup import RELAUNCH_EXIT


def _show_error(message: str) -> None:
    if sys.platform == "win32":
        ctypes.windll.user32.MessageBoxW(None, message, "Enigmatic Red Agent", 0x10)
    else:
        print(message, file=sys.stderr)


def _port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as listener:
        listener.bind(("127.0.0.1", 0))
        return int(listener.getsockname()[1])


def _server_ready(
    address: str,
    process: subprocess.Popen[Any],
    deadline: float,
    *,
    expect: str,
) -> dict[str, Any]:
    """Wait for the shape this launch asked for, and return its own report.

    Two shapes are legitimate and each is one the server itself states:
    ``run`` (``red serve --hands``: plan, runs, audited and a tool list) and
    ``setup`` (``red serve --restart-on-setup``: a page whose form writes the
    attestation ``--hands`` needs). Anything else is not "not yet" - it is a
    server that answered a question it should not have answered differently -
    so it raises rather than looping.
    """
    while time.monotonic() < deadline:
        if process.poll() is not None:
            raise RuntimeError(
                "The local agent stopped before it became ready. On a fresh install "
                "run `red init` for this home first; the reason it exited is in "
                "the agent-ui.log file."
            )
        try:
            with urllib.request.urlopen(address + "/api/capabilities", timeout=1) as response:
                status = json.load(response)
        except (urllib.error.URLError, OSError):
            time.sleep(0.25)
            continue

        found = _surface(status)
        if found == expect:
            return status
        if found is not None:
            raise RuntimeError(
                f"The local server started as {found!r} where this launch asked "
                f"for {expect!r}."
            )
    raise RuntimeError("The local agent did not become ready within two minutes.")


def _surface(status: Any) -> str | None:
    """The shape a capabilities answer describes: ``run``, ``setup`` or nothing.

    Pure, so the two shapes are one testable decision rather than two branches
    inside a polling loop. A run surface is the stricter claim and is checked
    first: `runs: true` with no tools is not a run surface at all.
    """
    if not isinstance(status, dict):
        return None
    if (
        status.get("plan") is True
        and status.get("runs") is True
        and status.get("audited") is True
        and isinstance(status.get("tools"), list)
        and status["tools"]
    ):
        return "run"
    if status.get("setup") is True:
        return "setup"
    return None


def _authorized(home: Path) -> bool:
    """Whether ``--hands`` can start here, asked of the gate rather than the file.

    The desktop used to find this out by starting the server and watching it
    die. The same question is answerable first: a seeded scope plus an
    attestation the gate accepts for the target it names. A file that is
    expired, stale or signed against another scope answers ``False`` for the
    same reason the run would be refused, and the window opens on setup.
    """
    scope_file = home / "config" / "scope.yaml"
    authorization_file = home / "config" / "authorization.json"
    if not scope_file.is_file() or not authorization_file.is_file():
        return False
    try:
        from cli.home import attestation_from_dict
        from safety.authz import AuthorizationGate
        from safety.scope import Scope

        scope = Scope.from_yaml(scope_file)
        attestation = attestation_from_dict(
            json.loads(authorization_file.read_text(encoding="utf-8"))
        )
        ok, _reason = AuthorizationGate().check(
            attestation, attestation.target, scope
        )
    except Exception:  # noqa: BLE001 - an unreadable home means "not yet"
        return False
    return ok


def _stop(process: subprocess.Popen[Any]) -> None:
    if process.poll() is not None:
        return
    process.terminate()
    try:
        process.wait(timeout=10)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait()


def _server_command(
    red: Path,
    home: Path,
    port: int,
    interface: Path,
    *,
    hands: bool,
) -> list[str]:
    """The one command this window runs, in the shape the home is in.

    ``--hands`` is the run surface; without it the same page is the setup form,
    which exists because ``--hands`` on an un-attested home dies before the
    window has anything to show. The last flag is what lets the setup form hand
    back: the server exits with :data:`agent.setup.RELAUNCH_EXIT` once the
    attestation is written, and this process restarts it with ``--hands``.
    """
    command = [
        str(red),
        "--home",
        str(home),
        "serve",
        "--host",
        "127.0.0.1",
        "--port",
        str(port),
        "--interface",
        str(interface),
    ]
    command.append("--hands" if hands else "--restart-on-setup")
    return command


def _relaunch_command() -> list[str]:
    """This launcher again, for the restart after setup writes the attestation.

    pywebview allows one ``start()`` per process, so coming back from setup
    means a new process. A frozen build re-runs the exe; a source run re-runs
    the module, because ``sys.argv[0]`` alone would start the script without
    ``-m`` and lose the package context.
    """
    if getattr(sys, "frozen", False):
        return [sys.executable, *sys.argv[1:]]
    return [sys.executable, "-m", "agent.desktop", *sys.argv[1:]]


def _watch(
    process: subprocess.Popen[Any], window: Any, ended: list[int | None]
) -> None:
    """Close the window when the server behind it has gone.

    A window kept open over a dead backend is the failure this change is
    about: a page that cannot answer and does not say so. Called on a thread
    because ``webview.start`` owns the main one.
    """
    process.wait()
    ended.append(process.returncode)
    try:
        window.destroy()
    except Exception:  # noqa: BLE001 - a window already gone is fine
        pass


def run(home: Path) -> None:
    try:
        import webview
    except ImportError as exc:
        raise RuntimeError(
            "The desktop window package is missing. Run EnigmaticRed-Setup.exe "
            "again to repair this install."
        ) from exc

    package_root = Path(__file__).resolve().parent.parent
    interface = package_root / "web" / "agent" / "index.html"
    red = Path(sys.executable).with_name("red.exe" if os.name == "nt" else "red")
    if not red.is_file():
        raise RuntimeError(f"The installed agent command is missing: {red}")
    if not interface.is_file():
        raise RuntimeError(f"The desktop interface is missing: {interface}")

    port = _port()
    address = f"http://127.0.0.1:{port}"
    log_path = home / "logs" / "agent-ui.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)
    # The same question the server would die on, asked before it is started, so
    # a fresh install opens on the setup form instead of a MessageBox.
    hands = _authorized(home)
    command = _server_command(red, home, port, interface, hands=hands)
    ended: list[int | None] = []

    with log_path.open("a", encoding="utf-8") as log:
        process = subprocess.Popen(
            command,
            stdin=subprocess.DEVNULL,
            stdout=log,
            stderr=subprocess.STDOUT,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        try:
            _server_ready(
                address,
                process,
                time.monotonic() + 120,
                expect="run" if hands else "setup",
            )
            window = webview.create_window(
                "Enigmatic Red Agent",
                address,
                width=1280,
                height=820,
                min_size=(760, 560),
                background_color="#0c0d0f",
            )
            threading.Thread(
                target=_watch, args=(process, window, ended), daemon=True
            ).start()
            webview.start(gui="edgechromium")
        finally:
            _stop(process)

    if ended and ended[0] == RELAUNCH_EXIT:
        # The setup form said the attestation is written and the gate accepts
        # it. Come back as the run surface; the window that comes back is this
        # process's replacement, not a second one.
        restart = _relaunch_command()
        os.execv(restart[0], restart)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="Enigmatic Red Agent")
    parser.add_argument("--home", required=True, type=Path)
    args = parser.parse_args(argv)
    try:
        run(args.home.expanduser())
    except Exception as exc:
        _show_error(
            f"{exc}\n\nIf the error mentions WebView2, install the Microsoft "
            "Edge WebView2 Runtime. Agent startup details are in "
            f"{args.home.expanduser() / 'logs' / 'agent-ui.log'}."
        )
        return 1
    return 0


if __name__ == "__main__":  # pragma: no cover - launched by the Start Menu shortcut
    raise SystemExit(main())
