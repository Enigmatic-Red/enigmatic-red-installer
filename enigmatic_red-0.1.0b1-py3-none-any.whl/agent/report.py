"""The scan report, and the discipline that makes it worth reading.

A report is the product. It must answer four questions and refuse to blur them:
what was confirmed, what was only suspected, what was never tested, and what the
platform declined to do. The classification is already made by
:mod:`agent.honesty`; this module's job is to present it so that a reader cannot
mistake one category for another, and to carry the audit chain along so every
confirmed statement can be checked by hand.

So there is no "confidence" field and no severity invented here. A finding is a
claim with completed observations behind it; everything else is listed under its
own heading, with the reason it did not qualify.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Iterable, Mapping, Sequence

from agent.honesty import (
    LEAD,
    SEVERITY_ORDER,
    AuditIndex,
    ClaimVerdict,
    findings,
    verdict_counts,
)

__all__ = [
    "NotTested",
    "RefusalRecord",
    "ScanReport",
    "build_report",
]


@dataclass(frozen=True)
class RefusalRecord:
    """Something the platform declined to do, and why.

    Refusals belong in the deliverable. "We tried the template sweep and the
    guard refused it without an approval" is information the reader is owed;
    a report that silently omits it reads as a scan that found nothing there.
    """

    capability: str
    code: str
    reason: str
    action_class: str = ""
    command: str = ""
    matched_rules: tuple[str, ...] = ()

    def describe(self) -> dict[str, Any]:
        return {
            "capability": self.capability,
            "code": self.code,
            "reason": self.reason,
            "action_class": self.action_class,
            "command": self.command,
            "matched_rules": list(self.matched_rules),
        }


@dataclass(frozen=True)
class NotTested:
    """Coverage the customer should not assume: target, subject, and why."""

    target: str
    what: str
    reason: str

    def describe(self) -> dict[str, Any]:
        return {"target": self.target, "what": self.what, "reason": self.reason}


@dataclass(frozen=True)
class ScanReport:
    """One scan, as delivered.

    Args:
        scan_id: the identifier every audit entry of this scan carries.
        org: the organization the authorization covered.
        domain: the domain pack key.
        tier: the entitlement tier key.
        phase_ceiling: how far the tier was entitled to go.
        phases_run: phases the plan actually worked in, in order.
        verdicts: every claim, checked against the chain.
        refusals: actions the registry or the guard refused.
        not_tested: coverage that did not happen, with a reason each.
        usage: token/step counters, as the planner recorded them.
        index: the audit chain this report cites, plus its integrity verdict.
        objective: the operator's objective, verbatim.
    """

    scan_id: str
    org: str
    domain: str
    tier: str
    phase_ceiling: str
    index: AuditIndex
    objective: str = ""
    phases_run: tuple[str, ...] = ()
    verdicts: tuple[ClaimVerdict, ...] = ()
    refusals: tuple[RefusalRecord, ...] = ()
    not_tested: tuple[NotTested, ...] = ()
    usage: Mapping[str, Any] = field(default_factory=dict)

    # ------------------------------------------------------------- selection
    @property
    def confirmed(self) -> tuple[ClaimVerdict, ...]:
        """Verified findings, most severe first."""
        return tuple(
            sorted(findings(self.verdicts), key=self._severity_key)
        )

    @property
    def leads(self) -> tuple[ClaimVerdict, ...]:
        """Assertions with no citation: worth a look, not worth a claim."""
        return self._with_status(LEAD)

    @property
    def unverified(self) -> tuple[ClaimVerdict, ...]:
        """Claims the chain does not support, each with the reason it failed."""
        return tuple(
            verdict for verdict in self.verdicts if not verdict.is_finding and verdict.status != LEAD
        )

    @property
    def status_counts(self) -> dict[str, int]:
        return verdict_counts(self.verdicts)

    @property
    def severity_totals(self) -> dict[str, int]:
        totals: dict[str, int] = {}
        for verdict in self.confirmed:
            severity = verdict.claim.severity
            totals[severity] = totals.get(severity, 0) + 1
        return totals

    @property
    def dropped_citations(self) -> int:
        """References the model offered that the chain did not back.

        Not cosmetic: a rising count means claims are arriving pre-decorated,
        which is worth knowing before it reaches a customer.
        """
        return sum(len(verdict.dropped) for verdict in self.verdicts)

    @property
    def unscored(self) -> tuple[ClaimVerdict, ...]:
        """High or critical findings still without a CVSS 4.0 vector."""
        return tuple(v for v in self.confirmed if v.claim.needs_scoring)

    @property
    def integrity(self) -> str:
        return "ok" if self.index.chain_ok else "broken"

    def _severity_key(self, verdict: ClaimVerdict) -> int:
        return SEVERITY_ORDER.get(verdict.claim.severity, 5)

    def _with_status(self, status: str) -> tuple[ClaimVerdict, ...]:
        return tuple(
            sorted(
                (v for v in self.verdicts if v.status == status),
                key=self._severity_key,
            )
        )

    # -------------------------------------------------------------- caveats
    def caveats(self) -> tuple[str, ...]:
        """What a reader must know before believing the top of this report."""
        notes: list[str] = []
        if not self.index.chain_ok:
            notes.append(
                "The audit chain does not verify "
                f"({self.index.chain_message}), so nothing in this scan is "
                "reported as confirmed. Treat the entries below as leads only."
            )
        if self.dropped_citations:
            notes.append(
                f"{self.dropped_citations} citation(s) given for claims in this scan "
                "were not backed by the audit log and were discarded; each rejection "
                "is listed with its claim."
            )
        if self.unscored:
            notes.append(
                f"{len(self.unscored)} high or critical finding(s) carry no CVSS 4.0 "
                "vector yet; the severity shown is the model's claim, not a score."
            )
        if self.not_tested:
            notes.append(
                f"Coverage is incomplete: {len(self.not_tested)} thing(s) could not be "
                "tested. See 'Not tested' - a target listed there was not cleared."
            )
        if self.refusals:
            notes.append(
                f"{len(self.refusals)} action(s) were refused by policy or the action "
                "guard. See 'Refused'. A refusal is a decision, not an absence of risk."
            )
        if self.leads:
            notes.append(
                f"{len(self.leads)} assertion(s) cite no run at all and are reported as "
                "leads, never as findings."
            )
        notes.append(
            "No finding here means no finding was confirmed within this scope and "
            "phase ceiling - not that the target is secure."
        )
        return tuple(notes)

    def summary_line(self) -> str:
        """One log-safe line: the whole scan at a glance."""
        return (
            f"scan {self.scan_id} [{self.domain}/{self.tier}]: "
            f"{len(self.confirmed)} confirmed, {len(self.leads)} lead(s), "
            f"{len(self.unverified)} unverified, {len(self.refusals)} refused, "
            f"{len(self.not_tested)} not tested, audit chain {self.integrity}"
        )

    # --------------------------------------------------------------- exports
    def to_dict(self) -> dict[str, Any]:
        """JSON-ready. Contains no secrets and no raw tool output."""
        return {
            "scan": {
                "scan_id": self.scan_id,
                "org": self.org,
                "domain": self.domain,
                "tier": self.tier,
                "phase_ceiling": self.phase_ceiling,
                "objective": self.objective,
                "phases_run": list(self.phases_run),
            },
            "audit": self.index.describe(),
            "counts": {
                "confirmed": len(self.confirmed),
                "leads": len(self.leads),
                "unverified": len(self.unverified),
                "refused": len(self.refusals),
                "not_tested": len(self.not_tested),
                "by_status": self.status_counts,
            },
            "severity_totals": self.severity_totals,
            "metrics": {
                "dropped_citations": self.dropped_citations,
                "unscored_high_or_critical": len(self.unscored),
                "audit_entries": len(self.index),
                "llm_usage": dict(self.usage),
            },
            "findings": [verdict.describe() for verdict in self.confirmed],
            "leads": [verdict.describe() for verdict in self.leads],
            "unverified": [verdict.describe() for verdict in self.unverified],
            "refusals": [record.describe() for record in self.refusals],
            "not_tested": [item.describe() for item in self.not_tested],
            "caveats": list(self.caveats()),
        }

    def to_markdown(self) -> str:
        """A plain-text report: same structure, in the order a human reads it."""
        lines: list[str] = [
            f"# Enigmatic Red scan report - {self.org}",
            "",
            f"- Scan: `{self.scan_id}`",
            f"- Domain pack: {self.domain}",
            f"- Tier: {self.tier} (reaches {self.phase_ceiling})",
            f"- Objective: {self.objective or 'not recorded'}",
            "- Phases worked: "
            + (", ".join(self.phases_run) if self.phases_run else "none recorded"),
            f"- Audit chain: {self.integrity} - {self.index.chain_message}",
            "",
            "## Summary",
            "",
            f"- Confirmed findings: {len(self.confirmed)}",
            f"- Leads (no supporting run): {len(self.leads)}",
            f"- Claims the chain does not support: {len(self.unverified)}",
            f"- Actions refused by policy: {len(self.refusals)}",
            f"- Not tested: {len(self.not_tested)}",
            "",
        ]
        for severity, count in sorted(
            self.severity_totals.items(), key=lambda item: SEVERITY_ORDER.get(item[0], 5)
        ):
            lines.append(f"  - {severity}: {count}")
        lines.append("")

        lines += [f"## Confirmed findings ({len(self.confirmed)})", ""]
        if self.confirmed:
            for number, verdict in enumerate(self.confirmed, start=1):
                lines += _finding_block(number, verdict)
        else:
            lines += [
                "None. Read the caveats at the end before taking that as 'secure'.",
                "",
            ]

        lines += [f"## Leads - not findings ({len(self.leads)})", ""]
        lines += _claim_lines(self.leads) or ["None.", ""]

        lines += [
            f"## Claims the audit chain does not support ({len(self.unverified)})",
            "",
        ]
        lines += _claim_lines(self.unverified) or ["None.", ""]

        lines += [f"## Not tested ({len(self.not_tested)})", ""]
        for item in self.not_tested:
            lines.append(f"- `{item.target}` - {item.what}: {item.reason}")
        if not self.not_tested:
            lines.append("None recorded.")
        lines.append("")

        lines += [f"## Refused by policy ({len(self.refusals)})", ""]
        for record in self.refusals:
            line = f"- {record.capability} [{record.code}]: {record.reason}"
            if record.command:
                line += f"\n  - command: `{record.command}`"
            lines.append(line)
        if not self.refusals:
            lines.append("None recorded.")
        lines.append("")

        lines += ["## Caveats", ""]
        lines += [f"- {note}" for note in self.caveats()]
        lines.append("")
        return "\n".join(lines)


# ------------------------------------------------------- markdown fragments
def _evidence(verdict: ClaimVerdict) -> str:
    if not verdict.citations:
        return "none"
    return ", ".join(
        f"seq {row.get('seq')} ({str(row.get('entry_hash') or '')[:12]})"
        for row in verdict.citations
    )


def _finding_block(number: int, verdict: ClaimVerdict) -> list[str]:
    claim = verdict.claim
    block = [f"### {number}. [{claim.severity}] {claim.title}", ""]
    if claim.target:
        block.append(f"Target: `{claim.target}`")
    if claim.detail:
        block += ["", claim.detail]
    block.append(f"- Evidence: {_evidence(verdict)} - {verdict.reason}")
    if claim.cvss_vector:
        score = f" ({claim.cvss_score})" if claim.cvss_score is not None else ""
        block.append(f"- CVSS 4.0: {claim.cvss_vector}{score}")
    if claim.remediation:
        block.append(f"- Remediation: {claim.remediation}")
    if claim.notes:
        block += [f"- Note: {note}" for note in claim.notes]
    block.append("")
    return block


def _claim_lines(verdicts: Sequence[ClaimVerdict]) -> list[str]:
    lines: list[str] = []
    for verdict in verdicts:
        claim = verdict.claim
        where = f" - `{claim.target}`" if claim.target else ""
        lines.append(f"- **{claim.title}** [{claim.severity}]{where}")
        lines.append(f"  - {verdict.reason}")
        if claim.detail:
            lines.append(f"  - as asserted: {claim.detail}")
        for note in verdict.dropped:
            lines.append(f"  - discarded citation {note}")
    lines.append("")
    return lines


# ----------------------------------------------------------------- assembly
def build_report(
    *,
    scan_id: str,
    org: str,
    domain: str,
    tier: str,
    phase_ceiling: str,
    index: AuditIndex,
    objective: str = "",
    phases_run: Iterable[str] = (),
    verdicts: Iterable[ClaimVerdict] = (),
    refusals: Iterable[RefusalRecord] = (),
    not_tested: Iterable[NotTested] = (),
    usage: Mapping[str, Any] | None = None,
) -> ScanReport:
    """Assemble a report from what the planner actually recorded.

    The order of the phases and verdicts is preserved where it carries meaning
    (what was worked, in order) and sorted by severity where it does not.
    """
    return ScanReport(
        scan_id=scan_id,
        org=org,
        domain=domain,
        tier=tier,
        phase_ceiling=phase_ceiling,
        index=index,
        objective=objective,
        phases_run=tuple(dict.fromkeys(str(phase) for phase in phases_run)),
        verdicts=tuple(verdicts),
        refusals=tuple(refusals),
        not_tested=tuple(not_tested),
        usage=dict(usage or {}),
    )