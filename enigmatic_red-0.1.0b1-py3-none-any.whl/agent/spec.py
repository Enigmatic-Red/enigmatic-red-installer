"""The agent's declarative configuration, as objects.

Three files decide what an agent may do, and none of them is code:

* ``config/domains.yaml`` — the domain packs (what the product sells), the
  shared phase model, and a phase ceiling per tier;
* ``config/plans.yaml``   — the entitlement contract: the same ceilings, plus
  per-tier limits and the global scan budget;
* ``config/models.yaml``  — which model handles which kind of call, and the
  planner loop's hard limits.

They are loaded *and cross-checked* here, at start-up. The failure this module
exists to prevent is silent drift: a ceiling reading ``P3_assess`` in one file
and ``P5_report`` in another, a pack naming a phase nobody defined, a
``prompt_pack`` pointing at a directory that does not exist. A YAML mistake
must fail in CI with the file and the key named — never at 03:00, mid-scan,
as a KeyError inside the planner.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping

import yaml

from config.settings import CONFIG_DIR

__all__ = [
    "AgentSpec",
    "DomainPack",
    "Limits",
    "PROMPTS_DIR",
    "Phase",
    "RoleSpec",
    "Routing",
    "Tier",
    "load_spec",
]

#: A pack's prompt pack lives in ``<PROMPTS_DIR>/<prompt_pack>/*.md``.
PROMPTS_DIR = Path(__file__).resolve().parent / "prompts"


def _read(path: Path) -> dict[str, Any]:
    if not path.exists():
        raise ValueError(f"missing configuration file: {path}")
    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8"))
    except yaml.YAMLError as exc:
        raise ValueError(f"{path.name} is not valid YAML: {exc}") from exc
    if data is None:
        return {}
    if not isinstance(data, dict):
        raise ValueError(f"{path.name} must contain a mapping at the top level")
    return data


def _text(value: Any, *, where: str) -> str:
    text = str(value or "").strip()
    if not text:
        raise ValueError(f"{where} must be a non-empty string")
    return text


def _positive_int(value: Any, *, where: str, default: int) -> int:
    if value is None:
        return default
    if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
        raise ValueError(f"{where} must be a positive integer, got {value!r}")
    return value


def _text_tuple(value: Any, *, where: str) -> tuple[str, ...]:
    if not isinstance(value, Iterable) or isinstance(value, (str, bytes)):
        raise ValueError(f"{where} must be a list of strings")
    items: list[str] = []
    for raw in value:
        item = str(raw).strip()
        if not item:
            raise ValueError(f"{where} contains an empty entry")
        if item in items:
            raise ValueError(f"{where} lists {item!r} twice")
        items.append(item)
    if not items:
        raise ValueError(f"{where} must not be empty")
    return tuple(items)


@dataclass(frozen=True)
class Phase:
    """One step of the shared phase model (P0_intake .. P5_report)."""

    key: str
    description: str = ""


@dataclass(frozen=True)
class DomainPack:
    """A capability the product sells: a tool set, a phase list, a prompt pack.

    Nothing here grants authority. Listing ``nuclei`` only removes it from
    consideration for the other packs; the action guard, the scope and the
    authorization gate still decide whether it may run at all.
    """

    key: str
    label: str
    summary: str
    prompt_pack: str
    phases: tuple[str, ...]
    tools: tuple[str, ...]

    @classmethod
    def from_mapping(
        cls,
        key: str,
        raw: Mapping[str, Any],
        *,
        known_phases: Iterable[str],
        prompts_dir: Path | None = PROMPTS_DIR,
    ) -> "DomainPack":
        if not isinstance(raw, Mapping):
            raise ValueError(f"domains.{key} must be a mapping")
        phases = _text_tuple(raw.get("phases"), where=f"domains.{key}.phases")
        unknown = [phase for phase in phases if phase not in set(known_phases)]
        if unknown:
            raise ValueError(
                f"domains.{key}.phases names {unknown}, which the shared phase "
                f"model does not define"
            )
        tools = _text_tuple(raw.get("tools"), where=f"domains.{key}.tools")
        lowered = tuple(tool.lower() for tool in tools)
        if len(set(lowered)) != len(lowered):
            raise ValueError(f"domains.{key}.tools repeats a tool name")
        prompt_pack = _text(raw.get("prompt_pack"), where=f"domains.{key}.prompt_pack")
        if prompts_dir is not None:
            pack_dir = prompts_dir / prompt_pack
            if not pack_dir.is_dir() or not any(pack_dir.glob("*.md")):
                raise ValueError(
                    f"domains.{key}.prompt_pack is {prompt_pack!r} but "
                    f"{pack_dir} is missing or holds no markdown pack"
                )
        return cls(
            key=key,
            label=_text(raw.get("label") or key, where=f"domains.{key}.label"),
            summary=str(raw.get("summary") or "").strip(),
            prompt_pack=prompt_pack,
            phases=phases,
            tools=lowered,
        )


@dataclass(frozen=True)
class Tier:
    """Entitlement for one tier, as declared by the two files."""

    key: str
    label: str
    phase_ceiling: str
    domains: tuple[str, ...]
    max_concurrent_jobs: int = 1
    scans_total: int | None = None
    scans_per_month: int = 0
    evidence_retention_days: int = 30
    exports: tuple[str, ...] = ("json",)

    @property
    def unlimited_scans(self) -> bool:
        """``scans_total: null`` means the tier is metered per month instead."""
        return self.scans_total is None


@dataclass(frozen=True)
class RoleSpec:
    """One model role: its candidate ids and the defaults for its calls."""

    role: str
    candidates: tuple[str, ...]
    max_tokens: int
    temperature: float


@dataclass(frozen=True)
class Routing:
    """Which role handles which kind of call. Cheap first, escalate on failure."""

    mapping: Mapping[str, str]

    def role_for(self, task: str, default: str = "fast") -> str:
        return self.mapping.get(task, default)

    def tasks_for(self, role: str) -> tuple[str, ...]:
        return tuple(
            sorted(task for task, value in self.mapping.items() if value == role)
        )

    def describe(self) -> dict[str, str]:
        return dict(self.mapping)


@dataclass(frozen=True)
class Limits:
    """Hard ceilings for one scan, mirroring ``models.yaml`` and ``plans.yaml``.

    These are not advice to the model. The planner reads them from here, so a
    model that decides it wants forty more steps does not get them.
    """

    max_react_steps: int = 25
    max_consecutive_tool_failures: int = 3
    max_tool_calls_per_step: int = 3
    scan_token_budget: int = 2_000_000
    max_targets_per_scan: int = 25
    max_scan_duration_minutes: int = 60

    def __post_init__(self) -> None:
        for name in (
            "max_react_steps",
            "max_consecutive_tool_failures",
            "max_tool_calls_per_step",
            "scan_token_budget",
            "max_targets_per_scan",
            "max_scan_duration_minutes",
        ):
            _positive_int(getattr(self, name), where=f"limits.{name}", default=1)


@dataclass
class AgentSpec:
    """Everything declarative the planner needs, already cross-checked."""

    phases: Mapping[str, Phase]
    packs: Mapping[str, DomainPack]
    tiers: Mapping[str, Tier]
    roles: Mapping[str, RoleSpec]
    routing: Routing
    limits: Limits
    notes: tuple[str, ...] = ()

    # ------------------------------------------------------------- accessors
    def phase(self, key: str) -> Phase:
        try:
            return self.phases[key]
        except KeyError:
            raise ValueError(
                f"unknown phase {key!r}; the phase model defines "
                f"{', '.join(self.phases)}"
            ) from None

    def pack(self, key: str) -> DomainPack:
        try:
            return self.packs[key]
        except KeyError:
            raise ValueError(
                f"unknown domain pack {key!r}; configured packs are "
                f"{', '.join(self.packs)}"
            ) from None

    def tier(self, key: str) -> Tier:
        try:
            return self.tiers[key]
        except KeyError:
            raise ValueError(
                f"unknown tier {key!r}; configured tiers are {', '.join(self.tiers)}"
            ) from None

    def phase_index(self, key: str) -> int:
        self.phase(key)
        return list(self.phases).index(key)

    def ceiling_for(self, tier: str) -> str:
        return self.tier(tier).phase_ceiling

    def phase_allowed(self, tier: str, phase: str) -> bool:
        """A tier reaches every phase up to and including its ceiling."""
        return self.phase_index(phase) <= self.phase_index(self.ceiling_for(tier))

    def phases_for(self, pack: str, tier: str) -> tuple[str, ...]:
        """The pack's phases that survive this tier's ceiling, in order."""
        return tuple(
            phase
            for phase in self.pack(pack).phases
            if self.phase_allowed(tier, phase)
        )

    def tools_for(self, pack: str, tier: str) -> frozenset[str]:
        """The pack's tools — reachable only while the pack has a live phase."""
        if not self.phases_for(pack, tier):
            return frozenset()
        return frozenset(self.pack(pack).tools)

    def effective_token_budget(self, settings: object | None = None) -> int:
        """The strictest token budget in force: configuration may only tighten.

        ``models.yaml`` documents the ceiling; ``LLM_SCAN_TOKEN_BUDGET`` can
        override it per deployment. An operator who lowers it gets the lower
        number, and nothing can raise the ceiling above the file's value.
        """
        if settings is None:
            return self.limits.scan_token_budget
        requested = _positive_int(
            getattr(settings, "llm_scan_token_budget", None),
            where="settings.llm_scan_token_budget",
            default=self.limits.scan_token_budget,
        )
        return min(requested, self.limits.scan_token_budget)

    def describe(self) -> dict[str, Any]:
        """Log-safe summary for the admin panel and the M2 acceptance test."""
        return {
            "phases": list(self.phases),
            "packs": {
                key: {"label": pack.label, "tools": list(pack.tools)}
                for key, pack in self.packs.items()
            },
            "tiers": {key: tier.phase_ceiling for key, tier in self.tiers.items()},
            "roles": {key: list(role.candidates) for key, role in self.roles.items()},
            "routing": self.routing.describe(),
            "limits": {
                "max_react_steps": self.limits.max_react_steps,
                "max_consecutive_tool_failures": (
                    self.limits.max_consecutive_tool_failures
                ),
                "max_tool_calls_per_step": self.limits.max_tool_calls_per_step,
                "scan_token_budget": self.limits.scan_token_budget,
                "max_targets_per_scan": self.limits.max_targets_per_scan,
            },
            "notes": list(self.notes),
        }


def _cross_check_ceilings(
    domain_ceilings: Mapping[str, Any], tiers: Mapping[str, Tier]
) -> list[str]:
    """``domains.yaml`` and ``plans.yaml`` must agree on where each tier stops.

    Stating the ceiling twice is deliberate — one file is the capability model,
    the other the entitlement contract — so a disagreement means somebody
    changed one and forgot the other. The product would then advertise a phase
    it does not run, which is a refund argument, not a bug report. Fail here.
    """
    if set(domain_ceilings) != set(tiers):
        raise ValueError(
            "tier_phase_ceiling in domains.yaml and tiers in plans.yaml list "
            f"different tiers: {sorted(domain_ceilings)} vs {sorted(tiers)}"
        )
    for key, ceiling in domain_ceilings.items():
        declared = str(ceiling or "").strip()
        if declared != tiers[key].phase_ceiling:
            raise ValueError(
                f"tier {key!r}: domains.yaml says the ceiling is {declared!r} "
                f"but plans.yaml says {tiers[key].phase_ceiling!r}"
            )
    return []


def _load_phases(domains_raw: Mapping[str, Any]) -> dict[str, Phase]:
    raw = domains_raw.get("phases")
    if not isinstance(raw, Mapping) or not raw:
        raise ValueError("domains.yaml must define a non-empty phases: mapping")
    phases: dict[str, Phase] = {}
    for key, value in raw.items():
        body = value if isinstance(value, Mapping) else {}
        phases[str(key)] = Phase(str(key), str(body.get("description") or "").strip())
    return phases


def _load_packs(
    domains_raw: Mapping[str, Any],
    phases: Mapping[str, Phase],
    prompts_dir: Path | None,
) -> dict[str, DomainPack]:
    raw = domains_raw.get("domains")
    if not isinstance(raw, Mapping) or not raw:
        raise ValueError("domains.yaml must define a non-empty domains: mapping")
    return {
        str(key): DomainPack.from_mapping(
            str(key), value, known_phases=phases, prompts_dir=prompts_dir
        )
        for key, value in raw.items()
    }


def load_spec(
    config_dir: Path = CONFIG_DIR,
    *,
    settings: object | None = None,
    require_prompts: bool = True,
) -> AgentSpec:
    """Load and cross-check the three configuration files.

    Args:
        config_dir: directory holding ``domains.yaml``/``plans.yaml``/
            ``models.yaml``. Tests pass a temporary copy to exercise a broken
            file without touching the real one.
        settings: optional :class:`config.settings.Settings`. When supplied it
            may only *tighten* the token ceiling; a lower value is recorded in
            :attr:`AgentSpec.notes`.
        require_prompts: when true (the default) every pack's ``prompt_pack``
            directory must exist and hold at least one markdown file, because a
            pack whose instructions are missing would silently plan blind.

    Raises:
        ValueError: naming the file and the key that is wrong.
    """
    config_dir = Path(config_dir)
    domains_raw = _read(config_dir / "domains.yaml")
    plans_raw = _read(config_dir / "plans.yaml")
    models_raw = _read(config_dir / "models.yaml")

    phases = _load_phases(domains_raw)
    packs = _load_packs(domains_raw, phases, PROMPTS_DIR if require_prompts else None)

    tiers: dict[str, Tier] = {}
    raw_tiers = plans_raw.get("tiers")
    if not isinstance(raw_tiers, Mapping) or not raw_tiers:
        raise ValueError("plans.yaml must define a non-empty tiers: mapping")
    for key, value in raw_tiers.items():
        if not isinstance(value, Mapping):
            raise ValueError(f"tiers.{key} must be a mapping")
        where = f"tiers.{key}"
        tier_limits = value.get("limits") or {}
        if not isinstance(tier_limits, Mapping):
            raise ValueError(f"{where}.limits must be a mapping")
        tiers[str(key)] = Tier(
            key=str(key),
            label=_text(value.get("label") or key, where=f"{where}.label"),
            phase_ceiling=_text(
                value.get("phase_ceiling"), where=f"{where}.phase_ceiling"
            ),
            domains=_text_tuple(value.get("domains"), where=f"{where}.domains"),
            max_concurrent_jobs=_positive_int(
                value.get("max_concurrent_jobs"),
                where=f"{where}.max_concurrent_jobs",
                default=1,
            ),
            scans_total=(
                None
                if value.get("scans_total") is None
                else _positive_int(
                    value.get("scans_total"), where=f"{where}.scans_total", default=1
                )
            ),
            scans_per_month=int(value.get("scans_per_month") or 0),
            evidence_retention_days=_positive_int(
                tier_limits.get("evidence_retention_days"),
                where=f"{where}.limits.evidence_retention_days",
                default=30,
            ),
            exports=_text_tuple(
                tier_limits.get("exports") or ["json"],
                where=f"{where}.limits.exports",
            ),
        )

    domain_ceilings = domains_raw.get("tier_phase_ceiling")
    if not isinstance(domain_ceilings, Mapping) or not domain_ceilings:
        raise ValueError("domains.yaml must define a non-empty tier_phase_ceiling")
    _cross_check_ceilings(domain_ceilings, tiers)

    for key, tier in tiers.items():
        for pack_key in tier.domains:
            if pack_key not in packs:
                raise ValueError(
                    f"tiers.{key}.domains lists {pack_key!r}, which is not a "
                    "domain pack"
                )
        if tier.phase_ceiling not in phases:
            raise ValueError(
                f"tiers.{key}.phase_ceiling is {tier.phase_ceiling!r}, which the "
                "phase model does not define"
            )

    roles = _load_roles(models_raw)
    routing = _load_routing(models_raw, roles)
    limits = _load_limits(models_raw, plans_raw)

    notes: list[str] = []
    if settings is not None:
        # The environment may lower the ceiling; it may never raise it. That is
        # the same one-way ratchet policy.yaml follows for the action guard.
        requested = _positive_int(
            getattr(settings, "llm_scan_token_budget", None),
            where="settings.llm_scan_token_budget",
            default=limits.scan_token_budget,
        )
        if requested < limits.scan_token_budget:
            notes.append(
                "LLM_SCAN_TOKEN_BUDGET tightens the per-scan budget to "
                f"{requested:,} tokens"
            )

    return AgentSpec(
        phases=phases,
        packs=packs,
        tiers=tiers,
        roles=roles,
        routing=routing,
        limits=limits,
        notes=tuple(notes),
    )


def _load_roles(models_raw: Mapping[str, Any]) -> dict[str, RoleSpec]:
    raw = models_raw.get("roles")
    if not isinstance(raw, Mapping) or not raw:
        raise ValueError("models.yaml must define a non-empty roles: mapping")
    roles: dict[str, RoleSpec] = {}
    for key, value in raw.items():
        if not isinstance(value, Mapping):
            raise ValueError(f"roles.{key} must be a mapping")
        candidates = value.get("candidates") or []
        if isinstance(candidates, str):
            candidates = [candidates]
        if not isinstance(candidates, Iterable):
            raise ValueError(f"roles.{key}.candidates must be a list of model ids")
        cleaned = tuple(
            str(item).strip() for item in candidates if str(item).strip()
        )
        if not cleaned:
            raise ValueError(
                f"roles.{key}.candidates is empty; pin at least one model id"
            )
        roles[str(key)] = RoleSpec(
            role=str(key),
            candidates=cleaned,
            max_tokens=_positive_int(
                value.get("max_tokens"), where=f"roles.{key}.max_tokens", default=2048
            ),
            temperature=float(value.get("temperature", 0.2)),
        )
    return roles


def _load_routing(
    models_raw: Mapping[str, Any], roles: Mapping[str, RoleSpec]
) -> Routing:
    raw = models_raw.get("routing") or {}
    if not isinstance(raw, Mapping):
        raise ValueError("models.yaml routing: must be a mapping")
    routing = Routing({str(task): str(role) for task, role in raw.items()})
    for task, role in routing.mapping.items():
        if role not in roles:
            raise ValueError(
                f"routing.{task} names the role {role!r}, which roles: does not "
                f"define (known: {', '.join(roles)})"
            )
    return routing


def _load_limits(
    models_raw: Mapping[str, Any], plans_raw: Mapping[str, Any]
) -> Limits:
    """Merge the loop limits from ``models.yaml`` with ``plans.yaml``.

    The two files carry different halves of the same picture: ``models.yaml``
    bounds the planner loop, ``plans.yaml`` bounds the scan as a unit of work.
    Where they overlap (the token ceiling) they must agree, because the number is
    quoted in the page's guardrail list.
    """
    raw = models_raw.get("limits") or {}
    if not isinstance(raw, Mapping):
        raise ValueError("models.yaml limits: must be a mapping")
    global_limits = plans_raw.get("global_limits") or {}
    if not isinstance(global_limits, Mapping):
        raise ValueError("plans.yaml global_limits: must be a mapping")

    file_budget = _positive_int(
        raw.get("scan_token_budget"),
        where="limits.scan_token_budget",
        default=2_000_000,
    )
    plan_budget = _positive_int(
        global_limits.get("llm_tokens_per_scan"),
        where="global_limits.llm_tokens_per_scan",
        default=file_budget,
    )
    if file_budget != plan_budget:
        raise ValueError(
            "the token ceiling disagrees between files: models.yaml "
            f"limits.scan_token_budget={file_budget:,}, plans.yaml "
            f"global_limits.llm_tokens_per_scan={plan_budget:,}"
        )

    return Limits(
        max_react_steps=_positive_int(
            raw.get("max_react_steps"),
            where="limits.max_react_steps",
            default=25,
        ),
        max_consecutive_tool_failures=_positive_int(
            raw.get("max_consecutive_tool_failures"),
            where="limits.max_consecutive_tool_failures",
            default=3,
        ),
        max_tool_calls_per_step=_positive_int(
            raw.get("max_tool_calls_per_step"),
            where="limits.max_tool_calls_per_step",
            default=3,
        ),
        scan_token_budget=file_budget,
        max_targets_per_scan=_positive_int(
            global_limits.get("max_targets_per_scan"),
            where="global_limits.max_targets_per_scan",
            default=25,
        ),
        max_scan_duration_minutes=_positive_int(
            global_limits.get("max_scan_duration_minutes"),
            where="global_limits.max_scan_duration_minutes",
            default=60,
        ),
    )
