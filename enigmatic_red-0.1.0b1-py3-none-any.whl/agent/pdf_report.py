"""The audit report as a PDF, rendered from lines so the two cannot drift.

``red report`` answers a narrow question - what the audit log records - and
:func:`report_lines` is that answer as plain, wrapped text. :func:`render_pdf`
is the only part that knows about PDF: it draws those same lines in a monospace
face, so a test can assert the content without parsing a PDF, and the paper copy
cannot say anything the terminal does not.

The rendering is byte-deterministic. reportlab writes a creation date and a
random document id by default; ``invariant=1`` replaces both with fixed values,
so one audit log yields the same bytes on any machine - which is what lets the
output be checked by hash, the way this project's raster assets are.

The document is deliberately *not* a findings report, and says so on its face.
Which claims were confirmed is decided by :mod:`agent.honesty` against a planned
scan's citations; this renderer has no claims to check, so it claims none.
"""

from __future__ import annotations

from io import BytesIO
from pathlib import Path
from typing import Any, Mapping, Sequence

__all__ = ["NOT_A_FINDINGS_REPORT", "WIDTH", "render_pdf", "report_lines", "write_pdf"]

#: The line length the report is wrapped to, and the width the PDF draws. An
#: 88-column page at 9pt Courier fits A4's text block, so the wrap and the page
#: agree and no line is ever clipped.
WIDTH = 88

#: The one thing a reader must not get wrong about this document.
NOT_A_FINDINGS_REPORT = (
    "This is what the audit log records: which controls ran, which refused, and "
    "whether the chain behind them still verifies. It is not a findings report. "
    "A confirmed finding requires a planned scan, and nothing here invents one "
    "from a tool run."
)


def _wrap(text: str, width: int = WIDTH) -> list[str]:
    """Wrap on spaces; a word longer than a line is split, never dropped.

    A leading indent becomes a left margin for the whole block, so an indented
    paragraph keeps its column on every line and not only the first. Runs of
    spaces *inside* a line are collapsed, so a column that must stay aligned is
    built with :func:`_labelled` rather than passed here.
    """
    text = str(text)
    indent = text[: len(text) - len(text.lstrip(" "))]
    if len(indent) >= width - 1:
        indent = ""
    fresh = width - len(indent)  # the room on a line that already carries the indent
    words = text.split()
    if not words:
        return [""]
    lines: list[str] = []
    current = ""
    for word in words:
        while word:
            room = fresh - (len(current) + (1 if current else 0))
            if room <= 0 or (current and len(word) > room and len(word) <= fresh):
                # Open a new line rather than break a word that would fit on one.
                lines.append(current)
                current = ""
                continue
            if len(word) <= room:
                current += (" " if current else "") + word
                word = ""
            else:
                # The word is longer than a whole line: split it, do not drop it.
                current += (" " if current else "") + word[:room]
                lines.append(current)
                current = ""
                word = word[room:]
    if current or not lines:
        lines.append(current)
    if indent:
        lines = [indent + line for line in lines]
    return lines


def _row(text: str) -> list[str]:
    """A structured line: kept verbatim while it fits, wrapped when it cannot."""
    line = str(text)
    return [line] if len(line) <= WIDTH else _wrap(line)


def _labelled(label: str, value: str, *, label_width: int = 9) -> list[str]:
    """A label column and a value that wraps underneath it, never beside it."""
    head = label.ljust(label_width)
    payload = str(value)
    if len(head) + len(payload) <= WIDTH:
        return [head + payload]
    wrapped = _wrap(payload, WIDTH - len(head))
    return [head + wrapped[0]] + [" " * len(head) + line for line in wrapped[1:]]



def report_lines(payload: Mapping[str, Any]) -> tuple[str, ...]:
    """The audit report as plain lines, wrapped for an 88-column page.

    Args:
        payload: the same shape ``red report --json`` prints -
            ``audit_path``, ``chain_ok``, ``chain_message``, ``entries``,
            ``head_hash``, ``decisions`` (name -> count) and ``refusals`` (the
            audit rows a control stopped, in log order).

    The chain is stated before the counts, and a broken chain says so in words,
    because a report over a chain that does not verify is not a report.
    """
    audit_path = str(payload.get("audit_path") or "(unknown)")
    chain_ok = bool(payload.get("chain_ok"))
    chain_message = str(payload.get("chain_message") or "")
    try:
        entries = int(payload.get("entries") or 0)
    except (TypeError, ValueError):
        entries = 0
    head_hash = str(payload.get("head_hash") or "")
    decisions: Mapping[str, Any] = payload.get("decisions") or {}
    refusals: Sequence[Mapping[str, Any]] = payload.get("refusals") or ()

    lines: list[str] = ["Enigmatic Red - audit report", "=" * WIDTH, ""]
    lines += _wrap(NOT_A_FINDINGS_REPORT)
    lines += ["", f"audit log  {audit_path}", ""]

    lines.append("Integrity")
    lines += _labelled("chain", f"{'intact' if chain_ok else 'BROKEN'}: {chain_message}")
    lines += _labelled("entries", str(entries))
    lines += _labelled("head", head_hash)
    if not chain_ok:
        lines.append("")
        lines += _wrap(
            "  The chain does not verify, so no entry below can be treated as "
            "evidence. Find the break before reading the counts."
        )
    lines.append("")

    lines.append("Decisions")
    if decisions:
        for key, count in sorted(
            decisions.items(), key=lambda item: (-int(item[1]), str(item[0]))
        ):
            lines += _row(f"  {int(count):>6}  {key}")
    else:
        lines.append("  (none recorded)")
    lines.append("")

    lines.append(f"Refused by policy ({len(refusals)})")
    if refusals:
        for row in refusals:
            detail = dict(row.get("detail") or {})
            reason = detail.get("reason") or detail.get("refusal") or ""
            seq = row.get("seq")
            head = (
                f"  #{seq if seq is not None else '?'} {row.get('event')} "
                f"{row.get('target') or ''}"
            )
            lines += _row(head.rstrip())
            if reason:
                lines += _wrap(f"      {reason}")
    else:
        lines.append("  (none recorded)")
    lines.append("")
    return tuple(lines)



def render_pdf(lines: Sequence[str], *, footer: str = "") -> bytes:
    """Draw ``lines`` in a monospace face, deterministically, and return the PDF.

    One page or many: the lines flow at 12pt leading and each page is stamped
    with ``footer`` and its number. Nothing here reads the clock or the machine,
    so the same ``lines`` and ``footer`` give the same bytes everywhere.

    Raises:
        ImportError: reportlab is not installed. The caller turns that into a
            sentence naming the ``reporting`` extra, so an install that only
            scans never has to carry it.
    """
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.units import mm
        from reportlab.pdfgen import canvas
    except ImportError as exc:  # pragma: no cover - the CLI turns this into a sentence
        raise ImportError(
            "rendering a PDF needs reportlab, which lives in the 'reporting' extra"
        ) from exc

    body = [str(line) for line in lines]
    font = "Courier"
    size = 9.0
    leading = 12.0
    margin = 18 * mm
    page_height = A4[1]
    per_page = max(1, int((page_height - 2 * margin) // leading))
    pages = max(1, -(-len(body) // per_page))

    buffer = BytesIO()
    pdf = canvas.Canvas(
        buffer,
        pagesize=A4,
        invariant=1,  # fixed date and document id: the bytes are reproducible
        pageCompression=1,
    )
    pdf.setTitle("Enigmatic Red audit report")
    pdf.setAuthor("Enigmatic Red")
    pdf.setSubject("A rendering of the audit log, not a findings report")
    pdf.setCreator("red report --pdf")
    pdf.setProducer("Enigmatic Red")
    for page in range(pages):
        pdf.setFont(font, size)
        y = page_height - margin
        for line in body[page * per_page : (page + 1) * per_page]:
            pdf.drawString(margin, y, line)
            y -= leading
        stamp = f"page {page + 1} of {pages}"
        if footer:
            stamp = f"{footer}  -  {stamp}"
        pdf.setFont(font, 7.5)
        pdf.drawString(margin, margin / 2, stamp)
        pdf.showPage()
    pdf.save()
    return buffer.getvalue()


def write_pdf(path: str | Path, lines: Sequence[str], *, footer: str = "") -> Path:
    """Render ``lines`` to ``path``, creating the parent directory first."""
    destination = Path(path).expanduser()
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(render_pdf(lines, footer=footer))
    return destination
