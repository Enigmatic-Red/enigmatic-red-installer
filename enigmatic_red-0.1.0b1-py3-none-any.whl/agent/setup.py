"""The setup surface: the scope on screen, one dated attestation, then hands.

``red serve --hands`` needs a seeded home *and* an attestation naming an
in-scope target. Without the second it refuses to start, and the desktop window
that supervises it has nothing to show - which is the dead end this module
removes. What is served instead is this: the scope file as it stands, its
digest, and one form that writes the same ``config/authorization.json``
``red authorize`` writes, through the same :func:`safety.authz.make_attestation`
call, so the terminal and the window cannot produce different paper.

It is built by :func:`cli.commands.cmd_serve` and mounted by
:func:`agent.serve.create_app` only when there are no hands, and it exposes no
run route: the routes here are a page and a file, and the file is what the gate
reads the next time the command is started with ``--hands``. Nothing here can
scan, and nothing here edits the scope - an attestation must bind to a scope a
human wrote, not to one a form widened.
"""

# No ``from __future__ import annotations`` here, for the reason
# :mod:`agent.hands` gives: FastAPI reads these endpoint signatures at run time,
# and a postponed ``Request`` annotation would not resolve to the class imported
# inside :meth:`Setup.mount` - it would be read as a field to validate, and a
# documented POST body would answer 422 without the handler ever running.
import json
import os
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable

from agent.session import LAB_STATEMENT
from cli.home import attestation_from_dict
from safety.authz import (
    ATTESTATION_STATEMENT,
    Attestation,
    AuthorizationGate,
    VerificationMethod,
    make_attestation,
    scope_digest,
)
from safety.scope import Scope

__all__ = ["RELAUNCH_EXIT", "Setup", "VERIFICATION_LABELS"]

#: Exit code that tells the desktop launcher "the attestation is written; start
#: me again with ``--hands``". From the sysexits range (EX_TEMPFAIL), so it is
#: not a code a crash or argparse would produce.
RELAUNCH_EXIT = 75

#: How the page names each method. ``none`` is listed because the terminal
#: allows it; whether this install accepts it is the gate's answer, not ours.
VERIFICATION_LABELS = {
    VerificationMethod.NONE: "Self-attested only",
    VerificationMethod.DNS_TXT: "DNS TXT record on the target domain",
    VerificationMethod.HTTP_FILE: "HTTP file under /.well-known/",
    VerificationMethod.CLOUD_IAM: "Cloud IAM (provider API)",
    VerificationMethod.MANUAL_REVIEW: "Manual review of an uploaded document",
}

#: The furthest one signature may claim to be valid. The gate's ``max_age_days``
#: is a different number: this is how long the paper claims, not how old a
#: record may be before it is refused.
MAX_DAYS = 365


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


class Setup:
    """The page that exists instead of the chain, and the one file it writes.

    Args:
        scope_file: the scope this home was seeded with. Read, never written.
        authorization_file: the file ``red authorize`` writes; the only thing
            this surface creates.
        gate: the gate whose answers decide whether the attestation on file is
            still good. Defaults to the one :class:`agent.session.ScanSession`
            would build, so the page and the run agree by construction.
        statement: the words the form is pre-filled with. Defaults to
            :data:`safety.authz.ATTESTATION_STATEMENT`, the statement the gate's
            own builder defaults to - the terminal's ``red authorize`` pre-fills
            the lab preset instead, and the page offers that one too, because
            the words are the operator's to choose and the file records them
            verbatim.
        relaunch: called after a successful ``POST /api/setup/relaunch``. The
            command passes one only when it was started to be supervised (see
            ``red serve --restart-on-setup``); without it the route says how to
            restart by hand rather than killing a server nobody is watching.
    """

    def __init__(
        self,
        *,
        scope_file: Path,
        authorization_file: Path,
        gate: AuthorizationGate | None = None,
        statement: str = ATTESTATION_STATEMENT,
        default_days: int = 30,
        max_days: int = MAX_DAYS,
        relaunch: Callable[[], None] | None = None,
    ) -> None:
        self.scope_file = Path(scope_file)
        self.authorization_file = Path(authorization_file)
        self.gate = gate or AuthorizationGate()
        self.statement = statement
        self.default_days = default_days
        self.max_days = max_days
        self.relaunch = relaunch

    # ------------------------------------------------------------- what it is
    @property
    def home_root(self) -> Path:
        """The home, derived from the two files it was given."""
        return self.authorization_file.parent.parent

    def _read(self) -> tuple[Attestation | None, str]:
        """The attestation on file, or ``(None, why not)``."""
        if not self.authorization_file.is_file():
            return None, f"no attestation at {self.authorization_file}"
        try:
            raw = json.loads(self.authorization_file.read_text(encoding="utf-8"))
            return attestation_from_dict(raw), ""
        except Exception as exc:  # noqa: BLE001 - a hand-edited file is a state
            return None, (
                f"{self.authorization_file.name} could not be read: "
                f"{type(exc).__name__}: {exc}"
            )

    def state(self) -> dict[str, Any]:
        """Whether a run would be allowed for the target already on file.

        The question is deliberately the attested target's own: this surface
        names one asset, and "would a run against *that* asset be permitted" is
        the only answer that decides whether ``--hands`` will start.
        """
        scope = Scope.from_yaml(self.scope_file)
        digest = scope_digest(scope)
        attestation, problem = self._read()
        now = _utcnow()
        if attestation is None:
            return {
                "state": "missing",
                "reason": problem,
                "attestation": None,
                "scope_digest": digest,
            }

        ok, reason = self.gate.check(attestation, attestation.target, scope, now=now)
        if ok:
            word = "ready"
        elif attestation.is_expired(now):
            word = "expired"
        elif (now - attestation.signed_at).days > self.gate.max_age_days:
            word = "stale"
        elif (
            self.gate.require_verification
            and attestation.verification is VerificationMethod.NONE
        ):
            word = "self_attested"
        elif attestation.scope_digest != digest:
            word = "scope_changed"
        else:
            word = "refused"
        return {
            "state": word,
            # The gate's own sentence, not a second wording of the same fact.
            "reason": reason,
            "scope_digest": digest,
            "attestation": {
                "target": attestation.target,
                "organization": attestation.organization,
                "subject": attestation.subject,
                "reference": attestation.reference,
                "verification": attestation.verification.value,
                "signed_at": attestation.signed_at.isoformat(),
                "expires_at": (
                    attestation.expires_at.isoformat()
                    if attestation.expires_at
                    else None
                ),
                "scope_digest": attestation.scope_digest,
                "statement_digest": attestation.statement_digest,
            },
        }

    def status(self) -> dict[str, Any]:
        """Everything the page needs to render, and nothing it has to guess."""
        found = self.state()
        return {
            "setup": True,
            "scope_path": str(self.scope_file),
            "scope_text": self.scope_file.read_text(encoding="utf-8"),
            "scope_digest": found["scope_digest"],
            "authorization_path": str(self.authorization_file),
            "authorization": found["attestation"],
            "state": found["state"],
            "reason": found["reason"],
            "statement": self.statement,
            "statement_options": {
                "lab": LAB_STATEMENT,
                "attestation": ATTESTATION_STATEMENT,
            },
            "require_verification": self.gate.require_verification,
            "max_age_days": self.gate.max_age_days,
            "default_days": self.default_days,
            "max_days": self.max_days,
            "verification_methods": [
                {
                    "value": method.value,
                    "label": VERIFICATION_LABELS[method],
                    # The gate's rule, stated where the choice is made: a
                    # self-attested record is a file the run then refuses.
                    "allowed": not (
                        method is VerificationMethod.NONE
                        and self.gate.require_verification
                    ),
                }
                for method in VerificationMethod
            ],
            "can_restart": self.relaunch is not None,
            "commands": {
                "authorize": (
                    f'red --home "{self.home_root}" authorize --target '
                    "<target> --organization <who you are> --subject "
                    "<who signs> --reference <ticket> --confirm"
                ),
                "serve": f'red --home "{self.home_root}" serve --hands',
            },
            "note": (
                "the scope is read from disk and never edited here: an "
                "attestation binds to the exact text it was signed against, so "
                f"edit {self.scope_file} in an editor and reload this page"
            ),
        }

    # ------------------------------------------------------------- one record
    def write(self, body: Any) -> tuple[int, dict[str, Any]]:
        """Sign one target, or answer why not. Returns ``(status, payload)``.

        Every refusal here is the terminal's own refusal, in the same words: an
        out-of-scope target, a missing confirmation, a self-reported method the
        gate will not accept. A page that could produce paper the command
        refuses would be a second, weaker authority, which is the one thing this
        surface must not become.
        """
        if not isinstance(body, dict):
            return 400, {"error": "the request body is not a JSON object"}

        scope = Scope.from_yaml(self.scope_file)
        target = str(body.get("target") or "").strip()
        if not target:
            return 400, {
                "error": (
                    "a target is required: an attestation names one asset, and "
                    "that name is what the gate checks the scope against"
                )
            }
        decision = scope.check(target)
        if not decision.allowed:
            return 409, {
                "error": (
                    f"refusing to authorize {target!r}: {decision.reason}. "
                    f"Edit {self.scope_file} if that asset is genuinely in scope."
                )
            }

        organization = str(body.get("organization") or "").strip()
        subject = str(body.get("subject") or "").strip()
        reference = str(body.get("reference") or "").strip()
        for name, value, why in (
            ("organization", organization, "which body holds the authority"),
            ("subject", subject, "which human signs"),
            ("reference", reference, "which written permission is cited"),
        ):
            if not value:
                return 400, {
                    "error": (
                        f"{name} is required: the record has to say {why}, "
                        "because a reviewer reads it beside the statement"
                    )
                }

        method_text = str(body.get("verification") or "").strip().lower()
        try:
            method = VerificationMethod(method_text)
        except ValueError:
            options = ", ".join(
                found.value
                for found in VerificationMethod
                if not (
                    found is VerificationMethod.NONE
                    and self.gate.require_verification
                )
            )
            return 400, {
                "error": f"{method_text!r} is not a verification method: {options}"
            }
        if self.gate.require_verification and method is VerificationMethod.NONE:
            return 409, {
                "error": (
                    "this install requires target control to be verified, so a "
                    "self-attested record would be refused at run time: choose "
                    "dns_txt, http_file, cloud_iam or manual_review - the record "
                    "says how it was corroborated, so it has to be true"
                )
            }

        statement = str(body.get("statement") or "").strip()
        if len(statement) < 40:
            return 400, {
                "error": (
                    "the statement is stored verbatim with the scan and read "
                    "beside it later; sign the words, do not clear them"
                )
            }

        days = body.get("days", self.default_days)
        if (
            isinstance(days, bool)
            or not isinstance(days, int)
            or not 1 <= days <= self.max_days
        ):
            return 400, {
                "error": f"days must be a whole number between 1 and {self.max_days}"
            }

        # The typed confirmation, not a tick: the operator has to have looked at
        # the asset they are signing for. The terminal's `--confirm` is the same
        # promise with less to read, and it stays as it is.
        if str(body.get("confirm") or "").strip() != target:
            return 400, {
                "error": (
                    f"confirm must be the target, typed exactly ({target!r}): "
                    "the record names one asset, and this is the moment you look "
                    "at it"
                )
            }

        attestation = make_attestation(
            organization=organization,
            subject=subject,
            target=target,
            reference=reference,
            scope=scope,
            signed_text=statement,
            verification=method,
            valid_for=timedelta(days=days),
        )
        written_to = self._write_file(attestation)
        return 200, {
            "written": str(written_to),
            "target": attestation.target,
            "organization": attestation.organization,
            "subject": attestation.subject,
            "reference": attestation.reference,
            "verification": attestation.verification.value,
            "expires_at": (
                attestation.expires_at.isoformat() if attestation.expires_at else None
            ),
            "scope_digest": attestation.scope_digest,
            "state": self.state()["state"],
        }

    def _write_file(self, attestation: Attestation) -> Path:
        """Write through a temporary file, so a partial record is never read.

        ``red authorize`` writes in place; the content is identical and the
        difference is deliberate: the page's version has to survive losing power
        between two writes, because a half-written JSON here reads as "no
        attestation" at the next start and the operator would sign twice.
        """
        path = self.authorization_file
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_name(path.name + ".tmp")
        temporary.write_text(
            json.dumps(attestation.to_dict(), indent=2), encoding="utf-8"
        )
        os.replace(temporary, path)
        return path

    # ---------------------------------------------------------------- routing
    def mount(self, app: Any) -> None:
        """Add ``GET /api/setup``, ``POST /api/setup/attest`` and one restart.

        ``Request`` is imported here for the reason :mod:`agent.hands` gives: it
        has to be the *annotation*, so FastAPI reads the body as the body rather
        than as a field called ``request``.
        """
        from fastapi import Request
        from fastapi.responses import JSONResponse

        @app.get("/api/setup")
        def explain() -> Any:
            """The scope, the state and the words, for the page to render."""
            try:
                return JSONResponse(self.status())
            except Exception as exc:  # noqa: BLE001 - a broken scope is a state
                # A hand-edited YAML is a thing the operator can see and fix, so
                # it is answered as a state rather than as a 500 the page can
                # only render as "unavailable".
                return JSONResponse(
                    {
                        "setup": True,
                        "state": "unreadable",
                        "reason": (
                            f"{self.scope_file.name} could not be read: "
                            f"{type(exc).__name__}: {exc}"
                        ),
                        "scope_path": str(self.scope_file),
                        "authorization_path": str(self.authorization_file),
                    }
                )

        @app.post("/api/setup/attest")
        async def attest(request: Request) -> Any:
            """Write the dated attestation, or say why it would be worthless."""
            try:
                body = await request.json()
            except Exception:  # noqa: BLE001 - a page can post anything
                return JSONResponse(
                    status_code=400,
                    content={"error": "the request body is not valid JSON"},
                )
            status, payload = self.write(body)
            return JSONResponse(status_code=status, content=payload)

        @app.post("/api/setup/relaunch")
        def relaunch() -> Any:
            """Ask the supervisor to come back with ``--hands``.

            Only once the file exists and the gate accepts it: a restart on
            paper the gate still refuses would put the operator back in front of
            the same window, which is the failure this surface was built to end.
            """
            found = self.state()
            if found["state"] != "ready":
                return JSONResponse(
                    status_code=409,
                    content={
                        "error": (
                            "no attestation the gate would accept is on file "
                            f"yet: {found['reason']}"
                        )
                    },
                )
            if self.relaunch is None:
                return JSONResponse(
                    status_code=409,
                    content={
                        "error": (
                            "this backend was not started by a supervisor, so it "
                            "will not restart itself: stop it and run the command "
                            "below"
                        ),
                        "command": f'red --home "{self.home_root}" serve --hands',
                    },
                )
            self.relaunch()
            return JSONResponse({"restarting": True, "exit_code": RELAUNCH_EXIT})
