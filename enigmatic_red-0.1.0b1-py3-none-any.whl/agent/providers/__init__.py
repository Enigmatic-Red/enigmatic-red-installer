"""LLM providers.

The orchestrator depends on :class:`~agent.providers.base.LLMProvider` only.
Swap the implementation here and nothing else in the codebase changes.
"""

from agent.providers.base import (
    ChatMessage,
    ChatResult,
    ChatStreamChunk,
    LLMProvider,
    ModelSpec,
    TokenLedger,
    ToolCall,
    ToolSpec,
    Usage,
)

__all__ = [
    "ChatMessage",
    "ChatResult",
    "ChatStreamChunk",
    "FeatherlessProvider",
    "LLMProvider",
    "ModelSpec",
    "TokenLedger",
    "ToolCall",
    "ToolSpec",
    "Usage",
    "provider_from_settings",
    "resolve_model_spec",
]


def __getattr__(name: str):
    """Import the vendor adapter lazily.

    ``python -m agent.providers.featherless`` must not find the module already
    in ``sys.modules`` at startup, or the interpreter emits a RuntimeWarning.
    """
    if name in {"FeatherlessProvider", "provider_from_settings", "resolve_model_spec"}:
        from agent.providers import featherless

        return getattr(featherless, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

