"""Provider-agnostic LLM interface.

The orchestrator never imports an HTTP client. It talks to :class:`LLMProvider`
and, in tests, to a fake one. That keeps model choice — and the vendor's
pricing, availability and deprecations — an operational detail rather than an
architectural constraint.

The wire format is the OpenAI chat-completions shape, which Featherless
implements: ``messages``, ``tools``, ``tool_choice`` in, a ``tool_calls``
array out. Everything vendor-specific lives in a subclass.
"""

from __future__ import annotations

import ipaddress
import json
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, AsyncIterator, Iterable, Sequence
from urllib.parse import urlparse

__all__ = [
    "ChatMessage",
    "ChatResult",
    "ChatStreamChunk",
    "LLMProvider",
    "ModelSpec",
    "TokenLedger",
    "ToolCall",
    "ToolSpec",
    "Usage",
    "host_is_local",
]

#: Hostnames that mean "this machine or this network", so no key is expected.
LOCAL_HOST_SUFFIXES = (".local", ".internal", ".lan", ".home.arpa", ".localhost")


def host_is_local(base_url: str) -> bool:
    """True when the endpoint is this machine or this network.

    The setup scripts point the agent at a model on the operator's own machine
    (loopback, or a box on the LAN), and such an endpoint authenticates nobody.
    A missing key there is therefore correct rather than a misconfiguration -
    which is what lets a self-hosted install run with no credential at all.
    """
    host = (urlparse(base_url).hostname or "").lower().strip("[]")
    if not host:
        return True  # no host at all: nothing remote is reachable
    if host == "localhost" or host.endswith(LOCAL_HOST_SUFFIXES):
        return True
    try:
        address = ipaddress.ip_address(host)
    except ValueError:
        return False  # a name on the public DNS: assume it is hosted
    return address.is_loopback or address.is_private or address.is_link_local



# --------------------------------------------------------------------- specs
@dataclass(frozen=True)
class ModelSpec:
    """A resolved model plus the defaults to use with it."""

    id: str
    role: str = "fast"
    max_tokens: int = 2048
    temperature: float = 0.2

    def __post_init__(self) -> None:
        if not self.id or not self.id.strip():
            raise ValueError("ModelSpec requires a model id")


@dataclass(frozen=True)
class ToolSpec:
    """A tool offered to the model, in OpenAI function-calling shape."""

    name: str
    description: str
    parameters: dict[str, Any] = field(
        default_factory=lambda: {"type": "object", "properties": {}}
    )

    def to_openai(self) -> dict[str, Any]:
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.parameters,
            },
        }


@dataclass(frozen=True)
class ToolCall:
    """A tool invocation requested by the model."""

    id: str
    name: str
    arguments: dict[str, Any] = field(default_factory=dict)
    raw_arguments: str = ""

    @classmethod
    def from_openai(cls, payload: dict[str, Any]) -> "ToolCall":
        """Build from one entry of an OpenAI ``tool_calls`` array.

        Models sometimes emit malformed JSON in ``arguments``. That becomes an
        empty argument dict plus the raw string rather than an exception, so a
        single bad call cannot kill a scan.
        """
        function = payload.get("function") or {}
        raw = function.get("arguments") or "{}"
        try:
            parsed = json.loads(raw) if isinstance(raw, str) else dict(raw)
            if not isinstance(parsed, dict):
                parsed = {"_value": parsed}
        except (json.JSONDecodeError, TypeError, ValueError):
            parsed = {}
        return cls(
            id=str(payload.get("id") or ""),
            name=str(function.get("name") or ""),
            arguments=parsed,
            raw_arguments=raw if isinstance(raw, str) else json.dumps(raw),
        )

    def to_openai(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "type": "function",
            "function": {
                "name": self.name,
                "arguments": self.raw_arguments or json.dumps(self.arguments),
            },
        }


@dataclass(frozen=True)
class ChatMessage:
    """One conversation turn. ``role`` is system/user/assistant/tool."""

    role: str
    content: str = ""
    tool_calls: tuple[ToolCall, ...] = ()
    tool_call_id: str | None = None
    name: str | None = None

    def to_openai(self) -> dict[str, Any]:
        payload: dict[str, Any] = {"role": self.role, "content": self.content}
        if self.tool_calls:
            payload["tool_calls"] = [call.to_openai() for call in self.tool_calls]
        if self.tool_call_id:
            payload["tool_call_id"] = self.tool_call_id
        if self.name:
            payload["name"] = self.name
        return payload

    @classmethod
    def system(cls, content: str) -> "ChatMessage":
        return cls(role="system", content=content)

    @classmethod
    def user(cls, content: str) -> "ChatMessage":
        return cls(role="user", content=content)

    @classmethod
    def assistant(cls, content: str = "", tools: Sequence[ToolCall] = ()) -> "ChatMessage":
        return cls(role="assistant", content=content, tool_calls=tuple(tools))

    @classmethod
    def tool_result(
        cls, call_id: str, content: str, name: str | None = None
    ) -> "ChatMessage":
        return cls(role="tool", content=content, tool_call_id=call_id, name=name)


@dataclass
class Usage:
    """Token counts for one call."""

    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0

    @classmethod
    def from_openai(cls, payload: dict[str, Any] | None) -> "Usage":
        payload = payload or {}
        prompt = int(payload.get("prompt_tokens", 0) or 0)
        completion = int(payload.get("completion_tokens", 0) or 0)
        total = int(payload.get("total_tokens", 0) or (prompt + completion))
        return cls(prompt, completion, total)

    def __add__(self, other: "Usage") -> "Usage":
        return Usage(
            self.prompt_tokens + other.prompt_tokens,
            self.completion_tokens + other.completion_tokens,
            self.total_tokens + other.total_tokens,
        )


@dataclass
class TokenLedger:
    """Cumulative model spend for one scan, with a hard ceiling.

    Featherless bills per token, to whoever is running the scan, and a prompt
    loop with no ceiling can run away on its own. So every scan carries a budget
    and the orchestrator refuses to continue once it is spent.
    """

    budget: int = 0  # 0 means unlimited (dev only)
    used: Usage = field(default_factory=Usage)
    calls: int = 0

    def add(self, usage: Usage) -> None:
        self.used = self.used + usage
        self.calls += 1

    @property
    def exhausted(self) -> bool:
        return self.budget > 0 and self.used.total_tokens >= self.budget

    @property
    def remaining(self) -> int:
        if self.budget <= 0:
            return -1
        return max(0, self.budget - self.used.total_tokens)

    def describe(self) -> dict[str, int]:
        return {
            "budget": self.budget,
            "used_prompt": self.used.prompt_tokens,
            "used_completion": self.used.completion_tokens,
            "used_total": self.used.total_tokens,
            "remaining": self.remaining,
            "calls": self.calls,
        }


@dataclass
class ChatResult:
    """A completed (non-streaming) turn."""

    message: ChatMessage
    model: str
    usage: Usage = field(default_factory=Usage)
    finish_reason: str | None = None
    latency_ms: float = 0.0
    raw: dict[str, Any] = field(default_factory=dict)
    role_used: str = "fast"

    @property
    def text(self) -> str:
        return self.message.content

    @property
    def tool_calls(self) -> tuple[ToolCall, ...]:
        return self.message.tool_calls


@dataclass
class ChatStreamChunk:
    """One delta from a streaming turn."""

    text: str = ""
    tool_call_deltas: tuple[dict[str, Any], ...] = ()
    finish_reason: str | None = None


class LLMProvider(ABC):
    """What the orchestrator is allowed to assume about a model backend."""

    name: str = "abstract"

    @abstractmethod
    async def chat(
        self,
        messages: Sequence[ChatMessage],
        *,
        tools: Iterable[ToolSpec] | None = None,
        role: str = "fast",
        temperature: float | None = None,
        max_tokens: int | None = None,
        json_mode: bool = False,
    ) -> ChatResult:
        """Run one completion and return the assistant turn."""

    @abstractmethod
    def stream(
        self,
        messages: Sequence[ChatMessage],
        *,
        tools: Iterable[ToolSpec] | None = None,
        role: str = "fast",
        temperature: float | None = None,
        max_tokens: int | None = None,
    ) -> AsyncIterator[ChatStreamChunk]:
        """Stream one completion (drives the chat UI's typing effect)."""

    @abstractmethod
    async def aclose(self) -> None:
        """Release the underlying connection pool."""

    @property
    @abstractmethod
    def ledger(self) -> TokenLedger:
        """Cumulative usage for this provider instance."""
