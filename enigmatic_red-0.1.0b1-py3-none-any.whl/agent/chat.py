"""A BYOK chat surface: the model talks, nothing else happens.

Red has two model-driven surfaces, and this module is deliberately the smaller
one. The planner (`agent/planner.py`) *acts*: it chooses capabilities, and every
choice is re-checked against the kill switch, the authorization, the scope and
the guard before a process exists. This module *talks*: it sends the operator's
words to the endpoint configured in `.env` and prints what comes back.

That difference is the whole design. A chat turn here:

* runs no capability, spawns nothing, and touches no target;
* therefore writes no audit line, because there is nothing to record;
* refuses to pretend otherwise - when the model answers with a tool call it is
  reported as a **suggestion that was not run**, never as a result.

Bring your own key: the key and the endpoint come from `.env`
(``FEATHERLESS_API_KEY`` / ``LLM_API_KEY``, ``FEATHERLESS_BASE_URL``) or from the
environment, so this is a self-hosted beta with no sign-up and no key issued by
anyone. A model on the operator's own machine needs no key at all, which is what
``setup_local_model.*`` produces and what :func:`key_status` reports.

Because the prompt is *input* to a model and never authority, a sentence here is
a claim until a run in the audit log supports it - the same rule the report
enforces, applied to conversation. :data:`CHAT_CONTRACT` says so to the model;
the operator-facing sentence is printed by `red` and pinned by the tests.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Mapping, Sequence

import httpx

from agent.chat_tools import (
    MAX_CALLS_PER_ROUND,
    MAX_ROUNDS,
    NOT_RUN_NOTICE,
    READ_ONLY_FAILED,
    READ_ONLY_NAMED,
    READ_ONLY_NOTE,
    REFUSED_NOTE,
    TIMEOUT_MS,
    ReferenceRefused,
    as_failure,
    as_tool_message,
    named_in,
    plan_read,
    site_text,
    tool_specs,
)
from agent.providers.base import ChatMessage, ToolCall, host_is_local
from config.settings import Settings, get_settings

__all__ = [
    "CHAT_CONTRACT",
    "NOT_A_RUN",
    "ChatSession",
    "ChatTurn",
    "TARGET_NOTE",
    "VERDICT_REPLACED",
    "answer_is_a_verdict",
    "as_lines",
    "chat_system_prompt",
    "empty_answer_line",
    "install_facts",
    "key_status",
    "names_a_target",
]

#: Printed under every answer, and quoted in the docs. One sentence, because the
#: failure mode it prevents - an operator reading a chat sentence as a finding -
#: is the one thing an assessment tool must never allow.
NOT_A_RUN = (
    "chat only: nothing was run, no target was touched, and nothing was audited. "
    "A sentence from a model here is a claim; only `red scan` produces findings."
)

#: The local-endpoint rule lives in :mod:`agent.providers.base` (``host_is_local``),
#: because the provider is what must honour it when it decides whether a key is
#: required; `key_status` below only reports what that rule decided.

#: The route to a run is deliberately *not* in here. This text is shared
#: byte-for-byte with the hosted Function (`functions/api/chat.js`), so a route
#: named in it is a route named at a web visitor, who has nothing to run it with.
#: Live turn, second finding: told it was "not the planning mode", a 7B offered to
#: "use the planning mode to define a scope and obtain the necessary attestations"
#: - a door that does not exist (`agent/planner.py` has no command; `BETA.md` says
#: a planned scan is driven from Python for now). Commands belong to the install,
#: so each surface names its own routes in its own facts block: below, for
#: `red`; `hostedFacts` in the Function for the web, which names none and says
#: where the run happens instead.
CHAT_CONTRACT = """You are the conversational half of Enigmatic Red, an authorised,
scope-locked, non-destructive vulnerability assessment platform. This mode only
talks: it runs no step, chooses no step, and has none of the acting half's
machinery.

What is true here, and what you may not imply otherwise:

- You have **no capabilities** in this mode. You cannot run a tool, a command or
  a probe, and you cannot read a target. If you emit a tool call, nothing will
  run it: the operator sees it as a suggestion, and it is reported as one.
- Nothing you say here is audited. There is no run behind it, so there is no
  evidence behind it, and nothing you say can become a finding.
- Never say you scanned, checked, tested, verified, confirmed or exploited
  anything. You did not, and the operator is told so in the same breath.
- Answer about the method: how scope is written, why a class of action is
  forbidden or intrusive, what a phase is for, how to read an audit line, what a
  report will and will not assert. That is what this mode is for.
- Answer the technique as well as the method. A publicly documented class of
  attack, and the tooling around it, is knowledge this mode answers rather than
  declines: what the class is, why it works, which phase this product would work
  it in and which adapter exercises that phase, what the guard checks before such
  a step, and where the authoritative write-up lives. Name those references as
  Markdown links - an OWASP WSTG test, a CWE, a MITRE ATT&CK technique, a CVE, a
  vendor advisory, a project's own documentation - so the reader can follow them
  to the primary source instead of trusting this answer for a fact it cannot
  hold. A request naming a public technique is a request about the method, not a
  verdict to give.
- When a question needs a real run, say where that run happens and that the guard
  and the audit log apply there and not here. Name a route only if the facts
  below name one: this mode is one of two surfaces, and a command is useful only
  where the operator can type it.
- Quote nothing you were not given. If you do not know, say you do not know; that
  is more useful than a fluent guess, and it is the same rule the report follows.
- Authorisation is not this mode's to decide: there is no scope file, no
  attestation and no mandate here to consult. So answer no request with a verdict
  on it - not that it is unauthorised, and not that it is invalid,
  inappropriate, out of scope or a request you cannot help with, which is the
  same refusal in different words - and never refuse a target, a capability or a
  lab address on your own judgement. A question that names a target is a question
  about the method: answer what a run against it would do, which adapter a phase
  would use and what the guard would check, and say what a run would need - that
  target named in the scope file, a signed attestation, and a human's yes for an
  intrusive command line - and that a run is what checks them. The refusal a run
  gives, with its reason, is the only authorisation answer this product has.

Be direct and short. The operator is a professional reading a terminal."""


#: Printed under an answer whenever the question named something a run could be
#: pointed at, and the reason it exists is a bug rather than a feature request.
#:
#: The hosted chat has no mandate to consult - no scope file, no attestation -
#: so a model asked "is this authorised?" has no evidence to answer with and
#: refuses the safest thing it can name. That produced a refusal of this
#: product's *own* documented example (``hack localhost``, the sentence in
#: ``README.md`` and ``agent/mission.py``, against the ``127.0.0.1`` that
#: ``config/scope.example.yaml`` ships as the lab default). The contract above
#: now tells the model not to decide authorisation at all; this line is the other
#: half, and it is deterministic: the site states, in its own words and whatever
#: the model said, where the decision actually lives.
#:
#: The first live turn against the deployed Function found the residual, and it
#: is why the bullet above grew longer: the model answered *"This request is not
#: valid"* - the same verdict in a word the bullet had not named, because the
#: bullet banned a word rather than the behaviour. It now forbids the verdict in
#: any wording, and states the shape of an answer to a question that names a
#: target. No prompt makes a small model reliable; what a prompt can do is stop
#: asking it for a judgement it has no evidence to make, which is what this line
#: is here to hold whatever it answers.
TARGET_NOTE = (
    "[target] this mode has no scope file and no attestation, so it neither "
    "authorises nor refuses a target. A run decides that - the target named in "
    "your scope file, a signed attestation, and your yes for an intrusive "
    "command line - and `red scan` checks all three before anything runs."
)

#: A question that names something a run could be pointed at, as a *display*
#: rule and nothing more. :mod:`safety.scope` is the authority on whether a
#: target may be touched; this decides only whether the line above is printed,
#: and it is deliberately unable to become a claim: a name it misses costs a
#: note, and a name it matches asserts nothing about that name.
#:
#: The four shapes are the ones this repository's own examples and docs write -
#: ``localhost`` (``README.md``, ``agent/mission.py``), the IPv6 loopback, an
#: IPv4 address or CIDR (``config/scope.example.yaml``), and a URL whose scheme a
#: run can use (the schemes :mod:`safety.scope` reads). A bare public hostname is
#: *not* matched: that would mean a suffix list to keep in step, and a missed
#: note is not a wrong one.
#:
#: ``functions/api/chat.js`` carries the same pattern in JavaScript, and
#: ``tests/test_chat.py`` / ``tests/test_chat_function.py`` run one case table
#: through both - so the two copies answer alike on the cases the suite knows,
#: which is the only promise two languages can keep. No lookbehind is used, so
#: old Node parses it as readily as Python.
_TARGET_IN_QUESTION = re.compile(
    r"(?:^|[^A-Za-z0-9_.-])(?:"
    r"localhost(?![A-Za-z0-9_-])"
    r"|\[::1\]"
    r"|::1"
    r"|[0-9]{1,3}(?:\.[0-9]{1,3}){3}(?:/[0-9]{1,2})?"
    r"|(?:https?|s3|hf|repo|git|model)://"
    r")",
    re.IGNORECASE,
)


def names_a_target(question: str) -> bool:
    """Whether a question names something a run could be pointed at.

    A hint for :data:`TARGET_NOTE`, never a check: it authorises nothing, refuses
    nothing, and is not consulted by any adapter - every adapter asks
    :class:`safety.scope.Scope` immediately before it runs.
    """
    return _TARGET_IN_QUESTION.search(question or "") is not None


#: A question that asks about a *technique*, as a *display* rule and nothing more,
#: on exactly the terms :data:`_TARGET_IN_QUESTION` is written on: it authorises
#: nothing, refuses nothing, and is not consulted by any adapter.
#:
#: It exists because a target is not the only thing a model refuses. The verdict
#: rule below used to be gated on :func:`names_a_target` alone, so a refusal to a
#: question that named no target - "how does an IDOR work", "what does WSTG-ATHZ-04
#: test", "which tool finds that" - reached the reader untouched, and the surface
#: whose whole purpose is to answer about the method answered with a decline. The
#: terms below are the vocabulary of the publicly documented disciplines this
#: product covers, and they are deliberately generous: a *miss* costs one leftover
#: refusal, while an *over-match* deletes an answer that was right - and here the
#: over-match is the safe direction in the one place it usually is not, because the
#: replacement names what happened rather than pretending the answer was absent.
#:
#: ``functions/api/chat.js`` carries the same pattern, and
#: ``tests/test_chat.py`` / ``tests/test_chat_function.py`` run one case table
#: through both. No lookbehind is used, so old Node parses it as readily as Python.
_TECHNIQUE_IN_QUESTION = re.compile(
    r"\b(?:"
    r"injection|sqli|xss|csrf|ssrf|xxe|rce|lfi|rfi|idor|bola|bopla|"
    r"deserializ(?:ation|e)|path traversal|directory traversal|"
    r"escalat(?:e|es|ed|ing|ion)|privesc|lateral movement|persistence|exfiltration|"
    r"buffer overflow|use-after-free|heap spray|shellcode|payload|"
    r"exploit|exploitation|weaponiz(?:e|ation)|reverse shell|bind shell|"
    r"brute[- ]?forc(?:e|ing)|password cracking|crack|rainbow table|"
    r"phishing|social engineering|kerberoast(?:ing)?|pass-the-hash|golden ticket|"
    r"rootkit|ransomware|botnet|keylogger|"
    r"reconnaissance|enumeration|fuzzing|port scan|wordlist|"
    r"wstg|owasp|mitre|attack technique|technique|cve|cvss|"
    r"metasploit|sqlmap|nmap|nuclei|ffuf|gobuster|hydra|hashcat|"
    r"john the ripper|burp|aircrack|mimikatz|"
    r"vulnerabilit(?:y|ies)|exploitability|ctf|pentest|penetration test|"
    r"web app(?:lication)? security|api security"
    r")\b",
    re.IGNORECASE,
)


def asks_about_technique(question: str) -> bool:
    """Whether a question asks about a publicly documented security technique.

    A hint for :func:`as_lines`, never a check: it authorises nothing, refuses
    nothing, and is not consulted by any adapter - every adapter asks
    :class:`safety.scope.Scope` immediately before it runs. It decides one thing
    only: whether a model's refusal to such a question is replaced with the
    product's own sentence rather than printed as though it were an answer.
    """
    return _TECHNIQUE_IN_QUESTION.search(question or "") is not None


#: What replaces a model's own verdict when the question named a target, and the
#: reason this is deterministic rather than another rewrite of the contract.
#:
#: The bullet above forbids the verdict, and a small model gives one anyway. A
#: live turn against the deployed Function answered *"This request cannot be
#: honored"* and *"I'm not allowed to assist"*, directly over a note saying this
#: mode neither authorises nor refuses a target. A prompt cannot make a
#: contradiction impossible; a rule in the composer can, and this is it.
#:
#: The parenthetical is the shape :func:`empty_answer_line` already uses, and for
#: the same reason: the operator is owed a sentence about what happened to the
#: answer rather than silence where an answer was. It says what the model did, so
#: nothing is hidden - the withheld text is named, not quietly swapped.
VERDICT_REPLACED = (
    "(the model answered with a refusal - a verdict this mode has nothing to "
    "decide it with; the note below says where that decision is taken)"
)

#: What replaces a model's verdict when the question asked about a *technique*
#: rather than naming a target (:func:`asks_about_technique`), and the reason it is
#: a different sentence from :data:`VERDICT_REPLACED`.
#:
#: The target note below the answer already says where authorisation is decided, so
#: a refusal under a target question is answered by pointing at it. A technique
#: question needs no note - nothing about authorisation was asked - so the
#: replacement has to carry the useful half itself: it says what happened to the
#: answer *and* what would have answered it. It names no technique of its own on
#: purpose, for the same reason :data:`TARGET_NOTE` names no target: the sentence is
#: printed under every technique question, so it must be true of all of them.
TECHNIQUE_REPLACED = (
    "(the model answered with a refusal - a verdict this mode has nothing to "
    "decide it with; a publicly documented technique is knowledge this mode "
    "answers, so ask again naming the technique, the phase you are working in, and "
    "what you want out of it)"
)

#: Phrases only a decliner writes, addressed to the request it was asked.
#:
#: Deliberately *not* a list of single words. This module prints "a run refuses a
#: target the scope file does not name" and "the refusal a run gives", so a rule
#: keyed on `refuse`, or on `not allowed`, would eat the product's own correct
#: answers and replace them with a note about a refusal that never happened.
#: Every phrase here is anchored on the speaker (`i cannot`) or on the request
#: (`this request is not valid`), which is what makes a wrong match something a
#: model has to write rather than something a docstring can.
#:
#: An answer that carries the verdict in some other wording is simply not caught,
#: and that is the safe direction: a phrase missed costs one leftover refusal, and
#: a phrase over-matched would delete an answer that was right. It is the same
#: trade :data:`_TARGET_IN_QUESTION` makes, for the same reason.
#:
#: ``functions/api/chat.js`` carries the same list, and ``tests/test_chat.py`` /
#: ``tests/test_chat_function.py`` run one case table through both - so the two
#: copies agree on the cases the suite knows, which is the only promise two
#: languages can keep.
_VERDICT_PHRASES = (
    "cannot be honored",
    "cannot be honoured",
    "cannot be fulfilled",
    "cannot comply with this request",
    "cannot assist with this request",
    "this request is not valid",
    "this request is invalid",
    "i cannot help",
    "i can't help",
    "i cannot assist",
    "i can't assist",
    "i cannot comply",
    "i can't comply",
    "i must decline",
    "i have to decline",
    "i decline to",
    "i won't help",
    "i will not help",
    "i won't assist",
    "i will not assist",
    "i am unable to",
    "i'm unable to",
    "i am not able to",
    "i'm not able to",
    "not allowed to assist",
    "not allowed to help",
    "not permitted to assist",
    "not something i can do",
    "not something i can help",
    "against my guidelines",
    "against my policy",
    "against my programming",
)


def answer_is_a_verdict(answer: str) -> bool:
    """Whether an answer is the model giving a verdict on the request.

    A *display* rule and never a check: it authorises nothing, refuses nothing,
    and no adapter consults it. :mod:`safety.scope` remains the authority on what
    may be touched, and the only refusal this product gives is a run's.

    The typographic apostrophe is folded to the plain one first, because a model
    writing "can't" with a curly apostrophe is writing the same word.
    """
    text = (answer or "").casefold().replace("\u2019", "'").replace("`", "'")
    return any(phrase in text for phrase in _VERDICT_PHRASES)


def key_status(settings: Settings | None = None) -> tuple[bool, str]:
    """Whether this install has the credential its endpoint needs.

    Returns ``(ok, sentence)``. ``ok`` is False only when a *hosted* endpoint has
    no key - a local model needs none, which is the point of the beta.
    """
    resolved = settings or get_settings()
    have_key = bool(resolved.llm_api_key or resolved.featherless_api_key)
    if have_key:
        return True, "key set"
    if host_is_local(resolved.featherless_base_url):
        return True, "no key needed: the endpoint is on this machine or this network"
    return False, "no key set, and the endpoint is remote"


def install_facts(
    settings: Settings | None = None,
    *,
    surface: str = "chat",
    where: str = "",
) -> str:
    """The facts of *this* install, in the words of the surface printing them.

    One block per surface, because the routes an install can offer belong to the
    surface that can offer them: the hosted Function names none (``hostedFacts``
    in ``functions/api/chat.js``), and it says so in the same breath. The two
    local surfaces - ``red`` in a terminal, and ``red serve``'s backend
    answering the same interface in a browser - both have a real install behind
    them, so both may name ``red init`` and the rest; what differs is which one
    the operator is looking at, and that is what ``where`` says.

    ``surface`` is deliberately a word rather than a flag: a third local surface
    would have to state its own case here, next to the other two, instead of
    inheriting text written for somebody else's screen.
    """
    resolved = settings or get_settings()
    _, sentence = key_status(resolved)
    facts = [
        "## This install",
        f"- Endpoint: {resolved.featherless_base_url} ({sentence})",
        "- Mode: conversation only, no capabilities, no audit lines.",
    ]
    if surface == "serve":
        facts.append(
            "- You are answering over the chat interface this install serves on "
            f"{where or 'a local address'} to the operator who started it: the "
            "same install, the same `.env`, the same models, reached from a "
            "browser instead of a terminal. The page ran nothing to ask you, and "
            "it will run nothing with your answer."
        )
    facts.append(
        "- Any run that would produce a finding goes through `red scan`, or the "
        "line you work here when it names a target, where the kill switch, the "
        "authorization, the scope and the guard apply before a process exists."
    )
    facts.append(
        "- A question that needs a run names the route to it: `red init` creates "
        "the config home and the scope file, editing that scope file names the "
        "assets, `red authorize --target ... --confirm` writes the dated "
        "attestation, `red scan --target ... --tool nmap|httpx|nuclei` runs one "
        "adapter, and a line here that names a target is worked as a mission - "
        "several steps, each chosen from what the last one showed. A step the "
        "model chose itself is scripted from Python with `agent.planner`, which "
        "has no command of its own."
    )
    return "\n".join(facts)


def chat_system_prompt(
    settings: Settings | None = None,
    *,
    extra: str = "",
    surface: str = "chat",
    where: str = "",
) -> str:
    """The contract, plus the two facts of *this* install.

    Not the planner's prompt: no domain pack, no tier ceiling, no phase. A chat
    turn cannot be raised into a planned run by editing a prompt, because this
    one names no capability to call.

    ``surface`` and ``where`` are handed to :func:`install_facts`, which is the
    one place the facts block is written.
    """
    resolved = settings or get_settings()
    parts = [
        CHAT_CONTRACT,
        install_facts(resolved, surface=surface, where=where),
    ]
    if extra.strip():
        parts.append(extra.strip())
    return "\n\n".join(parts)


#: The one client the references are read with, made on first use.
#:
#: A module-level client rather than the provider's, and the difference is the
#: whole reason this function exists: a provider client carries the model's key
#: as a default header on every request it makes, so a reader that borrowed one
#: would be the single path by which that key reached a forge. This one carries
#: no default header at all - each read passes the two it is allowed, and
#: `tests/test_chat_tools.py` reads them off the wire to hold that.
_READER: httpx.AsyncClient | None = None


def _reader() -> httpx.AsyncClient:
    """The shared read-only client, created when the first read needs it."""
    global _READER
    if _READER is None:
        _READER = httpx.AsyncClient(
            timeout=TIMEOUT_MS / 1000, follow_redirects=False
        )
    return _READER


@dataclass
class ChatTurn:
    """One answered turn, with what the operator needs to read it correctly."""

    question: str
    answer: str
    model: str
    finish_reason: str | None = None
    tool_calls: tuple[ToolCall, ...] = ()
    total_tokens: int = 0
    #: The read-only references this turn actually read, each named the way the
    #: visitor reads it ("a repository's public metadata") rather than by its
    #: function name: the note is prose, and `read_github_repo` in the middle of
    #: a sentence reads like something that ran.
    consulted: tuple[str, ...] = ()
    #: The documents the *message itself* named and this surface read before the
    #: model was asked anything - the automatic read in
    #: :func:`agent.chat_tools.named_in`. Kept apart from `consulted` because the
    #: note under the answer says who named it: "the model read" would be false of
    #: a document the visitor's own words named and the model never asked for.
    named: tuple[str, ...] = ()
    #: Whether any read that was attempted did not come back. It changes one
    #: sentence and nothing else - a turn that could not read must say so rather
    #: than answer as though it had.
    reads_failed: bool = False

    @property
    def suggested(self) -> tuple[str, ...]:
        """Names the model asked to run. Reported, never executed."""
        return tuple(call.name for call in self.tool_calls)

    @property
    def ran_anything(self) -> bool:
        """Always False: this surface has nothing to run.

        Unchanged by the references, and the property is what keeps that honest:
        a read is a GET of a public document, it touches no target, chooses no
        step and writes no audit line, so a turn that read three of them ran
        nothing - in the sense this word has always had here.
        """
        return False


@dataclass
class ChatSession:
    """A conversation with the configured model that can only talk.

    Deliberately not built on the planner's context: there is no scope, guard,
    limiter or audit log here because none of them apply to a turn that runs
    nothing. Accepting one would imply an enforcement that does not exist.
    """

    provider: object
    settings: Settings | None = None
    model: str = "reason"
    system: str | None = None
    history: list[ChatMessage] = field(default_factory=list)
    #: The client a read is made with - deliberately *not* the provider's. A
    #: provider's client carries the model's key as a default header, so a
    #: reader that reused it would be the one path by which that key reached a
    #: forge. Created on first use, and injectable so a test can script it.
    reader: httpx.AsyncClient | None = None

    def __post_init__(self) -> None:
        if self.system is None:
            self.system = chat_system_prompt(self.settings)

    def messages(self, question: str | None = None) -> list[ChatMessage]:
        """The contract, this conversation so far, and the pending question."""
        thread = [ChatMessage.system(self.system or "")]
        thread.extend(self.history)
        if question is not None:
            thread.append(ChatMessage.user(question))
        return thread

    async def ask(self, question: str) -> ChatTurn:
        """One turn: sends text, stores text, runs nothing.

        Since the references exist, "runs nothing" has one more thing it has to
        mean, and it still does: what a turn may do beyond talking is *read* -
        at most `MAX_ROUNDS` rounds of at most `MAX_CALLS_PER_ROUND` GETs of
        public documents each, unauthenticated, with no target behind them and no
        audit line after them. Two rounds is what lets the model read something
        and then read one thing that answer named; it is still bounded, and the
        bound is a constant. Before the model is asked anything, the visitor's own
        words may name a document too - see `agent/chat_tools.named_in` - and that
        read is the same kind of GET through the same rows, with `MAX_NAMED_READS`
        as its own cap, so the cost of a turn is a constant either way. The tool
        exchanges in the middle are the model's, not the operator's: the transcript
        keeps the question and the final answer, so what is stored is a
        conversation rather than a trace of machinery.

        Raises whatever the provider raises on transport, auth or budget
        failures - a chat that could not reach the model must not look like one
        that answered.
        """
        text = question.strip()
        if not text:
            raise ValueError("nothing to ask: the message was empty")
        # What this install reads, which is the whole table unless the operator
        # narrowed it (see `Settings.chat_reference_hosts`). Narrowing decides
        # only what the model is *offered*: a reference the deployment dropped is
        # reported below like any other name this surface does not read.
        offers = tool_specs(self.settings.chat_reference_hosts)
        offered = {spec.name for spec in offers}
        # The documents the message itself names, read before the model is asked
        # anything: a visitor who pastes a forge address should not have to hope
        # that this turn's model decides to look it up, and a small local model
        # that cannot call a tool at all still answers from the document. Same
        # rows, same composition and the same checks as a read the model asks for
        # - `named_in` hands back the shape a tool call carries - and only from
        # what this deployment still reads, so a source an operator switched off
        # is not read from here either.
        named: list[str] = []
        prefetched: list[str] = []
        for name, arguments in named_in(text):
            if name not in offered:
                continue
            message, reads = await self._read_named(name, arguments)
            # A read this surface chose rather than one the model asked for, and it
            # did not come back: nothing is said about it. Nothing asked for it, so
            # there is no attempt of the turn's to report - and a model that does
            # ask later gets *that* read reported if it fails, which is the case
            # the note exists for.
            if reads is None or reads in named:
                continue
            named.append(reads)
            prefetched.append(message)
        # Handed over inside the visitor's own message rather than as a tool
        # result, because there is no assistant turn that asked for it - a
        # `role: tool` message with no `tool_calls` before it is a request the
        # provider refuses outright, and inventing an assistant turn would be this
        # surface writing words the model never said. The untrusted-text notice
        # above each block is what keeps a fetched document data rather than
        # instruction, whichever message it arrived in.
        asked = "\n\n".join([text, *prefetched]) if prefetched else text
        thread = self.messages(asked)
        consulted: list[str] = []
        reads_failed = False
        result = await self.provider.chat(  # type: ignore[attr-defined]
            thread, role=self.model, tools=offers
        )
        for _round in range(MAX_ROUNDS):
            # Only names this surface offered: a model cannot widen its own reach
            # by inventing one, and a name that is not a reference is left to be
            # reported as a suggestion, exactly as it always was.
            wanted = [call for call in result.tool_calls if call.name in offered][
                :MAX_CALLS_PER_ROUND
            ]
            if not wanted:
                break
            outcomes = [(call, *await self._read(call)) for call in wanted]
            thread = [
                *thread,
                ChatMessage.assistant(result.text, result.tool_calls),
                *[
                    ChatMessage.tool_result(call.id, message, name=call.name)
                    for call, message, _reads in outcomes
                ],
            ]
            for _call, _message, reads in outcomes:
                if reads is None:
                    reads_failed = True
                elif reads not in consulted and reads not in named:
                    consulted.append(reads)
            result = await self.provider.chat(  # type: ignore[attr-defined]
                thread, role=self.model, tools=offers
            )
        self.history.append(ChatMessage.user(text))
        self.history.append(ChatMessage.assistant(result.text, result.tool_calls))
        return ChatTurn(
            question=text,
            answer=result.text,
            model=result.model,
            finish_reason=result.finish_reason,
            tool_calls=tuple(result.tool_calls),
            total_tokens=result.usage.total_tokens,
            consulted=tuple(consulted),
            named=tuple(named),
            reads_failed=reads_failed,
        )

    async def _read(self, call: ToolCall) -> tuple[str, str | None]:
        """One read the model asked for, by the call it made."""
        return await self._read_named(call.name, call.arguments)

    async def _read_named(
        self, name: str, arguments: Mapping[str, Any]
    ) -> tuple[str, str | None]:
        """One read by name: the message the model gets, and what was read.

        One function for both ways a read is asked for, which is the point: a
        document the visitor's message named goes through exactly here, so the
        same rows, the same patterns, the same composition of an address and the
        same two headers apply to it - and `agent/chat_tools.named_in` is what
        gives the arguments, in the shape a tool call carries.

        Three outcomes, and each has to be *said* rather than implied - which is
        the whole of what makes this feature safe to ship: a reference this
        install holds, read here with nothing leaving the machine; a reference
        whose arguments were refused, where the model is told what was wrong
        with them because that is something it can correct; and a read that was
        made and did not come back, where the model is told it has nothing from
        that source rather than being handed an empty result to guess around.

        Only the first of the three names what was read, and that name is what
        the note under the answer lists.
        """
        try:
            planned = plan_read(name, arguments)
        except ReferenceRefused as refused:
            return str(refused), None
        if not planned.url.startswith("http"):
            # One of this install's own three tables: it is *here*, so it is read
            # here, and no request leaves the machine for it.
            try:
                return as_tool_message(planned, site_text(planned.name)), planned.reads
            except ReferenceRefused as refused:
                return str(refused), None
        client = self.reader or _reader()
        try:
            response = await client.get(
                planned.url,
                headers=planned.headers,
                follow_redirects=False,
                timeout=TIMEOUT_MS / 1000,
            )
        except httpx.HTTPError:
            return as_failure("it could not be reached from this machine"), None
        if 300 <= response.status_code < 400:
            return (
                as_failure(
                    "the source answered with a redirect, and this reader does "
                    "not follow one"
                ),
                None,
            )
        if response.status_code >= 400:
            return as_failure(f"the source answered {response.status_code}"), None
        return as_tool_message(planned, response.text), planned.reads

    def transcript(self) -> list[dict[str, str]]:
        """The conversation as role/content pairs - what `--transcript` writes."""
        return [{"role": m.role, "content": m.content} for m in self.history]

    def describe(self) -> dict[str, object]:
        """Non-secret summary, safe to print or log."""
        ok, sentence = key_status(self.settings)
        return {
            "mode": "chat",
            "turns": len(self.history) // 2,
            "model_role": self.model,
            "key_ok": ok,
            "key": sentence,
            "runs_capabilities": False,
            "audited": False,
        }


#: The two words a provider uses for "the cap was reached before there was
#: anything to read": OpenAI says ``length``, Anthropic says ``max_tokens``. They
#: mean the same thing to the person reading an empty answer, which is the one
#: empty answer that has a remedy.
_CAPPED_REASONS = frozenset({"length", "max_tokens"})

#: Reasons that need no explaining. A turn that ended normally and carried no
#: text is simply a turn that carried no text - naming the reason there would be
#: noise dressed as an explanation.
_QUIET_REASONS = frozenset({"stop", "end_turn", ""})


def empty_answer_line(finish_reason: str | None, total_tokens: int = 0) -> str:
    """The line for a turn that came back with no text, and why, when it is known.

    An empty answer is the one case where the operator has nothing to read *and*
    nothing to act on. The provider's own word for what happened reaches this
    module through :class:`ChatTurn`, so it is reported rather than discarded: a
    capped answer and a filtered one look identical in the transcript otherwise,
    and only one of them is fixed by asking for less thinking or a larger budget.

    ``functions/api/chat.js`` builds the same sentence, and
    ``tests/test_chat_function.py`` compares the two line for line - so this
    wording is one decision in two languages, not two decisions.
    """
    reason = (finish_reason or "").strip()
    if reason in _QUIET_REASONS:
        return "(the model returned no text)"
    spent = f", {total_tokens} tokens" if total_tokens > 0 else ""
    if reason in _CAPPED_REASONS:
        return (
            f"(the model returned no text: it hit the token cap{spent} "
            f'(finish_reason "{reason}") - raise Reasoning power, or choose a '
            "model that does not spend the budget thinking)"
        )
    return f'(the model returned no text: finish_reason "{reason}"{spent})'


def as_lines(turn: ChatTurn) -> Sequence[str]:
    """Render a turn as the lines `red` prints, notes included."""
    answer = turn.answer.strip() or empty_answer_line(
        turn.finish_reason, turn.total_tokens
    )
    # A verdict is not this mode's to give, so the composer does not print one
    # directly over a note that says the mode decides nothing. A refusal verdict on
    # a question that named a target becomes the product's own sentence, and the
    # note below then says where that decision is actually taken; a refusal to a
    # question that asked about a *technique* becomes the sentence that says a
    # technique is knowledge this mode answers. Questions that did neither are left
    # exactly as they were - the words are the operator's to read.
    named_target = names_a_target(turn.question)
    if (named_target or asks_about_technique(turn.question)) and answer_is_a_verdict(
        answer
    ):
        answer = VERDICT_REPLACED if named_target else TECHNIQUE_REPLACED
    lines = [answer]
    if turn.tool_calls:
        named = ", ".join(turn.suggested)
        # `NOT_RUN_NOTICE` is the one wording both surfaces use, so this line is
        # the same sentence the hosted answer carries. A name in it was not read:
        # either it is not a reference at all, or this turn's round of reads was
        # already spent.
        lines.append(NOT_RUN_NOTICE.format(names=named))
    if turn.consulted:
        read = (
            f"{READ_ONLY_NOTE['lead']} {', '.join(turn.consulted)} "
            f"{READ_ONLY_NOTE['tail']}"
        )
        lines.append(f"{read}{REFUSED_NOTE}" if turn.reads_failed else read)
    elif turn.reads_failed:
        # Every read that was attempted failed, so there is nothing to name - and
        # a turn that tried and got nowhere is still a fact the visitor should
        # read. The sentence is a different one for that reason; "the model read"
        # followed by nothing is not a sentence.
        lines.append(READ_ONLY_FAILED)
    if turn.named:
        # A document the *message* named, read before the model was asked: a
        # different sentence from the one above, because "the model read" would be
        # false of a read the model never asked for - and this composer does not
        # print a false sentence about a turn, however small the difference looks
        # in a transcript.
        lines.append(
            f"{READ_ONLY_NAMED['lead']} {', '.join(turn.named)}"
            f"{READ_ONLY_NAMED['tail']}"
        )
    if named_target:
        lines.append(TARGET_NOTE)
    lines.append(f"[{NOT_A_RUN}]")
    return lines
