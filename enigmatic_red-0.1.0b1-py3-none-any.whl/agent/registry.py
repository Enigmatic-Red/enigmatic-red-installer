"""The capability registry: the only actions a plan is allowed to name.

The reference implementation let the model write a ``shell`` or ``python``
action and then tried to guess whether the command was acceptable. That design
cannot be made safe by better prompts, because the model's reach is defined by
what a shell can do — everything. Here the model's reach is defined by a list of
:class:`Capability` objects, each one a typed wrapper around a real adapter in
``tools/``. A name that is not in this list is refused, recorded, and shown to
the model as a refusal. There is no second path and no shell.

Three properties matter, and each is enforced *here as well as* in the adapter:

1. **No unmodelled flags.** Each capability declares a JSON schema with
   ``additionalProperties: False``, and the adapters' own escape hatch
   (``extra_args``) is deliberately absent from every schema. A model cannot
   express ``--script vuln`` by inventing a keyword: the argument is rejected
   before the adapter ever sees it. The *argv* a human can be asked to approve
   is therefore built only from validated values.
2. **No target outside the scope kind.** A host capability refuses a URL, and
   the URL capability refuses a bare host, so the common ``nmap
   https://app.example.com`` mistake is a refusal with a reason rather than a
   silently different scan.
3. **The plan is pre-flighted through the very same guard.** ReAct works better
   when a refusal is explained *before* the action: the planner asks
   :meth:`Registry.preflight`, which runs the identical ``Guard`` the adapter
   will run, and hands the model either the exact command line or the rule that
   forbids it. This is a courtesy to the model, not a control: pre-flight cannot
   widen authority, and the adapter re-checks everything at execution time.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Iterable, Mapping, Sequence

from agent.providers.base import ToolSpec
from agent.spec import AgentSpec
from safety.errors import ToolExecutionError
from safety.guard import ActionClass, Guard, GuardDecision
from tools.base import ToolAdapter, ToolContext, ToolResult
from tools.ai_benchmark import AIBenchmarkAdapter, BENCHMARK_CATEGORIES
from tools.dnsx import DNSX_RECORD_FLAGS, DnsxAdapter
from tools.ffuf import FfufAdapter
from tools.git import GitAdapter
from tools.github import GitHubAdapter
from tools.gobuster import GobusterAdapter
from tools.httpx import HttpxAdapter
from tools.hub import HubAdapter
from tools.nmap import NmapAdapter
from tools.nuclei import NucleiAdapter
from tools.parsers import SEVERITIES
from tools.subfinder import SubfinderAdapter
from tools.whatweb import WhatwebAdapter

__all__ = [
    "CAPABILITIES",
    "Capability",
    "Preflight",
    "Refusal",
    "Registry",
    "UnknownCapability",
]


class UnknownCapability(ValueError):
    """The model asked for an action that is not a registered capability."""


@dataclass(frozen=True)
class Refusal:
    """Why an action will not run. This is text the model gets to read."""

    code: str
    reason: str
    matched_rules: tuple[str, ...] = ()
    action_class: str = ""

    def describe(self) -> dict[str, Any]:
        return {
            "code": self.code,
            "reason": self.reason,
            "matched_rules": list(self.matched_rules),
            "action_class": self.action_class,
        }


@dataclass(frozen=True)
class Preflight:
    """The outcome of asking the guard about an action *before* taking it.

    Exactly one of ``command``/``refusal`` is meaningful: when ``refusal`` is
    ``None`` the action is permitted (possibly with an approval already
    attached) and ``command`` is the exact argv that would run.
    """

    name: str
    capability: "Capability | None" = None
    command: str = ""
    decision: GuardDecision | None = None
    refusal: Refusal | None = None
    #: True when the action is intrusive but a human has already approved this
    #: exact command line for this scan.
    approved: bool = False

    @property
    def ok(self) -> bool:
        return self.refusal is None

    @property
    def action_class(self) -> str:
        # ``is not None``, not truthiness: GuardDecision.__bool__ returns
        # ``allowed``, so a forbidden decision is falsy by design.
        return self.decision.action_class.value if self.decision is not None else ""

    def describe(self) -> dict[str, Any]:
        return {
            "capability": self.name,
            "command": self.command,
            "action_class": self.action_class,
            "approved": self.approved,
            "allowed": self.ok,
            **({"refusal": self.refusal.describe()} if self.refusal else {}),
        }


@dataclass(frozen=True)
class Capability:
    """One registered action: an adapter plus what the model may say about it.

    Args:
        name: the registry key, matching ``domains.yaml`` and the guard table.
        adapter: the adapter that runs it. Adapters hold no state, so one
            instance per capability is enough.
        summary: one or two sentences for the model — what the action gives it.
        parameters: JSON schema, OpenAI function-calling shape. Must set
            ``additionalProperties: False`` and list every accepted keyword.
        target_kind: ``host`` (hostname, IP or CIDR), ``url`` (with scheme),
            ``repository`` (``github.com/owner/name``) or ``model``
            (``owner/name``, or ``hf://owner/name``).
        phases: the phases this action is honest in. Advisory: it tells the
            planner (and the prompt) that, say, ``nuclei`` is an assessment
            tool, so calling it in P1_recon wastes the customer's budget. The
            guard and the tier ceiling remain the enforcement.
    """

    name: str
    adapter: ToolAdapter
    summary: str
    parameters: Mapping[str, Any]
    target_kind: str = "host"
    phases: tuple[str, ...] = ()

    @property
    def required(self) -> tuple[str, ...]:
        return tuple(self.parameters.get("required") or ())

    def tool_spec(
        self, *, action_class: str = "", requires_approval: bool = False
    ) -> ToolSpec:
        """The declaration handed to the model, with its class stated openly.

        A model that knows ``nuclei`` needs an approval will budget for the
        operator round-trip instead of discovering it by being refused.
        """
        note = ""
        if action_class:
            suffix = ", needs a human approval" if requires_approval else ""
            note = f" [action class: {action_class}{suffix}]"
        return ToolSpec(
            name=self.name,
            description=f"{self.summary}{note}",
            parameters=dict(self.parameters),
        )


def _schema(
    properties: dict[str, Any], *, required: Sequence[str] = ("target",)
) -> dict[str, Any]:
    """A closed object schema: exactly these keywords, ``target`` is mandatory."""
    return {
        "type": "object",
        "properties": properties,
        "required": list(required),
        #: The no-shell guarantee, stated as a schema: a keyword that is not
        #: listed cannot be sent, so ``extra_args``/``--script`` stays
        #: unreachable from a model turn however the prompt is phrased.
        "additionalProperties": False,
    }


#: Mirrors ``tools.nmap._PORT_SPEC``: digits, commas and ranges, nothing else.
_PORT_SPEC = r"^[0-9]{1,5}(-[0-9]{1,5})?(,[0-9]{1,5}(-[0-9]{1,5})?)*$"

NMAP_PARAMETERS = _schema(
    {
        "target": {
            "type": "string",
            "description": "Hostname, IP address or CIDR inside the authorised scope.",
        },
        "ports": {
            "type": "string",
            "pattern": _PORT_SPEC,
            "description": 'Ports to probe, e.g. "22,80,443" or "1-1024". Omit for nmap defaults.',
        },
        "top_ports": {
            "type": "integer",
            "minimum": 1,
            "maximum": 65535,
            "description": "Scan only the N most common ports.",
        },
        "service_detection": {
            "type": "boolean",
            "description": "Version detection (-sV). Default true: a finding should be able "
            "to name a version and be re-checked later.",
        },
        "skip_discovery": {
            "type": "boolean",
            "description": "Assume the host is up (-Pn). Default true: a host that does not "
            "answer ICMP is still worth looking at.",
        },
        "max_rate": {
            "type": "number",
            "minimum": 1,
            "maximum": 1000,
            "description": "Probe-rate ceiling in packets per second, for production estates.",
        },
        "host_timeout_s": {
            "type": "integer",
            "minimum": 1,
            "maximum": 3600,
            "description": "Give up on this host after N seconds.",
        },
    }
)

NUCLEI_PARAMETERS = _schema(
    {
        "target": {
            "type": "string",
            "minLength": 8,
            "description": "Absolute URL including scheme, e.g. https://app.example.com",
        },
        "templates": {
            "type": "array",
            "items": {"type": "string"},
            "minItems": 1,
            "description": "Template ids or paths, e.g. [\"cve-2021-44228\"]. Specific "
            "templates only: the full template set is not covered by an approval.",
        },
        "tags": {
            "type": "array",
            "items": {"type": "string"},
            "minItems": 1,
            "description": 'Tag selection, e.g. ["cve", "xss", "headers"].',
        },
        "exclude_tags": {
            "type": "array",
            "items": {"type": "string"},
            "description": 'Tags to skip, e.g. ["dos"].',
        },
        "severities": {
            "type": "array",
            "items": {"type": "string", "enum": list(SEVERITIES)},
            "description": 'Keep findings at these severities, e.g. ["high", "critical"].',
        },
        "rate_limit": {
            "type": "integer",
            "minimum": 1,
            "maximum": 150,
            "description": "Requests per second, capped at 150 by the adapter.",
        },
        "concurrency": {
            "type": "integer",
            "minimum": 1,
            "maximum": 25,
            "description": "Parallel templates, capped at 25 by the adapter.",
        },
        "per_request_timeout_s": {
            "type": "integer",
            "minimum": 1,
            "maximum": 30,
            "description": "Per-request timeout.",
        },
    },
    # ``templates``/``tags`` are not schema-required because the adapter's own
    # refusal is more useful: it names *why* a bare sweep is unapprovable, and
    # pre-flight passes that sentence straight back to the model.
    required=("target",),
)


#: Mirrors ``tools.httpx._ports_argument``: nmap-style port groups, each of which
#: may name the scheme it applies to (``http:80,https:443,8000-8090``).
_HTTPX_PORT_SPEC = (
    r"^((https?):)?[0-9]{1,5}(-[0-9]{1,5})?"
    r"(,((https?):)?[0-9]{1,5}(-[0-9]{1,5})?)*$"
)

HTTPX_PARAMETERS = _schema(
    {
        "target": {
            "type": "string",
            "description": "Hostname, IP address or CIDR inside the authorised scope.",
        },
        "ports": {
            "type": "string",
            "pattern": _HTTPX_PORT_SPEC,
            "description": 'Ports to probe, e.g. "443" or "http:80,https:443". Omit for '
            "httpx defaults.",
        },
        "paths": {
            "type": "array",
            "items": {"type": "string"},
            "minItems": 1,
            "description": 'Paths to request on that host, e.g. ["/", "/api/"].',
        },
        "status_codes": {
            "type": "array",
            "items": {"type": "string"},
            "description": 'Report only these status codes, e.g. ["200", "301", "403"].',
        },
        "follow_redirects": {
            "type": "boolean",
            "description": "Follow redirects (-fr). Default false: report what the "
            "target itself answered.",
        },
        "threads": {
            "type": "integer",
            "minimum": 1,
            "maximum": 25,
            "description": "Parallel probes, capped at 25 by the adapter.",
        },
        "rate_limit": {
            "type": "integer",
            "minimum": 1,
            "maximum": 150,
            "description": "Requests per second, capped at 150 by the adapter.",
        },
        "timeout_s": {
            "type": "integer",
            "minimum": 1,
            "maximum": 30,
            "description": "Per-request timeout.",
        },
    }
)


GIT_PARAMETERS = _schema(
    {
        "target": {
            "type": "string",
            "description": "Repository as github.com/owner/name, inside the authorised scope.",
        },
        "operation": {
            "type": "string",
            "enum": ["ls_remote", "clone", "push"],
            "description": "ls_remote lists branches; clone makes a shallow local "
            "checkout you can read; push publishes a nominated checkout's HEAD to a "
            "branch. push needs a human approval of its exact command line.",
        },
        "depth": {
            "type": "integer",
            "minimum": 1,
            "maximum": 50,
            "description": "Commits of history to check out. Default 1: read the "
            "current state, do not mirror the repository.",
        },
        "remote_branch": {
            "type": "string",
            "description": "Branch a push publishes to, e.g. audit/2026-10. Required "
            "for push.",
        },
        "source_path": {
            "type": "string",
            "description": "Absolute path of the checkout a push reads its commits "
            "from. It must sit inside the operator's SAFETY_WRITE_ROOT, or the push "
            "is reported as skipped rather than guessed at.",
        },
    },
    required=("target", "operation"),
)

GITHUB_PARAMETERS = _schema(
    {
        "target": {
            "type": "string",
            "description": "Repository as github.com/owner/name, inside the authorised scope.",
        },
        "operation": {
            "type": "string",
            "enum": ["repo_view", "pr_create"],
            "description": "repo_view reads what the host publishes about the "
            "repository; pr_create opens a pull request and needs a human approval.",
        },
        "title": {
            "type": "string",
            "description": "Pull request title. Required for pr_create.",
        },
        "body": {
            "type": "string",
            "description": "Pull request body. Keep it short: it is prose a human reads.",
        },
        "base": {
            "type": "string",
            "description": "Branch the pull request merges into, e.g. main.",
        },
        "head": {
            "type": "string",
            "description": "Branch the pull request comes from. It must already exist "
            "on the remote: push it first, with its own approval.",
        },
    },
    required=("target", "operation"),
)

HUB_PARAMETERS = _schema(
    {
        "target": {
            "type": "string",
            "description": "Model id as owner/name (or hf://owner/name), inside the "
            "authorised scope.",
        },
        "operation": {
            "type": "string",
            "enum": ["model_info", "upload"],
            "description": "model_info reads the model's published metadata - its "
            "files, licence, whether it ships pickle-format weights; upload publishes "
            "a path into the repository and needs a human approval.",
        },
        "revision": {
            "type": "string",
            "description": "Branch, tag or commit to read. Default main.",
        },
        "repo_type": {
            "type": "string",
            "enum": ["model", "dataset"],
            "description": "Hub repository type for upload. Default model.",
        },
        "source_path": {
            "type": "string",
            "description": "Absolute local file or directory an upload publishes. It "
            "must sit inside the operator's SAFETY_WRITE_ROOT.",
        },
        "path_in_repo": {
            "type": "string",
            "description": "Where the upload lands inside the repository, e.g. "
            "audit/2026-10. Omit to keep the local name.",
        },
    },
    required=("target", "operation"),
)


#: The passive enumeration pair. Both are *discovery*: they ask third parties
#: (subfinder) or resolvers (dnsx) what is already published about a name, and
#: neither sends a request to the target's own services. ``extra_args`` is
#: absent for the reason it is absent everywhere: a keyword that is not listed
#: cannot be sent, so no unmodelled flag has a way in.
SUBFINDER_PARAMETERS = _schema(
    {
        "target": {
            "type": "string",
            "description": "Registrable domain inside the authorised scope, "
            "e.g. example.com. Subdomains are discovered, not resolved.",
        },
        "sources": {
            "type": "array",
            "items": {"type": "string"},
            "minItems": 1,
            "description": 'Passive sources to ask, e.g. ["crtsh", "hackertarget"]. '
            "Omit for subfinder's own defaults.",
        },
        "exclude_sources": {
            "type": "array",
            "items": {"type": "string"},
            "description": 'Sources to skip, e.g. ["dnsdumpster"].',
        },
        "all_sources": {
            "type": "boolean",
            "description": "Ask every source subfinder knows. Slower, and it tells "
            "more third parties that this domain is being looked at.",
        },
        "threads": {
            "type": "integer",
            "minimum": 1,
            "maximum": 25,
            "description": "Parallel source queries, capped at 25 by the adapter.",
        },
        "rate_limit": {
            "type": "integer",
            "minimum": 1,
            "maximum": 150,
            "description": "Requests per second against each source, capped at 150.",
        },
        "timeout_s": {
            "type": "integer",
            "minimum": 1,
            "maximum": 60,
            "description": "Per-source timeout in seconds.",
        },
    }
)

DNSX_PARAMETERS = _schema(
    {
        "target": {
            "type": "string",
            "description": "Hostname, IP address or CIDR to resolve. A wildcard "
            "sweep is not offered: the names to test come from what the scope "
            "already named, or from subfinder's output.",
        },
        "record_types": {
            "type": "array",
            "items": {"type": "string", "enum": sorted(DNSX_RECORD_FLAGS)},
            "minItems": 1,
            "description": 'Record types to ask for, e.g. ["a", "mx", "txt"]. '
            "Omit for dnsx's default (A, and the CNAME chain above it).",
        },
        "response": {
            "type": "boolean",
            "description": "Keep the resolver's answer next to the record (default "
            "true). The answer is the evidence; without it a finding is a claim.",
        },
        "threads": {
            "type": "integer",
            "minimum": 1,
            "maximum": 25,
            "description": "Parallel queries, capped at 25 by the adapter.",
        },
        "rate_limit": {
            "type": "integer",
            "minimum": 1,
            "maximum": 150,
            "description": "Queries per second, capped at 150.",
        },
        "timeout_s": {
            "type": "integer",
            "minimum": 1,
            "maximum": 10,
            "description": "Per-query timeout in seconds.",
        },
    }
)

WHATWEB_PARAMETERS = _schema(
    {
        "target": {
            "type": "string",
            "description": "Absolute URL including scheme, e.g. https://app.example.com. "
            "One page: whatweb reports what that response says about itself.",
        },
        "threads": {
            "type": "integer",
            "minimum": 1,
            "maximum": 25,
            "description": "Parallel requests when the target redirects to more "
            "than one URL, capped at 25.",
        },
        "timeout_s": {
            "type": "integer",
            "minimum": 1,
            "maximum": 10,
            "description": "Per-request timeout in seconds.",
        },
        "user_agent": {
            "type": "string",
            "description": "Optional User-Agent; the default is whatweb's own, "
            "which is what makes the fingerprint reproducible.",
        },
    }
)


#: A duration as the model may state it: bare milliseconds, or an explicit
#: ``ms``/``s``/``m`` suffix. The adapter keeps the floor - gobuster's 100ms,
#: ffuf's 0.1s - because that floor is what keeps a discovery run from being a
#: load test, and a model that asks for less is answered with the floor rather
#: than with an approximation of it.
_DURATION_SPEC = r"^[0-9]+(\.[0-9]+)?(ms|s|m)?$"

GOBUSTER_PARAMETERS = _schema(
    {
        "target": {
            "type": "string",
            "description": "Absolute URL including scheme, e.g. "
            "https://app.example.com - gobuster walks paths under it.",
        },
        "wordlist": {
            "type": "string",
            "description": "Which list to walk: \"builtin\" for the compiled-in "
            "list, or a path inside the operator-nominated write root. Naming a "
            "path does not widen the scope or the write root.",
        },
        "threads": {
            "type": "integer",
            "minimum": 1,
            "maximum": 25,
            "description": "Parallel requests, capped at 25 by the adapter.",
        },
        "delay": {
            "type": "string",
            "pattern": _DURATION_SPEC,
            "description": 'Delay between requests, e.g. "250ms" or "2s". At '
            "least 100ms: the adapter raises anything lower to that floor.",
        },
        "timeout_s": {
            "type": "integer",
            "minimum": 1,
            "maximum": 30,
            "description": "Per-request timeout in seconds.",
        },
    }
)

FFUF_PARAMETERS = _schema(
    {
        "target": {
            "type": "string",
            "description": "Absolute URL including scheme and containing the FUZZ "
            "keyword, e.g. https://app.example.com/FUZZ. The keyword is where "
            "each wordlist entry is substituted; it is what makes the run "
            "answer one question rather than every question.",
        },
        "wordlist": {
            "type": "string",
            "description": "Which list to substitute: \"builtin\" for the "
            "compiled-in list, or a path inside the operator-nominated write root.",
        },
        "threads": {
            "type": "integer",
            "minimum": 1,
            "maximum": 10,
            "description": "Parallel requests, capped at 10 by the adapter.",
        },
        "rate": {
            "type": "integer",
            "minimum": 1,
            "maximum": 25,
            "description": "Requests-per-second ceiling, capped at 25. The delay "
            "below is a floor, not a target: rate stops a burst, delay paces it.",
        },
        "delay": {
            "type": "string",
            "pattern": _DURATION_SPEC,
            "description": 'Delay between requests, e.g. "0.1s" or "1s". At least '
            "0.1s: the adapter raises anything lower to that floor.",
        },
        "timeout_s": {
            "type": "integer",
            "minimum": 1,
            "maximum": 30,
            "description": "Per-request timeout in seconds.",
        },
    }
)


# AI benchmark parameters for AI model security assessment
AI_BENCHMARK_PARAMETERS = _schema(
    {
        "target": {
            "type": "string",
            "description": "Target AI model or service endpoint, e.g. https://api.model.example.com "
            "or model repository path like hf://organization/model-name",
        },
        "category": {
            "type": "string",
            "enum": list(BENCHMARK_CATEGORIES),
            "description": 'Assessment category: "prompt_injection", "adversarial_robustness", '
            '"data_privacy", "supply_chain", or "model_security".',
        },
        "framework": {
            "type": "string",
            "enum": ["OWASP-LLM", "NIST-AI-RMF", "ISO-42001"],
            "description": 'Framework alignment for the assessment.',
        },
        "rate_limit": {
            "type": "integer",
            "minimum": 1,
            "maximum": 150,
            "description": "Requests per second for scanning operations.",
        },
        "concurrency": {
            "type": "integer",
            "minimum": 1,
            "maximum": 25,
            "description": "Parallel assessment operations.",
        },
        "include_metrics": {
            "type": "boolean",
            "description": "Include detailed risk metrics and effectiveness scores. Default true.",
        },
    },
    required=("target", "category", "framework"),
)


# -------------------------------------------------------------------------------
#  Registered capabilities. Adding one is a code change on purpose: a YAML line
#  cannot conjure a tool into existence, and anything not listed here is refused
#  as "not registered" - including every tool ``domains.yaml`` names but no
#  adapter implements yet (see :meth:`Registry.unavailable`).
# -------------------------------------------------------------------------------
CAPABILITIES: tuple[Capability, ...] = (
    Capability(
        name="httpx",
        adapter=HttpxAdapter(),
        summary=(
            "Probe an HTTP service and report what answered: status code, page "
            "title, web server, technology, response size. No fuzzing, no "
            "content discovery, no browser - one request per path, rate-limited."
        ),
        parameters=HTTPX_PARAMETERS,
        target_kind="host",
        phases=("P1_recon", "P2_enumerate"),
    ),
    Capability(
        name="nmap",
        adapter=NmapAdapter(),
        summary=(
            "Find reachable TCP services and their versions on a host: which "
            "ports answer, what is behind them, how it identifies itself. "
            "Version detection only - no NSE scripts, no OS fingerprinting, no "
            "aggressive timing."
        ),
        parameters=NMAP_PARAMETERS,
        target_kind="host",
        phases=("P1_recon", "P2_enumerate", "P3_assess"),
    ),
    Capability(
        name="nuclei",
        adapter=NucleiAdapter(),
        summary=(
            "Run specific nuclei templates or tags against a URL to test one "
            "hypothesis. Safety defaults are fixed: no out-of-band interaction "
            "service, no mid-scan template download. Choose templates "
            "narrowly - a broad sweep is not covered by an approval and is "
            "refused."
        ),
        parameters=NUCLEI_PARAMETERS,
        target_kind="url",
        phases=("P3_assess", "P4_verify"),
    ),
    Capability(
        name="git",
        adapter=GitAdapter(),
        summary=(
            "Read a source repository, or publish to one. ls_remote lists its "
            "branches; clone makes a shallow single-branch checkout into a "
            "private temporary directory so you can read the source rather than "
            "guess about it; push publishes the HEAD of a checkout the operator "
            "nominated. push changes someone else's repository and always needs "
            "a human approval; a force-push or a branch deletion is refused "
            "outright."
        ),
        parameters=GIT_PARAMETERS,
        target_kind="repository",
        phases=("P1_recon", "P2_enumerate", "P5_report"),
    ),
    Capability(
        name="gh",
        adapter=GitHubAdapter(),
        summary=(
            "Read what GitHub publishes about a repository (visibility, default "
            "branch, whether it is archived or a fork, licence, last push, "
            "whether vulnerability alerts are on), or open a pull request. "
            "pr_create changes the repository and notifies people, so it always "
            "needs a human approval."
        ),
        parameters=GITHUB_PARAMETERS,
        target_kind="repository",
        phases=("P1_recon", "P2_enumerate", "P5_report"),
    ),
    Capability(
        name="hf",
        adapter=HubAdapter(),
        summary=(
            "Read what a model hub publishes about a model: its files, licence, "
            "whether it is gated or private, whether it ships pickle-format "
            "weights (which execute when loaded) and whether it carries its own "
            "Python. Or upload a path the operator nominated into an in-scope "
            "repository, which needs a human approval."
        ),
        parameters=HUB_PARAMETERS,
        target_kind="model",
        phases=("P1_recon", "P3_assess", "P5_report"),
    ),
    Capability(
        name="subfinder",
        adapter=SubfinderAdapter(),
        summary=(
            "Discover subdomains from what is already published: certificate "
            "transparency logs, search engines, passive DNS. Asks third parties, "
            "not the target, so the target sees nothing. It finds names; it does "
            "not say whether they resolve, and a name it returns is a lead, not "
            "a host."
        ),
        parameters=SUBFINDER_PARAMETERS,
        target_kind="host",
        phases=("P1_recon",),
    ),
    Capability(
        name="dnsx",
        adapter=DnsxAdapter(),
        summary=(
            "Resolve names and read their records: which names answer, to what, "
            "and which record types (A, AAAA, CNAME, MX, TXT, NS, SOA, SRV, PTR, "
            "CAA). A resolver lookup, not a scan of the host - taking the answer "
            "is the point, because it is what a later re-check compares against."
        ),
        parameters=DNSX_PARAMETERS,
        target_kind="host",
        phases=("P1_recon", "P2_enumerate"),
    ),
    Capability(
        name="whatweb",
        adapter=WhatwebAdapter(),
        summary=(
            "Fingerprint one URL: content management system, framework, server, "
            "analytics, and versions where the page admits them. Passive "
            "identification from a single response - one request, no payloads, "
            "no login attempts, no fuzzing."
        ),
        parameters=WHATWEB_PARAMETERS,
        target_kind="url",
        phases=("P1_recon", "P2_enumerate"),
    ),
    Capability(
        name="gobuster",
        adapter=GobusterAdapter(),
        summary=(
            "Discover reachable paths under a URL by walking a wordlist and "
            "reporting the status code and size of each answer. Content "
            "discovery only: no exploitation, no credential guessing, "
            "rate-limited with a delay floor the adapter enforces."
        ),
        parameters=GOBUSTER_PARAMETERS,
        target_kind="url",
        phases=("P2_enumerate", "P3_assess"),
    ),
    Capability(
        name="ffuf",
        adapter=FfufAdapter(),
        summary=(
            "Substitute a wordlist into a URL's FUZZ keyword and report the "
            "answers that stand out from the rest by status, size or word count. "
            "Sends requests to the target, so it needs the target in scope and "
            "is paced: a rate ceiling, a delay floor, and a thread cap the "
            "adapter enforces."
        ),
        parameters=FFUF_PARAMETERS,
        target_kind="url",
        phases=("P2_enumerate", "P3_assess"),
    ),
Capability(
        name="ai-benchmark",
        adapter=AIBenchmarkAdapter(),
        summary=(
            "Assess AI model security using benchmark-driven evaluations: prompt "
            "injection testing, adversarial robustness analysis, and data privacy "
            "compliance. Uses nuclei and httpx for automated scanning, aligned with "
            "OWASP Top 10 for LLM and NIST AI RMF frameworks. Provides risk scoring "
            "and effectiveness metrics for comprehensive AI security assessment."
        ),
        parameters=AI_BENCHMARK_PARAMETERS,
        target_kind="model",
        phases=("P3_assess", "P4_verify", "P5_report"),
    ),
)


# ------------------------------------------------------- argument validation
def _numeric_problem(name: str, value: Any, kind: str, spec: Mapping[str, Any]) -> str:
    if isinstance(value, bool) or (
        not isinstance(value, int) if kind == "integer" else not isinstance(value, (int, float))
    ):
        return f"{name!r} must be an {kind}"
    minimum = spec.get("minimum")
    maximum = spec.get("maximum")
    if minimum is not None and value < minimum:
        return f"{name!r} must be at least {minimum}"
    if maximum is not None and value > maximum:
        return f"{name!r} must be at most {maximum}"
    return ""


def _type_problem(name: str, value: Any, spec: Mapping[str, Any]) -> str:
    """One problem, in the operator's words. Empty string means it is fine."""
    kind = spec.get("type")
    if kind == "string":
        if not isinstance(value, str):
            return f"{name!r} must be a string"
        allowed = spec.get("enum")
        if allowed and value not in allowed:
            return f"{name!r} is {value!r}; expected one of {', '.join(allowed)}"
        if spec.get("pattern") and not re.match(spec["pattern"], value.strip()):
            return f"{name!r} does not look like a valid value: {value!r}"
        if spec.get("minLength") and len(value.strip()) < spec["minLength"]:
            return f"{name!r} is too short: {value!r}"
        return ""
    if kind in ("integer", "number"):
        return _numeric_problem(name, value, kind, spec)
    if kind == "boolean":
        return "" if isinstance(value, bool) else f"{name!r} must be true or false"
    if kind == "array":
        if isinstance(value, (str, bytes)) or not isinstance(value, Sequence):
            return f"{name!r} must be an array of strings"
        allowed = (spec.get("items") or {}).get("enum")
        for entry in value:
            if not isinstance(entry, str):
                return f"{name!r} must contain only strings"
            if allowed and entry not in allowed:
                return f"{name!r} contains {entry!r}; expected one of {', '.join(allowed)}"
        minimum = spec.get("minItems")
        if minimum and len(value) < minimum:
            return f"{name!r} needs at least {minimum} entry"
        return ""
    return f"{name!r} has an unsupported schema type {kind!r}"


def _argument_problems(
    arguments: Mapping[str, Any], schema: Mapping[str, Any]
) -> tuple[str, ...]:
    """Check the model's arguments against the capability's closed schema.

    Unknown keywords are refused by name. That is the difference between this
    design and a shell: there is no keyword under which an unmodelled flag can
    travel, so ``extra_args`` and ``--script`` are simply not sayable.
    """
    if not isinstance(arguments, Mapping):
        return (f"arguments must be an object, got {type(arguments).__name__}",)
    properties: Mapping[str, Any] = schema.get("properties") or {}
    problems = [
        f"missing required argument {name!r}"
        for name in schema.get("required") or ()
        if name not in arguments
    ]
    for key, value in arguments.items():
        spec = properties.get(key)
        if spec is None:
            if schema.get("additionalProperties", True) is False:
                problems.append(
                    f"unknown argument {key!r}; this capability accepts only: "
                    f"{', '.join(sorted(properties))}"
                )
            continue
        problem = _type_problem(key, value, spec)
        if problem:
            problems.append(problem)
    return tuple(problems)


#: ``10.0.0.0/24`` is a legitimate nmap target; ``/`` anywhere else is a path.
_CIDR = re.compile(r"^[0-9a-fA-F:.]+/[0-9]{1,3}$")

#: Code hosts a repository target may name. The same four ``safety/scope.py``
#: knows, restated here because this module must refuse the target *before* the
#: adapter builds an argv from it.
_SCOPE_HOSTS = frozenset({"github.com", "gitlab.com", "codeberg.org", "bitbucket.org"})


def _segments(value: str) -> list[str]:
    """Path segments of a target, with any scheme removed."""
    text = value.split("://", 1)[1] if "://" in value else value
    return [part for part in text.strip().strip("/").split("/") if part]


def _target_problem(target: Any, kind: str) -> str:
    """Reject the target before the adapter does, with a sentence that teaches."""
    if not isinstance(target, str) or not target.strip():
        return "no target given"
    value = target.strip()
    if value.startswith("-"):
        return f"refusing a target that looks like an option: {value!r}"
    if any(char.isspace() for char in value) or "\x00" in value:
        return f"refusing a target containing whitespace or NULs: {value!r}"
    if kind == "url":
        if "://" not in value:
            return (
                f"{value!r} is not a URL. This capability needs the full URL including "
                "its scheme, e.g. https://app.example.com/login"
            )
        return ""
    if kind == "repository":
        parts = _segments(value)
        if len(parts) != 3 or parts[0].lower() not in _SCOPE_HOSTS:
            return (
                f"{value!r} is not a repository on a code host this product can "
                "name. Give it as github.com/owner/name"
            )
        return ""
    if kind == "model":
        if len(_segments(value)) != 2:
            return (
                f"{value!r} is not a model id. Give it as owner/name, or as "
                "hf://owner/name"
            )
        return ""
    if "://" in value or ("/" in value and not _CIDR.match(value)):
        return (
            f"{value!r} is not a host. This capability takes a hostname, IP address or "
            "CIDR range - not a URL, not a path"
        )
    return ""


# --------------------------------------------------------------- the registry
class Registry:
    """The actions one scan may name, and the pre-flight for each of them.

    Args:
        capabilities: the registered set. Defaults to :data:`CAPABILITIES`.
        guard: the guard used for pre-flight. Pass the scan's own guard so the
            answer the model gets is the answer it will actually receive.
    """

    def __init__(
        self,
        capabilities: Iterable[Capability] = CAPABILITIES,
        *,
        guard: Guard | None = None,
    ) -> None:
        self.capabilities = tuple(capabilities)
        self._by_name: dict[str, Capability] = {}
        for capability in self.capabilities:
            if capability.name in self._by_name:
                raise ValueError(f"capability {capability.name!r} is registered twice")
            self._by_name[capability.name] = capability
        if not self._by_name:
            raise ValueError("a registry with no capabilities cannot run a scan")
        self.guard = guard if guard is not None else Guard()

    # ------------------------------------------------------------------ lookup
    @property
    def names(self) -> tuple[str, ...]:
        return tuple(sorted(self._by_name))

    def __len__(self) -> int:
        return len(self._by_name)

    def __contains__(self, name: object) -> bool:
        return name in self._by_name

    def get(self, name: str) -> Capability:
        try:
            return self._by_name[name]
        except KeyError:
            raise UnknownCapability(
                f"{name!r} is not a registered capability. This scan can call: "
                f"{', '.join(self.names)}"
            ) from None

    def class_for(self, name: str) -> ActionClass:
        """The class the guard will assign, so the prompt can state it plainly."""
        return self.guard.class_for_tool(name)

    def requires_approval(self, name: str) -> bool:
        """Whether a human must approve this capability's command line.

        Delegated to the guard rather than re-derived: a class check written
        here could drift from the guard's own rule, and this is the property the
        model is told about before it plans.
        """
        return self.guard.classify_command(name).requires_approval

    # -------------------------------------------------------- pack filtering
    def available(
        self, spec: AgentSpec, domain: str, tier: str
    ) -> tuple[Capability, ...]:
        """Registered capabilities this pack, on this tier, may use."""
        allowed = spec.tools_for(domain, tier)
        return tuple(c for c in self.capabilities if c.name in allowed)

    def unavailable(self, spec: AgentSpec, domain: str, tier: str) -> tuple[str, ...]:
        """Pack tools with no adapter yet.

        ``domains.yaml`` names the product's intended surface; this method is
        how the gap is *reported* instead of hidden. The planner shows these to
        the model as "listed but not implemented", so a model that cannot find
        ``whatweb`` says so rather than reinventing it.
        """
        return tuple(sorted(spec.tools_for(domain, tier) - set(self._by_name)))

    def tool_specs(
        self, spec: AgentSpec, domain: str, tier: str
    ) -> tuple[ToolSpec, ...]:
        """Declarations for the model, each stating its own action class."""
        return self._specs(self.available(spec, domain, tier))

    def all_tool_specs(self) -> tuple[ToolSpec, ...]:
        """Declarations for every registered capability.

        The planner narrows by domain pack and tier; freestyle has neither - the
        operator named one target and asked what this install would do to it - so
        the whole registry is offered. This is not a widening of authority: the
        guard classifies each of these identically whether the planner or
        freestyle asked, and the adapter re-checks everything at execution.
        """
        return self._specs(self.capabilities)

    def _specs(self, capabilities: Iterable[Capability]) -> tuple[ToolSpec, ...]:
        return tuple(
            capability.tool_spec(
                action_class=self.class_for(capability.name).value,
                requires_approval=self.requires_approval(capability.name),
            )
            for capability in capabilities
        )


    # ------------------------------------------------------------- preflight
    def preflight(
        self,
        name: str,
        arguments: Mapping[str, Any] | None = None,
        *,
        raw_arguments: str = "",
        approved_commands: Iterable[str] = (),
    ) -> Preflight:
        """Decide what would happen, without making it happen.

        The order mirrors the adapter's own chain — capability, arguments,
        target kind, guard — so the refusal a model reads is the one it would
        have received from the run itself, one step earlier. Pre-flight cannot
        widen authority: the adapter still re-checks everything at execution.

        Args:
            approved_commands: the scan's approved command lines. An intrusive
                action whose *exact* line appears here is not refused — it is
                an approval that already exists, not a refusal to report.
        """
        arguments = dict(arguments or {})
        capability = self._by_name.get(name)
        if capability is None:
            return Preflight(
                name,
                refusal=Refusal(
                    "unknown_capability",
                    f"{name!r} is not a registered capability. This scan can call: "
                    f"{', '.join(self.names)}. Do not describe a shell command or a "
                    "program in its place.",
                ),
            )
        documented = ", ".join(sorted(capability.parameters["properties"]))
        if raw_arguments and not arguments:
            return Preflight(
                name,
                capability=capability,
                refusal=Refusal(
                    "bad_arguments",
                    f"the arguments for {name!r} did not parse as a JSON object: "
                    f"{raw_arguments[:200]!r}. Send one object containing only the "
                    f"documented keys: {documented}.",
                ),
            )
        problems = _argument_problems(arguments, capability.parameters)
        if problems:
            return Preflight(
                name,
                capability=capability,
                refusal=Refusal("bad_arguments", "; ".join(problems)),
            )
        problem = _target_problem(arguments.get("target"), capability.target_kind)
        if problem:
            return Preflight(
                name, capability=capability, refusal=Refusal("bad_target", problem)
            )

        target = str(arguments["target"]).strip()
        options = {key: value for key, value in arguments.items() if key != "target"}
        try:
            argv = [
                str(part) for part in capability.adapter.build_argv(target, **options)
            ]
        except (ValueError, ToolExecutionError) as exc:
            # The adapter's validation is the last word on what a value may be;
            # surfacing it here keeps the refusal in the model's own terms.
            return Preflight(
                name,
                capability=capability,
                refusal=Refusal("bad_arguments", str(exc)),
            )

        command = " ".join(argv)
        decision = self.guard.classify_command(capability.name, argv[1:])
        if not decision.allowed:
            return Preflight(
                name,
                capability=capability,
                command=command,
                decision=decision,
                refusal=Refusal(
                    "forbidden",
                    "; ".join(decision.reasons)
                    or "this action is in a permanently forbidden class",
                    decision.matched_rules,
                    decision.action_class.value,
                ),
            )
        if decision.requires_approval and command not in approved_commands:
            return Preflight(
                name,
                capability=capability,
                command=command,
                decision=decision,
                refusal=Refusal(
                    "approval_required",
                    "this action is intrusive: a human must approve this exact "
                    "command line before it runs. " + "; ".join(decision.reasons),
                    decision.matched_rules,
                    decision.action_class.value,
                ),
            )
        return Preflight(
            name,
            capability=capability,
            command=command,
            decision=decision,
            approved=decision.requires_approval,
        )

    # -------------------------------------------------------------- execution
    def execute(
        self,
        name: str,
        arguments: Mapping[str, Any],
        *,
        context: ToolContext,
        target: str | None = None,
    ) -> ToolResult:
        """Run one capability under the adapter's full enforcement chain.

        Pre-flight is deliberately *not* consulted here. The adapter re-checks
        the kill switch, the authorization, the scope, the guard and the rate
        limit from scratch, because a plan is a request, not a permission.
        """
        capability = self.get(name)
        options = dict(arguments)
        value = target if target is not None else options.pop("target", "")
        problem = _target_problem(value, capability.target_kind)
        if problem:
            raise ValueError(problem)
        return capability.adapter.run(str(value).strip(), context, **options)

    def describe(self) -> dict[str, Any]:
        """Log-safe inventory: names, classes and whether approval is needed."""
        return {
            "capabilities": {
                capability.name: {
                    "class": self.class_for(capability.name).value,
                    "requires_approval": self.requires_approval(capability.name),
                    "phases": list(capability.phases),
                    "arguments": sorted(capability.parameters["properties"]),
                }
                for capability in self.capabilities
            },
            "unknown_tool_class": self.guard.unknown_tool_class.value,
        }
