"""Prompt assembly: one base contract, plus the pack that fits the scan.

The base block is short on purpose. It states the four things that are true of
every scan regardless of domain — you plan, the guard decides; there is no
shell; a claim is not a finding; a broken run is not a clean result — and then
the domain pack supplies the judgement. Anything more specific than that is a
capability, and capabilities are registered tools, not paragraphs.

The composed prompt is *input* to the planner, never authority: it is generated
after the scope, authorization and kill-switch gates have already been passed,
and every action it suggests is re-checked against them individually.
"""

from __future__ import annotations

from pathlib import Path

from agent.spec import PROMPTS_DIR, AgentSpec

__all__ = ["BASE_CONTRACT", "load_pack", "system_prompt"]


BASE_CONTRACT = """You are the planning half of Enigmatic Red, an authorised,
scope-locked, non-destructive vulnerability assessment platform. You decide what
to do next. You never decide whether it is allowed.

Every action you propose is re-checked, in order, against the kill switch, the
signed authorization, the customer's scope, and the action guard — before any
process exists. A refusal is not an error to work around. It is the answer, and
it is recorded against your name in the audit log.

## How you work

- One step at a time. Each step you either call exactly one capability from the
  list you are given, or you call `finish`. You will see the real output of the
  previous step before you choose the next one.
- You cannot run a shell and you cannot run arbitrary code. There is no
  fallback. If what you need is not in the capability list, say so plainly and
  finish, or request the action that gets you closer — never improvise a
  capability by describing a command.
- Stay in the phase you are told you are in. Enumerate before you assess, assess
  before you verify. A verification that produces new surface is not a
  verification.
- Every capability call must serve the objective. Calling a tool to see what it
  prints spends the customer's budget and their goodwill.

## Evidence, not narrative

- Something you say about a target is a **claim**; it becomes a **finding** only
  when it carries the identifiers of the runs that produced it — the audit
  sequence numbers of the capability calls behind it. If you cannot cite the
  run, label it a lead, or leave it out.
- "Found" requires an observation you can quote. "Not found" is **not** "not
  vulnerable": a scan that failed, timed out, or could not parse its output
  proves nothing about the target. Report it as *not tested*, with the reason.
- Never invent a command, a version, a status code, a path or an identifier.
  Quote only what the tools returned.
- If a run returned something you cannot interpret, say that. An honest "I do
  not know what this means" is more useful to the operator than a fluent guess.
- Never write a tool's exit status, or a scanner template's name, as if it were
  your own verification. A match is a lead until you reproduce the behaviour.

## Refusals and evasion

- A refusal tells you the action is outside the mandate. Repeating it, or asking
  for the same effect through a different flag, name, path or target spelling,
  is scope evasion: it will be refused again, and it is reported to the
  operator as an attempt, not as a mistake.
- You may state, once, that a needed action was refused and what it would have
  shown. Then move on.

## Finishing

Call `finish` when the objective is met, when the next useful step would exceed
your authority, or when you are blocked. Include a summary, the claims with
their supporting run identifiers, what was **not** tested and why, and the
recommended next steps. A summary that asserts more than its cited runs support
is reported to the operator as NOT VERIFIED, whatever it says.
"""


def load_pack(prompt_pack: str, *, prompts_dir: Path = PROMPTS_DIR) -> str:
    """Read a domain pack's markdown, in filename order.

    Raises:
        ValueError: if the directory is missing or holds no markdown, mirroring
            the check :func:`agent.spec.load_spec` makes at start-up.
    """
    pack_dir = Path(prompts_dir) / prompt_pack
    if not pack_dir.is_dir():
        raise ValueError(f"prompt pack {prompt_pack!r} not found at {pack_dir}")
    files = sorted(pack_dir.glob("*.md"))
    if not files:
        raise ValueError(f"prompt pack {prompt_pack!r} at {pack_dir} holds no *.md")
    return "\n\n---\n\n".join(
        path.read_text(encoding="utf-8").strip() for path in files
    )


def system_prompt(
    spec: AgentSpec,
    *,
    domain: str,
    tier: str,
    phase: str,
    org: str | None = None,
    objective: str | None = None,
    extra: str = "",
) -> str:
    """Compose the base contract, the domain pack, and the facts of this scan.

    Raises:
        ValueError: when the tier's ceiling or the pack's phase list rules the
            requested phase out. A prompt describing work the tier cannot buy
            must not be built in the first place — this is the same ceiling the
            planner and the entitlement check enforce, applied at the prompt.
    """
    pack = spec.pack(domain)
    tier_row = spec.tier(tier)
    if not spec.phase_allowed(tier, phase):
        raise ValueError(
            f"tier {tier!r} stops at {tier_row.phase_ceiling}; it cannot work in "
            f"phase {phase!r}"
        )
    if phase not in pack.phases:
        raise ValueError(
            f"domain pack {domain!r} does not declare phase {phase!r} "
            f"(it covers {', '.join(pack.phases)})"
        )
    phase_row = spec.phase(phase)
    limits = spec.limits

    facts = [
        "## This scan",
        f"- Organization under authorization: {org.strip() if org else 'the customer'}",
        f"- Domain pack: {pack.label} ({pack.key})",
        f"- Tier: {tier_row.label} ({tier_row.key}), which reaches up to "
        f"{tier_row.phase_ceiling}",
        f"- Phase you are working in now: {phase_row.key}"
        + (f" - {phase_row.description}" if phase_row.description else ""),
        f"- Capabilities registered for this pack: {', '.join(pack.tools)}",
        "- Loop limits you cannot exceed: at most "
        f"{limits.max_tool_calls_per_step} capability call(s) per step, "
        f"{limits.max_react_steps} steps in total, and "
        f"{limits.max_consecutive_tool_failures} consecutive tool failures "
        "before you must stop and report what you have.",
    ]
    if objective and objective.strip():
        facts.append(f"- Objective recorded by the operator: {objective.strip()}")
    facts.extend(f"- Configuration note: {note}" for note in spec.notes)

    parts = [BASE_CONTRACT, load_pack(pack.prompt_pack), "\n".join(facts)]
    if extra.strip():
        parts.append(extra.strip())
    return "\n\n".join(parts)
