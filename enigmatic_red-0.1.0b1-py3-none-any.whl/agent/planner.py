"""The planner: a bounded ReAct loop that can only name registered capabilities.

What the reference implementation did: ask a model for a JSON action, salvage a
tool name out of the text with a regex, and — for anything that was not a tool —
run it through a shell. Three failure modes came with that, and each is removed
here rather than mitigated:

* **The shell.** A model that can write a shell command can do anything a shell
  can do, which no prompt can fix. Here a step is either a capability from
  :mod:`agent.registry` or ``finish``. Native function calling carries the call;
  nothing is parsed out of prose.
* **Silent budget drift.** The step limit, the per-step call limit, the
  consecutive-failure limit and the scan token budget are read from
  :class:`agent.spec.Limits` and the provider's ledger, and they stop the loop.
  They are not advice in a prompt.
* **Optimistic reporting.** A refusal is fed back to the model *as a refusal*,
  and it is recorded: on the plan, in the audit chain, and in the delivered
  report. The claims the model finishes with are then checked against that same
  chain by :mod:`agent.honesty` before anything is called a finding.

Everything the planner decides is appended to the scan's hash-chained log, in
the same chain the adapters write to: ``plan.started``, ``plan.refused``,
``plan.executed``, ``plan.stalled``, ``plan.claim_rejected``, ``plan.halted``,
``plan.finished``.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Mapping

from agent.honesty import (
    AuditIndex,
    Claim,
    ClaimVerdict,
    claim_from_model,
    verify_claims,
)
from agent.prompts import system_prompt
from agent.providers.base import (
    ChatMessage,
    ChatResult,
    LLMProvider,
    ToolCall,
    ToolSpec,
)
from agent.registry import Preflight, Refusal, Registry
from agent.report import NotTested, RefusalRecord, ScanReport, build_report
from agent.spec import AgentSpec
from safety.errors import (
    ApprovalRequired,
    AuthorizationError,
    ForbiddenActionError,
    KillSwitchEngaged,
    ProviderError,
    RateLimitExceeded,
    ScopeViolation,
    ToolExecutionError,
)
from tools.base import ToolContext, ToolResult

__all__ = ["FINISH", "FINISH_TOOL", "PlanStep", "Planner", "ScanOutcome"]

#: The one name that is not a capability: how a plan ends.
FINISH = "finish"

#: Enforcement failures a single step can raise. Caught so the loop can carry on
#: with the next idea instead of dying on one blocked action.
_STEP_ERRORS = (
    ScopeViolation,
    AuthorizationError,
    ForbiddenActionError,
    ApprovalRequired,
    RateLimitExceeded,
    KillSwitchEngaged,
    ToolExecutionError,
)

FINISH_TOOL = ToolSpec(
    name=FINISH,
    description=(
        "Stop the scan and report. Call this when the objective is met, when the "
        "next useful step would exceed your authority, or when you are blocked. "
        "Every claim you report must cite the audit run id(s) it rests on: a "
        "claim with no run id is delivered as a lead, not as a finding."
    ),
    parameters={
        "type": "object",
        "properties": {
            "summary": {
                "type": "string",
                "description": "What was done and what it showed, in a short paragraph.",
            },
            "claims": {
                "type": "array",
                "items": {"type": "object"},
                "description": (
                    "Assertions about the target. Each: {title, detail, target, "
                    "severity (info|low|medium|high|critical|unknown), evidence "
                    "(run ids), cvss_vector (CVSS:4.0/...), remediation}."
                ),
            },
            "not_tested": {
                "type": "array",
                "items": {"type": "object"},
                "description": (
                    "Coverage that did not happen. Each: {target, what, reason} - "
                    "work refused, or a capability that was unavailable."
                ),
            },
            "next_steps": {
                "type": "array",
                "items": {"type": "string"},
                "description": "What a later phase or a human should pick up.",
            },
            "blocked": {
                "type": "boolean",
                "description": "True when you stopped because you were blocked.",
            },
        },
        "required": ["summary"],
        "additionalProperties": False,
    },
)


@dataclass(frozen=True)
class PlanStep:
    """One attempt: what was asked for, what the guard said, what came back."""

    index: int
    phase: str
    capability: str
    arguments: Mapping[str, Any] = field(default_factory=dict)
    preflight: Preflight | None = None
    result: ToolResult | None = None
    refusal: Refusal | None = None
    note: str = ""

    @property
    def ran(self) -> bool:
        return self.result is not None and self.result.ran

    @property
    def command(self) -> str:
        return self.preflight.command if self.preflight is not None else ""

    @property
    def ok(self) -> bool:
        return bool(self.result is not None and self.result.ok)

    def describe(self) -> dict[str, Any]:
        return {
            "index": self.index,
            "phase": self.phase,
            "capability": self.capability,
            "arguments": dict(self.arguments),
            "command": self.command,
            "action_class": self.preflight.action_class if self.preflight else "",
            "ran": self.ran,
            "ok": self.ok,
            "note": self.note,
            "audit_seq": self.result.audit_seq if self.result is not None else 0,
            **({"refusal": self.refusal.describe()} if self.refusal else {}),
        }


@dataclass(frozen=True)
class ScanOutcome:
    """The scan's result: what is delivered, plus how it went."""

    report: ScanReport
    steps: tuple[PlanStep, ...] = ()
    claims: tuple[Claim, ...] = ()
    rejected_claims: tuple[str, ...] = ()
    summary: str = ""
    next_steps: tuple[str, ...] = ()
    blocked: bool = False
    stop_reason: str = ""

    @property
    def verdicts(self) -> tuple[ClaimVerdict, ...]:
        return self.report.verdicts

    @property
    def refusals(self) -> tuple[RefusalRecord, ...]:
        """What was refused — the same records the report lists."""
        return self.report.refusals

    def describe(self) -> dict[str, Any]:
        return {
            "stop_reason": self.stop_reason,
            "blocked": self.blocked,
            "summary": self.summary,
            "next_steps": list(self.next_steps),
            "rejected_claims": list(self.rejected_claims),
            "steps": [step.describe() for step in self.steps],
            "report": self.report.to_dict(),
        }


class Planner:
    """Runs one phase of one scan, one step at a time.

    Args:
        spec: loaded configuration. Every limit comes from here, not a prompt.
        registry: the capabilities this scan may name.
        provider: the model backend. Tests pass a scripted double.
        context: scope, guard, limiter, audit log, attestation, kill switch.
        domain: domain pack key; must be included in the tier.
        tier: entitlement tier key.
        phase: the phase to work in — inside the tier's ceiling and part of the
            pack's phase list, checked here so a mis-wired scan fails at
            construction rather than at the first tool call.
        objective: the operator's objective, verbatim.
        task: routing key for the model role (default ``recon_plan``).
        max_output_chars: how much of a run's stdout the model is shown. The
            full output stays in the evidence trail; the model gets a bounded
            slice so one noisy scan cannot spend the token budget.
    """

    def __init__(
        self,
        *,
        spec: AgentSpec,
        registry: Registry,
        provider: LLMProvider,
        context: ToolContext,
        domain: str,
        tier: str,
        phase: str = "P1_recon",
        objective: str = "",
        task: str = "recon_plan",
        max_output_chars: int = 4000,
    ) -> None:
        tier_row = spec.tier(tier)
        if domain not in tier_row.domains:
            raise ValueError(
                f"tier {tier!r} does not include the {domain!r} domain pack; it "
                f"covers {', '.join(tier_row.domains)}"
            )
        if not spec.phase_allowed(tier, phase):
            raise ValueError(
                f"tier {tier!r} stops at {tier_row.phase_ceiling}; it cannot work "
                f"in phase {phase!r}"
            )
        pack = spec.pack(domain)
        if phase not in pack.phases:
            raise ValueError(
                f"domain pack {domain!r} does not declare phase {phase!r} "
                f"(it covers {', '.join(pack.phases)})"
            )

        self.spec = spec
        self.registry = registry
        self.provider = provider
        self.context = context
        self.limits = spec.limits
        self.pack = pack
        self.tier_row = tier_row
        self.domain = domain
        self.tier = tier
        self.phase = phase
        self.objective = objective.strip()
        self.task = task
        self.role = spec.routing.role_for(task)
        self.max_output_chars = max(200, int(max_output_chars))

        self.steps: list[PlanStep] = []
        self.claims: list[Claim] = []
        self.rejected: list[str] = []
        self.refusals: list[RefusalRecord] = []
        self.not_tested: list[NotTested] = []
        self.summary = ""
        self.next_steps: tuple[str, ...] = ()
        self.blocked = False
        self.stalls = 0
        self.llm_calls = 0

    # ------------------------------------------------------------- inventory
    def tools(self) -> tuple[ToolSpec, ...]:
        """Declarations handed to the model: this pack, this tier, plus finish."""
        return (
            *self.registry.tool_specs(self.spec, self.domain, self.tier),
            FINISH_TOOL,
        )

    def phase_sequence(self) -> tuple[str, ...]:
        """Phases this tier may work in, in order — what an orchestrator loops."""
        return self.spec.phases_for(self.domain, self.tier)

    def package_gaps(self) -> tuple[str, ...]:
        """Pack tools with no adapter in this build."""
        return self.registry.unavailable(self.spec, self.domain, self.tier)

    # ----------------------------------------------------------------- audit
    def _audit(
        self,
        event: str,
        *,
        target: str | None = None,
        action: str | None = None,
        action_class: str | None = None,
        decision: str | None = None,
        **detail: Any,
    ) -> int:
        entry = self.context.audit.append(
            event,
            actor=self.context.actor,
            org=self.context.org,
            target=target,
            action=action,
            action_class=action_class,
            decision=decision,
            scan_id=self.context.scan_id,
            **detail,
        )
        return entry.seq

    # ------------------------------------------------------------- prompting
    def _addendum(self) -> str:
        """The capability list, in the model's own terms."""
        lines = ["## The actions you can take", ""]
        for capability in self.registry.available(self.spec, self.domain, self.tier):
            action_class = self.registry.class_for(capability.name).value
            approval = (
                "; needs a human approval for the exact command line"
                if self.registry.requires_approval(capability.name)
                else ""
            )
            lines.append(f"- `{capability.name}` ({action_class}{approval})")
            lines.append(f"  - what it gives you: {capability.summary}")
            lines.append(
                "  - arguments: "
                + ", ".join(capability.required)
                + " required; accepted: "
                + ", ".join(sorted(capability.parameters["properties"]))
            )
            if capability.phases:
                lines.append(f"  - most useful in: {', '.join(capability.phases)}")
        gaps = self.package_gaps()
        if gaps:
            lines += [
                "",
                "Named in this pack but not implemented in this build, so you "
                "cannot call them and must not pretend to: " + ", ".join(gaps) + ".",
            ]
        lines += [
            "",
            "Call `finish` when the objective is met, when you are blocked, or "
            "when the next useful step would exceed your authority.",
        ]
        return "\n".join(lines)

    def _initial_messages(self) -> list[ChatMessage]:
        system = system_prompt(
            self.spec,
            domain=self.domain,
            tier=self.tier,
            phase=self.phase,
            org=self.context.org,
            objective=self.objective,
            extra=self._addendum(),
        )
        task = self.objective or (
            f"Work phase {self.phase} of the {self.domain} scan, then report what "
            "you can support with a run id."
        )
        return [ChatMessage.system(system), ChatMessage.user(task)]

    # -------------------------------------------------------------- the loop
    async def run(self) -> ScanOutcome:
        """Drive the loop, then assemble the report.

        Never raises because a step was refused: a refusal is a recorded
        outcome, and the scan continues with the next idea. It *does* stop on
        the kill switch, the step limit, the token budget and repeated failure -
        loudly, with the reason named in the report.
        """
        available = self.registry.available(self.spec, self.domain, self.tier)
        self._audit(
            "plan.started",
            domain=self.domain,
            tier=self.tier,
            phase=self.phase,
            objective=self.objective[:400],
            capabilities=sorted(capability.name for capability in available),
            unavailable=list(self.package_gaps()),
        )
        messages = self._initial_messages()
        stop_reason = "the step limit was reached"
        failures = 0

        for index in range(1, self.limits.max_react_steps + 1):
            if self._halted():
                stop_reason = "halted by the operator's kill switch"
                break
            if self.provider.ledger.exhausted:
                stop_reason = "the scan token budget was exhausted"
                self._audit(
                    "plan.stalled",
                    code="budget_exhausted",
                    **self.provider.ledger.describe(),
                )
                break
            try:
                turn: ChatResult = await self.provider.chat(
                    messages, tools=self.tools(), role=self.role
                )
            except ProviderError as exc:
                stop_reason = f"the model call failed: {exc}"
                self._audit("plan.stalled", code="provider_error", reason=str(exc)[:300])
                break
            self.llm_calls += 1
            calls = tuple(turn.tool_calls)
            messages.append(ChatMessage.assistant(turn.text, calls))

            if not calls:
                # A turn with no call is not progress. Say so once, then stop.
                self.stalls += 1
                self._audit("plan.stalled", code="no_action", said=turn.text[:300])
                messages.append(
                    ChatMessage.user(
                        "A turn with no capability call makes no progress. Call one "
                        "of the declared functions, or call finish if you are done "
                        "or blocked."
                    )
                )
                if self.stalls >= _MAX_STALLS:
                    stop_reason = "the model stopped calling capabilities"
                    break
                continue

            self.stalls = 0
            for call in calls[: self.limits.max_tool_calls_per_step]:
                if self._is_finish(call):
                    self._read_finish(call)
                    stop_reason = "finished by the model"
                    break
                step = self._take(index, call)
                messages.append(
                    ChatMessage.tool_result(
                        call.id, self._feedback(step), name=step.capability
                    )
                )
                failures = 0 if step.ok else failures + 1
                if failures >= self.limits.max_consecutive_tool_failures:
                    stop_reason = f"{failures} consecutive unsuccessful steps"
                    self._audit("plan.stalled", code="step_failures", count=failures)
                    break
            else:
                continue  # the whole batch ran; take another turn
            break  # a break in the inner loop is a reason to stop

        return self._assemble(stop_reason)

    # ------------------------------------------------------------------ halt
    def _halted(self) -> bool:
        if self.context.killswitch is None:
            return False
        try:
            self.context.killswitch.check(self.context.org)
        except KillSwitchEngaged as exc:
            self._audit("plan.halted", decision="halted", reason=str(exc)[:300])
            return True
        return False

    # ----------------------------------------------------------- one attempt
    def _is_finish(self, call: ToolCall) -> bool:
        return (call.name or "").strip().lower() == FINISH

    def _take(self, index: int, call: ToolCall) -> PlanStep:
        """Pre-flight one call, then run it, refuse it, or record why not."""
        name = (call.name or "").strip().lower()
        arguments = dict(call.arguments or {})
        target = str(arguments.get("target") or "")
        flight = self.registry.preflight(
            name,
            arguments,
            raw_arguments=call.raw_arguments,
            approved_commands=self.context.approved,
        )

        if not flight.ok:
            refusal = flight.refusal
            assert refusal is not None  # "not ok" always carries a reason
            self.refusals.append(
                RefusalRecord(
                    capability=name or "(unnamed)",
                    code=refusal.code,
                    reason=refusal.reason,
                    action_class=refusal.action_class,
                    command=flight.command,
                    matched_rules=refusal.matched_rules,
                )
            )
            self._audit(
                "plan.refused",
                target=target or None,
                action=flight.command or name or "(unnamed)",
                action_class=refusal.action_class or None,
                decision="refused",
                code=refusal.code,
                reason=refusal.reason[:400],
                matched_rules=list(refusal.matched_rules),
            )
            if refusal.code == "approval_required":
                self.not_tested.append(
                    NotTested(
                        target or "(target unknown)",
                        name,
                        "intrusive action, and no human approved this exact command "
                        "line, so it never ran",
                    )
                )
            elif refusal.code == "unknown_capability":
                self.not_tested.append(
                    NotTested(
                        target or "(target unknown)",
                        name or "(unnamed)",
                        "the planner asked for something that is not a registered "
                        "capability, so nothing ran",
                    )
                )
            step = PlanStep(
                index, self.phase, name, arguments, preflight=flight, refusal=refusal
            )
        else:
            step = self._execute(index, name, arguments, flight, target)

        self.steps.append(step)
        return step

    def _execute(
        self,
        index: int,
        name: str,
        arguments: Mapping[str, Any],
        flight: Preflight,
        target: str,
    ) -> PlanStep:
        """Hand the call to the registry, which hands it to the adapter chain."""
        try:
            result = self.registry.execute(name, arguments, context=self.context)
        except _STEP_ERRORS as exc:
            # The adapter wrote its own refusal entry; this is the plan's view of
            # the same event, and it stops the model trying an equivalent.
            code = _code_for(exc)
            self._audit(
                "plan.blocked",
                target=target or None,
                action=flight.command,
                action_class=flight.action_class or None,
                decision="refused",
                code=code,
                reason=str(exc)[:400],
            )
            self.refusals.append(
                RefusalRecord(
                    capability=name,
                    code=code,
                    reason=str(exc),
                    action_class=flight.action_class,
                    command=flight.command,
                )
            )
            self.not_tested.append(
                NotTested(
                    target or "(target unknown)",
                    name,
                    f"refused before it ran: {str(exc)[:200]}",
                )
            )
            return PlanStep(
                index,
                self.phase,
                name,
                dict(arguments),
                preflight=flight,
                note=str(exc)[:400],
            )

        self._audit(
            "plan.executed",
            target=target or None,
            action=flight.command,
            action_class=flight.action_class or None,
            decision="ok" if result.ok else "error",
            audit_seq=result.audit_seq,
            skipped=result.skipped,
            approved=flight.approved,
            **({"parse_error": result.parse_error[:200]} if result.parse_error else {}),
        )
        if result.skipped:
            self.not_tested.append(
                NotTested(
                    target or "(target unknown)",
                    name,
                    f"the tool could not run: {result.skip_reason}",
                )
            )
        return PlanStep(
            index,
            self.phase,
            name,
            dict(arguments),
            preflight=flight,
            result=result,
        )

    # ------------------------------------------------------ what the model sees
    def _parsed_summary(self, step: PlanStep) -> str:
        if step.result is None or step.result.parsed is None:
            return ""
        if step.capability not in self.registry:
            return ""
        try:
            summary = self.registry.get(step.capability).adapter.summarize(
                step.result.parsed
            )
        except (TypeError, ValueError) as exc:  # pragma: no cover - defensive
            return f"(could not summarise the result: {exc})"
        try:
            return _clip(json.dumps(summary, default=str), 1200)
        except (TypeError, ValueError):  # pragma: no cover - defensive
            return ""

    def _feedback(self, step: PlanStep) -> str:
        """What the model is told after a step. Never raw output, never a hint
        about how to get around a refusal."""
        if step.refusal is not None:
            refusal = step.refusal
            lines = [
                f"`{step.capability or 'that action'}` did NOT run ({refusal.code}).",
                refusal.reason,
            ]
            if step.command:
                lines.append(f"Command line considered: {step.command}")
            guidance = _REFUSAL_GUIDANCE.get(refusal.code, "")
            if guidance:
                lines.append(guidance)
            return "\n".join(lines)

        if step.result is None:
            return (
                f"`{step.capability}` was refused before it started: {step.note}\n"
                f"Command line considered: {step.command}\n"
                "Report this as not tested. Do not retry the same effect under "
                "another name."
            )

        result = step.result
        lines = [
            f"`{step.capability}` ran (audit seq {result.audit_seq}): {step.command}"
        ]
        if result.skipped:
            lines.append(
                f"It did not run: {result.skip_reason}. This proves nothing about "
                "the target - report it as not tested."
            )
        elif result.parse_error:
            lines.append(
                f"Nothing could be parsed from its output: {result.parse_error}. "
                "This proves nothing about the target."
            )
        elif result.command is not None and not result.command.ok:
            lines.append(
                f"It exited with rc {result.command.returncode}; treat what follows "
                "with care."
            )
        summary = self._parsed_summary(step)
        if summary:
            lines.append(f"Parsed result: {summary}")
        if result.command is not None and result.command.stdout:
            lines.append("Output: " + _clip(result.command.stdout, self.max_output_chars))
        lines.append(f"Cite this run as evidence id {result.audit_seq}.")
        return "\n".join(lines)

    # ---------------------------------------------------------------- finish
    def _read_finish(self, call: ToolCall) -> None:
        """Take the model's closing statement and record it, unfiltered."""
        payload = dict(call.arguments or {})
        if call.raw_arguments and not payload:
            self.rejected.append(
                f"the finish arguments did not parse: {call.raw_arguments[:200]!r}"
            )
        self.summary = str(payload.get("summary") or "").strip()
        self.blocked = bool(payload.get("blocked"))

        for raw in payload.get("claims") or ():
            try:
                self.claims.append(claim_from_model(raw))
            except ValueError as exc:
                self.rejected.append(str(exc))
                self._audit(
                    "plan.claim_rejected", decision="rejected", reason=str(exc)[:300]
                )

        for raw in payload.get("not_tested") or ():
            if not isinstance(raw, Mapping):
                self.rejected.append(f"an entry in not_tested was not an object: {raw!r}")
                continue
            self.not_tested.append(
                NotTested(
                    target=str(raw.get("target") or "(target unknown)").strip(),
                    what=str(raw.get("what") or "unspecified").strip(),
                    reason=str(raw.get("reason") or "").strip(),
                )
            )

        raw_steps = payload.get("next_steps") or ()
        if isinstance(raw_steps, str):
            raw_steps = (raw_steps,)
        self.next_steps = tuple(
            text for text in (str(item).strip() for item in raw_steps) if text
        )

        self._audit(
            "plan.finished",
            decision="finished",
            blocked=self.blocked,
            summary=self.summary[:400],
            claims=len(self.claims),
            rejected_claims=len(self.rejected),
            steps=len(self.steps),
        )

    # -------------------------------------------------------------- assembly
    def _coverage_gaps(self) -> tuple[NotTested, ...]:
        """What the report must not let a reader assume was covered."""
        reported = tuple(self.not_tested)
        named = {item.what.lower() for item in reported}
        automatic = tuple(
            NotTested(
                "(any in-scope target)",
                tool,
                "named in this domain pack, but no adapter implements it in this "
                "build, so nothing was attempted for it",
            )
            for tool in self.package_gaps()
            if tool.lower() not in named
        )
        return reported + automatic

    def _usage(self) -> dict[str, Any]:
        return {
            "steps": len(self.steps),
            "llm_calls": self.llm_calls,
            "model_role": self.role,
            "tokens": self.provider.ledger.describe(),
        }

    def _assemble(self, stop_reason: str) -> ScanOutcome:
        """Verify the claims against the chain, then build what is delivered."""
        if not self.summary:
            self.summary = (
                "The scan ended without a closing summary from the model; the "
                f"recorded reason is: {stop_reason}."
            )
        self._audit(
            "plan.reported",
            decision="reported",
            stop_reason=stop_reason,
            claims=len(self.claims),
            refusals=len(self.refusals),
            not_tested=len(self.not_tested),
        )
        index = AuditIndex.from_log(self.context.audit, scan_id=self.context.scan_id)
        report = build_report(
            scan_id=self.context.scan_id,
            org=self.context.org or "(unknown)",
            domain=self.domain,
            tier=self.tier,
            phase_ceiling=self.tier_row.phase_ceiling,
            index=index,
            objective=self.objective,
            phases_run=[step.phase for step in self.steps],
            verdicts=verify_claims(self.claims, index),
            refusals=self.refusals,
            not_tested=self._coverage_gaps(),
            usage=self._usage(),
        )
        return ScanOutcome(
            report=report,
            steps=tuple(self.steps),
            claims=tuple(self.claims),
            rejected_claims=tuple(self.rejected),
            summary=self.summary,
            next_steps=self.next_steps,
            blocked=self.blocked,
            stop_reason=stop_reason,
        )


# ------------------------------------------------------------- small helpers
def _clip(text: str, limit: int) -> str:
    """Bound what the model sees; the full output stays in the evidence trail."""
    text = text or ""
    if len(text) <= limit:
        return text
    return text[:limit] + f"\n[... {len(text) - limit} more characters not shown]"


def _code_for(exc: Exception) -> str:
    """A stable code for a refusal raised by the enforcement chain."""
    if isinstance(exc, ApprovalRequired):
        return "approval_required"
    if isinstance(exc, ForbiddenActionError):
        return "forbidden"
    if isinstance(exc, ScopeViolation):
        return "out_of_scope"
    if isinstance(exc, AuthorizationError):
        return "not_authorized"
    if isinstance(exc, RateLimitExceeded):
        return "rate_limited"
    if isinstance(exc, KillSwitchEngaged):
        return "halted"
    if isinstance(exc, ToolExecutionError):
        return "tool_error"
    return "refused"


#: How many consecutive turns without a capability call are tolerated.
_MAX_STALLS = 2

#: What the model is told after a refusal. One sentence each, and none of them
#: points at a way around the decision.
_REFUSAL_GUIDANCE = {
    "unknown_capability": (
        "Call only the declared functions - there is no shell and no fallback. If "
        "the action you need does not exist, say so and finish."
    ),
    "bad_arguments": (
        "Send one object containing only the documented keys for that function, "
        "with values in the documented ranges."
    ),
    "bad_target": (
        "Give the target in the form that function expects, as it appears in the "
        "authorised scope."
    ),
    "forbidden": (
        "This class of action is permanently forbidden and cannot be approved by "
        "anyone. Choose a different approach or finish."
    ),
    "approval_required": (
        "A human must approve that exact command line before it runs. Repeating it, "
        "or asking for the same effect under another name, will be refused again - "
        "report it as not tested instead."
    ),
}