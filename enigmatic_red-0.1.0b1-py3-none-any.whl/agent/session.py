"""The enforcement chain, assembled in one place.

Every scan entry point needs the same six things, in the same order: a scope
that bounds the targets, a signed attestation that says the operator may touch
them, a policy guard that classifies each command before it is built, a rate
limiter, an audit log written *before* the process starts, and a kill switch.

Assembling that twice is how the two callers drift apart: the landing page's
capture would keep passing while ``red scan`` quietly stopped auditing, or the
other way round. So there is one builder here, and both use it:

* ``web/capture_demo.py``      - :meth:`ScanSession.for_lab_demo`, the preset
* the CLI's scan path          - :meth:`ScanSession.open`, from settings

Nothing here can relax a control. It only decides *what* the controls are wired
to; the guard, scope, gate and limiter enforce exactly as they always have.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import timedelta
from pathlib import Path

from config.settings import CONFIG_DIR, Settings, get_settings
from safety.audit import AuditLog
from safety.authz import (
    Attestation,
    AuthorizationGate,
    VerificationMethod,
    make_attestation,
)
from safety.guard import Guard
from safety.killswitch import KillSwitch
from safety.ratelimit import RateLimiter
from safety.scope import Scope
from tools.base import ToolContext

__all__ = ["LAB_ORG", "LAB_STATEMENT", "ScanSession"]

#: The lab preset's operator names. The demo pinned these and the landing page
#: quotes them, so they are constants rather than literals in the capture script.
LAB_ORG = "Enigmatic Red Demo"
LAB_ACTOR = "planner"
LAB_SUBJECT = "Demo Operator"

#: The words the operator signs. Kept verbatim: ``scope_digest`` binds the scope
#: into the attestation, and this text is what a reviewer reads beside it.
LAB_STATEMENT = (
    "The undersigned is authorised to grant access to the assets listed in this "
    "scope for the purpose of a non-destructive security assessment, and has "
    "notified the responsible parties. This authorization is valid for 90 days."
)


@dataclass
class ScanSession:
    """Scope, guard, audit, attestation and the :class:`ToolContext` over them.

    A session is the *authority* for a scan, not the scan itself: it holds the
    dated attestation and the hash-chained audit log, and hands each tool a
    context. The context is the thing a tool cannot forge - it carries the
    guard, the scope check and the limiter for that one call.
    """

    scope: Scope
    guard: Guard
    audit: AuditLog
    attestation: Attestation
    org: str
    actor: str = LAB_ACTOR
    gate: AuthorizationGate = field(default_factory=AuthorizationGate)
    #: Operator halt control. It has to be on the context or it is decorative:
    #: ``ToolAdapter._assert_not_halted`` returns immediately when this is None,
    #: so a session that forgets it can be "stopped" by a sentinel file and keep
    #: running. A switch with no sentinel path and no in-memory halt is inert.
    killswitch: KillSwitch | None = field(default_factory=KillSwitch)
    #: Requests per second allowed per host. Raising this cannot permit
    #: flood-class flags: the policy denies those outright.
    per_host_rps: float = 5.0
    max_concurrency: int = 2
    timeout_s: float = 180.0

    def context(
        self,
        scan_id: str,
        *,
        approved: frozenset[str] = frozenset(),
        actor: str | None = None,
    ) -> ToolContext:
        """Build the context for one tool call.

        A fresh limiter per context is deliberate: one shared across calls would
        let a long scan spend another's budget, and concurrency is per call.
        ``approved`` is the set of approval tokens a human has already granted
        for this call, and it defaults to empty - which is what makes an
        intrusive step stop and ask instead of proceeding.
        """
        return ToolContext(
            scan_id=scan_id,
            scope=self.scope,
            guard=self.guard,
            limiter=RateLimiter(
                per_host_rps=self.per_host_rps,
                max_concurrency=self.max_concurrency,
            ),
            audit=self.audit,
            attestation=self.attestation,
            gate=self.gate,
            org=self.org,
            actor=actor or self.actor,
            approved=approved,
            timeout_s=self.timeout_s,
            killswitch=self.killswitch,
        )

    def describe(self) -> dict[str, object]:
        """Non-secret summary, safe to print from ``red doctor`` or a report."""
        return {
            "org": self.org,
            "actor": self.actor,
            "scope": self.scope.describe(),
            "attestation_reference": self.attestation.reference,
            "attestation_verification": self.attestation.verification.value,
            "attestation_expires_at": (
                self.attestation.expires_at.isoformat()
                if self.attestation.expires_at
                else None
            ),
            "audit_path": str(self.audit.path),
            "audit_seq": self.audit.last_seq,
            "per_host_rps": self.per_host_rps,
            "max_concurrency": self.max_concurrency,
            "timeout_s": self.timeout_s,
        }

    @classmethod
    def open(
        cls,
        *,
        org: str,
        actor: str,
        attestation: Attestation,
        settings: Settings | None = None,
        scope_file: str | Path | None = None,
        policy_file: str | Path | None = None,
        audit_path: str | Path | None = None,
        per_host_rps: float | None = None,
        max_concurrency: int | None = None,
        timeout_s: float | None = None,
        killswitch_path: str | Path | None = None,
        fsync: bool = True,
    ) -> "ScanSession":
        """The real path: policy, scope and audit log resolved from settings.

        An explicit argument wins over settings, so a caller that has already
        decided where its log lives does not have to change global state to say
        so. Everything defaulted comes from :class:`Settings`, which is the only
        place in the codebase that reads the environment.
        """
        resolved = settings or get_settings()
        return cls(
            scope=Scope.from_yaml(scope_file or resolved.scope_file),
            guard=Guard.from_yaml(policy_file or resolved.policy_file),
            audit=AuditLog(audit_path or resolved.audit_path, fsync=fsync),
            attestation=attestation,
            org=org,
            actor=actor,
            per_host_rps=(
                resolved.safety_per_host_requests_per_second
                if per_host_rps is None
                else per_host_rps
            ),
            max_concurrency=(
                resolved.safety_max_concurrent_jobs
                if max_concurrency is None
                else max_concurrency
            ),
            timeout_s=(
                float(resolved.safety_job_timeout_s) if timeout_s is None else timeout_s
            ),
            killswitch=KillSwitch(
                killswitch_path or resolved.killswitch_path
            ),
        )

    @classmethod
    def for_lab_demo(
        cls,
        audit: AuditLog,
        *,
        host: str = "127.0.0.1",
        port: int = 8000,
        extra_ports: tuple[int, ...] = (8080,),
        policy_file: str | Path | None = None,
        killswitch_path: str | Path | None = None,
    ) -> "ScanSession":
        """The offline lab preset used by the landing-page capture and its tests.

        The chain exactly as the demo has always built it - loopback only, one
        host, two ports, a 30-day attestation, 20 rps, two workers - moved here
        unchanged, so the capture script no longer owns a second copy of it.
        ``web/captures/demo-captures.json`` must still reproduce byte for byte,
        which is what ``web/verify_page.py`` checks.
        """
        scope = Scope(
            allow_hosts=[host],
            allow_ports=[port, *extra_ports],
            allow_loopback=True,
            label="demo-lab",
        )
        return cls(
            scope=scope,
            guard=Guard.from_yaml(policy_file or (CONFIG_DIR / "policy.yaml")),
            audit=audit,
            attestation=make_attestation(
                organization=LAB_ORG,
                subject=LAB_SUBJECT,
                target=host,
                reference="DEMO-ATT-0001",
                scope=scope,
                signed_text=LAB_STATEMENT,
                verification=VerificationMethod.MANUAL_REVIEW,
                valid_for=timedelta(days=30),
            ),
            org=LAB_ORG,
            actor=LAB_ACTOR,
            per_host_rps=20.0,
            max_concurrency=2,
            timeout_s=180.0,
            killswitch=KillSwitch(killswitch_path),
        )
