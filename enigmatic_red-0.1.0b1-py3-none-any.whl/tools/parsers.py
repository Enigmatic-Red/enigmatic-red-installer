"""Parsers for the output of tools we run.

Tool output is attacker-influenced: a service banner, an HTTP title, a template
name, all come from the target. Everything here therefore treats its input as
untrusted bytes — no ``eval``, no entity expansion, no unbounded structures —
and returns plain frozen dataclasses that later stages can trust.

Eight tools so far: nmap XML (``-oX``), nuclei JSONL (``-jsonl``), httpx JSONL
(``-json``), subfinder JSONL (``-json``), dnsx JSONL (``-json``), whatweb brief
text, gobuster text and ffuf JSON. Each shape below was checked against the
installed binary's own output, and the fixtures in ``tests/test_parsers.py`` are
that output rather than a guess at it. A parser never raises on *content*; it raises only when the document
is so malformed that nothing can be recovered, because a half-written file from a
killed process is normal and the partial result is still evidence.
"""

from __future__ import annotations

import base64
import binascii
import json
import re
import xml.etree.ElementTree as ElementTree
from dataclasses import dataclass, field
from typing import Any, Iterator, Mapping, Sequence
from urllib.parse import urlsplit

from safety.errors import ToolExecutionError

__all__ = [
    "NMAP_DOCTYPE",
    "DnsxRecord",
    "FfufHit",
    "GobusterHit",
    "HttpxResult",
    "NucleiFinding",
    "NmapScan",
    "NmapHost",
    "Service",
    "SubfinderHost",
    "WhatwebPlugin",
    "WhatwebResult",
    "extract_host",
    "iter_httpx_jsonl",
    "iter_nuclei_jsonl",
    "iter_subfinder_jsonl",
    "parse_dnsx_jsonl",
    "parse_ffuf_json",
    "parse_gobuster_text",
    "parse_httpx_jsonl",
    "parse_nmap_xml",
    "parse_nuclei_jsonl",
    "parse_subfinder_jsonl",
    "parse_whatweb_brief",
]

#: The only DTD nmap emits. Anything else is refused rather than parsed.
NMAP_DOCTYPE = "<!DOCTYPE nmaprun>"

SEVERITIES = ("info", "low", "medium", "high", "critical", "unknown")

#: Ports that must never be reported as a plain "open service" finding: their
#: exposure is a different class of problem and gets its own treatment later.
SENSITIVE_PORTS: frozenset[int] = frozenset(
    {22, 23, 1433, 1521, 2375, 3306, 5432, 5900, 6379, 9200, 11211, 27017}
)


@dataclass(frozen=True)
class Service:
    """One service as nmap reported it."""

    port: int
    protocol: str = "tcp"
    state: str = "open"
    name: str = ""
    product: str = ""
    version: str = ""
    extra_info: str = ""
    tunnel: str = ""
    cpe: tuple[str, ...] = ()

    @property
    def label(self) -> str:
        """``443/tcp https nginx 1.24.0`` — the way an operator reads it."""
        parts = [f"{self.port}/{self.protocol}", self.name or "unknown"]
        if self.product:
            parts.append(f"{self.product} {self.version}".strip())
        return " ".join(part for part in parts if part)

    @property
    def needs_attention(self) -> bool:
        """True for ports whose mere reachability is worth a finding."""
        return self.port in SENSITIVE_PORTS and self.state == "open"

    def describe(self) -> dict[str, Any]:
        return {
            "port": self.port,
            "protocol": self.protocol,
            "state": self.state,
            "name": self.name,
            "product": self.product,
            "version": self.version,
            "tunnel": self.tunnel,
            "cpe": list(self.cpe),
        }


@dataclass(frozen=True)
class NmapHost:
    """One host from an nmap run, with whatever it could name it by."""

    address: str
    hostname: str = ""
    state: str = "up"
    services: tuple[Service, ...] = ()

    @property
    def open_services(self) -> tuple[Service, ...]:
        return tuple(svc for svc in self.services if svc.state == "open")

    @property
    def display(self) -> str:
        return self.hostname or self.address

    def describe(self) -> dict[str, Any]:
        return {
            "address": self.address,
            "hostname": self.hostname,
            "state": self.state,
            "open_ports": [svc.port for svc in self.open_services],
        }


@dataclass(frozen=True)
class NmapScan:
    """A whole nmap document."""

    hosts: tuple[NmapHost, ...] = ()
    command: str = ""
    scanner: str = ""
    version: str = ""
    started: str = ""
    finished: str = ""
    elapsed_s: float = 0.0
    extra_ports: tuple[Service, ...] = ()

    @property
    def open_services(self) -> tuple[Service, ...]:
        return tuple(svc for host in self.hosts for svc in host.open_services)

    @property
    def sensitive_services(self) -> tuple[Service, ...]:
        return tuple(svc for svc in self.open_services if svc.needs_attention)

    def describe(self) -> dict[str, Any]:
        return {
            "hosts": len(self.hosts),
            "up_hosts": sum(1 for host in self.hosts if host.state == "up"),
            "open_services": len(self.open_services),
            "sensitive_services": [svc.label for svc in self.sensitive_services],
            "elapsed_s": self.elapsed_s,
        }


@dataclass(frozen=True)
class NucleiFinding:
    """One nuclei template match (one JSONL line)."""

    template_id: str
    name: str = ""
    severity: str = "unknown"
    matched_at: str = ""
    host: str = ""
    type: str = ""
    matcher_name: str = ""
    tags: tuple[str, ...] = ()
    description: str = ""
    reference: tuple[str, ...] = ()
    extracted: tuple[str, ...] = ()
    curl_command: str = ""
    ip: str = ""
    timestamp: str = ""
    raw: dict[str, Any] = field(default_factory=dict)

    @property
    def hostname(self) -> str:
        return extract_host(self.host or self.matched_at)

    def describe(self) -> dict[str, Any]:
        return {
            "template_id": self.template_id,
            "name": self.name,
            "severity": self.severity,
            "host": self.hostname,
            "matched_at": self.matched_at,
            "tags": list(self.tags),
        }


# --------------------------------------------------------------------- helpers
def extract_host(value: str) -> str:
    """Hostname (or bare address) out of a URL, ``host:port`` or plain host."""
    text = (value or "").strip()
    if not text:
        return ""
    if "//" in text:
        candidate = urlsplit(text).hostname or ""
        return candidate.lower()
    if "://" not in text and text.count(":") == 1:
        head, _, tail = text.partition(":")
        if tail.isdigit() and head:
            return head.lower()
    return text.strip("[]").strip("<>").lower()


def _as_tuple(value: Any) -> tuple[str, ...]:
    """Normalize nuclei's ``tags``/``reference``, which are str *or* list."""
    if not value:
        return ()
    if isinstance(value, str):
        return tuple(part.strip() for part in value.split(",") if part.strip())
    if isinstance(value, (list, tuple, set, frozenset)):
        return tuple(str(item).strip() for item in value if str(item).strip())
    return (str(value),)


def _safe_xml_root(text: str) -> ElementTree.Element:
    """Parse XML with entity expansion refused.

    A target influences banner text, which lands inside the XML nmap writes.
    Refusing ``<!ENTITY`` removes the entity-expansion class outright while
    still accepting the ``<!DOCTYPE nmaprun>`` that nmap legitimately emits.
    """
    if not text or not text.strip():
        raise ToolExecutionError("no nmap output to parse")
    if "<!entity" in text.lower():
        raise ToolExecutionError(
            "refusing to parse nmap output containing an entity declaration"
        )
    try:
        return ElementTree.fromstring(text)
    except ElementTree.ParseError as exc:
        raise ToolExecutionError(f"nmap output is not parseable XML: {exc}") from exc


# ------------------------------------------------------------------------ nmap
def _service_from_port(port_element: ElementTree.Element) -> Service | None:
    """Build a :class:`Service`, or ``None`` when there is nothing to report."""
    raw_port = port_element.get("portid") or ""
    if not raw_port.isdigit():
        return None
    state_element = port_element.find("state")
    state = (state_element.get("state") if state_element is not None else "") or ""
    service_element = port_element.find("service")
    if service_element is None and state != "open":
        return None  # a closed port with no identifying data is noise
    service_element = service_element if service_element is not None else port_element
    service = Service(
        port=int(raw_port),
        protocol=(port_element.get("protocol") or "tcp").lower(),
        state=state or "open",
        name=(service_element.get("name") or "").lower(),
        product=service_element.get("product") or "",
        version=service_element.get("version") or "",
        extra_info=service_element.get("extrainfo") or "",
        tunnel=(service_element.get("tunnel") or "").lower(),
        cpe=tuple(
            (cpe.text or "").strip()
            for cpe in port_element.findall("service/cpe")
            if (cpe.text or "").strip()
        ),
    )
    return service


def _host_from_element(host_element: ElementTree.Element) -> NmapHost:
    status = host_element.find("status")
    state = (status.get("state") if status is not None else "") or "unknown"

    addresses = host_element.findall("address")
    address = ""
    for addrtype in ("ipv4", "ipv6"):
        for element in addresses:
            if (element.get("addrtype") or "") == addrtype:
                address = element.get("addr") or ""
                break
        if address:
            break
    if not address and addresses:
        address = addresses[0].get("addr") or ""

    hostname = ""
    hostname_element = host_element.find("hostnames/hostname")
    if hostname_element is not None:
        hostname = (hostname_element.get("name") or "").strip()

    services: list[Service] = []
    for port_element in host_element.findall("ports/port"):
        service = _service_from_port(port_element)
        if service is not None:
            services.append(service)

    return NmapHost(
        address=address,
        hostname=hostname,
        state=state,
        services=tuple(services),
    )


def parse_nmap_xml(text: str) -> NmapScan:
    """Parse ``nmap -oX`` output. Raises only when nothing is recoverable."""
    root = _safe_xml_root(text)
    if root.tag != "nmaprun":
        raise ToolExecutionError(
            f"not an nmap document: root element is {root.tag!r}, expected 'nmaprun'"
        )

    finished = root.find("runstats/finished")
    elapsed = 0.0
    if finished is not None:
        raw_elapsed = (finished.get("elapsed") or "").strip()
        try:
            elapsed = float(raw_elapsed)
        except ValueError:
            elapsed = 0.0

    extra_ports: list[Service] = []
    for port_element in root.findall("ports/port"):
        service = _service_from_port(port_element)
        if service is not None:
            extra_ports.append(service)

    return NmapScan(
        hosts=tuple(_host_from_element(element) for element in root.findall("host")),
        command=root.get("args") or "",
        scanner=root.get("scanner") or "nmap",
        version=root.get("version") or "",
        started=root.get("startstr") or root.get("start") or "",
        finished=(finished.get("timestr") if finished is not None else "") or "",
        elapsed_s=elapsed,
        extra_ports=tuple(extra_ports),
    )


# ---------------------------------------------------------------------- nuclei
def _severity(payload: dict[str, Any]) -> str:
    info = payload.get("info")
    raw = ""
    if isinstance(info, dict):
        raw = str(info.get("severity") or "")
    raw = (raw or str(payload.get("severity") or "unknown")).strip().lower()
    return raw if raw in SEVERITIES else "unknown"


def _finding_from_payload(payload: dict[str, Any]) -> NucleiFinding:
    info = payload.get("info") if isinstance(payload.get("info"), dict) else {}
    return NucleiFinding(
        template_id=str(
            payload.get("template-id")
            or payload.get("template_id")
            or payload.get("templateID")
            or ""
        ),
        name=str(info.get("name") or payload.get("name") or ""),
        severity=_severity(payload),
        matched_at=str(payload.get("matched-at") or payload.get("matched_at") or ""),
        host=str(payload.get("host") or ""),
        type=str(payload.get("type") or ""),
        matcher_name=str(
            payload.get("matcher-name") or payload.get("matcher_name") or ""
        ),
        tags=_as_tuple(info.get("tags") or payload.get("tags")),
        description=str(info.get("description") or ""),
        reference=_as_tuple(info.get("reference") or payload.get("reference")),
        extracted=_as_tuple(
            payload.get("extracted-results") or payload.get("extracted_results")
        ),
        curl_command=str(payload.get("curl-command") or payload.get("curl_command") or ""),
        ip=str(payload.get("ip") or ""),
        timestamp=str(payload.get("timestamp") or ""),
        raw=payload,
    )


def iter_nuclei_jsonl(text: str) -> Iterator[NucleiFinding]:
    """Yield findings from ``nuclei -jsonl`` output, one per line.

    Lines that are not JSON objects are skipped rather than fatal: nuclei writes
    to a pipe, so a banner line, a progress line and a final line cut in half by
    our own output cap are all normal.
    """
    for line in (text or "").splitlines():
        stripped = line.strip()
        if not stripped or stripped[0] not in "{[":
            continue
        try:
            payload = json.loads(stripped)
        except json.JSONDecodeError:
            continue
        if isinstance(payload, dict):
            finding = _finding_from_payload(payload)
            if finding.template_id or finding.matched_at:
                yield finding


def parse_nuclei_jsonl(text: str) -> list[NucleiFinding]:
    """Parse nuclei output, accepting both JSONL and a single JSON array."""
    stripped = (text or "").strip()
    if stripped.startswith("["):
        try:
            payload = json.loads(stripped)
        except json.JSONDecodeError:
            payload = None
        if isinstance(payload, list):
            return [
                _finding_from_payload(entry)
                for entry in payload
                if isinstance(entry, dict)
            ]
    return list(iter_nuclei_jsonl(text))


# ----------------------------------------------------------------------- httpx
#: httpx prints ``time`` as a Go duration: ``96.2607ms``, ``1.002s``, ``1m2s``.
_DURATION_UNITS = {
    "ns": 0.000001,
    "us": 0.001,
    "µs": 0.001,
    "ms": 1.0,
    "s": 1000.0,
    "m": 60000.0,
    "h": 3600000.0,
}
_DURATION = re.compile(r"([0-9]+(?:\.[0-9]+)?)(ns|us|µs|ms|s|m|h)")


def _duration_ms(value: Any) -> float:
    """Milliseconds out of httpx's duration string, e.g. ``96.2607ms``."""
    text = str(value if value is not None else "").strip()
    if not text:
        return 0.0
    parts = _DURATION.findall(text)
    if parts:
        return round(
            sum(float(count) * _DURATION_UNITS[unit] for count, unit in parts), 3
        )
    try:
        return round(float(text) * 1000.0, 3)  # a bare number is read as seconds
    except ValueError:
        return 0.0


def _as_count(value: Any) -> int:
    """An integer field httpx may print as a number or as a string."""
    if isinstance(value, bool) or not isinstance(value, (int, float, str)):
        return 0
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return 0


@dataclass(frozen=True)
class HttpxResult:
    """What one httpx probe said: one JSONL object, for one URL.

    ``input`` is what we asked for and ``url`` is what answered, and they differ
    whenever httpx followed a redirect or fell back from https to http - which is
    the difference between the report saying what was probed and what was found.
    """

    url: str
    input: str = ""
    status_code: int = 0
    title: str = ""
    webserver: str = ""
    content_type: str = ""
    content_length: int = 0
    method: str = ""
    scheme: str = ""
    host: str = ""
    port: str = ""
    path: str = ""
    tech: tuple[str, ...] = ()
    cpe: tuple[str, ...] = ()
    ips: tuple[str, ...] = ()
    words: int = 0
    lines: int = 0
    time_ms: float = 0.0
    failed: bool = False
    timestamp: str = ""
    raw: dict[str, Any] = field(default_factory=dict)

    @property
    def hostname(self) -> str:
        """The host this probe was about, whatever shape httpx printed it in."""
        return extract_host(self.host or self.url or self.input)

    @property
    def responding(self) -> bool:
        """True when something answered: a status code was actually read."""
        return not self.failed and self.status_code > 0

    @property
    def label(self) -> str:
        """``https://app.example.com/ [200] nginx`` — how an operator reads it."""
        parts = [self.url or self.input, f"[{self.status_code}]", self.webserver]
        return " ".join(part for part in parts if part)

    def describe(self) -> dict[str, Any]:
        """The stable subset the report and the audit trail may quote."""
        return {
            "url": self.url,
            "input": self.input,
            "status_code": self.status_code,
            "title": self.title,
            "webserver": self.webserver,
            "host": self.hostname,
            "port": self.port,
            "tech": list(self.tech),
            "content_length": self.content_length,
            "time_ms": self.time_ms,
        }



def _httpx_result_from_payload(payload: dict[str, Any]) -> HttpxResult:
    """Build an :class:`HttpxResult` from one decoded JSON object."""
    cpe = tuple(
        str(entry.get("cpe"))
        for entry in payload.get("cpe") or []
        if isinstance(entry, dict) and entry.get("cpe")
    )
    return HttpxResult(
        url=str(payload.get("url") or payload.get("input") or ""),
        input=str(payload.get("input") or ""),
        status_code=_as_count(payload.get("status_code")),
        title=str(payload.get("title") or ""),
        webserver=str(payload.get("webserver") or payload.get("server") or ""),
        content_type=str(payload.get("content_type") or ""),
        content_length=_as_count(payload.get("content_length")),
        method=str(payload.get("method") or ""),
        scheme=str(payload.get("scheme") or ""),
        host=str(payload.get("host") or ""),
        port=str(payload.get("port") or ""),
        path=str(payload.get("path") or ""),
        tech=_as_tuple(payload.get("tech")),
        cpe=cpe,
        ips=_as_tuple(payload.get("a")),
        words=_as_count(payload.get("words")),
        lines=_as_count(payload.get("lines")),
        time_ms=_duration_ms(payload.get("time")),
        failed=bool(payload.get("failed")),
        timestamp=str(payload.get("timestamp") or ""),
        raw=payload,
    )


def iter_httpx_jsonl(text: str) -> Iterator[HttpxResult]:
    """Yield results from ``httpx -json`` output, one per line.

    Same contract as the nuclei reader: a line that is not a JSON object is
    skipped rather than fatal, because httpx writes to a pipe and our own output
    cap can cut the last line in half. A line with neither a ``url`` nor an
    ``input`` is not a probe result and is skipped too.
    """
    for line in (text or "").splitlines():
        stripped = line.strip()
        if not stripped or stripped[0] not in "{[":
            continue
        try:
            payload = json.loads(stripped)
        except json.JSONDecodeError:
            continue
        if isinstance(payload, dict):
            result = _httpx_result_from_payload(payload)
            if result.url or result.input:
                yield result


def parse_httpx_jsonl(text: str) -> list[HttpxResult]:
    """Parse httpx output, accepting both JSONL and a single JSON array."""
    stripped = (text or "").strip()
    if stripped.startswith("["):
        try:
            payload = json.loads(stripped)
        except json.JSONDecodeError:
            payload = None
        if isinstance(payload, list):
            return [
                _httpx_result_from_payload(entry)
                for entry in payload
                if isinstance(entry, dict)
            ]
    return list(iter_httpx_jsonl(text))


# ------------------------------------------------------------------- subfinder
@dataclass(frozen=True)
class SubfinderHost:
    """One host subfinder reported: one JSONL line of ``subfinder -json``.

    ``input`` is the domain that was asked about and ``host`` is a name that
    answers under it, so a report can say which seed a name came from. ``-cs``
    changes ``source`` (a string) into ``sources`` (a list) - both are kept
    apart and read through :attr:`named_by`, so a run is evidence either way.
    """

    host: str
    input: str = ""
    source: str = ""
    sources: tuple[str, ...] = ()
    ips: tuple[str, ...] = ()
    raw: dict[str, Any] = field(default_factory=dict)

    @property
    def hostname(self) -> str:
        """The name, lower-cased and stripped of any port or scheme."""
        return extract_host(self.host)

    @property
    def named_by(self) -> tuple[str, ...]:
        """Every passive source that named this host, whichever shape printed."""
        if self.sources:
            return self.sources
        return (self.source,) if self.source else ()

    def describe(self) -> dict[str, Any]:
        return {
            "host": self.hostname,
            "input": self.input,
            "sources": list(self.named_by),
            "ips": list(self.ips),
        }


def _subfinder_host_from_payload(payload: dict[str, Any]) -> SubfinderHost:
    """Build a :class:`SubfinderHost` from one decoded JSON object."""
    return SubfinderHost(
        host=str(payload.get("host") or payload.get("input") or ""),
        input=str(payload.get("input") or ""),
        source=str(payload.get("source") or ""),
        sources=_as_tuple(payload.get("sources")),
        #: ``-oI`` prints one address; a later schema may print a list.
        ips=_as_tuple(payload.get("ip") or payload.get("ips")),
        raw=payload,
    )


def iter_subfinder_jsonl(text: str) -> Iterator[SubfinderHost]:
    """Yield hosts from ``subfinder -json`` output, one per line.

    Same contract as the other readers: a line that is not a JSON object is
    skipped rather than fatal, and a line with no host at all is not a result.
    """
    for line in (text or "").splitlines():
        stripped = line.strip()
        if not stripped or stripped[0] not in "{[":
            continue
        try:
            payload = json.loads(stripped)
        except json.JSONDecodeError:
            continue
        if isinstance(payload, dict):
            host = _subfinder_host_from_payload(payload)
            if host.host:
                yield host


def parse_subfinder_jsonl(text: str) -> list[SubfinderHost]:
    """Parse subfinder output, accepting both JSONL and a single JSON array."""
    stripped = (text or "").strip()
    if stripped.startswith("["):
        try:
            payload = json.loads(stripped)
        except json.JSONDecodeError:
            payload = None
        if isinstance(payload, list):
            return [
                _subfinder_host_from_payload(entry)
                for entry in payload
                if isinstance(entry, dict)
            ]
    return list(iter_subfinder_jsonl(text))


# ------------------------------------------------------------------------ dnsx
@dataclass(frozen=True)
class DnsxRecord:
    """What one name resolved to: one JSONL line of ``dnsx -json``.

    dnsx prints only the record types it was asked for, so every field below is
    empty unless that query type was requested. ``records`` is dnsx's own
    ``all`` list - the raw zone lines - and is kept verbatim because it is the
    primary evidence; the typed fields are the reading of it.
    """

    host: str
    status_code: str = ""
    resolver: tuple[str, ...] = ()
    ttl: int = 0
    addresses: tuple[str, ...] = ()
    ipv6: tuple[str, ...] = ()
    cname: tuple[str, ...] = ()
    ns: tuple[str, ...] = ()
    mx: tuple[str, ...] = ()
    txt: tuple[str, ...] = ()
    soa: tuple[str, ...] = ()
    srv: tuple[str, ...] = ()
    ptr: tuple[str, ...] = ()
    caa: tuple[str, ...] = ()
    records: tuple[str, ...] = ()
    response: str = ""
    query_time_ms: float = 0.0
    timestamp: str = ""
    raw: dict[str, Any] = field(default_factory=dict)

    @property
    def hostname(self) -> str:
        return extract_host(self.host)

    @property
    def resolved(self) -> bool:
        """True when a record came back: ``NOERROR`` alone is not an answer."""
        return bool(
            self.addresses
            or self.ipv6
            or self.cname
            or self.ns
            or self.mx
            or self.txt
            or self.soa
            or self.srv
            or self.ptr
            or self.caa
            or self.records
        )

    @property
    def answer_type(self) -> str:
        """The first record type this answer actually carries, e.g. ``A``."""
        for name, values in (
            ("A", self.addresses),
            ("AAAA", self.ipv6),
            ("CNAME", self.cname),
            ("NS", self.ns),
            ("MX", self.mx),
            ("TXT", self.txt),
            ("SOA", self.soa),
            ("SRV", self.srv),
            ("PTR", self.ptr),
            ("CAA", self.caa),
        ):
            if values:
                return name
        return ""

    def describe(self) -> dict[str, Any]:
        return {
            "host": self.hostname,
            "status_code": self.status_code,
            "resolved": self.resolved,
            "answer_type": self.answer_type,
            "addresses": list(self.addresses),
            "cname": list(self.cname),
            "query_time_ms": self.query_time_ms,
        }


def _dnsx_record_from_payload(payload: dict[str, Any]) -> DnsxRecord:
    """Build a :class:`DnsxRecord` from one decoded JSON object."""
    return DnsxRecord(
        host=str(payload.get("host") or ""),
        status_code=str(payload.get("status_code") or payload.get("rcode") or ""),
        resolver=_as_tuple(payload.get("resolver")),
        ttl=_as_count(payload.get("ttl")),
        addresses=_as_tuple(payload.get("a")),
        ipv6=_as_tuple(payload.get("aaaa")),
        cname=_as_tuple(payload.get("cname")),
        ns=_as_tuple(payload.get("ns")),
        mx=_as_tuple(payload.get("mx")),
        txt=_as_tuple(payload.get("txt")),
        soa=_as_tuple(payload.get("soa")),
        srv=_as_tuple(payload.get("srv")),
        ptr=_as_tuple(payload.get("ptr")),
        caa=_as_tuple(payload.get("caa")),
        records=_as_tuple(payload.get("all")),
        response=str(payload.get("raw") or payload.get("response") or ""),
        #: dnsx prints this as a Go duration - ``9ms``.
        query_time_ms=_duration_ms(
            payload.get("query-time") or payload.get("query_time")
        ),
        timestamp=str(payload.get("timestamp") or ""),
        raw=payload,
    )


def parse_dnsx_jsonl(text: str) -> list[DnsxRecord]:
    """Parse dnsx output, accepting both JSONL and a single JSON array."""
    stripped = (text or "").strip()
    if stripped.startswith("["):
        try:
            payload = json.loads(stripped)
        except json.JSONDecodeError:
            payload = None
        if isinstance(payload, list):
            return [
                _dnsx_record_from_payload(entry)
                for entry in payload
                if isinstance(entry, dict)
            ]
    records: list[DnsxRecord] = []
    for line in (text or "").splitlines():
        candidate = line.strip()
        if not candidate or candidate[0] not in "{[":
            continue
        try:
            payload = json.loads(candidate)
        except json.JSONDecodeError:
            continue
        if isinstance(payload, dict) and payload.get("host"):
            records.append(_dnsx_record_from_payload(payload))
    return records


# --------------------------------------------------------------------- whatweb
#: whatweb's brief line: ``http://example.com [200 OK] Plugin[cue], ...``.
#: A numeric status is what makes a line a result, so the error lines whatweb
#: prints for an unreachable target are not mistaken for a fingerprint.
_WHATWEB_LINE = re.compile(
    r"^(?P<target>\S+)\s+\[(?P<code>[0-9]{3})(?P<phrase>[^\]]*)\]"
    r"(?:\s+(?P<cues>.*))?$"
)
#: One plugin cue, with every bracket value it printed (``Apache[a][b]``).
_WHATWEB_PLUGIN = re.compile(
    r"(?P<name>[A-Za-z][A-Za-z0-9_+.-]*)(?P<values>(?:\[[^\]]*\])+)"
)
_BRACKET = re.compile(r"\[([^\]]*)\]")
#: A plugin whatweb printed with no cue at all, e.g. ``HTML5`` or ``Script``.
_WHATWEB_BARE = re.compile(r"[A-Za-z][A-Za-z0-9_+.-]*")
_VERSION = re.compile(r"[0-9]+(?:\.[0-9]+)+[A-Za-z0-9._-]*")
#: Plugins whose cue is a name, a country or an address - never a version.
_WHATWEB_NO_VERSION = frozenset({"Country", "IP", "Title", "MD5", "Email"})


@dataclass(frozen=True)
class WhatwebPlugin:
    """One plugin whatweb matched, and the cue text it matched on."""

    name: str
    cues: tuple[str, ...] = ()
    version: str = ""

    def describe(self) -> dict[str, Any]:
        return {"name": self.name, "version": self.version, "cues": list(self.cues)}


@dataclass(frozen=True)
class WhatwebResult:
    """One fingerprinted target: one brief line of ``whatweb`` output.

    ``plugins`` is the whole fingerprint, in the order whatweb printed it. The
    convenience properties below read it rather than re-deriving anything, so a
    reader can always go back from a reported title to the cue it came from.
    """

    target: str
    status_code: int = 0
    phrase: str = ""
    plugins: tuple[WhatwebPlugin, ...] = ()

    @property
    def hostname(self) -> str:
        return extract_host(self.target)

    def _cues(self, *names: str) -> tuple[str, ...]:
        wanted = {name.lower() for name in names}
        out: list[str] = []
        for plugin in self.plugins:
            if plugin.name.lower() in wanted:
                out.extend(plugin.cues)
        return tuple(out)

    @property
    def technologies(self) -> tuple[str, ...]:
        return tuple(plugin.name for plugin in self.plugins)

    @property
    def title(self) -> str:
        cues = self._cues("Title")
        return cues[0] if cues else ""

    @property
    def webserver(self) -> str:
        """As printed - ``nginx/1.24.0`` - because the version is the point."""
        cues = self._cues("HTTPServer", "WebServer")
        return cues[0] if cues else ""

    @property
    def addresses(self) -> tuple[str, ...]:
        return self._cues("IP")

    def describe(self) -> dict[str, Any]:
        return {
            "target": self.target,
            "host": self.hostname,
            "status_code": self.status_code,
            "title": self.title,
            "webserver": self.webserver,
            "technologies": list(self.technologies),
        }


def _whatweb_plugin_from_match(match: re.Match[str]) -> WhatwebPlugin:
    """Read one ``Name[value][value]`` cue into a plugin."""
    name = match.group("name")
    cues = tuple(_BRACKET.findall(match.group("values")))
    version = ""
    if name not in _WHATWEB_NO_VERSION:
        for cue in cues:
            found = _VERSION.search(cue)
            if found:
                version = found.group(0)
                break
    return WhatwebPlugin(name=name, cues=cues, version=version)


def _split_cues(text: str) -> list[str]:
    """Split a brief line's cue list on the commas *between* plugins.

    A cue value may itself contain a comma - ``Title[Example Domain, Inc.]`` -
    so a plain ``split(",")`` would cut a plugin in half. Brackets are the only
    grouping whatweb prints and they do not nest, so bracket depth is enough.
    """
    parts: list[str] = []
    current: list[str] = []
    depth = 0
    for char in text:
        if char == "[":
            depth += 1
        elif char == "]":
            depth = max(0, depth - 1)
        if char == "," and depth == 0:
            parts.append("".join(current))
            current = []
            continue
        current.append(char)
    parts.append("".join(current))
    return [part.strip() for part in parts if part.strip()]


def parse_whatweb_brief(text: str) -> list[WhatwebResult]:
    """Parse ``whatweb`` brief output; a line with no status is not a result."""
    out: list[WhatwebResult] = []
    for line in (text or "").splitlines():
        match = _WHATWEB_LINE.match(line.strip())
        if match is None:
            continue
        plugins: list[WhatwebPlugin] = []
        for token in _split_cues(match.group("cues") or ""):
            found = _WHATWEB_PLUGIN.fullmatch(token)
            if found is not None:
                plugins.append(_whatweb_plugin_from_match(found))
                continue
            #: A plugin with no cue - ``HTML5``, ``Script``, ``Cookies`` - is
            #: still a name whatweb matched on, so it is a technology and not
            #: something to drop on the floor for having printed no brackets.
            if _WHATWEB_BARE.fullmatch(token) is not None:
                plugins.append(WhatwebPlugin(name=token))
        out.append(
            WhatwebResult(
                target=match.group("target"),
                status_code=int(match.group("code")),
                phrase=(match.group("phrase") or "").strip(),
                plugins=tuple(plugins),
            )
        )
    return out


# -------------------------------------------------------------------- gobuster
#: gobuster's result line: ``/admin               (Status: 200) [Size: 1234]``
#: The tail after the status is read separately because the optional fields
#: (size, then where a redirect pointed) are not always both printed.
_GOBUSTER_LINE = re.compile(
    r"^(?P<path>\S+)\s+\(Status:\s*(?P<code>[0-9]{3})\)(?P<tail>.*)$"
)
_GOBUSTER_SIZE = re.compile(r"\[Size:\s*(?P<size>[0-9]+)\]")
_GOBUSTER_REDIRECT = re.compile(r"\[-->\s*(?P<location>[^\]]*)\]")


@dataclass(frozen=True)
class GobusterHit:
    """One discovered path: one result line of ``gobuster dir``.

    gobuster prints its banner and its progress to the same stream as its
    results, so a line is taken only when it is shaped like a result. A target
    that answers ``200`` with an empty body is still a result, and a redirect
    keeps where it pointed - both are what makes the line worth a report.
    """

    path: str
    status_code: int = 0
    size: int = 0
    redirect: str = ""

    @property
    def hostname(self) -> str:
        return extract_host(self.path)

    def describe(self) -> dict[str, Any]:
        detail: dict[str, Any] = {
            "path": self.path,
            "status_code": self.status_code,
            "size": self.size,
        }
        if self.redirect:
            detail["redirect"] = self.redirect
        return detail


def parse_gobuster_text(text: str) -> list[GobusterHit]:
    """Parse ``gobuster`` output; anything not shaped like a result is skipped."""
    out: list[GobusterHit] = []
    for line in (text or "").splitlines():
        match = _GOBUSTER_LINE.match(line.strip())
        if match is None:
            continue
        tail = match.group("tail") or ""
        size = _GOBUSTER_SIZE.search(tail)
        location = _GOBUSTER_REDIRECT.search(tail)
        out.append(
            GobusterHit(
                path=match.group("path"),
                status_code=int(match.group("code")),
                size=int(size.group("size")) if size else 0,
                redirect=(location.group("location") or "").strip() if location else "",
            )
        )
    return out


# ------------------------------------------------------------------------ ffuf
#: ffuf reports its own timing in nanoseconds; this project talks in ms.
_NS_PER_MS = 1_000_000


@dataclass(frozen=True)
class FfufHit:
    """One matching response: one ``ffuf -json`` record.

    The keyword and the value that filled it are what make a hit reproducible,
    and ``-json`` base64-encodes every input value. :attr:`payload` decodes one
    that round-trips and keeps the original text when it does not, so nothing is
    ever guessed from a value that merely looks like base64.
    """

    url: str
    status_code: int = 0
    length: int = 0
    words: int = 0
    lines: int = 0
    content_type: str = ""
    redirect: str = ""
    inputs: tuple[tuple[str, str], ...] = ()
    duration_ms: float = 0.0
    position: int = 0
    host: str = ""
    raw: dict[str, Any] = field(default_factory=dict)

    @property
    def hostname(self) -> str:
        return extract_host(self.host or self.url)

    @property
    def payload(self) -> str:
        """The value that was filled into the keyword, decoded.

        ``ffuf -json`` records every input it knows, and ``FFUFHASH`` is one of
        them, so the keyword is looked for by name: taking the first key would
        report ffuf's own hash of the payload as the payload. A record that does
        not name the keyword falls back to the only input it has.
        """
        for key, value in self.inputs:
            if key.upper() == "FUZZ":
                return value
        return self.inputs[0][1] if self.inputs else ""

    def describe(self) -> dict[str, Any]:
        detail: dict[str, Any] = {
            "url": self.url,
            "host": self.hostname,
            "status_code": self.status_code,
            "length": self.length,
            "words": self.words,
            "lines": self.lines,
            "duration_ms": round(self.duration_ms, 3),
        }
        if self.inputs:
            detail["input"] = dict(self.inputs)
        return detail


def _b64_text(value: str) -> str:
    """Decode one of ffuf's input values, or keep it when it does not decode."""
    padded = value + "=" * (-len(value) % 4)
    try:
        decoded = base64.b64decode(padded, validate=True).decode("utf-8")
    except (binascii.Error, UnicodeDecodeError, ValueError):
        return value
    #: Only a value that re-encodes to exactly what ffuf printed is treated as
    #: encoded: every other string is its own plain text.
    if base64.b64encode(decoded.encode("utf-8")).decode("ascii") == padded:
        return decoded
    return value


def _ffuf_inputs(value: Any) -> tuple[tuple[str, str], ...]:
    if not isinstance(value, Mapping):
        return ()
    return tuple((str(key), _b64_text(str(raw))) for key, raw in value.items())


def _ffuf_hit_from_payload(payload: dict[str, Any]) -> FfufHit:
    """Build an :class:`FfufHit` from one decoded JSON object."""
    return FfufHit(
        url=str(payload.get("url") or ""),
        status_code=_as_count(payload.get("status")),
        length=_as_count(payload.get("length")),
        words=_as_count(payload.get("words")),
        lines=_as_count(payload.get("lines")),
        content_type=str(
            payload.get("content-type") or payload.get("content_type") or ""
        ),
        redirect=str(payload.get("redirectlocation") or payload.get("redirect") or ""),
        inputs=_ffuf_inputs(payload.get("input")),
        duration_ms=_as_count(payload.get("duration")) / _NS_PER_MS,
        position=_as_count(payload.get("position")),
        host=str(payload.get("host") or ""),
        raw=payload,
    )


def parse_ffuf_json(text: str) -> list[FfufHit]:
    """Parse ``ffuf -json`` output: JSONL, or one object holding ``results``.

    ``-json`` prints one record per line, which is what the adapter asks for;
    ``-o <file> -of json`` writes a single object wrapping a ``results`` array,
    which is accepted too so a capture made the other way still reads.
    """
    stripped = (text or "").strip()
    if stripped.startswith("{") and "\n" not in stripped:
        try:
            document = json.loads(stripped)
        except json.JSONDecodeError:
            document = None
        if isinstance(document, dict) and isinstance(document.get("results"), list):
            return [
                _ffuf_hit_from_payload(entry)
                for entry in document["results"]
                if isinstance(entry, dict)
            ]
    hits: list[FfufHit] = []
    for line in (text or "").splitlines():
        candidate = line.strip()
        if not candidate or candidate[0] != "{":
            continue
        try:
            payload = json.loads(candidate)
        except json.JSONDecodeError:
            continue
        if isinstance(payload, dict) and payload.get("url"):
            hits.append(_ffuf_hit_from_payload(payload))
    return hits
