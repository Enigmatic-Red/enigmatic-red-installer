"""subfinder adapter.

subfinder answers the first question recon asks about a name: what else is
registered under it? It is the one adapter here whose answers come from public
data rather than from the target - it asks certificate transparency logs,
threat-intel feeds and search indexes, not the customer's servers - which is why
the guard registers it `PASSIVE`: no packet of a subfinder run is addressed to
the target itself.

What the adapter fixes, and why:

* ``-json``: one JSON object per name on stdout, which is what the parser reads
  and what the audit entry hashes. ``-silent`` and ``-nc`` keep that stream
  strictly parsable - no banner, no progress meter, no ANSI escapes.
* ``-duc``: no update check, so a scan never reaches out on its own.
* ``-cs``: name the source for each host. A subdomain is a *lead* until it has
  been probed, and a report that says "found by crtsh" is measurable in a way
  that "found by subfinder" is not. The parser reads the list form and the
  single-source form both, because ``-cs`` changes one into the other.
* ``-rl`` / ``-t`` / ``-timeout`` are clamped (150 requests a second, 25
  threads, 60 seconds), because these are requests to *third parties*: a run
  that looks like a flood to them is a run that gets this whole class of tool
  rate-limited or blocked for everyone.
* the target travels as the value of ``-d`` and is refused when it starts with a
  dash, so it can never be read as an option.

Three families of flag stay refused even when a human has approved the action,
because the guard cannot see them in the finished command line and no approval
should exist for them. ``-d``/``-domain``/``-dl``/``-list``: the domain is the
one target the scope check saw, and a second domain set would be out of scope.
``-o``/``-output``: a name list written to local disk is a scan artifact this
build has no evidence store to keep honest. ``-config``/``-pc``/
``-provider-config``: a flag or provider config file names credentials and
sources the run must not read from disk. ``-r``/``-resolvers`` is refused as
well, because a resolver list decides who sees the run's queries, and ``-active``
because it stops being passive: it resolves names against the target's own
nameservers, which is a request the customer's SOC can see.
"""

from __future__ import annotations

import re
from typing import Any, Sequence

from safety.errors import ToolExecutionError
from tools.base import ToolAdapter, ToolContext, ToolResult
from tools.parsers import SubfinderHost, parse_subfinder_jsonl
from tools.runner import CommandResult

__all__ = [
    "BINARY",
    "RATE_LIMIT_CEILING",
    "SUBFINDER_REFUSED_FLAGS",
    "SubfinderAdapter",
    "THREADS_CEILING",
    "TIMEOUT_CEILING_S",
    "scan",
]

#: The scanner's executable, as it is spelled on ``PATH``.
BINARY = "subfinder"

#: A source name the way the tool spells it: ``crtsh``, ``anubis``,
#: ``dnsdumpster``. Kept to the shape of the real list, so a value can carry
#: neither a comma (which would add a second source) nor a leading dash (which
#: would turn a value into a flag).
_SOURCE = re.compile(r"^[a-z0-9][a-z0-9._-]*$")

#: Flags that would turn subfinder into something other than a passive lookup of
#: one scoped domain. Each carries its own sentence, because the refusal is what
#: an operator reads.
SUBFINDER_REFUSED_FLAGS: dict[str, str] = {
    "-d": "the domain is the scoped target; a second one would be out of scope",
    "-domain": "the domain is the scoped target; a second one would be out of scope",
    "-dl": "a domain list read from a file would bypass the scope check",
    "-list": "a domain list read from a file would bypass the scope check",
    "-o": "output would be written to local disk as a scan artifact",
    "-output": "output would be written to local disk as a scan artifact",
    "-oi": "the resolved addresses of a name are a probe's answer, not a lookup's",
    "-ip": "the resolved addresses of a name are a probe's answer, not a lookup's",
    "-config": "a config file would point the run at other sources and credentials",
    "-pc": "a provider config file carries credentials this run must not read",
    "-provider-config": (
        "a provider config file carries credentials this run must not read"
    ),
    "-r": "a resolver list decides who sees the run's queries",
    "-resolvers": "a resolver list decides who sees the run's queries",
    "-active": (
        "active enumeration resolves names against the target's own nameservers, "
        "which is a request the customer's SOC can see, not a passive lookup"
    ),
    "-rl": "the request rate is set by this adapter's own bound",
    "-rate-limit": "the request rate is set by this adapter's own bound",
    "-t": "the thread count is set by this adapter's own bound",
    "-timeout": "the per-source timeout is set by this adapter's own bound",
}

#: Bounds chosen so one run cannot look like a flood to the third-party sources
#: a passive lookup depends on.
THREADS_CEILING = 25
RATE_LIMIT_CEILING = 150
TIMEOUT_CEILING_S = 60


def _sources_argument(sources: Sequence[str]) -> str:
    """Validate ``-s`` / ``-es``; the list travels as one comma-joined value."""
    out: list[str] = []
    for value in sources:
        text = str(value).strip().lower()
        if not _SOURCE.match(text):
            raise ValueError(
                f"refusing an unparseable source name: {value!r}; a source is "
                "spelled the way `subfinder -ls` spells it, and contains no comma"
            )
        if text not in out:
            out.append(text)
    if not out:
        raise ValueError("no sources given to subfinder")
    return ",".join(out)


def _checked_extra_args(extra_args: Sequence[str]) -> list[str]:
    """Refuse the ``extra_args`` that would escape the controls; keep the rest.

    The guard classifies the finished command line, so most passthrough is
    already covered. These are the ones it *cannot* see: what the run reads as
    its input, where its output goes, and which service it asks.
    """
    out: list[str] = []
    for value in extra_args:
        text = str(value)
        flag = text.split("=", 1)[0].strip().lower()
        reason = SUBFINDER_REFUSED_FLAGS.get(flag)
        if reason:
            raise ValueError(f"refusing subfinder flag {flag!r}: {reason}")
        out.append(text)
    return out


class SubfinderAdapter(ToolAdapter):
    """``subfinder -json`` for one domain: the names registered under it."""

    name = "subfinder"

    def build_argv(
        self,
        target: str,
        *,
        sources: Sequence[str] = (),
        exclude_sources: Sequence[str] = (),
        all_sources: bool = False,
        threads: int = 20,
        rate_limit: int = 50,
        timeout_s: int = 30,
        extra_args: Sequence[str] = (),
    ) -> list[str]:
        """Build the argv.

        A bare run asks every source subfinder ships with, which is the point of
        the tool: the value of a passive lookup is that it collects what many
        public datasets already hold about one name.
        """
        target = str(target).strip()
        if not target:
            raise ValueError("no target given to subfinder")
        if target.startswith("-"):
            raise ValueError(f"refusing a target that looks like an option: {target!r}")

        argv = [BINARY, "-d", target, "-json", "-silent", "-nc", "-duc", "-cs"]
        if all_sources:
            argv.append("-all")
        if sources:
            argv += ["-s", _sources_argument(sources)]
        if exclude_sources:
            argv += ["-es", _sources_argument(exclude_sources)]
        argv += ["-t", str(self._bounded(threads, THREADS_CEILING))]
        argv += ["-rl", str(self._bounded(rate_limit, RATE_LIMIT_CEILING))]
        argv += ["-timeout", str(self._bounded(timeout_s, TIMEOUT_CEILING_S))]
        argv += _checked_extra_args(extra_args)
        return argv

    @staticmethod
    def _bounded(value: int, ceiling: int) -> int:
        """Clamp to ``1..ceiling``: plausible values in, plausible values out."""
        return max(1, min(ceiling, int(value)))

    def parse(self, command: CommandResult) -> tuple[SubfinderHost, ...]:
        hosts = tuple(parse_subfinder_jsonl(command.stdout))
        if hosts:
            return hosts
        if command.returncode != 0:
            raise ToolExecutionError(
                f"subfinder exited with rc {command.returncode} and reported no "
                "host, so the run could not be interpreted"
            )
        if command.stdout.strip():
            lines = len(command.stdout.splitlines())
            raise ToolExecutionError(
                "subfinder produced output but no host could be recovered "
                f"({lines} line(s), {len(command.stdout)} bytes); output is not "
                "subfinder JSONL"
            )
        # rc 0 with no output is subfinder answering the question: no passive
        # source holds a name under this domain. That is a finding about the
        # sources as much as about the target, and it is reported as such rather
        # than as a failure.
        return hosts

    def summarize(self, parsed: Any) -> dict[str, Any]:
        if not isinstance(parsed, tuple):
            return {}
        by_source: dict[str, int] = {}
        hosts: list[str] = []
        inputs: list[str] = []
        addressed: list[str] = []
        for host in parsed:
            name = host.hostname
            if name and name not in hosts:
                hosts.append(name)
            if host.input and host.input not in inputs:
                inputs.append(host.input)
            for address in host.ips:
                if address not in addressed:
                    addressed.append(address)
            for source in host.named_by or ("(unnamed)",):
                by_source[source] = by_source.get(source, 0) + 1
        return {
            "hosts_found": len(hosts),
            "hosts": hosts[:50],
            "inputs": inputs[:10],
            "by_source": dict(sorted(by_source.items())),
            "ip_count": len(addressed),
        }


def scan(target: str, context: ToolContext, **options: Any) -> ToolResult:
    """Convenience wrapper: ``scan(domain, context, all_sources=True)``."""
    return SubfinderAdapter().run(target, context, **options)
