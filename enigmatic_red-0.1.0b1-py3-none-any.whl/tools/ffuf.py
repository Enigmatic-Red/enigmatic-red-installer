"""ffuf adapter.

ffuf takes a keyword - ``FUZZ`` - and asks the same URL once for every line of a
list, reporting the requests whose response matched. It is the second discovery
capability here, and the more dangerous of the two: gobuster is a directory
brute-forcer with an opinionated shape, while ffuf will put the keyword anywhere
in the request, which is why every position it could reach except the path is
refused below.

What the adapter fixes, and why:

* ``-u <url>/FUZZ``: the keyword is placed in the path of the target this run was
  called with. ``-u`` is refused in passthrough, so that URL stays the one the
  scope check saw, and :func:`_keyword_url` refuses a target it cannot put a
  keyword in.
* ``-json -noninteractive``: one JSON object per line, which is what the parser
  reads, and no interactive console. The record carries the status, the lengths,
  the input value and the per-request duration, so a hit can be reproduced from
  the report rather than re-run.
* ``-mc``: the status codes that count as a match are the fixed list below and
  are refused in ``extra_args``. A run that could narrow its own match set could
  hide an answer, which is the same rule gobuster gets.
* ``-rate`` and ``-p``: a ceiling on requests per second and a floor on the delay
  between them, both owned by this adapter. Discovery at full speed is a load
  test on a customer's service, not a scan.
* ``-t`` (threads) and ``-timeout``: clamped, so passthrough cannot widen them.

Refused even with an approval behind them: ``-o``/``-of``/``-od`` write results
to local disk as a scan artifact; ``-w`` is the list this adapter validates;
``-H``/``-b``/``-X``/``-d`` put a header, a cookie, another method or a body into
the request, and this build does not send credentials or state-changing methods;
``-request``/``-request-proto`` read a whole request from a file;
``-input-cmd``/``-input-shell`` run a command to generate the payloads, which is
a shell this product does not spawn; ``-config`` reads options from a file;
``-x``/``-replay-proxy`` decide who else sees the requests; ``-recursion`` turns
one list into an unbounded walk; ``-k`` switches certificate verification off.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Sequence

from safety.errors import ToolExecutionError
from tools.base import ToolAdapter, ToolContext, ToolResult
from tools.parsers import FfufHit, parse_ffuf_json
from tools.runner import CommandResult
from tools.wordlist import BUILTIN_NAME, describe, path_for, path_from_argv

__all__ = [
    "BINARY",
    "DELAY_CEILING_S",
    "DELAY_DEFAULT_S",
    "DELAY_FLOOR_S",
    "FFUF_REFUSED_FLAGS",
    "KEYWORD",
    "MATCH_CODES",
    "RATE_CEILING",
    "RATE_DEFAULT",
    "THREADS_CEILING",
    "TIMEOUT_CEILING_S",
    "FfufAdapter",
    "FfufRun",
    "scan",
]

#: The scanner's executable, as it is spelled on ``PATH``.
BINARY = "ffuf"

#: The keyword ffuf replaces with each line of the list.
KEYWORD = "FUZZ"

#: The fixed match set: ffuf's own default. An answer outside it - a 404, a 500
#: of the kind every unmatched path gets - is not reported as a discovery.
MATCH_CODES = "200,204,301,302,307,401,403,405,500"

#: Bounds: one run must not look like a sweep. ffuf's own default thread count is
#: 40 and it has no rate limit at all, so both are set here rather than passed
#: through.
RATE_DEFAULT = 10
RATE_CEILING = 25
THREADS_CEILING = 10
TIMEOUT_CEILING_S = 30

#: A delay between requests, in seconds, with a floor. ffuf's default is none.
DELAY_DEFAULT_S = 0.1
DELAY_FLOOR_S = 0.1
DELAY_CEILING_S = 5.0

#: A duration an operator would write: ``250ms``, ``2s``, ``1.5s``, ``1m``.
_DURATION = re.compile(r"^(?P<value>[0-9]+(?:\.[0-9]+)?)(?P<unit>ms|s|m)$")
_UNIT_S = {"ms": 0.001, "s": 1.0, "m": 60.0}

#: Flags refused in ``extra_args`` even when the action was approved. Each
#: sentence says what the flag would change, because that is what an operator
#: needs to decide whether to ask again a different way.
FFUF_REFUSED_FLAGS: dict[str, str] = {
    "-o": "results would be written to local disk as a scan artifact",
    "-of": "results would be written to local disk as a scan artifact",
    "-od": "results would be written to local disk as a scan artifact",
    "-output": "results would be written to local disk as a scan artifact",
    "-w": "the word list is one this adapter validates, not one it is handed",
    "-wordlist": "the word list is one this adapter validates, not one it is handed",
    "-u": "the target is the one this adapter was called with",
    "-url": "the target is the one this adapter was called with",
    "-mc": "the matching status codes are fixed, so a run cannot hide an answer",
    "-fc": "a filter hides a matching answer from the report",
    "-fl": "a filter hides a matching answer from the report",
    "-fr": "a filter hides a matching answer from the report",
    "-fs": "a filter hides a matching answer from the report",
    "-fw": "a filter hides a matching answer from the report",
    "-ml": "a match rule narrows what counts as a hit",
    "-mr": "a match rule narrows what counts as a hit",
    "-ms": "a match rule narrows what counts as a hit",
    "-mt": "a match rule narrows what counts as a hit",
    "-H": "headers are not set by the plan: this build sends no credentials",
    "-header": "headers are not set by the plan: this build sends no credentials",
    "-b": "credentials are not handled by this build",
    "-cookie": "credentials are not handled by this build",
    "-X": (
        "the method is fixed, so a discovery run cannot become a state-changing "
        "request"
    ),
    "-method": (
        "the method is fixed, so a discovery run cannot become a state-changing "
        "request"
    ),
    "-d": "a request body is not sent by this build",
    "-data": "a request body is not sent by this build",
    "-request": "a whole request read from a file is one this adapter did not build",
    "-request-proto": (
        "a whole request read from a file is one this adapter did not build"
    ),
    "-input-cmd": "this product does not spawn a command to generate payloads",
    "-input-shell": "this product does not spawn a command to generate payloads",
    "-config": "options read from a file are options no approval saw",
    "-x": "the proxy decides who else sees the requests",
    "-proxy": "the proxy decides who else sees the requests",
    "-replay-proxy": "the replay proxy decides who else sees the requests",
    "-recursion": "recursion turns one list into an unbounded walk",
    "-recursion-depth": "recursion turns one list into an unbounded walk",
    "-recursion-strategy": "recursion turns one list into an unbounded walk",
    "-t": "the thread count is set by this adapter's own bound",
    "-threads": "the thread count is set by this adapter's own bound",
    "-rate": "the request rate is set by this adapter's own bound",
    "-p": "the delay between requests is set by this adapter's own bound",
    "-timeout": "the per-request timeout is set by this adapter's own bound",
    "-maxtime": "the run's overall bound is set by this adapter, not the plan",
    "-maxtime-job": "the run's overall bound is set by this adapter, not the plan",
    "-mode": "only the path is used here, so the mode is not the plan's",
    "-k": "certificate verification is not switched off by the plan",
    "-ignore-body": "a match is decided on the response, so the body is read",
    "-V": "version output is not a scan",
    "-v": "verbose output is not the record shape the parser reads",
    "-json": "the output format is fixed by this adapter",
    "-noninteractive": "the console mode is fixed by this adapter",
    "-s": "the output shape is fixed by this adapter",
    "-silent": "the output shape is fixed by this adapter",
}


def _checked_extra_args(extra_args: Sequence[str]) -> list[str]:
    """Refuse the ``extra_args`` that would escape the controls; keep the rest.

    ffuf parses flags with Go's own flag package, so an unknown flag is a
    non-zero exit and there is no silent-ignore hazard here: a refusal table is
    enough, and an allow-list would only stop a new ffuf from gaining flags.
    """
    out: list[str] = []
    for value in extra_args:
        text = str(value)
        # Looked up exactly first: ``-X`` (the method) and ``-x`` (the proxy) are
        # different flags, and ``-H`` is not ``-h``. Long flags are then tried
        # folded, since their case never means anything.
        flag = text.split("=", 1)[0].strip()
        reason = FFUF_REFUSED_FLAGS.get(flag) or FFUF_REFUSED_FLAGS.get(flag.lower())
        if reason:
            raise ValueError(f"refusing ffuf flag {flag!r}: {reason}")
        out.append(text)
    return out


def _delay_seconds(value: str | int | float) -> float:
    """Read a delay as seconds, and refuse one below the floor.

    Accepts what the adapter itself passes (a number of seconds) and what an
    operator would write (``250ms``, ``2s``). The floor is the point: ffuf has no
    delay of its own, and a discovery run with none is the loudest thing this
    product can do to a customer's service.
    """
    if isinstance(value, bool):
        raise ValueError("refusing a boolean delay")
    if isinstance(value, (int, float)):
        seconds = float(value)
    else:
        match = _DURATION.match(str(value).strip().lower())
        if match is None:
            raise ValueError(
                f"refusing the delay {value!r}: give a duration such as 250ms or 2s"
            )
        seconds = float(match.group("value")) * _UNIT_S[match.group("unit")]
    if seconds < DELAY_FLOOR_S:
        raise ValueError(
            f"refusing a delay of {seconds}s: it may be at least {DELAY_FLOOR_S}s, "
            "because discovery at full speed is a load test, not a scan"
        )
    return min(seconds, DELAY_CEILING_S)


def _format_delay(seconds: float) -> str:
    """The way ffuf is handed a delay: seconds, as a plain decimal."""
    return f"{seconds:.3f}".rstrip("0").rstrip(".") or "0"


def _keyword_url(target: str) -> str:
    """The URL this run is aimed at, with the keyword in its path.

    ffuf needs the keyword somewhere in the request, and the path is the only
    place this adapter puts it: a keyword in a header, a host name or a body
    would make the run a fuzzer pointed at something other than a URL's path.
    ``-u`` is refused in passthrough, so the URL built here is the one target the
    scope check saw, and ``-mode`` is refused so it cannot be filled elsewhere.
    """
    url = str(target).strip()
    if not url:
        raise ValueError("no target given to ffuf")
    if url.startswith("-"):
        raise ValueError(f"refusing a target that looks like an option: {url!r}")
    if "://" not in url:
        raise ValueError(
            f"refusing {url!r}: ffuf is given a URL with a scheme, e.g. "
            f"http://{url}/{KEYWORD}"
        )
    if KEYWORD in url:
        return url
    return f"{url.rstrip('/')}/{KEYWORD}"


@dataclass(frozen=True)
class FfufRun:
    """One ffuf run: the requests that matched, and the list that was asked.

    The list is part of the result rather than an implementation detail. How many
    requests a run makes is a fact about how loud it was, and the audit entry has
    to be able to state it, so the adapter does not throw away which file the run
    was pointed at.
    """

    hits: tuple[FfufHit, ...]
    wordlist: Path = Path("")

    def __iter__(self):
        return iter(self.hits)

    def __len__(self) -> int:
        return len(self.hits)

    @property
    def found(self) -> tuple[FfufHit, ...]:
        """The requests that matched, in the order ffuf reported them."""
        return self.hits


class FfufAdapter(ToolAdapter):
    """``ffuf`` against one URL: which paths under it answer, and how."""

    name = "ffuf"

    def build_argv(
        self,
        target: str,
        *,
        wordlist: str = BUILTIN_NAME,
        threads: int = 5,
        rate: int = RATE_DEFAULT,
        delay: str | int | float = DELAY_DEFAULT_S,
        timeout_s: int = 10,
        extra_args: Sequence[str] = (),
    ) -> list[str]:
        """The exact command line: target, list, JSON records, bounds.

        ``wordlist`` is a *name*, and the file it resolves to is decided by
        :mod:`tools.wordlist` - the compiled-in list, or a file inside
        ``SAFETY_WRITE_ROOT`` that the operator nominated in advance. Both are
        validated there, so what arrives here is a path this run may use.
        """
        url = _keyword_url(target)
        path = path_for(wordlist)
        argv = [
            BINARY,
            "-u",
            url,
            "-w",
            str(path),
            "-json",
            "-noninteractive",
            "-mc",
            MATCH_CODES,
            "-t",
            str(self._bounded(threads, THREADS_CEILING)),
            "-rate",
            str(self._bounded(rate, RATE_CEILING)),
            "-p",
            _format_delay(_delay_seconds(delay)),
            "-timeout",
            str(self._bounded(timeout_s, TIMEOUT_CEILING_S)),
        ]
        argv += _checked_extra_args(extra_args)
        return argv

    @staticmethod
    def _bounded(value: int, ceiling: int) -> int:
        """Clamp to ``1..ceiling``: plausible values in, plausible values out."""
        return max(1, min(ceiling, int(value)))

    def parse(self, command: CommandResult) -> FfufRun:
        run = FfufRun(
            hits=tuple(parse_ffuf_json(command.stdout)),
            wordlist=path_from_argv(command.argv),
        )
        if run.hits:
            return run
        if command.returncode != 0:
            first = (command.stderr or command.stdout).strip().splitlines()[:1]
            raise ToolExecutionError(
                f"ffuf exited with rc {command.returncode} and reported no match, "
                f"so the run could not be interpreted: {first}"
            )
        if command.stdout.strip():
            lines = len(command.stdout.splitlines())
            raise ToolExecutionError(
                "ffuf produced output but no JSON record could be read "
                f"({lines} line(s)); output is not ffuf's -json record format"
            )
        # rc 0 with no record is ffuf answering the question: no line of the list
        # produced a response outside the fixed match set. That is a finding
        # about those paths and nothing at all about the paths the list did not
        # name, which is why the audit entry states how many were asked.
        return run

    def summarize(self, parsed: Any) -> dict[str, Any]:
        if not isinstance(parsed, FfufRun):
            return {}
        hits = parsed.hits
        by_status: dict[str, int] = {}
        for hit in hits:
            key = str(hit.status_code)
            by_status[key] = by_status.get(key, 0) + 1
        detail: dict[str, Any] = {
            "matches": len(hits),
            "urls": [hit.url for hit in hits][:50],
            "by_status_code": dict(sorted(by_status.items())),
            "inputs": [hit.payload for hit in hits if hit.payload][:50],
            "redirects": [hit.redirect for hit in hits if hit.redirect][:10],
            "bytes_found": sum(hit.length for hit in hits),
            "slowest_ms": round(max((hit.duration_ms for hit in hits), default=0.0), 3),
        }
        if str(parsed.wordlist):
            try:
                detail.update(describe(parsed.wordlist))
            except ToolExecutionError:
                # A list that cannot be counted now is not reported as a count.
                # The command line still names the file, so the run is not lost.
                detail["wordlist"] = parsed.wordlist.name
        return detail


def scan(target: str, context: ToolContext, **options: Any) -> ToolResult:
    """Convenience wrapper: ``scan("http://127.0.0.1:8080/", context)``."""
    return FfufAdapter().run(target, context, **options)
