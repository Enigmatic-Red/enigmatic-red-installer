"""AI Security Benchmark adapter.

This adapter provides AI model security assessment capabilities using nuclei and
httpx for vulnerability scanning, aligned with OWASP Top 10 for LLM and NIST AI RMF
frameworks. It covers prompt injection testing, adversarial robustness evaluation,
and data privacy compliance assessment.

What the adapter provides:

* **Benchmark-driven assessments**: Uses curated benchmark datasets from
  `data/ai_security_benchmarks/` for consistent, repeatable security evaluations.
* **Multi-framework alignment**: Maps findings to OWASP Top 10 for LLM, NIST AI RMF,
  and ISO 42001 frameworks for comprehensive compliance reporting.
* **Automated scanning**: Leverages nuclei for vulnerability detection and httpx
  for service probing, with rate limiting and audit logging.
* **Risk scoring**: Calculates risk scores and effectiveness metrics aligned with
  standardized assessment protocols.

The adapter is classified as `ACTIVE` for scanning operations and `INTRUSIVE` for
assessments that write findings or require human approval for remediation actions.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Sequence

from safety.errors import ToolExecutionError
from tools.base import ToolAdapter, ToolContext, ToolResult
from tools.runner import CommandResult

__all__ = ["AIBenchmarkAdapter", "AI_SECURITY_BENCHMARK_PATH"]

#: Root path for AI security benchmark data
AI_SECURITY_BENCHMARK_PATH = Path(__file__).parent.parent / "data" / "ai_security_benchmarks"

#: Benchmark categories supported by this adapter
BENCHMARK_CATEGORIES = (
    "prompt_injection",
    "adversarial_robustness",
    "data_privacy",
    "supply_chain",
    "model_security",
)

#: Framework alignments available for assessment
FRAMEWORK_ALIGNMENTS = (
    "OWASP-LLM",
    "NIST-AI-RMF",
    "ISO-42001",
)


class AIBenchmarkAdapter(ToolAdapter):
    """Adapter for AI model security benchmarking and assessment.
    
    This adapter orchestrates AI security assessments using nuclei and httpx
    tools, drawing on benchmark data for consistent evaluations.
    """
    
    name = "ai-benchmark"
    
    def __init__(self) -> None:
        super().__init__()
        self._benchmark_path = AI_SECURITY_BENCHMARK_PATH
        self._models_path = self._benchmark_path / "models"
        self._frameworks_path = self._benchmark_path / "frameworks"
        self._datasets_path = self._benchmark_path / "datasets"
        self._metadata_path = self._benchmark_path / "metadata"
    
    def describe(self) -> str:
        return (
            "Assess AI model security using benchmark-driven evaluations: prompt "
            "injection testing, adversarial robustness analysis, and data privacy "
            "compliance. Aligned with OWASP Top 10 for LLM and NIST AI RMF."
        )
    
    def build_argv(self, target: str, **options: Any) -> list[str]:
        """Build the command line for AI security assessment.
        
        Args:
            target: Target AI model or service endpoint.
            **options: Assessment options including category, framework, rate_limit.
        
        Returns:
            Command line arguments as a list.
        """
        category = options.get("category", "prompt_injection")
        framework = options.get("framework", "OWASP-LLM")
        rate_limit = options.get("rate_limit", 100)
        concurrency = options.get("concurrency", 10)
        
        argv = [
            "nuclei",
            "-u", target,
            "-jsonl",
            "-silent",
        ]
        
        # Add category-specific templates if available
        templates_path = self._benchmark_path / "templates" / category
        if templates_path.exists():
            argv.extend(["-t", str(templates_path)])
        
        # Add framework tags
        if framework == "OWASP-LLM":
            argv.extend(["-tags", "owasp,llm"])
        elif framework == "NIST-AI-RMF":
            argv.extend(["-tags", "nist,ai-rmf"])
        elif framework == "ISO-42001":
            argv.extend(["-tags", "iso,42001"])
        
        # Add performance options
        argv.extend(["-rl", str(rate_limit), "-concurrency", str(concurrency)])
        
        return argv
    
    def parse(self, command: CommandResult) -> Any:
        """Parse assessment output into structured findings.
        
        Args:
            command: Command execution result with stdout/stderr.
        
        Returns:
            Parsed assessment findings as a dictionary.
        
        Raises:
            ToolExecutionError: When output cannot be parsed.
        """
        if not command.ok:
            raise ToolExecutionError(
                "ai-benchmark",
                f"Assessment failed: {command.stderr}",
                exit_code=command.exit_code,
            )
        
        findings = {
            "vulnerabilities": [],
            "metrics": {
                "total_findings": 0,
                "critical": 0,
                "high": 0,
                "medium": 0,
                "low": 0,
            },
        }
        
        # Parse JSONL output
        for line in command.stdout.strip().split("\n"):
            if line:
                try:
                    finding = json.loads(line)
                    findings["vulnerabilities"].append(finding)
                    
                    # Update metrics by severity
                    severity = finding.get("severity", "medium").lower()
                    findings["metrics"]["total_findings"] += 1
                    if severity in findings["metrics"]:
                        findings["metrics"][severity] += 1
                        
                except json.JSONDecodeError as e:
                    raise ToolExecutionError(
                        "ai-benchmark",
                        f"Failed to parse assessment output: {e}"
                    )
        
        return findings
    
    def run(self, context: ToolContext, **kwargs: Any) -> ToolResult:
        """Run an AI security benchmark assessment.
        
        Args:
            context: The tool execution context.
            **kwargs: Assessment parameters including target model, benchmark category,
                framework alignment, and scanning options.
        
        Returns:
            ToolResult with assessment findings and metrics.
        
        Raises:
            ToolExecutionError: When benchmark data is unavailable or assessment fails.
        """
        target = kwargs.get("target")
        category = kwargs.get("category", "prompt_injection")
        framework = kwargs.get("framework", "OWASP-LLM")
        
        if not target:
            raise ToolExecutionError("ai-benchmark", "target model or service must be specified")
        
        if category not in BENCHMARK_CATEGORIES:
            raise ToolExecutionError(
                "ai-benchmark",
                f"category {category!r} not in supported categories: {BENCHMARK_CATEGORIES}"
            )
        
        if framework not in FRAMEWORK_ALIGNMENTS:
            raise ToolExecutionError(
                "ai-benchmark",
                f"framework {framework!r} not in supported frameworks: {FRAMEWORK_ALIGNMENTS}"
            )
        
        # Validate benchmark data availability
        if not self._benchmark_path.exists():
            raise ToolExecutionError(
                "ai-benchmark",
                f"Benchmark data path not found: {self._benchmark_path}"
            )
        
        # Build assessment command
        command = self._build_assessment_command(context, target, category, framework, kwargs)
        
        # Execute assessment
        result = context.runner.run(command)
        
        if not result.ok:
            raise ToolExecutionError(
                "ai-benchmark",
                f"Assessment execution failed: {result.stderr}",
                exit_code=result.exit_code,
            )
        
        # Parse and return results
        findings = self._parse_assessment_result(result.stdout, category)
        
        return ToolResult(
            success=True,
            output=findings,
            metadata={
                "target": target,
                "category": category,
                "framework": framework,
                "benchmark_path": str(self._benchmark_path),
            },
        )
    
    def _build_assessment_command(
        self,
        context: ToolContext,
        target: str,
        category: str,
        framework: str,
        kwargs: dict[str, Any],
    ) -> list[str]:
        """Build the assessment command line."""
        command = [
            "nuclei",
            "-u", target,
            "-jsonl",
            "-silent",
        ]
        
        templates_path = self._benchmark_path / "templates" / category
        if templates_path.exists():
            command.extend(["-t", str(templates_path)])
        
        if framework == "OWASP-LLM":
            command.extend(["-tags", "owasp,llm"])
        elif framework == "NIST-AI-RMF":
            command.extend(["-tags", "nist,ai-rmf"])
        
        rate_limit = kwargs.get("rate_limit", 100)
        concurrency = kwargs.get("concurrency", 10)
        command.extend(["-rl", str(rate_limit), "-concurrency", str(concurrency)])
        
        return command
    
    def _parse_assessment_result(self, output: str, category: str) -> dict[str, Any]:
        """Parse assessment output into structured findings."""
        findings = {
            "category": category,
            "vulnerabilities": [],
            "metrics": {"total_findings": 0, "critical": 0, "high": 0, "medium": 0, "low": 0},
        }
        
        for line in output.strip().split("\n"):
            if line:
                try:
                    finding = json.loads(line)
                    findings["vulnerabilities"].append(finding)
                    severity = finding.get("severity", "medium").lower()
                    findings["metrics"]["total_findings"] += 1
                    if severity in findings["metrics"]:
                        findings["metrics"][severity] += 1
                except json.JSONDecodeError:
                    continue
        
        return findings
    
    def list_benchmarks(self) -> dict[str, Sequence[str]]:
        """List available benchmarks by category."""
        benchmarks = {}
        
        if self._models_path.exists():
            benchmarks["models"] = [f.name for f in self._models_path.glob("*.csv")]
        
        if self._frameworks_path.exists():
            benchmarks["frameworks"] = [f.name for f in self._frameworks_path.glob("*.csv")]
        
        if self._datasets_path.exists():
            benchmarks["datasets"] = [f.name for f in self._datasets_path.glob("*.csv")]
        
        return benchmarks
    
    def get_benchmark_metadata(self) -> dict[str, Any]:
        """Retrieve benchmark registry metadata."""
        registry_path = self._metadata_path / "benchmark_registry.json"
        
        if not registry_path.exists():
            return {"error": "Benchmark registry not found"}
        
        with open(registry_path, "r", encoding="utf-8") as f:
            return json.load(f)