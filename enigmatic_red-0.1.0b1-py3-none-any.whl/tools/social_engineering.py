"""Social engineering assessment tools.

This module provides adapters for social engineering assessment tools including
credential analysis, phishing simulation, and human-factor vulnerability scanning.

Each adapter follows the ToolAdapter pattern, integrating with ToolRunner execution
and safety protocols. Output is parsed into frozen dataclasses for downstream trust.
"""

from __future__ import annotations

import json
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterator, Sequence

from safety.errors import (
    ToolConfigurationError,
    ToolExecutionError,
    ToolOutputError,
)

__all__ = [
    "CredentialFinding",
    "PhishingIndicator",
    "SocialEngineeringAdapter",
    "SocialEngineeringTool",
    "UserBehaviorPattern",
    "parse_credential_findings",
    "parse_phishing_indicators",
]


#: Behavioral economics principles applied in social engineering assessments
BEHAVIORAL_PRINCIPLES = (
    "authority",
    "scarcity",
    "social_proof",
    "reciprocity",
    "commitment_consistency",
    "liking",
    "urgency",
)


@dataclass(frozen=True)
class CredentialFinding:
    """A credential vulnerability discovered during social engineering assessment.
    
    Attributes:
        credential_type: The type of credential analyzed.
        location: Where the credential was found (URL, file path, or identifier).
        risk_level: The assessed risk level of the finding.
        exposure_vector: How the credential could be exploited.
        recommendations: Suggested remediation actions.
        evidence: Supporting evidence from the assessment.
        metadata: Additional context from the tool output.
    """

    credential_type: str
    location: str
    risk_level: str
    exposure_vector: str
    recommendations: tuple[str, ...] = ()
    evidence: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Validate credential type and risk level."""
        if self.credential_type not in CREDENTIAL_TYPES:
            object.__setattr__(
                self,
                "credential_type",
                "custom"
            )
        
        valid_risks = frozenset({"critical", "high", "medium", "low", "info"})
        if self.risk_level not in valid_risks:
            object.__setattr__(self, "risk_level", "info")

    @property
    def is_high_risk(self) -> bool:
        """Return True for critical or high risk findings."""
        return self.risk_level in ("critical", "high")

    def describe(self) -> dict[str, Any]:
        """Return a structured description of the finding."""
        return {
            "type": self.credential_type,
            "location": self.location,
            "risk_level": self.risk_level,
            "exposure_vector": self.exposure_vector,
            "recommendations": list(self.recommendations),
            "evidence": self.evidence,
        }
#: Standard credential types analyzed by social engineering tools
CREDENTIAL_TYPES = frozenset({
    "password",
    "api_key",
    "certificate",
    "ssh_key",
    "mfa_token",
    "session_token",
    "oauth_credential",
})


@dataclass(frozen=True)
class PhishingIndicator:
    """A phishing-related indicator discovered during assessment.
    
    Attributes:
        indicator_type: The category of phishing indicator.
        target: The asset or endpoint being analyzed.
        confidence: Confidence score for the indicator (0.0-1.0).
        behavioral_triggers: Behavioral economics principles at play.
        attack_vectors: Potential attack methods identified.
        mitigation_strategies: Recommended defensive measures.
        raw_data: Original tool output data.
    """

    indicator_type: str
    target: str
    confidence: float
    behavioral_triggers: tuple[str, ...] = ()
    attack_vectors: tuple[str, ...] = ()
    mitigation_strategies: tuple[str, ...] = ()
    raw_data: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Validate confidence score and behavioral triggers."""
        if not (0.0 <= self.confidence <= 1.0):
            object.__setattr__(self, "confidence", 0.0)
        
        valid_triggers = frozenset(BEHAVIORAL_PRINCIPLES)
        filtered_triggers = tuple(
            t for t in self.behavioral_triggers if t in valid_triggers
        )
        if filtered_triggers != self.behavioral_triggers:
            object.__setattr__(self, "behavioral_triggers", filtered_triggers)

    @property
    def is_high_confidence(self) -> bool:
        """Return True for indicators with confidence >= 0.8."""
        return self.confidence >= 0.8

    def describe(self) -> dict[str, Any]:
        """Return a structured description of the indicator."""
        return {
            "type": self.indicator_type,
            "target": self.target,
            "confidence": self.confidence,
            "severity": self.severity,
            "timestamp": self.timestamp,
            "context": self.context,
        }


@dataclass(frozen=True)
class UserBehaviorPattern:
    """A user behavior pattern identified during social engineering analysis.
    
    Attributes:
        pattern_id: Unique identifier for the pattern.
        pattern_type: Category of behavior observed.
        frequency: How often the pattern occurs.
        risk_impact: The security impact of this behavior.
        affected_users: Number of users exhibiting this pattern.
        temporal_context: Time-related context for the pattern.
        recommendations: Suggested interventions.
    """

    pattern_id: str
    pattern_type: str
    frequency: str
    risk_impact: str
    affected_users: int = 0
    temporal_context: str = ""
    recommendations: tuple[str, ...] = ()

    @property
    def is_frequent(self) -> bool:
        """Return True for high or very_high frequency patterns."""
        return self.frequency in ("high", "very_high")

    @property
    def needs_intervention(self) -> bool:
        """Return True when pattern warrants attention."""
        return (
            self.risk_impact in ("high", "critical") or
            (self.is_frequent and self.affected_users > 10)
        )

    def describe(self) -> dict[str, Any]:
        """Return a structured description of the pattern."""
        return {
            "pattern_id": self.pattern_id,
            "type": self.pattern_type,
            "frequency": self.frequency,
            "risk_impact": self.risk_impact,
            "affected_users": self.affected_users,
            "temporal_context": self.temporal_context,
            "recommendations": list(self.recommendations),
        }


class SocialEngineeringTool(ABC):
    """Abstract base class defining the social engineering tool interface.
    
    This interface ensures consistency across social engineering tools and
    enables the ToolRunner to execute them uniformly.
    """

    @property
    @abstractmethod
    def name(self) -> str:
        """The tool identifier."""
        pass

    @property
    @abstractmethod
    def description(self) -> str:
        """A human-readable description of the tool's purpose."""
        pass

    @property
    @abstractmethod
    def version(self) -> str:
        """The tool version string."""
        pass

    @abstractmethod
    def build_command(self, target: str, **options: Any) -> list[str]:
        """Build the command line for executing the tool.
        
        Args:
            target: The assessment target (URL, domain, or identifier).
            **options: Tool-specific configuration options.
            
        Returns:
            A list of command-line arguments.
        """
        pass

    @abstractmethod
    def parse_output(self, output: str) -> Sequence[Any]:
        """Parse tool output into structured data.
        
        Args:
            output: The raw output from tool execution.
            
        Returns:
            A sequence of parsed result objects.
            
        Raises:
            ToolOutputError: When output cannot be parsed.
        """
        pass


class SocialEngineeringAdapter(ABC):
    """Abstract adapter for social engineering assessment tools.
    
    This adapter integrates social engineering tools with the execution
    framework, providing standardized argument construction and output
    parsing aligned with behavioral economics principles.
    
    The adapter ensures that:
    - All tool arguments are validated before execution
    - Output is parsed into trusted, frozen data structures
    - Errors are categorized for appropriate downstream handling
    - Behavioral economics principles are consistently applied
    """

    @property
    @abstractmethod
    def tool(self) -> SocialEngineeringTool:
        """The wrapped social engineering tool."""
        pass

    @abstractmethod
    def build_arguments(
        self,
        target: str,
        *,
        output_format: str = "json",
        output_path: Path | None = None,
        **tool_options: Any,
    ) -> list[str]:
        """Build validated arguments for tool execution.

        Args:
            target: The assessment target.
            output_format: Desired output format (json, csv, etc.).
            output_path: Optional path for output file.
            **tool_options: Additional tool-specific options.

        Returns:
            A list of validated command-line arguments.

        Raises:
            ToolConfigurationError: When arguments are invalid.
        """
        pass

    @abstractmethod
    def execute(
        self,
        target: str,
        **options: Any,
    ) -> Sequence[CredentialFinding | PhishingIndicator | UserBehaviorPattern]:
        """Execute the social engineering assessment.

        Args:
            target: The assessment target.
            **options: Execution options including output format and path.

        Returns:
            A sequence of assessment findings.

        Raises:
            ToolExecutionError: When tool execution fails.
            ToolOutputError: When output parsing fails.
        """
        pass


def parse_credential_findings(
    raw_data: dict[str, Any] | str,
) -> list[CredentialFinding]:
    """Parse credential assessment findings from raw data.
    
    This function transforms raw credential scan output into validated,
    frozen CredentialFinding instances. It supports both dictionary input
    (from JSON) and string input (from CSV or other text formats).
    
    Args:
        raw_data: Raw credential data as a dictionary or JSON string.
        
    Returns:
        A list of validated CredentialFinding instances.
        
    Raises:
        ToolOutputError: When parsing fails due to invalid data structure
            or validation errors.
        
    Example:
        >>> findings = parse_credential_findings(json_string)
        >>> for finding in findings:
        ...     if finding.risk_level == "high":
        ...         print(f"High risk: {finding.credential_type}")
    """
    from safety.errors import ToolOutputError

    if isinstance(raw_data, str):
        try:
            raw_data = json.loads(raw_data)
        except json.JSONDecodeError as e:
            raise ToolOutputError(
                "Invalid JSON format in credential findings output"
            ) from e

    if not isinstance(raw_data, dict):
        raise ToolOutputError(
            "Credential findings must be a dictionary or valid JSON string"
        )

    findings: list[CredentialFinding] = []
    items = raw_data.get("findings", raw_data.get("credentials", []))

    if isinstance(items, dict):
        items = [items]

    for idx, item in enumerate(items):
        try:
            finding = CredentialFinding(
                credential_type=item.get("credential_type", item.get("type", "unknown")),
                location=item.get("location", item.get("path", "unknown")),
                risk_level=item.get("risk_level", item.get("risk", "medium")),
                findings=item.get("findings", item.get("issues", [])),
                confidence_score=float(item.get("confidence_score", 0.5)),
                timestamp=item.get("timestamp", datetime.now().isoformat()),
            )
            findings.append(finding)
        except (ValueError, TypeError) as e:
            raise ToolOutputError(
                f"Invalid credential finding at index {idx}: {e}"
            ) from e

    return findings


def parse_phishing_indicators(
    raw_data: dict[str, Any] | str,
) -> list[PhishingIndicator]:
    """Parse phishing assessment indicators from raw data.
    
    This function transforms raw phishing scan output into validated,
    frozen PhishingIndicator instances. It analyzes email, URL, and
    behavioral indicators to identify potential social engineering attacks.
    
    Args:
        raw_data: Raw phishing data as a dictionary or JSON string.
        
    Returns:
        A list of validated PhishingIndicator instances.
        
    Raises:
        ToolOutputError: When parsing fails due to invalid data structure
            or validation errors.
        
    Example:
        >>> indicators = parse_phishing_indicators(json_string)
        >>> urgent = [i for i in indicators if i.urgency == "high"]
        >>> for indicator in urgent:
        ...     print(f"Urgent: {indicator.indicator_type}")
    """
    from safety.errors import ToolOutputError

    if isinstance(raw_data, str):
        try:
            raw_data = json.loads(raw_data)
        except json.JSONDecodeError as e:
            raise ToolOutputError(
                "Invalid JSON format in phishing indicators output"
            ) from e

    if not isinstance(raw_data, dict):
        raise ToolOutputError(
            "Phishing indicators must be a dictionary or valid JSON string"
        )

    indicators: list[PhishingIndicator] = []
    items = raw_data.get("indicators", raw_data.get("phishing_data", []))

    if isinstance(items, dict):
        items = [items]

    for idx, item in enumerate(items):
        try:
            indicator = PhishingIndicator(
                indicator_type=item.get("indicator_type", item.get("type", "unknown")),
                source=item.get("source", "unknown"),
                severity=item.get("severity", "medium"),
                urgency=item.get("urgency", "normal"),
                behavioral_triggers=item.get("behavioral_triggers", []),
                confidence_score=float(item.get("confidence_score", 0.5)),
                timestamp=item.get("timestamp", datetime.now().isoformat()),
            )
            indicators.append(indicator)
        except (ValueError, TypeError) as e:
            raise ToolOutputError(
                f"Invalid phishing indicator at index {idx}: {e}"
            ) from e

        return indicators


def iter_behavioral_patterns(
    raw_data: dict[str, Any] | str,
) -> Iterator[UserBehaviorPattern]:
    """Iterate over user behavior patterns from raw data.
    
    This generator function yields validated UserBehaviorPattern instances
    from raw behavioral data. It is designed for memory-efficient processing
    of large behavioral datasets, yielding patterns one at a time.
    
    Args:
        raw_data: Raw behavioral data as a dictionary or JSON string.
        
    Yields:
        Validated UserBehaviorPattern instances.
        
    Raises:
        ToolOutputError: When parsing fails due to invalid data structure
            or validation errors.
        
    Example:
        >>> for pattern in iter_behavioral_patterns(json_string):
        ...     if pattern.anomaly_score > 0.8:
        ...         print(f"Anomaly detected: {pattern.pattern_type}")
    """
    from safety.errors import ToolOutputError

    if isinstance(raw_data, str):
        try:
            raw_data = json.loads(raw_data)
        except json.JSONDecodeError as e:
            raise ToolOutputError(
                "Invalid JSON format in behavioral patterns output"
            ) from e

    if not isinstance(raw_data, dict):
        raise ToolOutputError(
            "Behavioral patterns must be a dictionary or valid JSON string"
        )

    items = raw_data.get("patterns", raw_data.get("behavioral_data", []))

    if isinstance(items, dict):
        items = [items]

    for idx, item in enumerate(items):
        try:
            pattern = UserBehaviorPattern(
                pattern_type=item.get("pattern_type", item.get("type", "unknown")),
                user_id=item.get("user_id", item.get("user", "unknown")),
                behavior_metrics=item.get("behavior_metrics", {}),
                anomaly_score=float(item.get("anomaly_score", 0.0)),
                behavioral_triggers=item.get("behavioral_triggers", []),
                timestamp=item.get("timestamp", datetime.now().isoformat()),
            )
            yield pattern
        except (ValueError, TypeError) as e:
            raise ToolOutputError(
                f"Invalid behavioral pattern at index {idx}: {e}"
            ) from e


# ============================================================================
# Concrete Adapters
# ============================================================================


class CredentialScannerAdapter(SocialEngineeringAdapter):
    """Credential scanning adapter for social engineering assessments.
    
    This adapter implements credential analysis capabilities, scanning for
    exposed credentials, weak authentication mechanisms, and credential
    misconfigurations. It integrates with the ToolRunner framework for
    execution and safety protocol compliance.
    
    The adapter supports multiple output formats (JSON, XML, CSV) and
    produces CredentialFinding instances that can be consumed by downstream
    analysis pipelines.
    
    Example:
        >>> adapter = CredentialScannerAdapter()
        >>> findings = adapter.run(
        ...     "https://example.com",
        ...     context,
        ...     output_format="json",
        ...     depth=3
        ... )
    """
    
    name = "credential_scanner"
    
    def build_argv(
        self,
        target: str,
        *,
        output_format: str = "json",
        depth: int = 2,
        include_history: bool = False,
        check_exposure: bool = True,
        extra_args: Sequence[str] = (),
    ) -> list[str]:
        """Build the command line arguments for credential scanning.
        
        Args:
            target: The target URL or identifier to scan.
            output_format: Output format (json, xml, csv). Defaults to json.
            depth: Scan depth for recursive credential discovery. Defaults to 2.
            include_history: Whether to include historical credential data.
            check_exposure: Whether to perform exposure vector analysis.
            extra_args: Additional arguments passed through to the tool.
            
        Returns:
            A list of command line arguments.
            
        Raises:
            ToolConfigurationError: When arguments are invalid.
        """
        from safety.errors import ToolConfigurationError
        
        target = str(target).strip()
        if not target:
            raise ToolConfigurationError("no target specified for credential scan")
        if target.startswith("-"):
            raise ToolConfigurationError(
                f"target cannot start with a dash: {target!r}"
            )
        
        valid_formats = frozenset({"json", "xml", "csv"})
        if output_format.lower() not in valid_formats:
            raise ToolConfigurationError(
                f"output_format must be one of {valid_formats}, got {output_format!r}"
            )
        
        if not 1 <= depth <= 10:
            raise ToolConfigurationError(
                f"depth must be between 1 and 10, got {depth}"
            )
        
        argv = ["credential-scanner"]
        argv += ["--format", output_format.lower()]
        argv += ["--depth", str(depth)]
        
        if include_history:
            argv.append("--include-history")
        if check_exposure:
            argv.append("--check-exposure")
        
        argv += [str(arg) for arg in extra_args]
        argv.append(target)
        
        return argv
    
    def parse(self, command: CommandResult) -> Sequence[CredentialFinding]:
        """Parse the command output into CredentialFinding instances.
        
        Args:
            command: The command execution result containing stdout.
            
        Returns:
            A sequence of parsed CredentialFinding instances.
            
        Raises:
            ToolOutputError: When parsing fails due to invalid output.
        """
        return parse_credential_findings(command.stdout)
    
    def summarize(self, parsed: Any) -> dict[str, Any]:
        """Generate a summary of the parsed findings.
        
        Args:
            parsed: The parsed CredentialFinding instances.
            
        Returns:
            A dictionary containing summary statistics.
        """
        if isinstance(parsed, Sequence):
            findings = list(parsed)
            risk_counts = {
                "critical": 0,
                "high": 0,
                "medium": 0,
                "low": 0,
                "info": 0,
            }
            type_counts: dict[str, int] = {}
            
            for finding in findings:
                if isinstance(finding, CredentialFinding):
                    risk_counts[finding.risk_level] = risk_counts.get(
                        finding.risk_level, 0
                    ) + 1
                    type_counts[finding.credential_type] = type_counts.get(
                        finding.credential_type, 0
                    ) + 1
            
            return {
                "total_findings": len(findings),
                "risk_distribution": risk_counts,
                "credential_types": type_counts,
                "high_risk_count": sum(
                    1 for f in findings
                    if isinstance(f, CredentialFinding) and f.is_high_risk
                ),
            }
        return {}


class PhishingSimulationAdapter(SocialEngineeringAdapter):
    """Phishing simulation adapter for social engineering assessments.
    
    This adapter implements phishing analysis capabilities, detecting
    phishing indicators, analyzing email and URL patterns, and assessing
    user susceptibility to phishing attacks.
    
    The adapter produces PhishingIndicator instances that capture
    suspicious patterns, threat classifications, and recommended
    defensive actions.
    
    Example:
        >>> adapter = PhishingSimulationAdapter()
        >>> indicators = adapter.run(
        ...     "campaign@example.com",
        ...     context,
        ...     simulation_type="email",
        ...     include_analysis=True
        ... )
    """
    
    name = "phishing_simulation"
    
    def build_argv(
        self,
        target: str,
        *,
        simulation_type: str = "email",
        include_analysis: bool = True,
        output_format: str = "json",
        threshold: float = 0.7,
        extra_args: Sequence[str] = (),
    ) -> list[str]:
        """Build the command line arguments for phishing simulation.
        
        Args:
            target: The target identifier or campaign name.
            simulation_type: Type of simulation (email, sms, voice).
            include_analysis: Whether to include detailed analysis.
            output_format: Output format (json, xml). Defaults to json.
            threshold: Confidence threshold for indicators. Defaults to 0.7.
            extra_args: Additional arguments passed through to the tool.
            
        Returns:
            A list of command line arguments.
            
        Raises:
            ToolConfigurationError: When arguments are invalid.
        """
        from safety.errors import ToolConfigurationError
        
        target = str(target).strip()
        if not target:
            raise ToolConfigurationError("no target specified for phishing simulation")
        
        valid_types = frozenset({"email", "sms", "voice", "web"})
        if simulation_type.lower() not in valid_types:
            raise ToolConfigurationError(
                f"simulation_type must be one of {valid_types}, got {simulation_type!r}"
            )
        
        if not 0.0 <= threshold <= 1.0:
            raise ToolConfigurationError(
                f"threshold must be between 0.0 and 1.0, got {threshold}"
            )
        
        argv = ["phishing-simulator"]
        argv += ["--type", simulation_type.lower()]
        argv += ["--format", output_format.lower()]
        argv += ["--threshold", str(threshold)]
        
        if include_analysis:
            argv.append("--include-analysis")
        
        argv += [str(arg) for arg in extra_args]
        argv.append(target)
        
        return argv
    
    def parse(self, command: CommandResult) -> Sequence[PhishingIndicator]:
        """Parse the command output into PhishingIndicator instances.
        
        Args:
            command: The command execution result containing stdout.
            
        Returns:
            A sequence of parsed PhishingIndicator instances.
            
        Raises:
            ToolOutputError: When parsing fails due to invalid output.
        """
        return parse_phishing_indicators(command.stdout)
    
    def summarize(self, parsed: Any) -> dict[str, Any]:
        """Generate a summary of the parsed phishing indicators.
        
        Args:
            parsed: The parsed PhishingIndicator instances.
            
        Returns:
            A dictionary containing summary statistics.
        """
        if isinstance(parsed, Sequence):
            indicators = list(parsed)
            threat_counts = {
                "spoofing": 0,
                "malicious_link": 0,
                "suspicious_sender": 0,
                "urgency_manipulation": 0,
                "credential_harvesting": 0,
            }
            confidence_scores: list[float] = []
            
            for indicator in indicators:
                if isinstance(indicator, PhishingIndicator):
                    threat_counts[indicator.indicator_type] = threat_counts.get(
                        indicator.indicator_type, 0
                    ) + 1
                    confidence_scores.append(indicator.confidence)

            avg_confidence = (
                sum(confidence_scores) / len(confidence_scores)
                if confidence_scores
                else 0.0
            )
            
            return {
                "total_indicators": len(indicators),
                "threat_distribution": threat_counts,
                "average_confidence": avg_confidence,
                "high_confidence_count": sum(
                    1 for c in confidence_scores if c >= 0.8
                ),
            }
        return {}


def scan_credentials(
    target: str,
    *,
    output_format: str = "json",
    include_metadata: bool = True,
    extra_args: Sequence[str] = (),
) -> Sequence[CredentialFinding]:
    """Convenience function to scan for exposed credentials.
    
    This function provides a simplified interface for credential scanning
    by creating a `CredentialScannerAdapter` instance and running it
    against the specified target.
    
    Args:
        target: The target identifier or URL to scan.
        output_format: Output format (json, xml). Defaults to json.
        include_metadata: Whether to include metadata in findings.
        extra_args: Additional arguments passed through to the adapter.
        
    Returns:
        A sequence of CredentialFinding instances.
        
    Example:
        >>> findings = scan_credentials("https://api.example.com")
        >>> for finding in findings:
        ...     print(f"{finding.credential_type}: {finding.location}")
    """
    adapter = CredentialScannerAdapter()
    argv = adapter.build_argv(
        target,
        output_format=output_format,
        include_metadata=include_metadata,
        extra_args=extra_args,
    )
    # In a real implementation, this would execute the command
    # and parse the results. For now, return an empty sequence.
    return []


def simulate_phishing(
    target: str,
    *,
    simulation_type: str = "email",
    include_analysis: bool = True,
    threshold: float = 0.7,
    extra_args: Sequence[str] = (),
) -> Sequence[PhishingIndicator]:
    """Convenience function to run phishing simulations.
    
    This function provides a simplified interface for phishing simulation
    by creating a `PhishingSimulationAdapter` instance and running it
    against the specified target.
    
    Args:
        target: The target identifier or campaign name.
        simulation_type: Type of simulation (email, sms, voice, web).
        include_analysis: Whether to include detailed analysis.
        threshold: Confidence threshold for indicators. Defaults to 0.7.
        extra_args: Additional arguments passed through to the adapter.
        
    Returns:
        A sequence of PhishingIndicator instances.
        
    Example:
        >>> indicators = simulate_phishing(
        ...     "campaign@example.com",
        ...     simulation_type="email",
        ...     threshold=0.8
        ... )
        >>> for indicator in indicators:
        ...     print(f"{indicator.indicator_type}: {indicator.confidence}")
    """
    adapter = PhishingSimulationAdapter()
    argv = adapter.build_argv(
        target,
        simulation_type=simulation_type,
        include_analysis=include_analysis,
        threshold=threshold,
        extra_args=extra_args,
    )
    # In a real implementation, this would execute the command
    # and parse the results. For now, return an empty sequence.
    return []