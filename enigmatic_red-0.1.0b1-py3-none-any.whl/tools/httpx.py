"""httpx adapter.

httpx - projectdiscovery's, not the Python library this repository also uses -
answers the first question a recon phase asks: what HTTP service is listening,
and what does it say about itself? The guard registers it `ACTIVE`: a probe is
not an attack, but it is a request the customer's SOC can see, so it is
rate-limited and it is audited like any other action.

What the adapter fixes, and why:

* ``-json``: one JSON object per probe on stdout, which is what the parser reads
  and what the audit entry hashes. ``-silent`` and ``-nc`` keep that stream
  strictly parsable - no banner, no progress meter, no ANSI escapes.
* ``-duc``: no update check. A scan must not reach the internet while it is
  aimed at a customer, and the binary is provisioned with the runner image.
* the target travels as the value of ``-u`` and is refused when it starts with a
  dash, so it can never be read as an option.
* the binary is named by :data:`BINARY`. The name is shared with the Python
  ``httpx`` client - a dependency of this repository, whose console script also
  installs as ``httpx`` into the interpreter's own ``Scripts`` directory - so
  ``red doctor`` refuses to count that one as the scanner. Running the wrong one
  is not silent: it exits non-zero, and :meth:`HttpxAdapter.parse` reports
  unparseable output rather than an empty result, naming the collision when the
  run's own output is the client's sentence about its optional extras.
* ``-t`` / ``-rl`` / ``-timeout`` are clamped (25 threads, 150 requests a
  second, 30 seconds), because the ceiling is the difference between recon and a
  load test.
* ``paths`` are refused unless they are absolute, uncomma'd and whitespace-free,
  so a path list cannot smuggle a second argument into the command line.

Three families of flag stay refused even when a human has approved the action,
because the guard cannot see them in the finished command line and no approval
should exist for them. ``-l``/``-list``: a target list read from a file would
bypass the scope check, which only ever sees the one target this adapter was
called with. ``-pdu``/``-dashboard-upload``: a customer's estate does not get
uploaded to projectdiscovery's cloud. And the headless-browser and response-store
flags (``-ss``, ``-sr``, ``-srd``, ...): a renderer executes page script, and a
response body written to local disk is an artifact this build has no evidence
store to keep honest.

Two classifications are deliberate rather than accidental, and the tests pin
them: a path list touching ``/admin`` is intrusive through the operator's own
policy rule (``admin_plane_paths``), and a target spelled ``http://127.0.0.1`` or
``http://localhost`` is intrusive through ``ssrf_probe``. The bare-host spelling
``127.0.0.1`` stays active - that is the rule as written, and it is why both
spellings are asserted rather than assumed.
"""

from __future__ import annotations

import re
from typing import Any, Sequence

from safety.errors import ToolExecutionError
from tools.base import ToolAdapter, ToolContext, ToolResult
from tools.parsers import HttpxResult, parse_httpx_jsonl
from tools.runner import CommandResult

__all__ = ["BINARY", "HttpxAdapter", "HTTPX_REFUSED_FLAGS", "scan"]

#: The scanner's executable, as it is spelled on ``PATH``.
BINARY = "httpx"

#: One port group the way httpx's ``-p`` takes it: a port or a range, optionally
#: prefixed with the scheme it applies to (``http:80,https:443,8000-8090``).
_PORT_GROUP = re.compile(r"^(?:(?:http|https):)?[0-9]{1,5}(?:-[0-9]{1,5})?$")

#: A path httpx is allowed to request: absolute, and free of the three things
#: that would change the shape of the command line (comma splits a list entry,
#: whitespace splits an argument, and a leading dash turns a value into a flag).
_PATH = re.compile(r"^/[^\s,\x00]*$")

#: A status httpx may match on with ``-mc``.
_STATUS = re.compile(r"^[1-5][0-9]{2}$")

#: Flags that would turn httpx into something other than a scope-checked probe.
#: Each carries its own sentence, because the refusal is what an operator reads.
HTTPX_REFUSED_FLAGS: dict[str, str] = {
    "-l": "a target list read from a file would bypass the scope check",
    "-list": "a target list read from a file would bypass the scope check",
    "-pdu": "output would be uploaded to projectdiscovery's cloud",
    "-dashboard-upload": "output would be uploaded to projectdiscovery's cloud",
    "-ss": "a headless browser renders the page and runs its scripts",
    "-screenshot": "a headless browser renders the page and runs its scripts",
    "-sr": "responses would be written to local disk as scan artifacts",
    "-store-response": "responses would be written to local disk as scan artifacts",
    "-srd": "responses would be written to local disk as scan artifacts",
    "-store-response-dir": "responses would be written to local disk as scan artifacts",
    "-x": "probing every HTTP method includes the state-changing ones (DELETE, PUT)",
}

#: Bounds chosen so one run cannot look like a flood from the target's side.
THREADS_CEILING = 25
RATE_LIMIT_CEILING = 150
TIMEOUT_CEILING_S = 30


def _ports_argument(ports: str | Sequence[int]) -> str:
    """Validate ``-p``, which accepts ports, ranges and scheme-prefixed groups."""
    if not isinstance(ports, str):
        numbers = sorted({int(port) for port in ports})
        if not numbers:
            raise ValueError("no ports given to httpx")
        for port in numbers:
            if not 0 < port < 65536:
                raise ValueError(f"{port} is not a valid TCP port")
        return ",".join(str(port) for port in numbers)
    spec = ports.strip()
    groups = spec.split(",")
    if not spec or not all(_PORT_GROUP.match(group) for group in groups):
        raise ValueError(f"refusing an unparseable port specification: {ports!r}")
    for group in groups:
        for bound in group.split(":")[-1].split("-"):
            if not 0 < int(bound) < 65536:
                raise ValueError(f"{bound} is not a valid TCP port")
    return spec


def _paths_argument(paths: Sequence[str]) -> str:
    """Validate ``-path``; the list travels as one comma-joined value."""
    out: list[str] = []
    for value in paths:
        text = str(value).strip()
        if not _PATH.match(text):
            raise ValueError(
                f"refusing an unparseable path: {value!r}; a path starts with '/' "
                "and contains no comma or whitespace"
            )
        out.append(text)
    if not out:
        raise ValueError("no paths given to httpx")
    return ",".join(out)


def _status_argument(status_codes: Sequence[str]) -> str:
    """Validate ``-mc``, so a filter cannot introduce a second argument."""
    out: list[str] = []
    for value in status_codes:
        text = str(value).strip()
        if not _STATUS.match(text):
            raise ValueError(f"refusing an unparseable status code: {value!r}")
        out.append(text)
    if not out:
        raise ValueError("no status codes given to httpx")
    return ",".join(out)


def _checked_extra_args(extra_args: Sequence[str]) -> list[str]:
    """Refuse the ``extra_args`` that would escape the controls; keep the rest.

    The guard classifies the finished command line, so most passthrough is
    already covered. These are the ones it *cannot* see: what the run reads as
    its input, and where its output goes.
    """
    out: list[str] = []
    for value in extra_args:
        text = str(value)
        flag = text.split("=", 1)[0].strip().lower()
        reason = HTTPX_REFUSED_FLAGS.get(flag)
        if reason:
            raise ValueError(f"refusing httpx flag {flag!r}: {reason}")
        out.append(text)
    return out


def _shadowed_hint(command: CommandResult) -> str:
    """Name the one failed run whose cause is legible: the wrong ``httpx``.

    ``httpx`` is also the name of a Python dependency of this project
    (``agent/providers/featherless.py``), and that package installs a console
    script of the same name beside the interpreter - first on ``PATH``. It fails
    the only way it can, with a sentence about its own optional extras, so the
    message is quotable evidence rather than a guess. ``red doctor`` is where the
    collision is named before a scan reaches this point.
    """
    said = f"{command.stdout}\n{command.stderr}".lower()
    named = "httpx command line client could not run" in said or "httpx[cli]" in said
    if not named:
        return ""
    return (
        "; the output names the Python `httpx` client's console script rather than "
        "the ProjectDiscovery scanner, which is also called `httpx` - run "
        "`red doctor`, which reports that collision and names the scanner"
    )


class HttpxAdapter(ToolAdapter):
    """``httpx -json`` against one target: what answers, and what it says."""

    name = "httpx"

    def build_argv(
        self,
        target: str,
        *,
        ports: str | Sequence[int] = (),
        paths: Sequence[str] = (),
        status_codes: Sequence[str] = (),
        follow_redirects: bool = False,
        threads: int = 20,
        rate_limit: int = 50,
        timeout_s: int = 10,
        title: bool = True,
        tech: bool = True,
        extra_args: Sequence[str] = (),
    ) -> list[str]:
        """Build the argv.

        A bare run - no ports, no paths - asks httpx for the root of the target
        on both schemes, which is the cheapest honest probe of "is there a web
        service here". ``-title`` and ``-td`` are on by default because a
        status code alone does not identify a service, and both are answered
        from the response httpx already fetched.
        """
        target = str(target).strip()
        if not target:
            raise ValueError("no target given to httpx")
        if target.startswith("-"):
            raise ValueError(f"refusing a target that looks like an option: {target!r}")

        argv = [BINARY, "-u", target, "-json", "-silent", "-nc", "-duc"]
        # Always on: no update check, so a scan never reaches out on its own.
        if title:
            argv.append("-title")
        if tech:
            argv.append("-td")
        if follow_redirects:
            argv.append("-fr")
        if ports:
            argv += ["-p", _ports_argument(ports)]
        if paths:
            argv += ["-path", _paths_argument(paths)]
        if status_codes:
            argv += ["-mc", _status_argument(status_codes)]
        argv += ["-t", str(self._bounded(threads, THREADS_CEILING))]
        argv += ["-rl", str(self._bounded(rate_limit, RATE_LIMIT_CEILING))]
        argv += ["-timeout", str(self._bounded(timeout_s, TIMEOUT_CEILING_S))]
        argv += _checked_extra_args(extra_args)
        return argv

    @staticmethod
    def _bounded(value: int, ceiling: int) -> int:
        """Clamp to ``1..ceiling``: plausible values in, plausible values out."""
        return max(1, min(ceiling, int(value)))

    def parse(self, command: CommandResult) -> tuple[HttpxResult, ...]:
        results = tuple(parse_httpx_jsonl(command.stdout))
        if results:
            return results
        if command.returncode != 0:
            raise ToolExecutionError(
                f"httpx exited with rc {command.returncode} and produced no probe "
                f"result, so the run could not be interpreted{_shadowed_hint(command)}"
            )
        if command.stdout.strip():
            # Output arrived but none of it was a probe result: a version whose
            # JSON schema we do not know, not an empty finding.
            lines = len(command.stdout.splitlines())
            raise ToolExecutionError(
                "httpx produced output but no probe result could be recovered "
                f"({lines} line(s), {len(command.stdout)} bytes); output is not "
                "httpx JSONL"
            )
        # rc 0 with no output is httpx answering the question: nothing on this
        # target spoke HTTP. That is a result, not an error - the report says
        # the target was probed and did not answer, which is different from
        # httpx never having run.
        return results

    def summarize(self, parsed: Any) -> dict[str, Any]:
        if not isinstance(parsed, tuple):
            return {}
        by_status: dict[str, int] = {}
        hosts: list[str] = []
        urls: list[str] = []
        tech: list[str] = []
        for result in parsed:
            if result.responding:
                by_status[str(result.status_code)] = (
                    by_status.get(str(result.status_code), 0) + 1
                )
            host = result.hostname
            if host and host not in hosts:
                hosts.append(host)
            if result.url and result.url not in urls:
                urls.append(result.url)
            for name in result.tech:
                if name not in tech:
                    tech.append(name)
        return {
            "probes": len(parsed),
            "responding": sum(1 for result in parsed if result.responding),
            "failed": sum(1 for result in parsed if result.failed),
            "by_status_code": by_status,
            "hosts": hosts[:25],
            "urls": urls[:25],
            "tech": sorted(tech)[:25],
        }


def scan(target: str, context: ToolContext, **options: Any) -> ToolResult:
    """Convenience wrapper: ``scan(host, context, ports="443")``."""
    return HttpxAdapter().run(target, context, **options)
