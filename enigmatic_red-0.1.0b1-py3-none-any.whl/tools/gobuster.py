"""gobuster adapter.

gobuster answers one question: which paths under this web root exist. It is the
discovery half of the web-application pack - ``httpx`` says what answers, this
says what else is there - and the guard registers it ACTIVE, because every
request it makes reaches the customer's own service.

What the adapter fixes, and why:

* ``dir`` mode with ``-q``: the mode whose result line is ``path (Status: 200)
  [Size: 708]``, and quiet mode, which stops gobuster printing its banner on the
  same stream as its results. The parser reads exactly that line shape, and a
  line that is not that shape is not a result.
* ``--no-progress`` and ``--no-color``: a progress meter and a colour escape are
  both noise inside the stream this project reads and hashes.
* ``-t`` is clamped to 25 threads (gobuster's own default is 10) and ``--delay``
  is set on every run, with a floor: gobuster's default delay is *zero*, which
  is exactly the setting that turns discovery into a burst. The delay is the
  rate control here - gobuster has no requests-per-second flag - so it is
  validated as a duration and cannot be lowered below 100ms.
* ``--timeout`` is clamped to 30 seconds per request.
* The status codes a run reports are gobuster's own non-error set (200, 204,
  301, 302, 307, 401, 403, with 404 blacklisted); ``-s`` and ``-b`` are refused
  as passthrough, because either one can hide the answers the run was asked for.
  gobuster refuses to start with both set, and setting them here would mean
  pinning a number this adapter does not need to pin.
* ``--force`` is refused: it continues past gobuster's precheck, and that
  precheck is what stops a wildcard host - one that answers 200 to everything -
  from turning every word in the list into a finding.

Refused for the same reasons as elsewhere: ``-o``/``--output`` writes results to
local disk, ``-w``/``--wordlist`` and ``-X``/``--extensions-file`` read a list
from somewhere this adapter did not validate, ``-p``/``--pattern`` and
``--discover-pattern`` read replacement patterns from a file,
``-c``/``--cookies``, ``-U``/``-P`` and the ``--client-cert-*`` family carry
credentials or key material, ``--proxy`` and ``--replay-proxy`` decide who else
sees the requests, ``-n``/``--no-status`` and ``--hide-length`` remove the two
fields that make a result worth reporting, ``--debug`` is not the shape the
parser reads, and ``-e``/``--expanded`` prints full URLs instead of paths.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Sequence

from safety.errors import ToolExecutionError
from tools.base import ToolAdapter, ToolContext, ToolResult
from tools.parsers import GobusterHit, parse_gobuster_text
from tools.runner import CommandResult
from tools.wordlist import BUILTIN_NAME, describe, path_for, path_from_argv

__all__ = [
    "BINARY",
    "DELAY_DEFAULT_MS",
    "DELAY_FLOOR_MS",
    "GOBUSTER_REFUSED_FLAGS",
    "TIMEOUT_CEILING_S",
    "THREADS_CEILING",
    "GobusterAdapter",
    "GobusterRun",
    "scan",
]

#: The scanner's executable, as it is spelled on ``PATH``.
BINARY = "gobuster"

#: gobuster's default delay is zero; this adapter always sets one. 250ms across
#: at most 25 threads is roughly 100 requests a second at the ceiling, and the
#: floor of 100ms is what a passthrough cannot go under.
DELAY_DEFAULT_MS = 250
DELAY_FLOOR_MS = 100
DELAY_CEILING_MS = 5000

#: Bounds: one run must not look like a sweep.
THREADS_CEILING = 25
TIMEOUT_CEILING_S = 30

#: A duration gobuster understands: ``250ms``, ``2s``, ``1m30s``.
_DURATION = re.compile(r"^(?P<value>[0-9]+)(?P<unit>ms|s|m|h)$")
_UNIT_MS = {"ms": 1, "s": 1000, "m": 60_000, "h": 3_600_000}

#: Flags refused in ``extra_args`` even when the action was approved.
GOBUSTER_REFUSED_FLAGS: dict[str, str] = {
    "-o": "results would be written to local disk as a scan artifact",
    "--output": "results would be written to local disk as a scan artifact",
    "-w": "the word list is one this adapter validates, not one it is handed",
    "--wordlist": "the word list is one this adapter validates, not one it is handed",
    "-X": "an extension list read from a file is a list this adapter did not validate",
    "--extensions-file": (
        "an extension list read from a file is a list this adapter did not validate"
    ),
    "-p": "a pattern file is read by gobuster and never validated here",
    "--pattern": "a pattern file is read by gobuster and never validated here",
    "--pd": "a pattern file is read by gobuster and never validated here",
    "--discover-pattern": "a pattern file is read by gobuster and never validated here",
    "-u": "the target is the one this adapter was called with",
    "--url": "the target is the one this adapter was called with",
    "-s": "the reported status codes are fixed, so a run cannot hide an answer",
    "--status-codes": (
        "the reported status codes are fixed, so a run cannot hide an answer"
    ),
    "-b": "the reported status codes are fixed, so a run cannot hide an answer",
    "--status-codes-blacklist": (
        "the reported status codes are fixed, so a run cannot hide an answer"
    ),
    "--force": (
        "gobuster's precheck is what stops a wildcard host from turning every "
        "word in the list into a finding"
    ),
    "-n": "the status code is what makes a result line a result",
    "--no-status": "the status code is what makes a result line a result",
    "--hl": "the body size is part of the finding",
    "--hide-length": "the body size is part of the finding",
    "--debug": "debug output is not the line shape the parser reads",
    "-e": "expanded output prints full URLs instead of the paths the parser reads",
    "--expanded": (
        "expanded output prints full URLs instead of the paths the parser reads"
    ),
    "-c": "credentials are not handled by this build",
    "--cookies": "credentials are not handled by this build",
    "-U": "credentials are not handled by this build",
    "--username": "credentials are not handled by this build",
    "-P": "credentials are not handled by this build",
    "--password": "credentials are not handled by this build",
    "--client-cert-pem": "client key material is not handled by this build",
    "--ccp": "client key material is not handled by this build",
    "--client-cert-pem-key": "client key material is not handled by this build",
    "--ccpk": "client key material is not handled by this build",
    "--client-cert-p12": "client key material is not handled by this build",
    "--ccp12": "client key material is not handled by this build",
    "--client-cert-p12-password": "client key material is not handled by this build",
    "--ccp12p": "client key material is not handled by this build",
    "--proxy": "the proxy decides who else sees the requests",
    "-t": "the thread count is set by this adapter's own bound",
    "--threads": "the thread count is set by this adapter's own bound",
    "-d": "the delay between requests is set by this adapter's own bound",
    "--delay": "the delay between requests is set by this adapter's own bound",
    "--timeout": "the timeout is set by this adapter's own bound",
    "--to": "the timeout is set by this adapter's own bound",
    "--wo": "resuming part-way through a list is a run this adapter does not schedule",
    "--wordlist-offset": (
        "resuming part-way through a list is a run this adapter does not schedule"
    ),
    "--interface": "the outgoing interface is a decision for the operator, not the plan",
    "--iface": "the outgoing interface is a decision for the operator, not the plan",
    "--local-ip": "the outgoing interface is a decision for the operator, not the plan",
}


def _delay_ms(value: str | int) -> int:
    """Read a delay as milliseconds, and refuse one below the floor.

    Accepts what the adapter itself passes (an integer number of milliseconds)
    and what an operator would write (a gobuster duration). The floor is the
    point: a discovery run with no delay is the loudest thing this product can
    do to a customer's service.
    """
    if isinstance(value, bool):
        raise ValueError("refusing a boolean delay")
    if isinstance(value, int):
        ms = value
    else:
        match = _DURATION.match(str(value).strip().lower())
        if match is None:
            raise ValueError(
                f"refusing the delay {value!r}: give a duration such as 250ms or 2s"
            )
        ms = int(match.group("value")) * _UNIT_MS[match.group("unit")]
    if ms < DELAY_FLOOR_MS:
        raise ValueError(
            f"refusing a delay of {ms}ms: it may be at least {DELAY_FLOOR_MS}ms, "
            "because discovery at full speed is a load test, not a scan"
        )
    return min(ms, DELAY_CEILING_MS)


def _checked_extra_args(extra_args: Sequence[str]) -> list[str]:
    """Refuse the ``extra_args`` that would escape the controls; keep the rest.

    Unlike ``dnsx``, gobuster is a cobra program: a flag it does not know is an
    error with a non-zero exit, so a refusal table is enough here and an
    allow-list would only stop a new gobuster from gaining flags.
    """
    out: list[str] = []
    for value in extra_args:
        text = str(value)
        # Looked up exactly first: ``-X`` and ``-x`` are different flags, and
        # folding the case would let the file-reading one pass as the inline
        # one. Long flags are then tried folded, since their case never means
        # anything.
        flag = text.split("=", 1)[0].strip()
        reason = GOBUSTER_REFUSED_FLAGS.get(flag) or GOBUSTER_REFUSED_FLAGS.get(
            flag.lower()
        )
        if reason:
            raise ValueError(f"refusing gobuster flag {flag!r}: {reason}")
        out.append(text)
    return out


def _scope_url(target: str) -> str:
    """The URL this run is aimed at, checked before it reaches the argv.

    gobuster has no positional target: it refuses to run with
    ``Required flags "url, wordlist" not set`` and exits 1, so the URL travels
    as the value of ``-u``. ``-u`` is refused in passthrough, which is what
    keeps that value the one target the scope check saw.
    """
    url = str(target).strip()
    if not url:
        raise ValueError("no target given to gobuster")
    if url.startswith("-"):
        raise ValueError(f"refusing a target that looks like an option: {url!r}")
    if "://" not in url:
        raise ValueError(
            f"refusing {url!r}: gobuster is given a URL with a scheme, e.g. "
            f"http://{url}/"
        )
    return url




@dataclass(frozen=True)
class GobusterRun:
    """One ``gobuster dir`` run: the paths that answered, and the list asked.

    The list is part of the result rather than an implementation detail. How many
    requests a run makes is a fact about how loud it was, and the audit entry has
    to be able to state it, so the adapter does not throw away which file the
    run was pointed at.
    """

    hits: tuple[GobusterHit, ...]
    wordlist: Path = Path("")

    def __iter__(self):
        return iter(self.hits)

    def __len__(self) -> int:
        return len(self.hits)

    @property
    def found(self) -> tuple[GobusterHit, ...]:
        """The paths that answered, in the order gobuster reported them."""
        return self.hits


class GobusterAdapter(ToolAdapter):
    """``gobuster dir`` for one URL: which paths under it exist."""

    name = "gobuster"

    def build_argv(
        self,
        target: str,
        *,
        wordlist: str = BUILTIN_NAME,
        threads: int = 10,
        delay: str | int = DELAY_DEFAULT_MS,
        timeout_s: int = 10,
        extra_args: Sequence[str] = (),
    ) -> list[str]:
        """The exact command line: mode, target, list, quiet, bounds.

        ``wordlist`` is a *name*, and the file it resolves to is decided by
        :mod:`tools.wordlist` - the compiled-in list, or a file inside
        ``SAFETY_WRITE_ROOT`` that the operator nominated in advance. Both are
        validated there, so what arrives here is a path this run may use.
        """
        url = _scope_url(target)
        path = path_for(wordlist)
        argv = [
            BINARY,
            "dir",
            "-u",
            url,
            "-w",
            str(path),
            "-q",
            "--no-progress",
            "--no-color",
            "-t",
            str(self._bounded(threads, THREADS_CEILING)),
            "--delay",
            f"{_delay_ms(delay)}ms",
            "--timeout",
            f"{self._bounded(timeout_s, TIMEOUT_CEILING_S)}s",
        ]
        argv += _checked_extra_args(extra_args)
        return argv

    @staticmethod
    def _bounded(value: int, ceiling: int) -> int:
        """Clamp to ``1..ceiling``: plausible values in, plausible values out."""
        return max(1, min(ceiling, int(value)))

    def parse(self, command: CommandResult) -> GobusterRun:
        run = GobusterRun(
            hits=tuple(parse_gobuster_text(command.stdout)),
            wordlist=path_from_argv(command.argv),
        )
        if run.hits:
            return run
        if command.returncode != 0:
            first = (command.stderr or command.stdout).strip().splitlines()[:1]
            raise ToolExecutionError(
                f"gobuster exited with rc {command.returncode} and reported no "
                f"path, so the run could not be interpreted: {first}"
            )
        if command.stdout.strip():
            lines = len(command.stdout.splitlines())
            raise ToolExecutionError(
                "gobuster produced output but no result line could be read "
                f"({lines} line(s)); output is not gobuster's -q result format"
            )
        # rc 0 with no result line is gobuster answering the question: none of
        # the paths in the list exists under this root. That is a finding about
        # those paths and nothing at all about the ones the list did not name,
        # which is why the audit entry states how many were asked.
        return run

    def summarize(self, parsed: Any) -> dict[str, Any]:
        if not isinstance(parsed, GobusterRun):
            return {}
        hits = parsed.hits
        by_status: dict[str, int] = {}
        for hit in hits:
            key = str(hit.status_code)
            by_status[key] = by_status.get(key, 0) + 1
        detail: dict[str, Any] = {
            "paths_found": len(hits),
            "paths": [hit.path for hit in hits][:50],
            "by_status_code": dict(sorted(by_status.items())),
            "redirects": [hit.redirect for hit in hits if hit.redirect][:10],
            "bytes_found": sum(hit.size for hit in hits),
        }
        if str(parsed.wordlist):
            try:
                detail.update(describe(parsed.wordlist))
            except ToolExecutionError:
                # A list that cannot be counted now is not reported as a count.
                # The command line still names the file, so the run is not lost.
                detail["wordlist"] = parsed.wordlist.name
        return detail


def scan(target: str, context: ToolContext, **options: Any) -> ToolResult:
    """Convenience wrapper: ``scan("http://127.0.0.1:8080/", context)``."""
    return GobusterAdapter().run(target, context, **options)
