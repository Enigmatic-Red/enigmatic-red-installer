"""GitHub CLI adapter: what a repository is, and opening a pull request.

Two operations:

* ``repo_view`` - read a repository's own description of itself: visibility,
  whether it is archived or a fork, its default branch, when it was last pushed,
  its licence, its size. This is the metadata half of reviewing a repository you
  have been asked to look at, and it changes nothing;
* ``pr_create`` - open a pull request. Intrusive: it writes to a repository and
  notifies people, so it needs a human approval of its exact command line. The
  head branch has to exist already, which is what :mod:`tools.git`'s ``push`` is
  for - the two compose, and each is approved separately.

``gh`` needs a credential for essentially everything, including a read of a
public repository, so one is passed when the operator configured it: through
``GH_TOKEN`` in the child's environment, never on the command line, because the
argv of every run is written into the append-only audit log. A machine with no
token reports the read as unreadable rather than as an empty repository, and
``GH_PROMPT_DISABLED``/``GH_NO_UPDATE_NOTIFIER`` are always set so the child can
neither wait for a login nor try to update itself mid-scan.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from typing import Any

from config.settings import get_settings
from safety.errors import ToolExecutionError
from tools.base import ToolAdapter, ToolContext, ToolResult
from tools.runner import CommandResult

__all__ = ["GitHubAdapter", "RepoView", "pr_create", "repo_view"]

#: ``owner/name`` on github.com, and nothing that could become an option.
_SLUG = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]*/[A-Za-z0-9][A-Za-z0-9._-]*$")

#: A branch name, with the spellings git itself means something else by.
_BRANCH = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._/-]*$")
_BRANCH_FORBIDDEN = ("..", "@{", "//", "\\", "^", "~", ":", "?", "*", "[")

#: The fields ``repo_view`` asks for. A closed list: ``gh --json`` takes one, and
#: an open-ended dump of every field a host knows is not evidence, it is noise.
_REPO_FIELDS = (
    "name",
    "owner",
    "visibility",
    "isArchived",
    "isFork",
    "isPrivate",
    "defaultBranchRef",
    "pushedAt",
    "createdAt",
    "diskUsage",
    "licenseInfo",
    "hasIssuesEnabled",
    "hasVulnerabilityAlertsEnabled",
)

#: A pull-request body is prose a human reads; this is a ceiling, not a policy.
BODY_CEILING = 4000


@dataclass(frozen=True)
class RepoView:
    """A repository as its own host describes it. Facts the host published."""

    slug: str
    visibility: str = ""
    default_branch: str = ""
    archived: bool = False
    fork: bool = False
    pushed_at: str = ""
    created_at: str = ""
    license: str = ""
    disk_usage_kb: int = 0
    vulnerability_alerts: bool = False
    raw: dict[str, Any] | None = None


def _slug(target: str) -> str:
    text = str(target or "").strip()
    for prefix in ("https://github.com/", "http://github.com/", "github.com/", "gh://"):
        text = text.removeprefix(prefix)
    text = text.removesuffix(".git").strip("/")
    if not _SLUG.match(text):
        raise ValueError(
            f"{target!r} is not a github.com repository. Give it as "
            f"github.com/owner/name"
        )
    return text


def _branch(name: Any, *, field: str) -> str:
    text = str(name or "").strip()
    if not text:
        raise ValueError(f"a pull request needs the {field} branch")
    if not _BRANCH.match(text) or any(part in text for part in _BRANCH_FORBIDDEN):
        raise ValueError(f"refusing an unparseable {field} branch: {name!r}")
    return text


def _gh_env() -> dict[str, str]:
    """The environment one ``gh`` child gets: no prompt, no self-update, a token.

    ``GH_TOKEN`` in the environment is the documented way to authenticate a
    non-interactive ``gh``, and it keeps the credential off the command line.
    """
    env = {
        "GH_PROMPT_DISABLED": "1",
        "GH_NO_UPDATE_NOTIFIER": "1",
        "GH_PAGER": "cat",
    }
    token = get_settings().github_token
    if token:
        env["GH_TOKEN"] = token
    return env


class GitHubAdapter(ToolAdapter):
    """``gh``, with an argv assembled from a closed set of validated values."""

    name = "gh"

    # -------------------------------------------------------------- to build
    def build_argv(self, target: str, **options: Any) -> list[str]:
        slug = _slug(target)
        operation = str(options.get("operation") or "repo_view").strip().lower()

        if operation == "repo_view":
            return ["gh", "repo", "view", slug, "--json", ",".join(_REPO_FIELDS)]

        if operation == "pr_create":
            title = str(options.get("title") or "").strip()
            if not title:
                raise ValueError("a pull request needs a title")
            if len(title) > 200 or any(char in title for char in "\r\n\x00"):
                raise ValueError("refusing a title with a newline or 200+ characters")
            body = str(options.get("body") or "").strip()[:BODY_CEILING]
            argv = [
                "gh",
                "pr",
                "create",
                "--repo",
                slug,
                "--base",
                _branch(options.get("base"), field="base"),
                "--head",
                _branch(options.get("head"), field="head"),
                "--title",
                title,
            ]
            if body:
                argv += ["--body", body]
            else:
                argv += ["--body", ""]
            return argv

        raise ValueError(
            f"{operation!r} is not a gh operation this adapter performs: "
            f"repo_view or pr_create"
        )

    def run_options(
        self, target: str, context: ToolContext, **options: Any
    ) -> dict[str, Any]:
        """The token and the non-interactive switches, for either operation."""
        return {"env": _gh_env()}

    # ---------------------------------------------------------------- parse
    def parse(self, command: CommandResult) -> Any:
        if "--json" in command.argv:
            return self._parse_repo(command)
        return self._parse_pr(command)

    @staticmethod
    def _failed(command: CommandResult, doing: str) -> ToolExecutionError:
        detail = (command.stderr or command.stdout or "").strip().splitlines()
        hint = f": {detail[-1][:200]}" if detail else ""
        return ToolExecutionError(f"gh could not {doing} (rc {command.returncode}){hint}")

    def _parse_repo(self, command: CommandResult) -> RepoView:
        if command.returncode != 0:
            lower = (command.stderr or "").lower()
            if "auth" in lower or "logged in" in lower or "token" in lower:
                raise ToolExecutionError(
                    "gh is not authenticated for this machine, so the repository "
                    "could not be read: set GITHUB_TOKEN, or report this as not "
                    "tested rather than as an empty repository"
                )
            raise self._failed(command, "read the repository")
        try:
            payload = json.loads(command.stdout or "{}")
        except json.JSONDecodeError as trouble:
            raise ToolExecutionError(
                f"gh did not answer with JSON ({trouble}); nothing can be read"
            ) from trouble
        if not isinstance(payload, dict):
            raise ToolExecutionError("gh answered with something that is not a repository")
        owner = payload.get("owner") or {}
        slug = str(payload.get("name") or "")
        if isinstance(owner, dict) and owner.get("login"):
            slug = f"{owner['login']}/{slug}"
        branch = payload.get("defaultBranchRef") or {}
        license_info = payload.get("licenseInfo") or {}
        return RepoView(
            slug=slug,
            visibility=str(payload.get("visibility") or ""),
            default_branch=str(branch.get("name") or "") if isinstance(branch, dict) else "",
            archived=bool(payload.get("isArchived")),
            fork=bool(payload.get("isFork")),
            pushed_at=str(payload.get("pushedAt") or ""),
            created_at=str(payload.get("createdAt") or ""),
            license=str(license_info.get("spdxId") or "")
            if isinstance(license_info, dict)
            else "",
            disk_usage_kb=int(payload.get("diskUsage") or 0),
            vulnerability_alerts=bool(payload.get("hasVulnerabilityAlertsEnabled")),
            raw=payload,
        )

    def _parse_pr(self, command: CommandResult) -> str:
        if command.returncode != 0:
            raise self._failed(command, "open the pull request")
        return (command.stdout or "").strip()

    # ------------------------------------------------------------- summarize
    def summarize(self, parsed: Any) -> dict[str, Any]:
        if isinstance(parsed, RepoView):
            return {
                "repo_slug": parsed.slug,
                "repo_visibility": parsed.visibility,
                "repo_archived": parsed.archived,
                "repo_fork": parsed.fork,
                "repo_pushed_at": parsed.pushed_at,
                "repo_license": parsed.license,
                "repo_default_branch": parsed.default_branch,
                "repo_vulnerability_alerts": parsed.vulnerability_alerts,
            }
        if isinstance(parsed, str):
            return {"repo_pr_url": parsed[:200]}
        return {}


def repo_view(target: str, context: ToolContext, **options: Any) -> ToolResult:
    """Read a repository's published metadata."""
    return GitHubAdapter().run(target, context, operation="repo_view", **options)


def pr_create(target: str, context: ToolContext, **options: Any) -> ToolResult:
    """Open a pull request from a branch that already exists on the remote."""
    return GitHubAdapter().run(target, context, operation="pr_create", **options)
