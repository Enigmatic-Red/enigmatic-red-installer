"""dnsx adapter.

dnsx is the resolver behind the rest of a recon phase: it turns a name into the
records that say what it is - an address, a CNAME to a third party, an MX that
belongs to a different provider. The guard registers it `PASSIVE`: a DNS query
goes to a resolver, not to the customer's own service, so it is not a request
their SOC sees as a connection to them.

What the adapter fixes, and why:

* ``-json``: one JSON object per name on stdout, which is what the parser reads
  and what the audit entry hashes. ``-silent`` and ``-nc`` keep that stream
  strictly parsable - no banner, no progress meter, no ANSI escapes.
* ``-duc``: no update check, so a scan never reaches out on its own.
* ``-resp``: keep the raw zone lines dnsx received. The typed fields
  (``a``, ``cname``, ...) are this project's reading of the answer; ``all`` is
  the answer, and a finding that cannot be traced back to the line it came from
  is not evidence.
* ``-retry`` fixed at 2: one retry over a UDP query is recovery from packet
  loss, not a flood; the value is fixed here so a passthrough cannot raise it.
* ``-t`` / ``-rl`` / ``-timeout`` are clamped (25 threads, 150 queries a second,
  10 seconds), and ``-rl`` is set on every run: dnsx defaults to no rate limit
  at all, which is exactly the setting that turns a lookup into a burst a
  resolver will treat as abuse.

The target travels the way dnsx takes names - **on stdin**, one name to a line,
not in the argv. dnsx reads a name list there and ignores its positional
arguments, so a target appended to the argv would be silently dropped; that was
observed, not assumed (``dnsx -a -json -silent example.com`` answers nothing,
the same line piped in answers the name). The audit entry is unaffected: the
target is a first-class field of every record this adapter writes, and a target
that cannot be fed as a plain line is refused as plainly as one that starts with
a dash.

Three families of flag stay refused even when a human has approved the action.
``-l``/``-list``: a name list read from a file would bypass the scope check,
which only ever sees the one target this adapter was called with. ``-o``/
``-output``/``-ot``/``-output-template``: results written to local disk are an
artifact this build has no evidence store to keep honest, and a template would
replace the JSON the parser reads. ``-r``/``-resolvers`` is refused because the
resolver decides who sees the run's queries - naming one is a decision about
disclosure, not about the target. ``-asn`` is refused because the attribution is
not resolved locally: dnsx's own ``asnmap`` client asks asnmap's online service
(``libs.DefaultClient``), which is egress this project does not make while aimed
at a customer. And ``-resp-only``/``-ro`` is refused because it changes the
output shape out from under the parser rather than adding to it.
"""

from __future__ import annotations

from typing import Any, Sequence

from safety.errors import ToolExecutionError
from tools.base import ToolAdapter, ToolContext, ToolResult
from tools.parsers import DnsxRecord, parse_dnsx_jsonl
from tools.runner import CommandResult

__all__ = [
    "BINARY",
    "DNSX_RECORD_FLAGS",
    "DNSX_REFUSED_FLAGS",
    "DnsxAdapter",
    "RATE_LIMIT_CEILING",
    "RETRY",
    "THREADS_CEILING",
    "TIMEOUT_CEILING_S",
    "scan",
]

#: The scanner's executable, as it is spelled on ``PATH``.
BINARY = "dnsx"

#: The record types this adapter can ask for, and the flag each one takes. The
#: parser has a field for every one of them, so a request cannot ask for a type
#: whose answer would be dropped on the floor.
DNSX_RECORD_FLAGS: dict[str, str] = {
    "a": "-a",
    "aaaa": "-aaaa",
    "cname": "-cname",
    "ns": "-ns",
    "mx": "-mx",
    "txt": "-txt",
    "soa": "-soa",
    "srv": "-srv",
    "ptr": "-ptr",
    "caa": "-caa",
}


#: Flags that would turn a scoped lookup into something else. Each carries its
#: own sentence, because the refusal is what an operator reads.
DNSX_REFUSED_FLAGS: dict[str, str] = {
    "-l": "a name list read from a file would bypass the scope check",
    "-list": "a name list read from a file would bypass the scope check",
    "-o": "results would be written to local disk as a scan artifact",
    "-output": "results would be written to local disk as a scan artifact",
    "-ot": "an output template would replace the JSON the parser reads",
    "-output-template": "an output template would replace the JSON the parser reads",
    "-r": "the resolver decides who sees the run's queries",
    "-resolvers": "the resolver decides who sees the run's queries",
    "-proxy": "the proxy decides who else sees the run's queries",
    "-p": "the proxy decides who else sees the run's queries",
    "-ro": "the response-only shape is not the JSON the parser reads",
    "-resp-only": "the response-only shape is not the JSON the parser reads",
    "-asn": (
        "attribution is not resolved locally: dnsx asks asnmap's online service, "
        "which is egress this project does not make while aimed at a customer"
    ),
    "-t": "the thread count is set by this adapter's own bound",
    "-threads": "the thread count is set by this adapter's own bound",
    "-rl": "the query rate is set by this adapter's own bound",
    "-rate-limit": "the query rate is set by this adapter's own bound",
    "-timeout": "the per-query timeout is set by this adapter's own bound",
    "-rt": "the retry count is fixed by this adapter",
    "-retry": "the retry count is fixed by this adapter",
    "-up": (
        "an update check is egress this project does not make while aimed at a "
        "customer"
    ),
    "-update": (
        "an update check is egress this project does not make while aimed at a "
        "customer"
    ),
    "-hf": "the system hosts file is a local source the scope check never saw",
    "-hostsfile": "the system hosts file is a local source the scope check never saw",
    "-trace": "a trace walks the delegation chain, which is more than a lookup",
    "-trace-max-recursion": (
        "a trace walks the delegation chain, which is more than a lookup"
    ),
    "-resume": "resuming takes its input from a previous run's file",
    "-stream": "stream mode takes its input as a stream this adapter does not feed",
    "-stats": "a progress meter is not the JSON the parser reads",
    "-v": "verbose output is not the JSON the parser reads",
    "-verbose": "verbose output is not the JSON the parser reads",
    "-raw": "raw debug output is not the JSON the parser reads",
    "-debug": "raw debug output is not the JSON the parser reads",
    "-rc": "filtering by response code would hide the answers this run was asked for",
    "-rcode": (
        "filtering by response code would hide the answers this run was asked for"
    ),
    "-rtf": "filtering by record type would hide the answers this run was asked for",
    "-response-type-filter": (
        "filtering by record type would hide the answers this run was asked for"
    ),
}

#: Every flag this dnsx understands, taken from its own ``-h``. A passthrough
#: flag outside this set is refused rather than passed on, because ``-silent``
#: makes an unknown flag fail *invisibly*: dnsx prints its error to a stream it
#: has been asked to keep quiet, exits 0 with no output, and a run that died at
#: its first argument would be recorded as "the name has no records" - a false
#: finding, which is the one thing this product must not produce.
DNSX_KNOWN_FLAGS: frozenset[str] = frozenset(
    {
        "-l",
        "-list",
        "-d",
        "-domain",
        "-w",
        "-wordlist",
        "-a",
        "-aaaa",
        "-cname",
        "-ns",
        "-txt",
        "-srv",
        "-ptr",
        "-mx",
        "-soa",
        "-any",
        "-axfr",
        "-caa",
        "-all",
        "-e",
        "-re",
        "-resp",
        "-ro",
        "-resp-only",
        "-rc",
        "-rcode",
        "-rtf",
        "-response-type-filter",
        "-cdn",
        "-asn",
        "-t",
        "-threads",
        "-rl",
        "-rate-limit",
        "-up",
        "-update",
        "-duc",
        "-disable-update-check",
        "-o",
        "-output",
        "-j",
        "-json",
        "-omit-raw",
        "-or",
        "-ot",
        "-output-template",
        "-hc",
        "-silent",
        "-v",
        "-verbose",
        "-raw",
        "-debug",
        "-stats",
        "-version",
        "-nc",
        "-no-color",
        "-retry",
        "-rt",
        "-hf",
        "-hostsfile",
        "-trace",
        "-trace-max-recursion",
        "-resume",
        "-stream",
        "-timeout",
        "-auth",
        "-r",
        "-resolvers",
        "-wt",
        "-wildcard-threshold",
        "-wd",
        "-wildcard-domain",
        "-auto-wildcard",
        "-proxy",
        "-p",
    }
)

#: Bounds chosen so one run cannot look like a resolver burst.
THREADS_CEILING = 25
RATE_LIMIT_CEILING = 150
TIMEOUT_CEILING_S = 10

#: One retry over UDP is loss recovery; the adapter fixes it so passthrough
#: cannot raise it.
RETRY = 2


def _record_args(record_types: Sequence[str]) -> list[str]:
    """Map requested record types onto dnsx's flags, refusing anything else.

    A bare run asks for ``A``: it is the record that answers "does this name
    point anywhere", and a lookup that returns addresses is the cheapest useful
    thing a recon phase can have.
    """
    wanted = [str(value).strip().lower().lstrip("-") for value in record_types]
    if not wanted:
        wanted = ["a"]
    out: list[str] = []
    for name in wanted:
        flag = DNSX_RECORD_FLAGS.get(name)
        if flag is None:
            raise ValueError(
                f"refusing an unknown dnsx record type: {name!r}; this adapter "
                f"can ask for {', '.join(sorted(DNSX_RECORD_FLAGS))}"
            )
        if flag not in out:
            out.append(flag)
    return out


def _checked_extra_args(extra_args: Sequence[str]) -> list[str]:
    """Refuse the ``extra_args`` that would escape the controls; keep the rest.

    Two checks, and the second is the less obvious one. The guard classifies the
    finished command line, but it cannot see what a flag *means* to dnsx: which
    stream the run reads its names from, where its output goes, who resolves it,
    which service it asks for attribution. Those are named in
    :data:`DNSX_REFUSED_FLAGS`. Anything that is not a dnsx flag at all is
    refused too, because ``-silent`` turns a mistyped flag into an empty result
    that reads as "no such record" (see :data:`DNSX_KNOWN_FLAGS`).
    """
    out: list[str] = []
    for value in extra_args:
        text = str(value)
        flag = text.split("=", 1)[0].strip().lower()
        reason = DNSX_REFUSED_FLAGS.get(flag)
        if reason:
            raise ValueError(f"refusing dnsx flag {flag!r}: {reason}")
        if flag.startswith("-") and flag not in DNSX_KNOWN_FLAGS:
            raise ValueError(
                f"refusing dnsx flag {flag!r}: dnsx has no such flag, and under "
                "-silent an unknown flag produces no output at all - a run that "
                "died on its arguments would be recorded as a name with no records"
            )
        out.append(text)
    return out


class DnsxAdapter(ToolAdapter):
    """``dnsx -json`` for one name: the records that say what it is."""

    name = "dnsx"

    def build_argv(
        self,
        target: str,
        *,
        record_types: Sequence[str] = (),
        response: bool = True,
        threads: int = 20,
        rate_limit: int = 50,
        timeout_s: int = 5,
        extra_args: Sequence[str] = (),
    ) -> list[str]:
        """Build the argv. The target is *not* in it - see :meth:`run_options`."""
        target = str(target).strip()
        if not target:
            raise ValueError("no target given to dnsx")
        if target.startswith("-"):
            raise ValueError(f"refusing a target that looks like an option: {target!r}")
        if "\n" in target or "\r" in target:
            raise ValueError(
                "refusing a target with a line break in it: dnsx reads names one "
                "per line, so a second line would be a second, unchecked target"
            )

        argv = [BINARY, "-json", "-silent", "-nc", "-duc"]
        argv += _record_args(record_types)
        if response:
            argv.append("-resp")
        argv += ["-retry", str(RETRY)]
        argv += ["-t", str(self._bounded(threads, THREADS_CEILING))]
        argv += ["-rl", str(self._bounded(rate_limit, RATE_LIMIT_CEILING))]
        argv += ["-timeout", str(self._bounded(timeout_s, TIMEOUT_CEILING_S))]
        argv += _checked_extra_args(extra_args)
        return argv

    def run_options(
        self, target: str, context: ToolContext, **options: Any
    ) -> dict[str, Any]:
        """Feed the one target on stdin, which is where dnsx reads a name list.

        The value is the scope-checked target, one line, and nothing else: the
        child sees exactly the name this run was authorised for, and an argv
        that carries no target cannot be copied into a shell as if it were the
        whole command.
        """
        name = str(target).strip()
        if not name:
            raise ToolExecutionError("no target given to dnsx")
        return {"stdin": f"{name}\n"}

    @staticmethod
    def _bounded(value: int, ceiling: int) -> int:
        """Clamp to ``1..ceiling``: plausible values in, plausible values out."""
        return max(1, min(ceiling, int(value)))

    def parse(self, command: CommandResult) -> tuple[DnsxRecord, ...]:
        records = tuple(parse_dnsx_jsonl(command.stdout))
        if records:
            return records
        if command.returncode != 0:
            raise ToolExecutionError(
                f"dnsx exited with rc {command.returncode} and returned no record, "
                "so the run could not be interpreted"
            )
        if command.stdout.strip():
            lines = len(command.stdout.splitlines())
            raise ToolExecutionError(
                "dnsx produced output but no record could be recovered "
                f"({lines} line(s), {len(command.stdout)} bytes); output is not "
                "dnsx JSONL"
            )
        # rc 0 and no output is dnsx answering the question: the name has no
        # record of the types that were asked for. That is a finding - the
        # target was queried and does not resolve - not a failure of the run.
        return records

    def summarize(self, parsed: Any) -> dict[str, Any]:
        if not isinstance(parsed, tuple):
            return {}
        by_type: dict[str, int] = {}
        by_status: dict[str, int] = {}
        hosts: list[str] = []
        addresses: list[str] = []
        aliases: list[str] = []
        unresolved: list[str] = []
        for record in parsed:
            name = record.hostname
            if name and name not in hosts:
                hosts.append(name)
            if record.status_code:
                by_status[record.status_code] = by_status.get(record.status_code, 0) + 1
            if not record.resolved:
                if name and name not in unresolved:
                    unresolved.append(name)
                continue
            answer = record.answer_type or "OTHER"
            by_type[answer] = by_type.get(answer, 0) + 1
            for address in (*record.addresses, *record.ipv6):
                if address not in addresses:
                    addresses.append(address)
            for alias in record.cname:
                if alias not in aliases:
                    aliases.append(alias)
        return {
            "queries": len(parsed),
            "resolved": sum(1 for record in parsed if record.resolved),
            "unresolved": unresolved[:25],
            "by_answer_type": dict(sorted(by_type.items())),
            "by_status_code": dict(sorted(by_status.items())),
            "hosts": hosts[:25],
            "addresses": addresses[:25],
            "cnames": aliases[:25],
            "resolvers": sorted(
                {resolver for record in parsed for resolver in record.resolver}
            )[:10],
        }


def scan(target: str, context: ToolContext, **options: Any) -> ToolResult:
    """Convenience wrapper: ``scan(name, context, record_types=[\"a\", \"mx\"])``."""
    return DnsxAdapter().run(target, context, **options)

