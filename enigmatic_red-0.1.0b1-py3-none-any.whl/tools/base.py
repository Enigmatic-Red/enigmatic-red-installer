"""The adapter contract: the only sanctioned path from a plan to a target.

Order matters, and it is fixed here rather than in each adapter:

1. Kill switch. A halt stops everything, immediately.
2. Authorization. A dated, verified attestation must cover this target.
3. Scope. The target itself must be inside the signed scope.
4. Guard. The exact argv must not be in a forbidden class, and if it is
   intrusive a human approval for *that* command must exist.
5. Audit *before* execution. If the decision cannot be recorded, the action
   does not happen — an unauditable scan is worse than a refused one.
6. Rate limit and concurrency slot.
7. Run, then audit the outcome, then parse.

Every failure is a refusal that raises (or, for a missing binary, a skipped
result), and each one is written to the audit log, because "we did not scan
that" is as important to the customer as "we did".
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Mapping, Sequence

from safety.audit import AuditLog
from safety.authz import Attestation, AuthorizationGate
from safety.errors import (
    ApprovalRequired,
    ForbiddenActionError,
    KillSwitchEngaged,
    ScopeViolation,
    ToolExecutionError,
)
from safety.guard import Guard, GuardDecision
from safety.killswitch import KillSwitch
from safety.ratelimit import RateLimiter
from safety.scope import Scope
from tools.runner import CommandResult, LocalSubprocessRunner, ToolRunner

__all__ = ["ToolAdapter", "ToolContext", "ToolResult"]


@dataclass(frozen=True)
class ToolContext:
    """Everything an adapter must consult before it runs anything.

    Args:
        scan_id: ties every audit entry of one scan together.
        scope: the signed scope; re-checked per target, never cached.
        guard: action guard, including operator policy from ``policy.yaml``.
        limiter: per-host throttle and worker concurrency cap.
        audit: append-only log. A write failure aborts the action.
        attestation: the authorization this scan runs under.
        gate: when supplied, authorization is re-verified for each target
            rather than only at scan start.
        killswitch: optional operator halt control.
        approved: exact command strings a human has approved for this scan.
        timeout_s: wall-clock ceiling for one tool run.
        mock_runner: a ``ToolRunner`` to use instead of a real subprocess.
    """

    scan_id: str
    scope: Scope
    guard: Guard
    limiter: RateLimiter
    audit: AuditLog
    attestation: Attestation | None = None
    gate: AuthorizationGate | None = None
    killswitch: KillSwitch | None = None
    org: str | None = None
    actor: str = "planner"
    approved: frozenset[str] = frozenset()
    timeout_s: float = 600.0
    runner: ToolRunner | None = None

    def runner_or_default(self) -> ToolRunner:
        return self.runner if self.runner is not None else LocalSubprocessRunner()


@dataclass(frozen=True)
class ToolResult:
    """What an adapter returns: raw output, parsed data, and the audit trail."""

    tool: str
    argv: tuple[str, ...] = ()
    command: CommandResult | None = None
    parsed: Any = None
    skipped: bool = False
    skip_reason: str = ""
    parse_error: str = ""
    audit_seq: int = 0

    @property
    def ran(self) -> bool:
        return not self.skipped and self.command is not None

    @property
    def ok(self) -> bool:
        return self.ran and bool(self.command and self.command.ok) and not self.parse_error

    def describe(self) -> dict[str, Any]:
        """Log-safe summary: never includes raw tool output."""
        return {
            "tool": self.tool,
            "argv": list(self.argv),
            "skipped": self.skipped,
            "skip_reason": self.skip_reason,
            "parse_error": self.parse_error,
            "ran": self.ran,
            **({"command": self.command.describe()} if self.command else {}),
        }


class ToolAdapter(ABC):
    """Base class for one tool: builds argv, runs it, parses it.

    Subclasses implement :meth:`build_argv` and :meth:`parse`. The enforcement
    chain lives here so a new adapter cannot forget, reorder or weaken it.
    """

    #: Registered name; must match ``config/domains.yaml`` and the guard table.
    name: str = "tool"

    # -------------------------------------------------------------- to build
    @abstractmethod
    def build_argv(self, target: str, **options: Any) -> list[str]:
        """Return the exact argv, ``argv[0]`` being the tool name."""

    @abstractmethod
    def parse(self, command: CommandResult) -> Any:
        """Turn raw output into structured data. Raises on unusable output."""

    def summarize(self, parsed: Any) -> dict[str, Any]:
        """Audit detail describing what was found (optional)."""
        return {}

    def run_options(
        self, target: str, context: "ToolContext", **options: Any
    ) -> Mapping[str, Any]:
        """Extra process settings for this one run: ``env``, ``cwd``, ``stdin``.

        Three rules make this the *only* sanctioned place for any of them:

        * **Not a place for an inherited secret.** The runner starts every child
          with an allow-list environment that deliberately drops ``*_TOKEN``. An
          adapter that needs a credential for one invocation supplies it here, so
          it reaches exactly one child and never the command line - the full
          argv is written into the append-only audit log, where a token could
          never be removed.
        * **Not a place to widen the filesystem.** ``cwd`` is for a directory the
          operator nominated, such as the checkout a ``push`` publishes from.
        * **Not a place to put a command line.** ``stdin`` is for a tool that
          takes its input as data rather than as an argument: ``dnsx`` resolves
          the names it reads on stdin. What travels there is still the
          scope-checked target of this run, it reaches exactly one child, and
          the audit entry for the run names that target in full - so a run
          stays reproducible even though the name is not in the argv.

        Returns ``{}`` by default, which means the tool inherits exactly the
        allow-list environment and the process's own working directory.
        """
        return {}

    # ------------------------------------------------------------------ run
    def run(self, target: str, context: ToolContext, **options: Any) -> ToolResult:
        """Run this tool against ``target`` under every safety control."""
        self._assert_not_halted(target, context)
        host = self._assert_in_scope(target, context)
        self._assert_authorized(target, context)

        try:
            argv = [str(part) for part in self.build_argv(target, **options)]
        except ValueError as exc:
            # Pre-flight already refuses a bad value by catching ValueError from
            # this same call. At execution time the value must become a refusal
            # with the adapter's own sentence too, or it escapes the run as an
            # exception the planner has no entry for.
            self._record(
                context,
                "tool.refused",
                target=target,
                action=self.name,
                decision="refused",
                reason=str(exc),
            )
            raise ToolExecutionError(str(exc)) from exc
        except ToolExecutionError as exc:
            # A capability that cannot be built here - no directory nominated to
            # publish from, say - is reported like a binary that is not
            # installed: named, recorded, and skipped rather than guessed at.
            return self._skipped(target, [], "", str(exc), context)

        command_text = " ".join(argv)
        decision = context.guard.classify_command(self.name, argv[1:])
        self._assert_allowed(target, command_text, decision, context)

        # Written before execution, deliberately: if this record cannot be
        # stored the AuditLog raises, and the tool never runs.
        self._record(
            context,
            "tool.requested",
            target=target,
            action=command_text,
            action_class=decision.action_class.value,
            decision="allowed",
            matched_rules=list(decision.matched_rules),
        )

        context.limiter.acquire(host)
        context.limiter.acquire_slot()
        try:
            outcome = self._run_process(target, argv, command_text, context, **options)
        finally:
            context.limiter.release_slot()

        if isinstance(outcome, ToolResult):
            return outcome
        return self._finish(target, argv, command_text, decision, outcome, context)

    # ------------------------------------------------------------ enforcement
    def _assert_not_halted(self, target: str, context: ToolContext) -> None:
        if context.killswitch is None:
            return
        try:
            context.killswitch.check(context.org)
        except KillSwitchEngaged as exc:
            self._record(
                context,
                "tool.halted",
                target=target,
                action=self.name,
                decision="halted",
                reason=str(exc),
            )
            raise

    def _assert_in_scope(self, target: str, context: ToolContext) -> str:
        scope_decision = context.scope.check(target)
        if not scope_decision.allowed:
            self._record(
                context,
                "scope.refused",
                target=target,
                action=self.name,
                decision="refused",
                reason=scope_decision.reason,
                matched_rule=scope_decision.matched_rule or "",
            )
            raise ScopeViolation(
                f"refusing {self.name}: {target!r} is out of scope: "
                f"{scope_decision.reason}"
            )
        resolved = scope_decision.target
        return resolved.host if resolved is not None else target

    def _assert_authorized(self, target: str, context: ToolContext) -> None:
        """Re-verify the attestation for this target when a gate was supplied."""
        if context.gate is None:
            return
        context.gate.require(context.attestation, target, context.scope)

    def _assert_allowed(
        self,
        target: str,
        command_text: str,
        decision: GuardDecision,
        context: ToolContext,
    ) -> None:
        try:
            context.guard.enforce(
                decision,
                approved=command_text in context.approved,
                context=command_text,
            )
        except (ForbiddenActionError, ApprovalRequired) as exc:
            self._record(
                context,
                "tool.refused",
                target=target,
                action=command_text,
                action_class=decision.action_class.value,
                decision=(
                    "refused"
                    if isinstance(exc, ForbiddenActionError)
                    else "approval_required"
                ),
                reason=str(exc),
                matched_rules=list(decision.matched_rules),
            )
            raise

    # ------------------------------------------------------------- execution
    def _run_process(
        self,
        target: str,
        argv: list[str],
        command_text: str,
        context: ToolContext,
        **options: Any,
    ) -> CommandResult | ToolResult:
        try:
            settings = self.run_options(target, context, **options)
            runner = context.runner_or_default()
            stdin = settings.get("stdin")
            if stdin is None:
                # Passed only when an adapter asked for it: a runner a test
                # supplies must not have to know about stdin to serve the
                # tools that take no input at all.
                return runner.run(
                    argv,
                    timeout_s=context.timeout_s,
                    env=settings.get("env"),
                    cwd=settings.get("cwd"),
                )
            return runner.run(
                argv,
                timeout_s=context.timeout_s,
                env=settings.get("env"),
                cwd=settings.get("cwd"),
                stdin=str(stdin),
            )
        except ToolExecutionError as exc:
            # A missing binary is not a compliance failure. Report it and let
            # the scan continue without that capability.
            return self._skipped(target, argv, command_text, str(exc), context)

    def _skipped(
        self,
        target: str,
        argv: list[str],
        command_text: str,
        reason: str,
        context: ToolContext,
    ) -> ToolResult:
        """Record a capability that will not run, and say why. Never a guess."""
        seq = self._record(
            context,
            "tool.unavailable",
            target=target,
            action=command_text or self.name,
            decision="skipped",
            reason=reason,
        )
        return ToolResult(
            tool=self.name,
            argv=tuple(argv),
            skipped=True,
            skip_reason=reason,
            audit_seq=seq,
        )

    def _finish(
        self,
        target: str,
        argv: list[str],
        command_text: str,
        decision: GuardDecision,
        command: CommandResult,
        context: ToolContext,
    ) -> ToolResult:
        """Parse, then record the outcome — including a parse failure."""
        parsed: Any = None
        parse_error = ""
        try:
            parsed = self.parse(command)
        except ToolExecutionError as exc:
            # A timeout or a half-written file is not a bug: keep the run as
            # evidence and record why nothing could be extracted.
            parse_error = str(exc)

        seq = self._record(
            context,
            "tool.completed",
            target=target,
            action=command_text,
            action_class=decision.action_class.value,
            decision="ok" if command.ok else "error",
            parse_error=parse_error,
            **command.describe(),
            **(self.summarize(parsed) if parsed is not None else {}),
        )
        return ToolResult(
            tool=self.name,
            argv=tuple(argv),
            command=command,
            parsed=parsed,
            parse_error=parse_error,
            audit_seq=seq,
        )

    # ---------------------------------------------------------------- audit
    def _record(
        self,
        context: ToolContext,
        event: str,
        *,
        target: str,
        action: str,
        action_class: str = "",
        decision: str = "",
        **detail: Any,
    ) -> int:
        """Append one audit entry. Raises if it cannot be stored (fail closed)."""
        entry = context.audit.append(
            event,
            actor=context.actor,
            org=context.org,
            target=target,
            action=action,
            action_class=action_class or None,
            decision=decision or None,
            scan_id=context.scan_id,
            **detail,
        )
        return entry.seq

