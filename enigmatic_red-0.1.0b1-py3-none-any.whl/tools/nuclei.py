"""nuclei adapter.

nuclei is the assessment tool of the exploit phase, and the guard registers it
as ``INTRUSIVE``: every invocation needs a human approval of the *exact*
command line before it runs. This adapter therefore aims to make that approval
cheap to grant and easy to audit —

* the command line is built only from validated template ids/tags, a validated
  severity filter and the target, so what a human approved is reproducible from
  the audit entry alone;
* ``-no-interactsh`` is always set: a finding may not be confirmed through a
  third-party out-of-band service the customer never agreed to;
* ``-disable-update-check`` is always set: the run stays within the target,
  and a host with no template set fails loudly instead of downloading one;
* ``-jsonl`` is always set, because one JSON object per line is both the
  parser's input and the evidence trail.

Template provisioning is deliberately an out-of-band step (baked into the
runner image at M5, or installed by an operator): a scan must not pull code
from the internet while it is aimed at a customer.

Two classes of nuclei invocation stay refused *even with an approval*, because
the guard classifies the finished command line and hard-denies them: flood or
high-rate flags (``--min-rate 5000``, ``-r`` in the thousands) and the
brute-force / DoS rules. Fuzzing and exploit *template paths* are the other
way round — the guard's ``exploit_tooling`` rule classifies them ``INTRUSIVE``
rather than forbidden, so they run only under a human approval naming that
exact command. Neither behaviour is an oversight — do not work around it here.
"""

from __future__ import annotations

import re
from typing import Any, Sequence

from safety.errors import ToolExecutionError
from tools.base import ToolAdapter, ToolContext, ToolResult
from tools.parsers import SEVERITIES, NucleiFinding, parse_nuclei_jsonl
from tools.runner import CommandResult

__all__ = ["NucleiAdapter", "scan"]

#: A template is an id (``cve-2021-44228``) or a path under nuclei-templates
#: (``http/cves/2021/CVE-2021-44228.yaml``). Never something that starts with a
#: dash, and never whitespace, so it cannot become an option.
_TEMPLATE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._/-]*$")

#: Tags and exclude-tags: lowercase words nuclei ships (``cve``, ``xss``, ...).
_TAG = re.compile(r"^[a-z0-9][a-z0-9._-]*$")

#: ``Name: value`` with no CR/LF anywhere: a header is a place where a newline
#: would let a model inject a second header (or a whole second request).
_HEADER = re.compile(r"^[A-Za-z0-9][A-Za-z0-9-]*:[ \t]*[^\r\n\x00]+$")

#: Bounds chosen so one run cannot look like a flood from the target's side.
RATE_LIMIT_CEILING = 150
CONCURRENCY_CEILING = 25
PER_REQUEST_CEILING_S = 30


def _templates(values: Sequence[str]) -> list[str]:
    out: list[str] = []
    for value in values:
        text = str(value).strip()
        if not _TEMPLATE.match(text):
            raise ValueError(f"refusing an unparseable nuclei template: {value!r}")
        out.append(text)
    return out


def _tags(values: Sequence[str]) -> list[str]:
    out: list[str] = []
    for value in values:
        text = str(value).strip()
        if not _TAG.match(text):
            raise ValueError(f"refusing an unparseable nuclei tag: {value!r}")
        out.append(text)
    return out


def _severities(values: Sequence[str]) -> list[str]:
    out: list[str] = []
    for value in values:
        text = str(value).strip().lower()
        if text not in SEVERITIES:
            raise ValueError(
                f"unknown severity {value!r}; expected one of {', '.join(SEVERITIES)}"
            )
        out.append(text)
    return out


def _headers(values: Sequence[str]) -> list[str]:
    out: list[str] = []
    for value in values:
        text = str(value).strip()
        if not _HEADER.match(text):
            raise ValueError(f"refusing an unparseable request header: {value!r}")
        out.append(text)
    return out


class NucleiAdapter(ToolAdapter):
    """``nuclei -jsonl`` against one target, under an explicit approval."""

    name = "nuclei"

    def build_argv(
        self,
        target: str,
        *,
        templates: Sequence[str] = (),
        tags: Sequence[str] = (),
        exclude_tags: Sequence[str] = (),
        severities: Sequence[str] = (),
        rate_limit: int = 50,
        concurrency: int = 10,
        per_request_timeout_s: int = 10,
        headers: Sequence[str] = (),
        extra_args: Sequence[str] = (),
    ) -> list[str]:
        """Build the argv.

        ``templates`` or ``tags`` must be given: sweeping the entire template
        set against a customer's estate is neither what was sold nor what was
        approved, so a bare nuclei run is refused instead of guessed at.
        """
        target = str(target).strip()
        if not target:
            raise ValueError("no target given to nuclei")
        if target.startswith("-"):
            raise ValueError(f"refusing a target that looks like an option: {target!r}")

        template_list = _templates(templates)
        tag_list = _tags(tags)
        exclude_list = _tags(exclude_tags)
        if not template_list and not tag_list:
            raise ValueError(
                "refusing to run nuclei without explicit templates or tags: "
                "the full template set is not covered by an approval"
            )

        argv = ["nuclei", "-target", target, "-jsonl", "-silent", "-nc"]
        # Always on: no third-party out-of-band service, no self-update fetch.
        argv += ["-no-interactsh", "-disable-update-check"]
        for template in template_list:
            argv += ["-t", template]
        if tag_list:
            argv += ["-tags", ",".join(tag_list)]
        if exclude_list:
            argv += ["-etags", ",".join(exclude_list)]
        severity_list = _severities(severities)
        if severity_list:
            argv += ["-severity", ",".join(severity_list)]
        argv += ["-rate-limit", str(self._bounded(rate_limit, RATE_LIMIT_CEILING))]
        argv += ["-concurrency", str(self._bounded(concurrency, CONCURRENCY_CEILING))]
        argv += [
            "-timeout",
            str(self._bounded(per_request_timeout_s, PER_REQUEST_CEILING_S)),
        ]
        for header in _headers(headers):
            argv += ["-H", header]
        argv += [str(arg) for arg in extra_args]
        return argv

    @staticmethod
    def _bounded(value: int, ceiling: int) -> int:
        """Clamp to ``1..ceiling``: plausible values in, plausible values out."""
        return max(1, min(ceiling, int(value)))

    def parse(self, command: CommandResult) -> tuple[NucleiFinding, ...]:
        findings = tuple(parse_nuclei_jsonl(command.stdout))
        if findings:
            return findings
        if command.returncode != 0:
            # A failed run with nothing parsed must not read as "no findings
            # found". The one cause we can name without guessing is a host with
            # no template set: ``-disable-update-check`` means nuclei will not
            # fetch it mid-scan, so provisioning is an out-of-band step.
            hint = ""
            if "no templates" in (command.stderr or "").lower():
                hint = (
                    "; nuclei reports no templates provisioned and this adapter "
                    "never fetches templates mid-scan (provision them out of band)"
                )
            raise ToolExecutionError(
                f"nuclei exited with rc {command.returncode} and produced no "
                f"findings, so the run could not be interpreted{hint}"
            )
        if command.stdout.strip():
            # Output arrived but none of it was a finding: a bad template path
            # or a schema change, not an empty result.
            lines = len(command.stdout.splitlines())
            raise ToolExecutionError(
                "nuclei produced output but no finding could be recovered "
                f"({lines} line(s), {len(command.stdout)} bytes); "
                "output is not nuclei JSONL"
            )
        return findings

    def summarize(self, parsed: Any) -> dict[str, Any]:
        if not isinstance(parsed, tuple):
            return {}
        counts: dict[str, int] = {}
        hosts: list[str] = []
        for finding in parsed:
            counts[finding.severity] = counts.get(finding.severity, 0) + 1
            host = finding.hostname
            if host and host not in hosts:
                hosts.append(host)
        return {
            "findings": len(parsed),
            "by_severity": counts,
            "hosts": hosts[:25],
            "templates": sorted({f.template_id for f in parsed if f.template_id})[:25],
        }


def scan(target: str, context: ToolContext, **options: Any) -> ToolResult:
    """Convenience wrapper: ``scan(host, context, tags=["cve"], approved={...})``."""
    return NucleiAdapter().run(target, context, **options)
