"""Process execution for tool adapters.

Every adapter runs an external binary through a :class:`ToolRunner` rather than
calling :mod:`subprocess` itself. That indirection exists for three reasons:

1. **Credentials.** A scanner inherits whatever environment the platform hands
   it. A tool that trusts a target's input — or a target that can read this
   process's environment — would otherwise be able to leak our own AWS/Stripe/
   LLM keys. The runner starts every child with an *allow-list* environment,
   never a copy of the parent's.
2. **No shell.** Arguments go to ``execve``/``CreateProcess`` as a list, never
   interpolated into a command line, so a hostname from a customer's scope file
   can never become a command.
3. **One place to swap isolation.** M5 runs these same adapters inside a
   container behind an egress proxy; only this module changes.
4. **Input that is not an argument.** A name list is data, not a command, so
   ``dnsx`` reads the names it resolves on stdin: that stream goes to one child
   and to no other, and never through a shell.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping, Protocol, Sequence, runtime_checkable

from safety.errors import ToolExecutionError

__all__ = [
    "ALLOWED_ENV",
    "DEFAULT_OUTPUT_CAP",
    "TIMEOUT_RETURNCODE",
    "CommandResult",
    "LocalSubprocessRunner",
    "ToolRunner",
]

#: Environment variables a scanned-tool child process may inherit. Everything
#: else (``AWS_*``, ``STRIPE_*``, ``FEATHERLESS_API_KEY``, ``JWT_SECRET``,
#: ``*_TOKEN``, proxy credentials) is deliberately dropped.
ALLOWED_ENV: frozenset[str] = frozenset(
    {
        "PATH",
        "PATHEXT",
        "SYSTEMROOT",
        "SYSTEMDRIVE",
        "COMSPEC",
        "NUMBER_OF_PROCESSORS",
        "HOME",
        "USERPROFILE",
        "APPDATA",
        "LOCALAPPDATA",
        "PROGRAMDATA",
        "TEMP",
        "TMP",
        "TMPDIR",
        "LANG",
        "LC_ALL",
        "TZ",
    }
)

#: Bytes of stdout+stderr retained per run. A scanner pointed at a large estate
#: can emit hundreds of megabytes; one scan must not be able to exhaust memory.
DEFAULT_OUTPUT_CAP: int = 8 * 1024 * 1024

#: Conventional exit code for a process killed by the runner's timeout.
TIMEOUT_RETURNCODE = 124


@dataclass(frozen=True)
class CommandResult:
    """Outcome of one process run, including the output the adapter must parse."""

    argv: tuple[str, ...]
    returncode: int
    stdout: str = ""
    stderr: str = ""
    duration_ms: float = 0.0
    truncated: bool = False
    timed_out: bool = False

    @property
    def ok(self) -> bool:
        return self.returncode == 0 and not self.timed_out

    def describe(self) -> dict:
        """Log-safe summary: tool name and sizes, never the output itself."""
        return {
            "tool": self.argv[0] if self.argv else "",
            "returncode": self.returncode,
            "stdout_bytes": len(self.stdout),
            "stderr_bytes": len(self.stderr),
            "duration_ms": round(self.duration_ms, 1),
            "truncated": self.truncated,
            "timed_out": self.timed_out,
        }


@runtime_checkable
class ToolRunner(Protocol):
    """What an adapter is allowed to assume about process execution."""

    def run(
        self,
        argv: Sequence[str],
        *,
        timeout_s: float,
        env: Mapping[str, str] | None = None,
        cwd: Path | None = None,
        stdin: str | None = None,
    ) -> CommandResult:
        """Run ``argv`` and return its output. Raises if the tool is unrunnable.

        ``stdin`` carries input that is data rather than an argument: ``dnsx``
        reads the names to resolve on stdin, so its target travels there and not
        in an argv that the audit log keeps in full. It reaches one child, and
        a caller that passes nothing gets the child's inherited stdin as before.
        """

    def available(self, tool: str) -> bool:
        """Whether the binary exists, so a pack can report a degraded mode."""


class LocalSubprocessRunner:
    """Runs tools on this machine, with a scrubbed environment.

    Args:
        output_cap: maximum bytes of output retained per run.
        env_extra: values added on top of the allow-list (e.g. ``NUCLEI_...``),
            supplied by the caller, never inherited.
        search_path: override ``PATH`` for the child, for a pinned tool dir.

    Limitation, deliberately not hidden: a timeout kills the direct child, but
    grandchildren a tool spawned itself can outlive it. The container runner in
    M5 closes that gap; until then ``safety_job_timeout_s`` is the backstop.
    """

    def __init__(
        self,
        *,
        output_cap: int = DEFAULT_OUTPUT_CAP,
        env_extra: Mapping[str, str] | None = None,
        search_path: str | None = None,
    ) -> None:
        self.output_cap = max(1024, int(output_cap))
        self._env_extra = dict(env_extra or {})
        self._search_path = search_path

    # ------------------------------------------------------------------- env
    def build_env(self) -> dict[str, str]:
        """A fresh, allow-listed environment for one child process."""
        env = {key: value for key, value in os.environ.items() if key in ALLOWED_ENV}
        if self._search_path:
            env["PATH"] = self._search_path
        env.update(self._env_extra)
        return env

    def resolve(self, tool: str) -> str:
        """Absolute path of ``tool``, or raise with an actionable message."""
        name = (tool or "").strip()
        if not name:
            raise ToolExecutionError("no tool given to run")
        if Path(name).is_absolute() and Path(name).exists():
            return name
        found = shutil.which(name, path=self._search_path)
        if found is None:
            raise ToolExecutionError(
                f"{name!r} is not installed (not found on PATH). Install it, or "
                "drop it from the active domain pack; the scan continues without "
                "that capability."
            )
        return found

    def available(self, tool: str) -> bool:
        try:
            self.resolve(tool)
        except ToolExecutionError:
            return False
        return True

    # ------------------------------------------------------------------- run
    def run(
        self,
        argv: Sequence[str],
        *,
        timeout_s: float,
        env: Mapping[str, str] | None = None,
        cwd: Path | None = None,
        stdin: str | None = None,
    ) -> CommandResult:
        args = [str(part) for part in argv]
        if not args:
            raise ToolExecutionError("empty command")
        executable = self.resolve(args[0])
        child_env = self.build_env()
        child_env.update({str(key): str(value) for key, value in (env or {}).items()})
        # ``stdin`` is data, not a command: it goes down a pipe to this one child.
        # ``None`` leaves the child's stdin alone, so a tool that reads nothing
        # behaves exactly as it did before this parameter existed.
        payload = None if stdin is None else str(stdin).encode("utf-8")

        started = time.perf_counter()
        try:
            completed = subprocess.run(
                [executable, *args[1:]],
                input=payload,
                capture_output=True,
                shell=False,
                check=False,
                timeout=max(0.1, float(timeout_s)),
                env=child_env,
                cwd=str(cwd) if cwd else None,
            )
        except subprocess.TimeoutExpired as exc:
            return self._result(args, started, None, exc)

        return self._result(args, started, completed, None)

    # ------------------------------------------------------------- internals
    def _result(
        self,
        args: list[str],
        started: float,
        completed: subprocess.CompletedProcess | None,
        expired: subprocess.TimeoutExpired | None,
    ) -> CommandResult:
        duration_ms = (time.perf_counter() - started) * 1000.0
        if expired is not None:
            stdout, truncated = self._decode(expired.stdout)
            stderr, truncated_err = self._decode(expired.stderr)
            return CommandResult(
                argv=tuple(args),
                returncode=TIMEOUT_RETURNCODE,
                stdout=stdout,
                stderr=stderr,
                duration_ms=duration_ms,
                truncated=truncated or truncated_err,
                timed_out=True,
            )
        assert completed is not None
        stdout, truncated = self._decode(completed.stdout)
        stderr, truncated_err = self._decode(completed.stderr)
        return CommandResult(
            argv=tuple(args),
            returncode=completed.returncode,
            stdout=stdout,
            stderr=stderr,
            duration_ms=duration_ms,
            truncated=truncated or truncated_err,
        )

    def _decode(self, payload: bytes | str | None) -> tuple[str, bool]:
        """Decode tool output as UTF-8, replacing garbage, capped by policy."""
        if payload is None:
            return "", False
        if isinstance(payload, bytes):
            raw = payload
        else:
            raw = payload.encode("utf-8", "replace")
        truncated = len(raw) > self.output_cap
        text = raw[: self.output_cap].decode("utf-8", "replace")
        if truncated:
            text += f"\n[output truncated at {self.output_cap} bytes]"
        return text, truncated
