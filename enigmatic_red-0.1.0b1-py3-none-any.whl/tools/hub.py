"""Model-hub adapter: what a published model is, and the one write that publishes.

Two operations:

* ``model_info`` - read a model's public metadata from the hub API: its files,
  its licence, whether it is gated or private, and - the part that matters to a
  security review - whether it ships **pickle-format weights**. A ``.bin``/``.pt``
  checkpoint is executable content by construction: loading it runs code. The
  safe format is ``safetensors``, and "which of the two is in this repository"
  is a fact, not an opinion;
* ``upload`` - publish a file or directory into an in-scope model repository,
  from a path inside ``SAFETY_WRITE_ROOT``. Intrusive: it changes a third
  party's repository, so it needs a human approval of its exact command line.

Everything above the call is the ordinary enforcement chain - kill switch,
authorization, scope, guard, audit, rate limit - and it is *not* re-implemented
here. The one difference from the other adapters is that the read operation
talks HTTPS instead of spawning a process, because the hub's metadata is an API
and not a CLI: :meth:`HubAdapter._run_process` is overridden for that, and the
audit entry records the request that was made. The upload runs the real ``hf``
binary, and a machine without it reports the capability as skipped rather than
as absent.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from config.settings import get_settings
from safety.errors import ToolExecutionError
from tools.base import ToolAdapter, ToolContext, ToolResult
from tools.runner import CommandResult

__all__ = ["HubAdapter", "HubModel", "model_info", "upload"]

#: ``owner/name`` as the hub accepts it, and nothing that could become a path
#: segment of a URL we build: no ``..``, no ``//``, no percent-encoding.
_REPO_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]*/[A-Za-z0-9][A-Za-z0-9._-]*$")

#: A revision is a branch, tag or commit: hex, and no path characters.
_REVISION = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._/-]*$")

_REPO_TYPES = ("model", "dataset")

#: Extensions whose contents execute when loaded. Naming them is the finding.
_PICKLE_SUFFIXES = (".bin", ".pt", ".pth", ".pkl", ".pickle", ".ckpt", ".h5", ".msgpack")
_SAFE_SUFFIXES = (".safetensors", ".gguf")

HUB_ORIGIN = "https://huggingface.co"
#: Bytes of a metadata response we keep. A hub answer is JSON, not a scan.
RESPONSE_CEILING = 512 * 1024


@dataclass(frozen=True)
class HubModel:
    """A model as the hub describes it. Facts only, no verdict of our own."""

    repo_id: str
    files: tuple[str, ...] = ()
    private: bool = False
    gated: bool = False
    last_modified: str = ""
    downloads: int = 0
    pipeline_tag: str = ""
    license: str = ""
    library: str = ""
    tags: tuple[str, ...] = ()

    @property
    def pickle_weights(self) -> tuple[str, ...]:
        """Files that run code when a model is loaded from them."""
        return tuple(
            name
            for name in self.files
            if name.lower().endswith(_PICKLE_SUFFIXES) and not name.endswith(".json")
        )

    @property
    def safe_weights(self) -> tuple[str, ...]:
        """Files in a format that is data only."""
        return tuple(
            name for name in self.files if name.lower().endswith(_SAFE_SUFFIXES)
        )

    @property
    def custom_code(self) -> tuple[str, ...]:
        """``trust_remote_code`` files: the model ships its own Python."""
        return tuple(
            name
            for name in self.files
            if name.endswith(".py") and name.rsplit("/", 1)[-1] != "__init__.py"
        )



def _repo_id(target: str) -> str:
    text = str(target or "").strip()
    text = text.removeprefix("hf://").removeprefix("model://")
    text = text.removeprefix(f"{HUB_ORIGIN}/").removeprefix("huggingface.co/")
    text = text.strip("/")
    if not _REPO_ID.match(text):
        raise ValueError(
            f"{target!r} is not a hub repository id. Give it as owner/name, or "
            f"hf://owner/name"
        )
    return text


def _revision(value: Any) -> str:
    text = str(value or "main").strip()
    if not _REVISION.match(text) or ".." in text or "//" in text:
        raise ValueError(f"refusing an unparseable revision: {value!r}")
    return text


def _repo_type(value: Any) -> str:
    text = str(value or "model").strip().lower()
    if text not in _REPO_TYPES:
        raise ValueError(
            f"{text!r} is not a hub repository type this adapter handles: "
            f"{', '.join(_REPO_TYPES)}"
        )
    return text


def _write_root(source: Any) -> Path:
    """Validate the local path an ``upload`` publishes, under the write root."""
    root = str(get_settings().safety_write_root or "").strip()
    if not root:
        raise ToolExecutionError(
            "this install publishes nothing from a local directory: no "
            "SAFETY_WRITE_ROOT is set, so 'upload' has no files to publish. Set "
            "it to the directory you want this capability to publish from."
        )
    if not str(source or "").strip():
        raise ValueError("an upload needs the local path it publishes")
    path = Path(str(source)).expanduser()
    if not path.is_absolute():
        raise ValueError(f"refusing a relative upload path: {source!r}")
    resolved = path.resolve()
    root_resolved = Path(root).expanduser().resolve()
    if resolved != root_resolved and root_resolved not in resolved.parents:
        raise ValueError(
            f"refusing to upload {resolved}: an upload may only read a path "
            f"inside SAFETY_WRITE_ROOT ({root_resolved})"
        )
    if not resolved.exists():
        raise ValueError(f"{resolved} does not exist")
    return resolved


class HubAdapter(ToolAdapter):
    """A model hub: metadata over HTTPS, publishing through the ``hf`` binary."""

    name = "hf"

    def __init__(self, client: Any | None = None) -> None:
        """``client`` is an ``httpx.Client``-shaped object; tests inject one."""
        self._client = client

    # -------------------------------------------------------------- to build
    def build_argv(self, target: str, **options: Any) -> list[str]:
        repo_id = _repo_id(target)
        operation = str(options.get("operation") or "model_info").strip().lower()

        if operation == "model_info":
            # Not a process: the argv *is* the request, and it is what the audit
            # entry records. "GET" sits where the other adapters have a
            # subcommand, so the line reads as what it does.
            revision = _revision(options.get("revision"))
            return ["hf", "GET", f"/api/models/{repo_id}?blobs=false&revision={revision}"]

        if operation == "upload":
            repo_type = _repo_type(options.get("repo_type"))
            local = _write_root(options.get("source_path"))
            remote_name = str(options.get("path_in_repo") or "").strip().strip("/")
            if remote_name and (
                ".." in remote_name.split("/") or re.search(r"[\s\\]", remote_name)
            ):
                raise ValueError(f"refusing an unparseable path_in_repo: {remote_name!r}")
            argv = ["hf", "upload", repo_id, str(local)]
            if remote_name:
                argv.append(remote_name)
            return argv + ["--repo-type", repo_type]

        raise ValueError(
            f"{operation!r} is not a hub operation this adapter performs: "
            f"model_info or upload"
        )

    # --------------------------------------------------------------- execute
    def _run_process(
        self,
        target: str,
        argv: list[str],
        command_text: str,
        context: ToolContext,
        **options: Any,
    ) -> CommandResult | ToolResult:
        """A GET is an HTTPS request; an upload is a real child process.

        Overridden because this adapter's read has no binary behind it. The
        chain *above* this call - kill switch, authorization, scope, guard,
        audit, rate limit - is the base class's, unchanged and not restated:
        only the "run it" step differs.
        """
        if len(argv) > 2 and argv[1] == "GET":
            return self._request(argv)
        return super()._run_process(target, argv, command_text, context, **options)

    def _request(self, argv: list[str]) -> CommandResult:
        import httpx

        headers = {"User-Agent": "enigmatic-red"}
        token = get_settings().hf_token
        if token:
            headers["Authorization"] = f"Bearer {token}"
        url = f"{HUB_ORIGIN}{argv[2]}"
        try:
            if self._client is None:
                with httpx.Client(
                    timeout=httpx.Timeout(30.0), follow_redirects=False
                ) as fresh:
                    response = fresh.get(url, headers=headers)
            else:
                response = self._client.get(url, headers=headers)
        except httpx.HTTPError as trouble:
            raise ToolExecutionError(
                f"the hub could not be reached for {argv[2]}: {trouble}"
            ) from trouble

        body = response.text[:RESPONSE_CEILING]
        return CommandResult(
            argv=tuple(argv),
            returncode=0 if response.status_code == 200 else response.status_code,
            stdout=body if response.status_code == 200 else "",
            stderr="" if response.status_code == 200 else body[:400],
        )

    # ---------------------------------------------------------------- parse
    def parse(self, command: CommandResult) -> Any:
        if len(command.argv) > 2 and command.argv[1] == "GET":
            return self._parse_model(command)
        if command.returncode != 0:
            detail = (command.stderr or command.stdout or "").strip().splitlines()
            hint = f": {detail[-1][:200]}" if detail else ""
            raise ToolExecutionError(f"hf could not publish (rc {command.returncode}){hint}")
        return tuple(line.strip() for line in command.stdout.splitlines() if line.strip())

    @staticmethod
    def _parse_model(command: CommandResult) -> HubModel:
        if command.returncode == 404:
            raise ToolExecutionError(
                "the hub has no such repository (404): check the owner and the "
                "name, and whether the model is private"
            )
        if command.returncode in (401, 403):
            raise ToolExecutionError(
                f"the hub refused this read ({command.returncode}): the "
                f"repository is gated or private, so read it with a token that "
                f"has access, or report it as not tested"
            )
        if command.returncode != 0:
            raise ToolExecutionError(
                f"the hub answered {command.returncode}: "
                f"{(command.stderr or '').strip()[:200]}"
            )
        try:
            payload = json.loads(command.stdout or "{}")
        except json.JSONDecodeError as trouble:
            raise ToolExecutionError(
                f"the hub answer is not JSON ({trouble}); nothing can be read from it"
            ) from trouble
        if not isinstance(payload, dict):
            raise ToolExecutionError("the hub answer is not a model object")
        return HubAdapter._model(payload)

    @staticmethod
    def _model(payload: dict[str, Any]) -> HubModel:
        siblings = payload.get("siblings") or []
        files = tuple(
            str(entry.get("rfilename") or "")
            for entry in siblings
            if isinstance(entry, dict) and entry.get("rfilename")
        )
        raw_card = payload.get("cardData")
        card: dict[str, Any] = raw_card if isinstance(raw_card, dict) else {}
        return HubModel(
            repo_id=str(payload.get("id") or payload.get("modelId") or ""),
            files=files,
            private=bool(payload.get("private")),
            gated=bool(payload.get("gated")),
            last_modified=str(payload.get("lastModified") or ""),
            downloads=int(payload.get("downloads") or 0),
            pipeline_tag=str(payload.get("pipeline_tag") or ""),
            license=str(card.get("license") or payload.get("license") or ""),
            library=str(payload.get("library_name") or ""),
            tags=tuple(str(tag) for tag in (payload.get("tags") or ()))[:40],
        )

    # ------------------------------------------------------------- summarize
    def summarize(self, parsed: Any) -> dict[str, Any]:
        if isinstance(parsed, HubModel):
            return {
                "hub_repo_id": parsed.repo_id,
                "hub_files": len(parsed.files),
                "hub_private": parsed.private,
                "hub_gated": parsed.gated,
                "hub_license": parsed.license,
                "hub_last_modified": parsed.last_modified,
                # The supply-chain facts, named rather than scored: this adapter
                # reports what the repository holds, and the report decides.
                "hub_pickle_weights": list(parsed.pickle_weights)[:25],
                "hub_safetensors": len(parsed.safe_weights),
                "hub_custom_code": list(parsed.custom_code)[:25],
            }
        if isinstance(parsed, tuple):
            return {"hub_uploaded_paths": list(parsed)[:25]}
        return {}


def model_info(target: str, context: ToolContext, **options: Any) -> ToolResult:
    """Read a model's public metadata from the hub."""
    return HubAdapter().run(target, context, operation="model_info", **options)


def upload(target: str, context: ToolContext, **options: Any) -> ToolResult:
    """Publish a path under ``SAFETY_WRITE_ROOT`` into an in-scope model repo."""
    return HubAdapter().run(target, context, operation="upload", **options)

