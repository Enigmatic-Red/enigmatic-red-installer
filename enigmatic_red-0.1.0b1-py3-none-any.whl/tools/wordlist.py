"""Word lists for the two capabilities that need one: gobuster and ffuf.

Both tools discover paths by asking for a list of names and reporting which ones
answer. That makes the list itself the thing that decides how loud the run is,
and it makes an arbitrary local file a live exfiltration route: aiming a
discovery run at a file of secrets would send each line to the target as a path
and let the target's access log hold the secret. So a list is accepted from
exactly two places:

* ``builtin`` - the list below, compiled into this file. A default that needs no
  setup is what makes a run reproducible; a clone with no word list installed
  can still do the discovery the beta claims, and two machines with this
  repository produce the same requests.
* an absolute path to a file **inside** ``SAFETY_WRITE_ROOT`` - the same
  operator-nominated root that a ``git push`` reads its checkout from. The point
  of that root is that a human named it in advance, which is exactly what a
  local file this product sends to a customer has to have.

A relative path, a path outside the root, a directory, an empty file and a path
that is not a file are all refused with a sentence. Every refusal is a
``ToolExecutionError``, so an install that cannot supply a list reports the
capability as *skipped* rather than failing the scan.

The line count is what the adapters report back: how many requests a run asks
for is a fact about the run, and it belongs in the audit entry.
"""

from __future__ import annotations

import hashlib
import tempfile
from pathlib import Path
from typing import Sequence

from config.settings import get_settings
from safety.errors import ToolExecutionError

__all__ = [
    "BUILTIN_NAME",
    "BUILTIN_PATHS",
    "LIST_FLAGS",
    "builtin_lines",
    "builtin_path",
    "describe",
    "entry_count",
    "path_for",
    "path_from_argv",
]

#: The name that selects the compiled-in list.
BUILTIN_NAME = "builtin"

#: A short, unremarkable list of names that exist in a great many web
#: applications. It is deliberately small and deliberately boring: the point of
#: the default is that a run is reproducible and quiet, not that it is thorough.
#: Ordering is fixed, and the file it compiles to is named after its content, so
#: every machine writes the same bytes.
BUILTIN_PATHS: tuple[str, ...] = (
    ".git/HEAD",
    ".git/config",
    ".well-known/security.txt",
    ".well-known/change-password",
    "admin",
    "admin/",
    "api",
    "api/",
    "api/v1",
    "assets/",
    "backup",
    "backup.zip",
    "config",
    "config.json",
    "config.php",
    "console",
    "crossdomain.xml",
    "css/",
    "dashboard",
    "debug",
    "docs",
    "download",
    "favicon.ico",
    "health",
    "healthz",
    "images/",
    "index.php",
    "info.php",
    "js/",
    "login",
    "logout",
    "metrics",
    "phpinfo.php",
    "robots.txt",
    "server-status",
    "sitemap.xml",
    "static/",
    "status",
    "swagger.json",
    "swagger-ui.html",
    "uploads/",
    "web.config",
    "wp-admin/",
    "wp-login.php",
)


def _digest() -> str:
    """A short digest of the list, computed rather than written down."""
    text = "".join(f"{line}\n" for line in BUILTIN_PATHS)
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:12]


def builtin_lines() -> tuple[str, ...]:
    """The compiled-in list, one entry per line, as the tools read it."""
    return BUILTIN_PATHS


def builtin_path() -> Path:
    """Where the compiled-in list is materialised (written on demand)."""
    return Path(tempfile.gettempdir()) / f"red-wordlist-{BUILTIN_NAME}-{_digest()}.txt"


def _write_builtin() -> Path:
    """Materialise the compiled-in list, idempotently and byte-for-byte."""
    path = builtin_path()
    text = "".join(f"{line}\n" for line in BUILTIN_PATHS)
    try:
        if not (path.exists() and path.read_text(encoding="utf-8") == text):
            path.write_text(text, encoding="utf-8")
    except OSError as exc:  # pragma: no cover - depends on the machine
        raise ToolExecutionError(
            f"could not write the built-in word list to {path}: {exc}"
        ) from exc
    return path


def entry_count(path: Path) -> int:
    """Usable entries in ``path``: no blank lines, no ``#`` comments.

    An empty list is refused rather than run: a discovery run that asks for
    nothing would produce a clean report that means nothing at all.
    """
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError as exc:
        raise ToolExecutionError(f"could not read the word list {path}: {exc}") from exc
    lines = [
        line.strip()
        for line in text.splitlines()
        if line.strip() and not line.strip().startswith("#")
    ]
    if not lines:
        raise ToolExecutionError(
            f"the word list {path} has no usable entry, so the run would ask for "
            "nothing"
        )
    return len(lines)


def _nominated_file(value: str) -> Path:
    """An operator-nominated list, confined to ``SAFETY_WRITE_ROOT``."""
    root = str(get_settings().safety_write_root or "").strip()
    if not root:
        raise ToolExecutionError(
            "this install discovers with the built-in list only: no "
            "SAFETY_WRITE_ROOT is set, so no local word list may be used. Set it "
            "to the directory you keep word lists in, or ask for 'builtin'."
        )
    path = Path(value).expanduser()
    if not path.is_absolute():
        raise ToolExecutionError(f"refusing a relative word list path: {value!r}")
    resolved = path.resolve()
    root_resolved = Path(root).expanduser().resolve()
    if resolved != root_resolved and root_resolved not in resolved.parents:
        raise ToolExecutionError(
            f"refusing the word list {resolved}: its lines are sent to the target "
            "as paths, so it may only be a file inside SAFETY_WRITE_ROOT "
            f"({root_resolved})"
        )
    if not resolved.is_file():
        raise ToolExecutionError(f"{resolved} is not a file")
    return resolved


def path_for(value: str) -> Path:
    """The file gobuster or ffuf should be pointed at.

    ``builtin`` - what the adapters ask for when nothing was named - is
    materialised under the temporary directory. Anything else must be an
    absolute path inside ``SAFETY_WRITE_ROOT``. A bare name is never resolved
    against the working directory, where it would mean "whatever file happens to
    be next to the process".
    """
    name = str(value or "").strip() or BUILTIN_NAME
    if name.lower() in (BUILTIN_NAME, "default"):
        path = _write_builtin()
        entry_count(path)
        return path
    path = _nominated_file(name)
    entry_count(path)
    return path


def describe(path: Path) -> dict[str, object]:
    """What an audit entry records about the list this run used."""
    return {
        "wordlist": path.name,
        "wordlist_entries": entry_count(path),
    }


#: The spellings both discovery adapters use for "the list", in the order a
#: command line is searched for them: the short form first, because that is what
#: this build writes.
LIST_FLAGS: tuple[str, ...] = ("-w", "--wordlist")


def path_from_argv(argv: Sequence[str]) -> Path:
    """The list a command line names, read back out of that line.

    Each adapter resolves the name to a path once, in ``build_argv``, so the
    approved argv already holds it. Reading it back keeps the path in the one
    place the run records - the command line - rather than in instance state,
    which an adapter the registry holds once would share between runs.
    """
    parts = [str(part) for part in argv]
    for flag in LIST_FLAGS:
        if flag in parts:
            index = parts.index(flag)
            if index + 1 < len(parts):
                return Path(parts[index + 1])
    return Path("")

