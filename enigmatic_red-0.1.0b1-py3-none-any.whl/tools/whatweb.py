"""whatweb adapter.

whatweb fingerprints what an HTTP service *is*: the web server and its version,
the framework, the CMS, the JavaScript libraries, the page title. It is the
cheapest way to answer "what am I actually looking at" before anything is
tested, and it is the one capability here that is not a Go binary - it is a Ruby
program, so it is absent more often than the others. That is fine: an absent
binary is reported as *not tested* and never as *clean*.

What the adapter fixes, and why:

* ``-q``: quiet mode, which is whatweb's brief output without the banner - one
  line per target, ``http://host [200 OK] Title[x], HTTPServer[nginx/1.24.0]``.
  That one line is the whole result, which is why the parser reads it and no
  other shape.
* ``--color=never``: a colour escape inside that line would be read as part of a
  plugin cue.
* ``--aggression 1``: whatweb's level 1 makes one request per target. Levels 3
  and above guess URLs and up to level 4 tries more than a hundred requests per
  target, which is a fuzzer wearing a fingerprinting name; the flag is fixed
  here and refused in ``extra_args`` for the same reason.
* ``--max-threads``: clamped to 25. whatweb's default is 25 already, but the
  value is pinned so passthrough cannot raise it.
* ``--read-timeout`` / ``--open-timeout``: clamped to 10 seconds. whatweb's
  default read timeout is 15 and there is no ceiling of its own.

The target is a positional argument - whatweb takes its targets on the command
line - so the guard's view of the command line contains the host this run is
aimed at, exactly as it does for httpx and nmap.

Refused even with an approval behind them: ``--log-brief``/``--log-verbose``/
``--log-json``/``--output`` write results to local disk, which is an artifact
this build has no evidence store to keep honest; ``--input-file`` reads a target
list from a file, bypassing the scope check that only ever sees this one target;
``--proxy`` decides who else sees the run's requests; ``--cookie`` and
``--user``/``--password`` carry credentials, which this build does not handle;
``--aggression`` above 1 turns the fingerprint into a fuzz.
"""

from __future__ import annotations

from typing import Any, Sequence

from safety.errors import ToolExecutionError
from tools.base import ToolAdapter, ToolContext, ToolResult
from tools.parsers import WhatwebResult, parse_whatweb_brief
from tools.runner import CommandResult

__all__ = [
    "BINARY",
    "THREADS_CEILING",
    "TIMEOUT_CEILING_S",
    "WHATWEB_AGGRESSION",
    "WHATWEB_REFUSED_FLAGS",
    "WhatwebAdapter",
    "scan",
]

#: The scanner's executable, as it is spelled on ``PATH``.
BINARY = "whatweb"

#: One request per target, and no URL guessing. The parser's brief line is the
#: level-1 shape; levels 3 and up print more and ask far more.
WHATWEB_AGGRESSION = 1

#: Flags refused in ``extra_args`` even when the action was approved. Each
#: sentence says what the flag would change, because that is what an operator
#: needs to decide whether to ask again a different way.
WHATWEB_REFUSED_FLAGS: dict[str, str] = {
    "--log-brief": "results would be written to local disk as a scan artifact",
    "--log-verbose": "results would be written to local disk as a scan artifact",
    "--log-json": "results would be written to local disk as a scan artifact",
    "--log-xml": "results would be written to local disk as a scan artifact",
    "--log-errors": "results would be written to local disk as a scan artifact",
    "--output": "results would be written to local disk as a scan artifact",
    "-o": "results would be written to local disk as a scan artifact",
    "--input-file": (
        "a target list read from a file would bypass the scope check, which only "
        "sees the one target this adapter was called with"
    ),
    "-i": (
        "a target list read from a file would bypass the scope check, which only "
        "sees the one target this adapter was called with"
    ),
    "--proxy": "the proxy decides who else sees the run's requests",
    "--proxy-user": "the proxy decides who else sees the run's requests",
    "--cookie": "credentials are not handled by this build",
    "-c": "credentials are not handled by this build",
    "--user": "credentials are not handled by this build",
    "-u": "credentials are not handled by this build",
    "--password": "credentials are not handled by this build",
    "-p": "credentials are not handled by this build",
    "--aggression": (
        "levels above 1 guess URLs and issue many requests per target, which is "
        "content discovery, not fingerprinting"
    ),
    "-a": (
        "levels above 1 guess URLs and issue many requests per target, which is "
        "content discovery, not fingerprinting"
    ),
    "--max-threads": "the thread count is set by this adapter's own bound",
    "--read-timeout": "the timeout is set by this adapter's own bound",
    "--open-timeout": "the timeout is set by this adapter's own bound",
    "--wait": "the wait between requests is set by this adapter's own bound",
    "--url": "the target is the one this adapter was called with",
}

#: Bounds: one run must not look like a sweep.
THREADS_CEILING = 25
TIMEOUT_CEILING_S = 10


def _checked_extra_args(extra_args: Sequence[str]) -> list[str]:
    """Refuse the ``extra_args`` that would escape the controls; keep the rest."""
    out: list[str] = []
    for value in extra_args:
        text = str(value)
        flag = text.split("=", 1)[0].strip().lower()
        reason = WHATWEB_REFUSED_FLAGS.get(flag)
        if reason:
            raise ValueError(f"refusing whatweb flag {flag!r}: {reason}")
        out.append(text)
    return out


class WhatwebAdapter(ToolAdapter):
    """``whatweb -q`` for one URL: what the service says it is."""

    name = "whatweb"

    def build_argv(
        self,
        target: str,
        *,
        threads: int = 10,
        timeout_s: int = 10,
        user_agent: str = "",
        extra_args: Sequence[str] = (),
    ) -> list[str]:
        target = str(target).strip()
        if not target:
            raise ValueError("no target given to whatweb")
        if target.startswith("-"):
            raise ValueError(f"refusing a target that looks like an option: {target!r}")
        if "://" not in target:
            # whatweb accepts a bare host and assumes http, but the scheme is
            # part of what makes a finding reproducible, so it is required here
            # rather than guessed at.
            raise ValueError(
                f"refusing {target!r}: whatweb is given a URL with a scheme, e.g. "
                f"http://{target}/"
            )

        argv = [
            BINARY,
            "-q",
            "--color=never",
            f"--aggression={WHATWEB_AGGRESSION}",
            f"--max-threads={self._bounded(threads, THREADS_CEILING)}",
            f"--read-timeout={self._bounded(timeout_s, TIMEOUT_CEILING_S)}",
            f"--open-timeout={self._bounded(timeout_s, TIMEOUT_CEILING_S)}",
        ]
        agent = str(user_agent).strip()
        if agent:
            if "\n" in agent or "\r" in agent:
                raise ValueError("refusing a user agent with a line break in it")
            argv.append(f"--user-agent={agent}")
        argv += _checked_extra_args(extra_args)
        argv.append(target)
        return argv

    @staticmethod
    def _bounded(value: int, ceiling: int) -> int:
        return max(1, min(ceiling, int(value)))

    def parse(self, command: CommandResult) -> tuple[WhatwebResult, ...]:
        results = tuple(parse_whatweb_brief(command.stdout))
        if results:
            return results
        if command.returncode != 0:
            raise ToolExecutionError(
                f"whatweb exited with rc {command.returncode} and returned no "
                "fingerprint, so the run could not be interpreted: "
                f"{(command.stderr or command.stdout).strip().splitlines()[:1]}"
            )
        if command.stdout.strip():
            raise ToolExecutionError(
                "whatweb produced output but no fingerprint line could be read; "
                "output is not whatweb's brief format"
            )
        # whatweb says nothing and exits 0 when the target does not answer. That
        # is a result: no fingerprint because nothing was served, not a failure
        # of the run and not evidence of a healthy service.
        return results

    def summarize(self, parsed: Any) -> dict[str, Any]:
        if not isinstance(parsed, tuple) or not parsed:
            return {"fingerprints": 0}
        first = parsed[0]
        return {
            "fingerprints": len(parsed),
            "targets": [result.target for result in parsed][:10],
            "status_codes": sorted({result.status_code for result in parsed}),
            "titles": sorted({result.title for result in parsed if result.title})[:10],
            "webservers": sorted(
                {result.webserver for result in parsed if result.webserver}
            )[:10],
            "technologies": sorted(
                {name for result in parsed for name in result.technologies}
            )[:25],
            "addresses": sorted(
                {address for result in parsed for address in result.addresses}
            )[:10],
            "first_title": first.title,
        }


def scan(target: str, context: ToolContext, **options: Any) -> ToolResult:
    """Convenience wrapper: ``scan("https://example.com/", context)``."""
    return WhatwebAdapter().run(target, context, **options)
