"""Tool adapters.

An adapter is the only place a scan is allowed to touch a target. It is
responsible for the full chain, in order: scope decision, authorization (held
by the scan), action-guard class, human approval where required, rate limit and
concurrency, audit record, then process execution — and parsing afterwards.

Nothing in this package trusts the model. The planner asks for a capability and
a target; the adapter decides whether either is permitted.
"""

from tools.base import ToolAdapter, ToolContext, ToolResult
from tools.httpx import HttpxAdapter
from tools.nmap import NmapAdapter
from tools.nuclei import NucleiAdapter
from tools.parsers import (
    SEVERITIES,
    HttpxResult,
    NucleiFinding,
    NmapHost,
    NmapScan,
    Service,
    extract_host,
    parse_httpx_jsonl,
    parse_nmap_xml,
    parse_nuclei_jsonl,
)
from tools.runner import (
    ALLOWED_ENV,
    DEFAULT_OUTPUT_CAP,
    TIMEOUT_RETURNCODE,
    CommandResult,
    LocalSubprocessRunner,
    ToolRunner,
)
from tools.social_engineering import (
    CredentialFinding,
    CredentialScannerAdapter,
    PhishingIndicator,
    PhishingSimulationAdapter,
    scan_credentials,
    simulate_phishing,
)

__all__ = [
    "ALLOWED_ENV",
    "DEFAULT_OUTPUT_CAP",
    "SEVERITIES",
    "TIMEOUT_RETURNCODE",
    "CommandResult",
    "HttpxAdapter",
    "HttpxResult",
    "LocalSubprocessRunner",
    "NmapAdapter",
    "NmapHost",
    "NmapScan",
    "NucleiAdapter",
    "NucleiFinding",
    "Service",
    "ToolAdapter",
    "ToolContext",
    "ToolResult",
    "ToolRunner",
    "extract_host",
    "parse_httpx_jsonl",
    "parse_nmap_xml",
    "parse_nuclei_jsonl",
]
