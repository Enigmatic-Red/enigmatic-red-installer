"""git adapter: read a repository, and publish from a directory you nominated.

Three operations, and the distance between them is the point:

* ``ls_remote`` - which branches exist and at which commit. One request, no
  checkout, nothing written;
* ``clone`` - a shallow, single-branch checkout of an *in-scope* repository
  into a private temporary directory, so a run can read the source instead of
  guessing about it. Nothing leaves this machine, and the copy is evidence;
* ``push`` - publishes commits from a checkout the **operator** nominated
  (``SAFETY_WRITE_ROOT``) into an in-scope repository. It needs a human
  approval of its exact command line, and the guard hard-denies force-push and
  reference deletion whatever the approval says.

Three properties are enforced here rather than trusted:

1. **The remote is built from the scope-validated target.** :func:`_remote_url`
   turns ``host/owner/name`` into a URL itself, so a model cannot name a remote
   of its own - and there is no ``--upload-pack``, ``--exec`` or
   ``core.sshCommand`` through which to run something else.
2. **A credential travels in the environment, never on the command line.**
   Every run's argv is written into the append-only audit log, where a token
   could never be removed afterwards, so the token is passed as ``GIT_CONFIG_*``
   (the mechanism CI uses) to exactly one child process.
3. **Writes are rooted.** ``push`` refuses to run unless ``SAFETY_WRITE_ROOT``
   names a directory and the checkout it is given is inside it, so write
   capabilities do not exist until an operator says which checkout they read.

``file://`` and ``ext::`` transports are disabled outright: a clone must not be
able to read this machine's filesystem through git's own plumbing.
"""

from __future__ import annotations

import base64
import hashlib
import re
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from config.settings import get_settings
from safety.errors import ToolExecutionError
from tools.base import ToolAdapter, ToolContext, ToolResult
from tools.runner import CommandResult

__all__ = [
    "GitAdapter",
    "GitCheckout",
    "GitRef",
    "PushReceipt",
    "clone",
    "ls_remote",
    "push",
]

#: Only a repository on a host this product knows how to name. The URL is built
#: from these captures, never taken from the model as an arbitrary string.
_REMOTE = re.compile(
    r"^(?:[a-z][a-z0-9+.-]*://)?(?:[^@/]+@)?"
    r"(?P<host>github\.com|gitlab\.com|codeberg\.org|bitbucket\.org)/"
    r"(?P<owner>[A-Za-z0-9][A-Za-z0-9._-]*)/"
    r"(?P<name>[A-Za-z0-9][A-Za-z0-9._-]*?)(?:\.git)?/?$"
)

#: A branch name git itself would accept, minus the spellings that mean
#: something else to it. A leading dash is impossible by the pattern.
_BRANCH = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._/-]*$")
_BRANCH_FORBIDDEN = ("..", "@{", "//", "\\", "^", "~", ":", "?", "*", "[")

#: Shallow depth is capped: a scan may look at a repository, not mirror it.
DEPTH_CEILING = 50
#: Entries counted in a checkout before the count stops being worth the walk.
FILES_CEILING = 20_000


@dataclass(frozen=True)
class GitRef:
    """One branch as ``git ls-remote --heads`` reports it."""

    ref: str
    sha: str

    @property
    def branch(self) -> str:
        return self.ref.removeprefix("refs/heads/")


@dataclass(frozen=True)
class GitCheckout:
    """A shallow copy on this machine. A path, and nothing that left it."""

    path: str
    revision: str = ""
    files: int = 0
    bytes: int = 0


@dataclass(frozen=True)
class PushReceipt:
    """What ``git push --porcelain`` reported: one line per reference."""

    remote: str
    refs: tuple[str, ...] = ()

    @property
    def ok(self) -> bool:
        return bool(self.refs) and not any(
            line.startswith(("!", "-")) for line in self.refs
        )


def _remote_url(target: str) -> str:
    """``github.com/acme/app`` -> ``https://github.com/acme/app``."""
    match = _REMOTE.match(str(target or "").strip())
    if match is None:
        raise ValueError(
            f"{target!r} is not a repository on a host this product can name "
            f"(github.com, gitlab.com, codeberg.org, bitbucket.org). Give it as "
            f"github.com/owner/name"
        )
    return f"https://{match['host']}/{match['owner']}/{match['name']}"


def _branch(value: Any) -> str:
    text = str(value or "").strip()
    if not text:
        raise ValueError("a push needs the branch it publishes to")
    if not _BRANCH.match(text) or any(part in text for part in _BRANCH_FORBIDDEN):
        raise ValueError(f"refusing an unparseable branch name: {value!r}")
    return text


def _scratch_path(target: str) -> Path:
    """A deterministic destination, so pre-flight and run agree on one argv.

    A random directory would make the command a human approves different from
    the command that runs, which is exactly what the approval is for.
    """
    digest = hashlib.sha256(str(target or "").encode("utf-8")).hexdigest()[:12]
    return Path(tempfile.gettempdir()) / f"red-clone-{digest}"


def _write_root(source: Any) -> Path:
    """Validate the checkout a ``push`` reads from, under ``SAFETY_WRITE_ROOT``.

    Raises :class:`ToolExecutionError` when no root is configured, which the
    adapter contract reports as a *skipped* capability with the reason - the
    same treatment a scanner that is not installed gets, and for the same
    reason: an install that cannot do this should say so, not fail the scan.
    """
    root = str(get_settings().safety_write_root or "").strip()
    if not root:
        raise ToolExecutionError(
            "this install publishes nothing from a local directory: no "
            "SAFETY_WRITE_ROOT is set, so 'push' has no checkout to read. Set it "
            "to the repository you want this capability to publish from."
        )
    if not str(source or "").strip():
        raise ToolExecutionError("a push needs the checkout it publishes from")
    path = Path(str(source)).expanduser()
    if not path.is_absolute():
        raise ToolExecutionError(f"refusing a relative checkout path: {source!r}")
    resolved = path.resolve()
    root_resolved = Path(root).expanduser().resolve()
    if resolved != root_resolved and root_resolved not in resolved.parents:
        raise ToolExecutionError(
            f"refusing to publish from {resolved}: a push may only read a "
            f"checkout inside SAFETY_WRITE_ROOT ({root_resolved})"
        )
    if not (resolved / ".git").exists():
        raise ToolExecutionError(f"{resolved} is not a git checkout")
    return resolved


def _git_env() -> dict[str, str]:
    """The environment one git child gets: no prompt, and a token if we have one.

    ``http.extraheader`` through ``GIT_CONFIG_*`` is how this is normally done in
    CI, and it is used here because it keeps the credential off the command line
    and out of ``.git/config`` on this disk.
    """
    env = {"GIT_TERMINAL_PROMPT": "0"}
    token = get_settings().github_token
    if token:
        basic = base64.b64encode(
            f"x-access-token:{token}".encode("utf-8")
        ).decode("ascii")
        env.update(
            {
                "GIT_CONFIG_COUNT": "1",
                "GIT_CONFIG_KEY_0": "http.extraheader",
                "GIT_CONFIG_VALUE_0": f"Authorization: Basic {basic}",
            }
        )
    return env


class GitAdapter(ToolAdapter):
    """git, with an argv assembled from a closed set of validated values."""

    name = "git"

    #: Always set, and not configurable: no ``ext::`` (which is a command), no
    #: ``file://`` (which is this machine's disk), and no interactive prompt
    #: that would leave a scan waiting for a password nobody can type.
    SAFETY: tuple[str, ...] = (
        "-c",
        "protocol.ext.allow=never",
        "-c",
        "protocol.file.allow=never",
        "-c",
        "credential.interactive=false",
    )

    # -------------------------------------------------------------- to build
    def build_argv(self, target: str, **options: Any) -> list[str]:
        url = _remote_url(target)
        operation = str(options.get("operation") or "ls_remote").strip().lower()
        argv = ["git", *self.SAFETY]

        if operation == "ls_remote":
            return argv + ["ls-remote", "--heads", url]

        if operation == "clone":
            depth = max(1, min(DEPTH_CEILING, int(options.get("depth") or 1)))
            destination = _scratch_path(target)
            if destination.exists():
                raise ValueError(
                    f"{destination} already holds a checkout of {url} from this "
                    f"session; read that one rather than cloning it twice"
                )
            return argv + [
                "clone",
                "--depth",
                str(depth),
                "--no-tags",
                "--single-branch",
                "--quiet",
                url,
                str(destination),
            ]

        if operation == "push":
            # The checkout a push reads is the child's *working directory*, not
            # a word in the command line: the approval a human grants is for the
            # remote, the refspec and nothing else, and the local path never
            # becomes part of an audited argv.
            refspec = f"HEAD:refs/heads/{_branch(options.get('remote_branch'))}"
            return argv + ["push", "--porcelain", url, refspec]

        raise ValueError(
            f"{operation!r} is not a git operation this adapter performs: "
            f"ls_remote, clone or push"
        )

    def run_options(
        self, target: str, context: ToolContext, **options: Any
    ) -> dict[str, Any]:
        """A push reads a nominated checkout and gets the credential; a read does not."""
        if str(options.get("operation") or "ls_remote").strip().lower() != "push":
            return {}
        return {"cwd": _write_root(options.get("source_path")), "env": _git_env()}

    # ---------------------------------------------------------------- parse
    def parse(self, command: CommandResult) -> Any:
        argv = list(command.argv)
        if "ls-remote" in argv:
            return self._parse_refs(command)
        if "clone" in argv:
            return self._parse_clone(command)
        if "push" in argv:
            return self._parse_push(command)
        raise ToolExecutionError(f"cannot tell what {argv[:4]} asked git to do")

    @staticmethod
    def _failed(command: CommandResult, doing: str) -> ToolExecutionError:
        detail = (command.stderr or command.stdout or "").strip().splitlines()
        hint = f": {detail[-1][:200]}" if detail else ""
        return ToolExecutionError(f"git could not {doing} (rc {command.returncode}){hint}")

    def _parse_refs(self, command: CommandResult) -> tuple[GitRef, ...]:
        if command.returncode != 0:
            raise self._failed(command, "list the branches")
        refs: list[GitRef] = []
        for line in command.stdout.splitlines():
            sha, _, ref = line.strip().partition("\t")
            if ref.startswith("refs/heads/") and sha:
                refs.append(GitRef(ref=ref, sha=sha))
        if not refs and command.stdout.strip():
            raise ToolExecutionError(
                f"git ls-remote answered with {len(command.stdout.splitlines())} "
                f"line(s) that are not branch references"
            )
        return tuple(refs)

    def _parse_clone(self, command: CommandResult) -> GitCheckout:
        if command.returncode != 0:
            raise self._failed(command, "clone the repository")
        path = Path(command.argv[-1])
        revision, files, total = "", 0, 0
        head = path / ".git" / "HEAD"
        if head.exists():
            revision = head.read_text(encoding="utf-8", errors="replace").strip()
        for entry in path.rglob("*"):
            if entry.is_file():
                files += 1
                total += entry.stat().st_size
                if files >= FILES_CEILING:
                    break
        return GitCheckout(path=str(path), revision=revision, files=files, bytes=total)

    def _parse_push(self, command: CommandResult) -> PushReceipt:
        if command.returncode != 0:
            raise self._failed(command, "push")
        remote = ""
        refs: list[str] = []
        for line in command.stdout.splitlines():
            if not line:
                continue
            if line.startswith("To "):
                remote = line[3:].strip()
            else:
                refs.append(line.strip())
        return PushReceipt(remote=remote, refs=tuple(refs))

    # ------------------------------------------------------------- summarize
    def summarize(self, parsed: Any) -> dict[str, Any]:
        if isinstance(parsed, tuple):
            return {
                "branches": [item.branch for item in parsed][:25],
                "branch_count": len(parsed),
            }
        if isinstance(parsed, GitCheckout):
            return {
                "checkout_files": parsed.files,
                "checkout_bytes": parsed.bytes,
                "checkout_revision": parsed.revision,
            }
        if isinstance(parsed, PushReceipt):
            return {"push_remote": parsed.remote, "push_refs": list(parsed.refs)[:25]}
        return {}


def ls_remote(target: str, context: ToolContext, **options: Any) -> ToolResult:
    """List the branches of an in-scope repository."""
    return GitAdapter().run(target, context, operation="ls_remote", **options)


def clone(target: str, context: ToolContext, **options: Any) -> ToolResult:
    """Shallow-clone an in-scope repository into a private temporary directory."""
    return GitAdapter().run(target, context, operation="clone", **options)


def push(target: str, context: ToolContext, **options: Any) -> ToolResult:
    """Publish a nominated checkout's HEAD to a branch of an in-scope repository."""
    return GitAdapter().run(target, context, operation="push", **options)
